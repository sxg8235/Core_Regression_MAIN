package com.homer.glue;

import org.openqa.selenium.By;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class PaypalPageStepDefn extends BaseStepDefn {
	
	
static final By editAddress = By.linkText("edit this address");

	public PaypalPageStepDefn(DataClass data) {
		super(data);
		
	}
	

	@Then("^I see paypal page$")
	public void i_see_paypal_page() throws Throwable { 
		paypal.verifyPayPalPgDisplayed();	  
	}
	
	@And("^I click cancel and return option$")
	public void i_click_cancel_and_return_option() throws Throwable { 
		paypal.clickCancelAndReturn();
	}
	
	@And("^I see the delivery charges applied in paypal order summary$")
	public void i_see_the_delivery_charges_applied_for_appliance() throws Throwable { 
		paypal.verifyDeliveryChargeInPaypalRightRail();
	}
	
	@When("^I enter paypal details and continue$")
	public void i_enter_paypal_details_and_continue() throws Throwable { 
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.payPalLogin();
		paypal.clickPayNowPaypal();
		}
	}
	
	@Then("^I see paypal order review page$")
	public void i_see_paypal_order_review_page() throws Throwable { 
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypalreview.verifyPaypalOrderReviewPage();	
		}
	}

	@Then("^I enter delivery details and submit order$")
	public void i_enter_delivery_details_and_submit_order() throws Throwable { 
		applianceDelivery.enterDeliveryAddress();
		applianceDelivery.selectDeliveryDate();
		paypalreview.submitOrderPaypal(); 
	}
	
	@And("^I click submit order paypal$")
	public void i_click_submit_order_paypal() throws Throwable { 
		paypalreview.submitOrderPaypal();	  
	}
	
	@And("^UnitPrice displayed in paypal order summary is equivalent to the price in Cassandra DB$")
	public void unitPrice_displayed_in_paypal_order_summary_is_equivalent_to_the_price_in_Cassandra_DB()
			throws Throwable {
		paypal.verifyUnitPriceOrderSummary();
	}
	
	@And("^I enter PayPalLogin with New address$")
	public void I_enter_PayPalLogin_with_New_address() throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.payPalLogin();
		paypal.enterPaypalContactPhoneno();
		Thread.sleep(10000);
		paypal.clickChangeAddrPpal();
		paypal.clickAddNewAddrPayPal();
		paypal.addNewAddrPPal();
		paypal.clickSavePPal();
		Thread.sleep(7000);
		paypal.clickPayNowPaypal();
		}
		
	}
	
	@And("^I click edit address$")
	public void I_click_edit_address() throws Throwable { 
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment() && (wh.isElementNotPresent(editAddress))) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.clickEditThisAddress();	
		}
		
	}
	
	
	@And("^I click update button$")
	public void I_click_update_button() throws Throwable { 
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.clickUpdateBtn();	
		}
		
	}
	
	@Then("^I see Custom blind item image and base attributes will not be displayed$")
	public void i_see_custom_blind_item_image_and_attributes_will_not_be_displayed() throws InterruptedException
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.verifyCustomBlindProductsNotPresentInPPalExp();
		}
	}
	
	@Then("^I see STHPOD item details$")
	public void i_see_STHPOD_item_details() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.verifySTHPODItemDetails();
		}
	}
	
	@Then("^I see STSPOD item details$")
	public void i_see_STSPOD_item_details() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		paypal.verifySTSPODItemDetails();
		}
	}
	
    
	
	///***************Instant Rebate*****************////

    @And("^I enter PayPalLogin with New IR address$")
    public void I_enter_PayPalLogin_with_New_IR_address() throws Throwable {
           wh.waitForPageLoaded();
           if (rc.isProdEnvironment()) {

                  report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
                               StepResult.WARNING);

           } else {
           paypal.payPalLogin();
           paypal.enterPaypalContactPhoneno();
           Thread.sleep(10000);
           paypal.clickChangeAddrPpal();
           paypal.clickAddNewAddrPayPal();
           paypal.addNewAddrPPalIR();
           paypal.clickSavePPal();
           Thread.sleep(7000);
           paypal.clickPayNowPaypal();
           }

    }
    
    @When("^I edit address in order review page$")
    public void i_edit_address_in_order_review_page() throws Throwable { 
    	paypalreview.clickEditThisAddress();
    	paypalreview.EditAddressOverlay();
    	paypalreview.verifyPaypalOrderReviewPage();	
      
    }
    
    @When("^I add address in order review page$")
    public void i_add_address_in_order_review_page() throws Throwable { 
    	paypalreview.clickaddNewAddress();
    	paypalreview.NewAddressOverlay();
    	paypalreview.verifyPaypalOrderReviewPage();	
      
    }
    @And("^I check price and store promotion in order review page$")
    public void i_check_price_and_store_promotion_in_order_review_page() throws Throwable { 
    	paypalreview.getpricedetails(database);
    }
    @Then("^I verify IR message in paypal order review$")
    public void i_verify_IR_message_in_paypal_order_review() throws Throwable { 
    	paypalreview.verifyIRmessage();
    }

    ///***************Instant Rebate*****************////

	
    @And("^I enter invalid PoBox in PayPalOrderReview$")
	public void i_enter_invalid_PoBox_in_PayPalOrderReview() throws Throwable {
    	paypalreview.enterInvalidPoBoxInPPOrderReview();
	}

	@And("^I enter first name with spl char in order review pg$")
	public void i_enter_first_name_with_spl_char_in_order_review_pg() throws Throwable {
		paypalreview.verifyFNErrorSplChar();
	}

	@And("^I enter first name with spl char and space in order review pg$")
	public void i_enter_first_name_with_spl_char_and_space_in_order_review_pg() throws Throwable {
		paypalreview.verifyFNErrorSplCharwithSpaces();
	}

}
