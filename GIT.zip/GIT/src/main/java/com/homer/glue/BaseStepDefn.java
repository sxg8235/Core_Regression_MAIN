package com.homer.glue;

import org.openqa.selenium.WebDriver;

import com.homer.dao.CheckoutConfig;
import com.homer.dao.CommonData;
import com.homer.dao.DataClass;
import com.homer.dao.InstanceContainer;
import com.homer.helper.DataTable;
import com.homer.po.ATCOverlay;
import com.homer.po.ApplianceDeliveryPage;
import com.homer.po.ApplianceOverlay;
import com.homer.po.BSSOverlay;
import com.homer.po.Blinds_61889;
import com.homer.po.CheckoutSignInPage;
import com.homer.po.CsrPage;
import com.homer.po.DBConnection;
import com.homer.po.DataBase;
import com.homer.po.EmailPage;
import com.homer.po.GiftCardPage;
import com.homer.po.HomePage;
import com.homer.po.MyAccountPage;
import com.homer.po.MyListOverlay;
import com.homer.po.PCPPage;
import com.homer.po.PIPPage;
import com.homer.po.PLPPage;
import com.homer.po.PaymentPage;
import com.homer.po.PaypalOrderReviewPage;
import com.homer.po.PaypalPage;
import com.homer.po.PickupOptionPage;
import com.homer.po.ScheduleDeliveryPage;
import com.homer.po.ShippingPage;
import com.homer.po.ShoppingCartPage;
import com.homer.po.SingleCheckoutPage;
import com.homer.po.ThankYouPage;
import com.homer.reports.Report;
import com.homer.resuablecomponents.ReusableComponents;
import com.homer.resuablecomponents.WebDriverHelper;

public class BaseStepDefn {
	
	protected Report report;
	protected DataTable dataTable;
	
	protected WebDriverHelper wh;
	protected DataClass ih;
	
	protected WebDriver driver;
	protected ReusableComponents rc;
	protected InstanceContainer ic;
	
	protected HomePage homePage;
	protected PLPPage plpPage;
	protected PIPPage pipPage;
	protected ShoppingCartPage shoppingCartPage;
	protected CheckoutSignInPage checkoutSignInPage;
	protected ShippingPage shippingPage;
	protected PaymentPage paymentPage;
	protected ThankYouPage thankYouPage;
	protected MyListOverlay myListOverlay;
	protected ApplianceDeliveryPage applianceDelivery;
	protected PickupOptionPage pickupPage;
	protected PaypalPage paypal;
	protected PaypalOrderReviewPage paypalreview;
	protected MyAccountPage myAccountPage;
	protected ScheduleDeliveryPage scheduleDeliveryPage;
	protected SingleCheckoutPage signInSection;
	protected SingleCheckoutPage pickUpOptionSection;
	protected SingleCheckoutPage paymentSection;
	protected SingleCheckoutPage billingSection;
	protected CsrPage csrPage;
	protected DataBase database;
	protected PCPPage pcppage;
	protected EmailPage emailPage;
	protected ATCOverlay atcOverlay;
	protected ApplianceOverlay applianceOverlay;
	protected DBConnection dbConnection;
	protected BSSOverlay bssOverlay;
	protected GiftCardPage giftcardpage;
	protected Blinds_61889 blindsDefect;
	CheckoutConfig checkoutConfig = new CheckoutConfig();
	
	CommonData commonData;	
	
	public BaseStepDefn(DataClass data) {
		
		this.ih = data;
		this.driver = data.driver;
		this.report = data.report;
		this.dataTable = data.dataTable;		
		this.commonData = (CommonData)data.commonData;

		wh = new WebDriverHelper(driver, report, dataTable);
		rc = new ReusableComponents(driver, report, wh, dataTable);
		
		ic = new InstanceContainer(driver, report,dataTable, wh, rc,commonData);
		
		homePage = new HomePage(ic);
		plpPage = new PLPPage(ic);
		pipPage = new PIPPage(ic);
		paymentPage = new PaymentPage(ic);
		shoppingCartPage = new ShoppingCartPage(ic);
		csrPage=new CsrPage(ic);
		checkoutSignInPage = new CheckoutSignInPage(ic);
		giftcardpage = new GiftCardPage(ic);
		shippingPage = new ShippingPage(ic);
		thankYouPage = new ThankYouPage(ic);
		myListOverlay = new MyListOverlay(ic);
		applianceDelivery = new ApplianceDeliveryPage(ic);
		pickupPage = new PickupOptionPage(ic);
		paypal = new PaypalPage(ic);
		paypalreview = new PaypalOrderReviewPage(ic);
		myAccountPage = new MyAccountPage(ic);
		scheduleDeliveryPage = new ScheduleDeliveryPage(ic);
		signInSection=new SingleCheckoutPage(ic);
		pickUpOptionSection=new SingleCheckoutPage(ic);
		paymentSection= new SingleCheckoutPage(ic);
		billingSection=new SingleCheckoutPage(ic);
		
		database = new DataBase(ic);
		pcppage = new PCPPage(ic);
		emailPage = new EmailPage(ic);
		atcOverlay = new ATCOverlay(ic);
		applianceOverlay = new ApplianceOverlay(ic);
		dbConnection = new DBConnection(ic);
		bssOverlay = new BSSOverlay(ic);
		blindsDefect= new Blinds_61889(ic);
	}


}
