package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;

public class GiftCardStepDefn extends BaseStepDefn {

	
	public GiftCardStepDefn(DataClass ih) {
		super(ih);
	}

	
	@And("^I see gift card page$")
	public void i_see_gift_card_page() throws Throwable {
		giftcardpage.verifyGCPage();

	}
	
	
	@And("^I verify shopGC and Balance check section$")
	public void i_verify_shopGC_and_Balance_check_section() throws Throwable {
		giftcardpage.verifySections();

	}

	@And("^I click check gift card balance link$")
	public void i_click_check_gift_card_balance_link() throws Throwable {
		giftcardpage.clickCheckBalanceLink();

	}
	
	@When("^I enter gift card and check balance$")
	public void i_enter_gift_card_and_check_balance() throws Throwable {
		giftcardpage.enterGiftCardAndCheckBalance();

	}
	
	@When("^I verify gift card error$")
	public void i_verify_gift_card_error() throws Throwable {
		giftcardpage.verifyGCError();

	}

}
