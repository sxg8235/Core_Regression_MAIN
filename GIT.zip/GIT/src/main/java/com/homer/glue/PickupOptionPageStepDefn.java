package com.homer.glue;

import org.openqa.selenium.By;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class PickupOptionPageStepDefn extends BaseStepDefn {
	
	public PickupOptionPageStepDefn(DataClass data) {
		super(data);
	}
	
	@Then("^I see pickup option page$")
	public void i_see_pickup_option_page() throws Throwable { 
		pickupPage.verifyPickupOptionPage();  
		pickupPage.verifyAndCloseSaveTripOverlay();
	}
	
	@And("^I verify and close the save trip overlay$")
	public void i_verify_and_close_the_save_trip_overlay() throws Throwable { 
		pickupPage.verifyAndCloseSaveTripOverlay();	  
	}
	
	@And("^I see price details in pickup option page$")
	public void i_see_price_details_in_pickup_option_page() throws Throwable { 
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();  
	}
	
	@And("^I See both sku added to same store$")
	public void I_See_both_sku_added_to_same_store() throws Throwable { 
		pickupPage.verifyBothSkuAddedToSameStore();
	}
	
	@And("^I verify Pickup options$")
	public void i_verify_pickup_options() throws Exception
	{
		pickupPage.verifyPickUpOptionLocations();
	}
	
	@And("^I choose a pickup date and time$")
	public void I_choose_a_pickup_date_and_time() throws Exception
	{
		pickupPage.choosePickupDateAndTimeAndVerify();
	 
	}
	
	@And("^I verify all details in pickup option page$")
	public void i_verify_all_details_in_pickup_option_page() throws Throwable {
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();
		pickupPage.verifyPickUpOptionLocations();
		pickupPage.choosePickupDateAndTimeAndVerify();
		pickupPage.verifyTotalPickUpOptionsPage();
		pickupPage.verifyPickUpText();
		pickupPage.verifyContinueAndBackBtn();
		pickupPage.verifyChooseInStorePickUp();
		pickupPage.verifyChooseAnotherPersonDetailsSaved();
		pickupPage.verifyMobileNumberAutoFormat();
		pickupPage.verifyImageInRightRail();
		pickupPage.verifyAddressPickUpOptionsPg();
	}
	
	@And("^I verify save trip option$")
	public void I_verify_save_trip_option() throws Throwable {
		pickupPage.verifySaveTripOption();
	}
	
	@And("^I click choose another person overlay and enter details$")
	public void i_click_choose_another_person_overlay_and_enter_details() throws Throwable { 
		pickupPage.enterChooseAnotherPersonDetails();
	}

	@And("^I enter \"(.*?)\" in First name for pickup person$")
	public void i_enter_arg1_in_First_name_for_pickup_person(String arg1) throws Throwable { 
		pickupPage.enterValidSymbolsPickUpFirstName(arg1);
		pickupPage.clickSaveAnotherPersonDetails();
	}
	
	@And("^I enter invalid symbols in First name for pickup person$")
	public void i_enter_invalid_symbols_in_First_name_for_pickup_person() throws Throwable {
		pickupPage.enterInvalidSymbolsPickUpFirstName();
	}

	@And("^I enter \"(.*?)\" in Last name for pickup person$")
	public void i_enter_arg1_in_Last_name_for_pickup_person(String arg1) throws Throwable {
		pickupPage.enterValidSymbolsPickUpLastName(arg1);
	}

	@And("^I enter invalid symbols in Last name for pickup person$")
	public void i_enter_invalid_symbols_in_Last_name_for_pickup_person() throws Throwable {
		pickupPage.enterInvalidSymbolsPickUpLastName();
	}
	
	@Then("^I see Base attributes will be displayed in the pickup page for BOSS custom blinds item$")
	 public void i_see_Base_attributes_will_be_displayed_in_the_pickup_page_for_Boss_custom_blinds_item() throws Exception
	 {
		 shoppingCartPage.verifyCustomAttrSequence();
	 }
	
	@Then("^I see Should be able to see the custom blind item detail in the Ship To Store POD$")
	public void i_see_should_beable_to_see_the_custom_blind_item_detail_in_the_ship_to_store_pod() throws Exception
	{
		pickupPage.verifySTSPODItemDetails();
	}

	@When("^I click back button in the pickup page$")
	public void i_click_back_button_in_the_pickup_page() throws Throwable { 
		pickupPage.clickBackBtn();
	}
	
	@And("^I verify store present in PickUpOptions$")
	public void i_verify_store_present_in_PickUpOptions() throws Exception
	{
		pickupPage.verifyStorePresentInPickupPage();
	}
	
	@And("^I verify Estimated tax in PickUpOptions$")
	public void i_verify_Estimated_tax_in_PickUpOptions() throws Exception
	{
		pickupPage.verifyEstimatedSalesTaxPymtPg();
	}
	
	@And("^I verify price present in PickUpOptions$")
	public void i_verify_price_present_in_pickupoptions() throws InterruptedException
	{
		pickupPage.verifyPriceInPickupPage();
	}
	
	@Then("I enter invalid phone num and verify error message")
	public void i_enter_invalid_phone_num_and_verify_error_message() throws Exception
	{
		pickupPage.verifyInvalidPhoneNumberErrorInPickup();
	}
	

    @Then("^I click choose another person overlay and verify error message without entering FN and LN$")
	public void i_click_choose_another_person_overlay_and_verify_erro_message_without_entering_FN_and_LN() throws Exception
	{
		pickupPage.clickChooseAnotherPersonDetails();
		pickupPage.clickSaveAnotherPersonDetails();
		pickupPage.verifyErrorMsgInChooseAnotPersonOverlay();
	}
    
    @And("^I click save button in Change Pick Up Person Overlay$")
    public void i_click_save_button_in_Change_pick_up_person_overlay() throws Exception
    {
    	pickupPage.clickSaveAnotherPersonDetails();
    }
    
    @Then("^I verify that dates are not blackouts dates$")
    public void i_verify_the_dates_are_not_blackouts_dates() throws Exception
    {
    	pickupPage.verifyPickUpDateTimeNotPresent();
    }
    
	//***************** Instant Rebates************************///
	
	
	@And("^I select a store from save trip overlay$")
    public void i_select_a_store_from_save_trip_overlay() throws Throwable {
		pickupPage.clickpickupstores();
             
	}
	
	@And("^I check price and store promotion in pickup options page$")
	public void i_check_price_and_store_promotion_in_pickup_options_page() throws Throwable {

			pickupPage.getpricedetails(database);
		
	}
	
	@And("^I verify IR message in pickup options page$")
	public void i_verify_IR_message_in_pickup_options_page() throws Throwable {

		pickupPage.verifyIRmessage();
	}
	
	//***************** End of Instant Rebates************************///
	
	@And("^I verify pick up options page$")
	public void i_verify_pick_up_options_page() throws Throwable { 
		
		pickupPage.verifyPickUpOptionsContiner();
	}
	
	@And("^I click continue button in pick up options page$")
	public void i_click_continue_button_in_pick_up_options_page() throws Throwable { 
		pickupPage.clickRightRailContinueBtn();
	}
	
	
	@And("^I click submitorder button in pick up options page$")
	public void i_click_submitorder_button_in_pick_up_options_page() throws Throwable { 
		
		 if (rc.isProdEnvironment()) 
				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
						"We do not place Orders on Production", StepResult.WARNING);
		else
			pickupPage.clickrigtRailSubmitOrderBtn();
	}
	
	@And("^I verify mixedcart grouped together in single store$")
	public void i_verify_mixedcart_grouped_together_in_single_store() throws Throwable { 
		pickupPage.verifyBossBopisGrpToGthrForSameStr();
	}
	
	@And("^I click Cart link in progress bar$")
	public void i_click_Cart_link_in_progress_bar() throws Throwable {
		pickupPage.clickCartLinkinProgressBar();
	}

	@And("^I verify a message in Choose a pickup time section$")
	public void i_verify_a_message_in_Choose_a_pickup_time_section() throws Throwable {

		pickupPage.msgChoosePupSection();
	}

	@And("^I verify selected pickup date and time$")
	public void I_verify_selected_pickup_date_and_time() throws Exception {
		pickupPage.verifySelectedtimeanddate();

	}

	@And("^I change pickup instore location$")
	public void I_change_pickup_instore_location() throws Exception {
		pickupPage.changePickupInstoreLocation();

	}

	@And("^I select a store and click update in save trip overlay in PUOP$")
	public void i_select_a_store_and_click_update_in_save_trip_overlay_in_PUOP() throws Throwable {
		pickupPage.verifyPickupOptionPage();
		pickupPage.verifyAndSelectStoreSaveTripOverlay();

	}

	@And("^I verify store details in PUOP after save trip update$")
	public void i_verify_store_details_in_PUOP_after_save_trip_update() throws Throwable {
		pickupPage.verifyStoreDetailsAfterSaveTripUpdate();

	}

	@And("^I verify store details in PUOP when No Thanks option selected$")
	public void I_verify_store_details_in_PUOP_when_No_Thanks_option_selected() throws Throwable {
		pickupPage.verifyStoreDetailsAfterNoThanksSelected();

	}

	@And("^I enter invalid email for pickup person$")
	public void i_enter_invalid_email_for_pickup_person() throws Throwable {
		pickupPage.clickChooseAnotherPersonDetails();
		pickupPage.enterInvalidPickupEmail();
	}

	@And("^I edit selected pickup date and time$")
	public void i_edit_selected_pickup_date_and_time() throws Exception {
		pickupPage.editPickupDateAndTimeAndVerify();
	}
	
	@And("^I Verify in Pick up options screen \"(.*?)\" text is displayed by default$")
	public void i_verify_in_pickupoptions_arg1screen_etxt_is_displayed_by_default(String arg1) throws Exception
	{
		pickupPage.verifyIwillPickUpItemtext(arg1);		
	}
	
	@And("^I Verify the Date and Time field are not editable$")
	public void i_verify_the_Date_and_Time_field_are_not_editable()
	{
		pickupPage.verifyPickUpDateTimeDropDown();
	}
	
	@And("^I get currently selected pickup date and time from PickUpOptions Page$")
	public void i_get_currently_selected_pickup_date_and_time_from_pickupoption_page()
	{
		pickupPage.getCurrentPickUpDatesTwoStores();
	}

	@And("^I verify mobile number is auto formatted$")
	public void i_verify_mobile_number_is_auto_formatted() throws Throwable {
		pickupPage.verifyMobileNumberAutoFormat();
	}
	
	@Then("^I verify pricing in RR in Pickup options page$")
	public void i_verify_pricing_in_RR_in_Pickup_options_page() throws Throwable { 
		pickupPage.verifyRRPricePPOP();
	}
	
	@Then("^I verify that the details of item added to cart is displayed in rightrail POD$")
	public void i_verify_that_the_details_of_item_added_to_cart_is_displayed_in_rightrail_POD() throws Exception
	{
		pickupPage.verifyPodValueinPickUp();
	}
}
