package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.CommonData;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;

public class ScheduleDeliveryPageStepDefn extends BaseStepDefn {
	
	public ScheduleDeliveryPageStepDefn(DataClass data) {
		super(data);
	}
	

	@Then("^I see bodfs schedule delivery page$")
	public void i_see_bodfs_schedule_delivery_page() throws Throwable { 
		scheduleDeliveryPage.verifyScheduleDeliveryPage();
	}
	
	/*
	 * Added by Kxn8362
	 */
	@Then("^I see Express Delivery page$")
	public void i_see_Express_Delivery_page() throws Throwable { 
	 scheduleDeliveryPage.verifyScheduleDeliveryPage();
	  
	}

	
	@And("^I see system unavailable err msg$")
	public void i_see_system_unavailable_err_msg() throws Throwable {
		scheduleDeliveryPage.verifySystemUnavailErrMsg();
	}
	
	@And("^I see limited qty err msg$")
	public void i_see_limited_qty_err_msg() throws Throwable {
		scheduleDeliveryPage.verifyLimitQtyErrMsg();
	  
	}
	
	
	@When("^I click back button$")
	public void i_click_back_button() throws Throwable { 
		scheduleDeliveryPage.clickBackButton();
	}
	
	
	@When("^I enter max of (\\d+) char in special instruction field$")
	public void i_enter_max_of_255_char_in_special_inst_field() throws Throwable { 
		scheduleDeliveryPage.VerifyMaxCharEntryInSpecialInstField();			
	}
	
	@And("^I see user is allowed to enter only max of (\\d+) char in special instruction field$")
	public void i_see_user_is_allowed_to_enter_only_max_of_255_char_in_special_instruction_field() throws Throwable { 
		scheduleDeliveryPage.VerifyMaxCharEntryInSpecialInstField();
	}
	
	
	@Then("^I see user is allowed to enter only max of (\\d+) char$")
	public void i_see_user_is_allowed_to_enter_only_max_of_255_char() throws Throwable { 
		scheduleDeliveryPage.VerifyExceedingMaxCharLimitInSpecialInstField();
	  
	}

	@And("^I check for right rail express delivery text$")
	public void i_check_for_right_rail_express_delivery_text() throws Throwable {
		scheduleDeliveryPage.rightRailExpressDelTxt();
	}
	
	@And("^I enter details in Express delivery page$")
	public void i_enter_details_in_Express_delivery_page() throws Throwable { 
		scheduleDeliveryPage.enterScheduledDeliveryAddressMCC();
	}
	
	@When("^I click on calendar icon$")
	public void i_click_on_calendar_icon() throws Throwable { 
		scheduleDeliveryPage.clickCalendar();
	}
	
	@Then("^calendar modal will be opened$")
	public void calendar_modal_will_be_opened() throws Throwable { 
		scheduleDeliveryPage.VerifyCalendarOverlay();	  
	}
	
	@When("^I select \"(.*?)\" from Service level drop down$")
	public void i_select_arg1_from_Service_level_drop_down(String arg1) throws Throwable { 
	    commonData.serviceLevelToSelect=arg1;
	    scheduleDeliveryPage.selectServiceLevelCalendarOverlay();    
	}
	
	@And("^I click continue in calendar overlay$")
	public void i_click_continue_in_calendar_overlay() throws Throwable { 
		scheduleDeliveryPage.clickContinueCalenderOverlay();	  
	}
	
	@And("^I verify adult text \"(.*?)\" is displayed below the reservation details$")
	public void i_verify_adult_text_arg1_is_displayed_below_the_reservation_details(String arg1) throws Throwable { 
	 		commonData.adultText=arg1;
	 		scheduleDeliveryPage.verifyAdultTextScheduleDelivery();
	 		
	}
	
	@When("^I Enter PO BOX in address line (\\d+) or (\\d+)$")
	public void i_Enter_PO_BOX_in_address_line_1_or_2() throws Throwable { 
		scheduleDeliveryPage.EnterPOBoxInAddressLine();	 	  
	}
	
	@And("^I click continue button in Express Delivery page$")
	public void i_click_continue_button_in_Express_Delivery_page() throws Throwable { 	
		scheduleDeliveryPage.clickContinueScheduleDelivery();	  
	}

	@Then("^I See Orders cannot be shipped to PO Box error message to be displayed$")
	public void i_See_Orders_cannot_be_shipped_to_PO_Box_error_message_to_be_displayed() throws Throwable { 
		scheduleDeliveryPage.verifyPOBoxErrMsg();	  
	}
	
	@When("^I click on add new address link$")
	public void i_click_on_add_new_address_link() throws Throwable { 		
		scheduleDeliveryPage.clickAddNewAddrLink();	 
	}
	
	@Then("^I see Add Address Overlay with blank expanded form field to be displayed$")
	public void i_see_Add_Address_Overlay_with_blank_expanded_form_field_to_be_displayed() throws Throwable { 
		scheduleDeliveryPage.verifyAddAddressOverlay();  	  
	}
	
	@When("^I Enter first name and leave all the other fields blank and click save button$")
	public void i_Enter_first_name_and_leave_all_the_other_fields_blank_and_click_save_button() throws Throwable {  
		scheduleDeliveryPage.defaultAddressSectionNewAddOverlay();
		scheduleDeliveryPage.EnterFnameNewAddOverlay();	 
		scheduleDeliveryPage.clickSaveButtonNewAddOverlay();			
	}
	
	@Then("^I see error message for Last Name, Address(\\d+) and Phone$")
	public void i_see_error_message_for_Last_Name_Address1_and_Phone() throws Throwable { 	 
		scheduleDeliveryPage.verifyErrorMsgLNameAddress1Ph();
	}
	
	@When("^I Enter Last name and leave all the other fields blank and click save button$")
	public void i_Enter_Last_name_and_leave_all_the_other_fields_blank_and_click_save_button() throws Throwable { 
		scheduleDeliveryPage.defaultAddressSectionNewAddOverlay();
		scheduleDeliveryPage.EnterLnameNewAddOverlay();	 
		scheduleDeliveryPage.clickSaveButtonNewAddOverlay();		  
	}
	
	@Then("^I see error message for First Name, Address(\\d+) and Phone$")
	public void i_see_error_message_for_First_Name_Address1_and_Phone() throws Throwable { 
		scheduleDeliveryPage.verifyErrorMsgFNameAddress1Ph();	 
	}
	
	@When("^I Enter Address(\\d+) and leave all the other fields blank and click save button$")
	public void i_Enter_Address1_and_leave_all_the_other_fields_blank_and_click_save_button() throws Throwable { 
		scheduleDeliveryPage.defaultAddressSectionNewAddOverlay();
		scheduleDeliveryPage.EnterAdd1NewAddOverlay();	 
		scheduleDeliveryPage.clickSaveButtonNewAddOverlay();	  
	}
	
	@Then("^I see error message for First Name, Last name and Phone$")
	public void i_see_error_message_for_First_Name_Last_name_and_Phone() throws Throwable { 
		scheduleDeliveryPage.verifyErrorMsgFNameLNamePh();		  
	}
	
	@When("^I Enter Phone and leave all the other fields blank and click save button$")
	public void i_Enter_Phone_and_leave_all_the_other_fields_blank_and_click_save_button() throws Throwable { 
		scheduleDeliveryPage.defaultAddressSectionNewAddOverlay();
		scheduleDeliveryPage.EnterPhoneNewAddOverlay();	 
		scheduleDeliveryPage.clickSaveButtonNewAddOverlay();		  
	}

	@Then("^I see error message for First Name, Last name, and Address (\\d+)$")
	public void i_see_error_message_for_First_Name_Last_name_and_Address_1() throws Throwable { 
		scheduleDeliveryPage.verifyErrorMsgFNameLNameAdd1();		  
	}
	
	@Then("^I see the Schedule delivery page with Delivery Reservation text$")
	public void i_again_see_the_Schedule_delivery_page_with_Delivery_reservation_text() throws Throwable { 
		scheduleDeliveryPage.verifyScheduleDeliveryPage();
		scheduleDeliveryPage.verifyDeliveryReservationText(); 
	}
	
	@And("^I see Delivery Reservation text is retained$")
	public void i_see_Delivery_Reservation_text_is_retained() throws Throwable { 
		scheduleDeliveryPage.verifyDeliveryReservationText();  
	}
	
	@And("^I see price details in express delivery page$")
	public void i_see_price_details_in_express_delivery_page() throws Throwable {
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();

	}
	
	@When("^I select Yes radio button of Can this delivery be left unattended$")
	public void i_select_Yes_radio_button_of_Can_this_delivery_be_left_unattended() throws Throwable { 
		scheduleDeliveryPage.selectYESRadioButtonOfDeliveryUnattended(); 
	}
	
	@And("^I see delivery unattended text \"(.*?)\" to be present in the calender modal$")
	public void i_see_delivery_unattended_text_arg1_to_be_present_in_the_calender_modal(String arg1) throws Throwable { 
		scheduleDeliveryPage.verifyDeliveryUnattendedTextInOverlay();	  
	}
	
	@Then("^I see delivery calender modal is displayed with curbside service level as default$")
	public void i_see_delivery_calender_modal_is_displayed_with_curbside_service_level_as_default() throws Throwable {
		scheduleDeliveryPage.VerifyCalendarOverlay();	 
		scheduleDeliveryPage.verifyDefaultServiceLevelCalendarOverlay();
		scheduleDeliveryPage.verifyOutsideDeliveryDescription();
	}

	@And("^I click change zipcode link in express delivery page$")
	public void i_click_change_zipcode_link_in_express_delivery_page() throws Throwable {
		scheduleDeliveryPage.clickChangeDeliveryZipCode();
	}

	@And("^I verify outside delivery selected by default and service level description$")
	public void i_verify_outside_delivery_selected_by_default_and_service_level_description() throws Throwable {
		scheduleDeliveryPage.verifyOutsideDeliveryInPage();
	}
	
	@And("^I verify threshold delivery and service description in calendar$")
	public void i_verify_threshold_delivery_and_service_description_in_calendar() throws Throwable {
		scheduleDeliveryPage.verifyThresholdDeliveryInCalendar();
	}
	
	@And("^I verify the delivery price$")
	public void i_verify_the_delivery_price() throws Throwable {
		scheduleDeliveryPage.verifySameDeliveryPrice();
	}
	
	@And("^I verify Phone field is displayed below Last Name in express delivery page$")
	public void i_verify_Phone_field_is_displayed_below_Last_Name_in_express_delivery_page() throws Throwable { 
		scheduleDeliveryPage.verifyPhoneFieldMovedUp();
	}
	
	@When("^I click on edit this address link express delivery page$")
	public void i_click_on_edit_this_address_link_express_delivery_page() throws Throwable { 
		scheduleDeliveryPage.clickEditThisAddrLink();  
	}

	@Then("^I see Edit address overlay in express delivery page$")
	public void i_see_Edit_address_overlay_in_express_delivery_page() throws Throwable { 
		scheduleDeliveryPage.verifyEditAddressOverlay();  
	}

	@And("^I enter new address in add addr overlay$")
	public void i_enter_new_address_in_add_addr_overlay() throws Throwable {
		scheduleDeliveryPage.EnterFnameNewAddOverlay();
		scheduleDeliveryPage.EnterLnameNewAddOverlay();
		scheduleDeliveryPage.EnterAdd1NewAddOverlay();
		scheduleDeliveryPage.EnterPhoneNewAddOverlay();
		scheduleDeliveryPage.clickSaveButtonNewAddOverlay();
	}

	@And("^I verify address in express delivery right rail$")
	public void i_verify_address_in_express_delivery_right_rail() throws Throwable {
		scheduleDeliveryPage.verifyRightRailAddress();
	}

	@And("^I edit address in edit addr overlay$")
	public void i_edit_address_in_edit_addr_overlay() throws Throwable {
		scheduleDeliveryPage.editdAddr1InEditAddrOverlay();
		scheduleDeliveryPage.clickUpdateButtonEditOverlay();
	}
	
	@And("^I Verify Interstitial Image is displayed$")
	public void i_Verify_Interstitial_Image_is_displayed() throws Exception
	{
		scheduleDeliveryPage.verifyInterstitialImageSection();
	}
	

}
