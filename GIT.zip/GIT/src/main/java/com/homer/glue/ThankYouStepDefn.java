package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Given;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;
import com.homer.po.WCSLogsvalidation;
import com.homer.po.wcsDBvalidationPage;

public class ThankYouStepDefn extends BaseStepDefn {

	public ThankYouStepDefn(DataClass data) {
		super(data);
	}

	@Then("^I see thank you page for order placed$")
	public void i_see_thank_you_page_for_order_placed() throws Throwable {

		thankYouPage.verifyThankYouPage();
	}

	@And("^I see delivery charges in order pods$")
	public void i_see_delivery_charges_in_order_pods() throws Throwable {
	  thankYouPage.verifyDeliveryChargeInThankYouPage();
	}

	@When("^I register in thank you page$")
	public void i_register_in_thank_you_page() throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		 thankYouPage.registerInThankYouPg();
		}
	}

	@And("^I click on prod description link$")
	public void i_click_on_prod_description_link() throws Throwable {
       thankYouPage.clickOnProdDescInTY();
	}

	@And("^I see callout option in thank you page$")
	public void i_see_callout_option_in_thank_you_page() throws Throwable {
		thankYouPage.verifyCallOutOptionPopup();
	}

	@And("^I should not see callout option in thank you page for mixed cart$")
	public void i_should_not_see_callout_option_in_thank_you_page_for_mixed_cart()
			throws Throwable {
		thankYouPage.verifyNoCallOutOptionPopup();

	}

	@Then("^I see thank you page for order and Express Delivery label in order total section$")
	public void i_see_thank_you_page_for_order_and_Express_Delivery_label_in_order_total_section() throws Throwable {

		thankYouPage.verifyThankYouPageWithExpressDeliveryLabel();

	}

	@And("^I keep the session idle for (\\d+) min$")
	public void i_keep_the_session_idle_for_60_min() throws Throwable {
		thankYouPage.idleWaitForAnHour();
	}

	@And("^I verify assembly option in Thank you page$")
	public void i_verify_assembly_option_in_Thank_you_page() throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		}
		else
		{
		thankYouPage.verifyAssemblyOptionInThankYouPg();
		}
	}

	@And("^I verify no assembly option in Thank you page$")
	public void i_verify_no_assembly_option_in_Thank_you_page() throws Throwable {
		thankYouPage.verifyNoAssemblyOptionInThankYouPg();
	}



	@And("^I verify shipping charges displayed in thank you page$")
	public void i_verify_shipping_charges_displayed_in_thank_you_page() throws Throwable {
	 // Write code here that turns the phrase above into concrete actions

	}

	@And("^UnitPrice displayed in order confirmation page is equivalent to the price in Cassandra DB$")
	public void unitPrice_displayed_in_order_confirmation_page_is_equivalent_to_the_price_in_Cassandra_DB() throws Throwable {
		thankYouPage.verifyUnitPriceOrderConfirmation();
	}


	@And("^Subtotal displayed in order confirmation order pods is as in Cart$")
	public void subtotal_displayed_in_order_confirmation_order_pods_is_as_in_Cart() throws Throwable {
		thankYouPage.verifySubTotalOrderConfirmation();
	}

	@And("^Total price displayed in order confirmation is the sum of all the totals$")
	public void total_price_displayed_in_order_confirmation_is_the_sum_of_all_the_totals() throws Throwable {
		thankYouPage.verifyTotalPrice();
	}

	@And("^I close the callout popup in thankyou page$")
	public void i_close_the_callout_popup_in_thankyou_page() throws Throwable {
		thankYouPage.verifyCallOutPopupClosed();
	}

	@And("^I see price details in order confirmation page$")
	public void i_see_price_details_in_order_confirmation_page() throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);
		} else {
		thankYouPage.verifyUnitPriceOrderConfirmation();
		thankYouPage.verifySubTotalOrderConfirmation();
		thankYouPage.verifyTotalPrice();
		}
	}

	@And("^I verified the given scenario$")
	public void i_verified_the_given_scenario() throws Throwable {

	  report.addReportStep("Execution Completed", "Execution Completed for the particular scenario", StepResult.PASS);
	}

	@And("^I see Product image and name on order confirmation page$")
	public void i_see_product_image_and_name_on_order_confirmation_page() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		thankYouPage.verifyImgProductNameOnConfirmationPage();
		}
	}

	//*******************************hdpp***************************************************
	@And("^I verify certona section in TYP$")
	public void i_verify_certona_section_in_TYP() throws Throwable {
		thankYouPage.verifyCertonaSectionTYP();
	}

		
	//And I see HDPP item in order confirmation page
		@And("^I see HDPP item in order confirmation page$")
		public void i_see_HDPP_item_in_order_confirmation_page() throws Throwable {
			thankYouPage.verifyHDPP();
		}
		@And("^I do not see HDPP item in order confirmation page$")
		public void i_do_not_see_HDPP_item_in_order_confirmation_page() throws Throwable {
			thankYouPage.verifyNoHDPP();
		}


		@And("^I see Next Step Copy message$")
		public void I_see_Next_Step_Copy_message() throws Throwable {
			thankYouPage.verifyNextStepMSG();
		}

		@And("^I do not see Next Step Copy message$")
		public void I_do_not_see_Next_Step_Copy_message() throws Throwable {
			thankYouPage.verifyNoNextStepMSG();
	}

	@And("^I click Add to cart from TYP certona$")
	public void i_click_Add_to_cart_from_TYP_certona() throws Throwable {
		thankYouPage.clickAddtoCartCertonaTYP();
	}
	@And("^I verify the order confirmation page with Billing info subtotal credit card$")
	public void i_verify_the_order_confirmation_page_with_Billing_info_subtotal_credit_card() throws Throwable {
		thankYouPage.verifyOrderConfirmationPageDetails();
	}

	@And("^I verify POField not displayed in Thank you page$")
	public void I_verify_POField_not_displayed_in_Thank_you_page () throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		thankYouPage.verifyPoNumberNotPresentInOrderConfirmationPage();
		}
	}
	
	@And("^I verify POField in Thank you page$")
	public void I_verify_POField_in_Thank_you_page () throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		thankYouPage.verifyPOFieldInThankYouPage();
		}
	}
	
	@And("^I Verify blind item image is displayed with \"(.*?)\" rendered on Image along with swatch$")
    public void i_verify_the_custom_blind_item_product_image_is_dispalyed() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment())
		{
			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);
		}
		else
		{
			thankYouPage.verifyCustomImage();
		}
	}
	
	@And("^I Check the default attributes display$")
	public void i_check_the_default_attributes_display() throws Exception
	{
		if (rc.isProdEnvironment())
		{
			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);
		}
		else
		{
		thankYouPage.verifyBlindsItemDescription();
		}
	}
	
	
	@And("^I verify all totals in thankyou page$")
	public void i_verify_all_totals_in_thankyou_page() throws Throwable {
		thankYouPage.verifyAllTotalsfromOrderConfirmPage();
		shippingPage.verifyDiscountAmt();
	}
	
	@And("^I update Order number in Common data$")
	public void i_update_prder_number_in_common_data() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		}
		else
		{
		thankYouPage.orderNumberIncommonData();
		}
	}
	
	@Then("^I see Estimated Tax in thank you page$")
	public void i_see_etsimated_tax_in_thank_you_page() throws Exception
	{
		thankYouPage.verifyEstimatedSalesTaxInOrderConfirmPage();
	}
	
	@Then("^I see the sales tax is calculated for the discounted price$")
	public void i_see_the_sales_tax_is_calcuclated_for_the_discounted_price() throws Exception
	{
		thankYouPage.verifyEstimatedSalesInOrderConfirmPage();
	}

	
	@And("^I verify log validatons$")
	public void i_verify_log_validatons() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		}
		else
		{
		WCSLogsvalidation wcslogvalidation = new WCSLogsvalidation(ic);
		wcsDBvalidationPage dbValidation = new wcsDBvalidationPage(ic);
		dbValidation.wcsDBValidation();
		wcslogvalidation.wcsLogsValidation();
		
		}
	}
	
	@Then("^I compare pickUp date and time in orderConfirmation with PickUpOption Page$")
	public void i_compare_pickUp_date_and_time_in_orderConfirmation_with_PickUpOption_Page() throws Exception
	{
		thankYouPage.compareDateTimeInPickUpOptionAndOrderDetailPg();
	}
	
	@And("^I verify the Order level status in Order Confirmation page$")
	public void i_verify_the_Order_level_status_in_order_confirmation_page()
	{
		thankYouPage.orderLevelStatus();
	}
	
	@And("^I verify default order information message in ThankYou Page$")
	public void i_verify_default_order_information_message_in_ThankYou_Page() throws Exception
	{
		thankYouPage.verifyDefaultMsgInOrderInfoPg();
	}

	@And("^I enter Weak registration pwd in thankyou page")
	public void i_enter_weak_registration_pwd_thankyou_page() throws Exception {
		thankYouPage.registerInThankYouPgWithWeakPwd("test");
	}

	@And("^I verify weak pwd msg styling TYP$")
	public void i_verify_weak_pwd_msg_styling_TYP() throws Throwable {
		thankYouPage.verifyWeakPwdMsgThankYouPg();
	}

	@And("^I enter mismatch pwd in thankyou page$")
	public void i_enter_mismatch_pwd_in_thankyou_page() throws Throwable {
		thankYouPage.enterMismatchPwdTYP();
	}

	@And("^I verify pwd mismatch err msg in TYP$")
	public void i_verify_pwd_mismatch_err_msg_in_TYP() throws Throwable {
		thankYouPage.verifyPwdMismatchErrMsgTYP();
	}
	
	@Then("^I verify Promotion code is displayed in TY page$")
	public void i_verify_Promotion_code_is_displayed_in_TY_Page() throws Exception
	{
		thankYouPage.verifyPromotionDetailsCnfmPage();
	}

	@And("^I verify delivery date displayed in TYP$")
	public void i_verify_delivery_date_displayed_in_TYP() throws Throwable {
		thankYouPage.verifySelectedApplDeliveryDateTYP();
	}
	
	@Then("^I store guest user shipping address in thank you page$")
	public void i_store_guest_user_shipping_address_in_thank_you_page() throws Exception
	{
		thankYouPage.storeGuestUserShipAddress();
	}

	@And("^I click mylist link in header$")
	public void i_click_mylist_link_in_header() throws Throwable {
		thankYouPage.clickMyListInHeader();
	}

	@And("^I click order status link in TYP$")
	public void i_click_order_status_link_in_TYP() throws Throwable {
		thankYouPage.clickOrderStatusLink();
	}

}
