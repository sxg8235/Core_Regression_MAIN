package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;

public class PaymentPageStepDefn extends BaseStepDefn {

	public PaymentPageStepDefn(DataClass data) {
		super(data);

	}

	@Then("^I see payment page$")
	public void i_see_payment_page() throws Throwable {

		paymentPage.verifyPaymentPage();
	}

	@Then("^I see the payment&billing page$")
	public void i_see_the_payment_billing_page() throws Throwable {

		paymentPage.verifyPaymentAndBillingPage();

	}

	@When("^I fill payment details$")
	public void i_fill_payment_details() throws Throwable {

		// paymentPage.fillPaymentPageDetails();
		paymentPage.enterCardDetails();
	}

	@When("^I enter payment details under credit card section$")
	public void i_enter_payment_details_under_credit_card_section() throws Throwable {

		// paymentPage.fillPaymentPageDetails();
		paymentPage.enterCardDetails();

	}

	@And("^I click submitorder button in Payment page$")
	public void i_click_submitorder_button_in_Payment_page() throws Throwable {

		thankYouPage = paymentPage.submitOrder();
	}

	@And("^I select paypal payment method$")
	public void i_select_paypal_payment_method() throws Throwable {
		paymentPage.selectRadioPaypal();
		paymentPage.clickGoToPaypal();
	}

	@And("^I verify saved shipping address$")
	public void i_verify_saved_shipping_address() throws Throwable {
		paymentPage.verifySavedAddress();

	}

	@And("^I click cart breadcrumb$")
	public void i_click_cart_breadcrumb() throws Throwable {
		paymentPage.clickCartBreadCrumb();
	}

	@And("^I register in payment page$")
	public void i_register_in_payment_page() throws Throwable {
		paymentPage.registerInPaymentPg();
	}

	@And("^I verify the estimated sales tax section$")
	public void i_verify_the_estimated_sales_tax_section() throws Throwable {

		paymentPage.verifyEstimatedTaxAmountAndLabel();
	}

	@When("^I enter card details$")
	public void i_enter_card_details() throws Throwable {
		paymentPage.enterCardDetails();
	}

	@Then("^I clear the card details entered$")
	public void i_clear_the_card_details_entered() throws Throwable {
		paymentPage.clearCardDetails();
	}

	@And("^I verify cvv error in payment page$")
	public void i_verify_cvv_error_in_payment_page() throws Throwable {
		paymentPage.verifyCvvErrorInPaymentPg();
	}
	
	@And("^I verify registration section in payment page")
	public void i_verify_registration_section_in_payment_page() throws Exception
	{
		paymentPage.verifyRegistrationSecPresentInPaymentPg();
	}
	
	@And("^I verify registration section not present in payment page")
	public void i_verify_registration_section_not_present_in_payment_page() throws Exception
	{
		paymentPage.verifyRegistrationSecNotPresentInPaymentPg();
	}
	

	@And("^I verify saved tax exempt no in payment page$")
	public void i_verify_saved_tax_exempt_no_in_payment_page() throws Throwable {
		paymentPage.verifySavedTaxIdInPaymentPg();
	}

	@And("^I verify tax calculated is zero$")
	public void i_verify_tax_calculated_is_zero() throws Throwable {
		paymentPage.verifyTaxIsZero();
	}

	@And("^I verify tax calculated is not zero$")
	public void i_verify_tax_calculated_is_not_zero() throws Throwable {
		paymentPage.verifyTaxIsNotZero();
	}

	@And("^UnitPrice displayed in product description is equivalent to the price in Cassandra DB$")
	public void unitPrice_displayed_in_product_description_is_equivalent_to_the_price_in_Cassandra_DB()
			throws Throwable {
		paymentPage.verifyUnitPriceRightRail();
	}

	@And("^Subtotal displayed in order pods is as in Cart$")
	public void subtotal_displayed_in_order_pods_is_as_in_Cart() throws Throwable {
		paymentPage.verifysubTotalRightRail();
	}

	@When("^I click back button in payment&billing page$")
	public void i_click_back_button_in_payment_billing_page() throws Throwable {
		paymentPage.clickBackButton();
	}

	@Then("^I verify Name on card field is not present in payment page$")
	public void i_verify_Name_on_card_field_is_not_present_in_payment_page() throws Throwable {
		paymentPage.verifyNameOnCardFieldNotPresent();
	}

	@Then("^I verify Buyer Name field is present in payment page$")
	public void i_verify_Buyer_Name_field_is_present_in_payment_page() throws Throwable {
		paymentPage.verifyNameOnCardFieldPresent();
	}

	@And("^I see price details in Payment Page$")
	public void i_see_price_details_in_Payment_Page() throws Throwable {
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();
	}

	@And("^I verify the Calculated shipping charges displayed in right rail$")
	public void i_verify_the_Calculated_shipping_charges_displayed_in_right_rail() throws Throwable {

		paymentPage.verifyRightRailShippingCharge();
		paymentPage.calculateShippingSurCharge();

	}

	@When("^I select saved card from dropdown$")
	public void i_select_saved_card_from_dropdown() throws Throwable {
		paymentPage.selectSavedCardDropDown();
	}

	@When("^I enter CVV for saved card$")
	public void i_enter_CVV_for_saved_card() throws Throwable {
		paymentPage.enterCvvSavedCards();
	}

	@Then("^I verify CVV is cleared$")
	public void i_verify_CVV_is_cleared() throws Throwable {
		paymentPage.verifyCvvCleared();
	}

	@Then("^I verify saved card displayed as radio$")
	public void i_verify_saved_card_displayed_as_radio() throws Throwable {
		paymentPage.verifySavedCreditCardRadio();
	}

	@Then("^I verify new card displayed as radio$")
	public void i_verify_new_card_displayed_as_radio() throws Throwable {
		paymentPage.verifyNewCardRadio();
	}

	@Then("^I verify paypal displayed as radio$")
	public void i_verify_paypal_displayed_as_radio() throws Throwable {
		paymentPage.verifyPaypalRadio();
	}

	@When("^I select new card radio$")
	public void i_select_new_card_radio() throws Throwable {
		paymentPage.selectNewCardRadio();
	}

	@Then("^I verify saved card section collapsed$")
	public void i_verify_saved_card_section_collapsed() throws Throwable {
		paymentPage.verifySavedCardCollapsed();
	}

	@Then("^I verify new card section displayed properly$")
	public void i_verify_new_card_section_displayed_properly() throws Throwable {
		paymentPage.verifyNewCardSection();

	}

	@When("^I click paypal radio button$")
	public void i_click_paypal_radio_button() throws Throwable {
		paymentPage.selectRadioPaypal();
	}

	@Then("^I verify gift card section is hidden$")
	public void i_verify_gift_card_section_is_hidden() throws Throwable {
		paymentPage.verifyGiftCardSecHidden();
	}

	@Then("^I verify billing section is hidden$")
	public void i_verify_billing_section_is_hidden() throws Throwable {
		paymentPage.verifyBillingSecHidden();
	}

	@When("^I select credit card radio$")
	public void i_select_credit_card_radio() throws Throwable {
		paymentPage.selectCreditCardRadio();
	}

	@And("^check PLCC promo is reduced from total$")
	public void check_PLCC_promo_is_reduced_from_total() throws Throwable {
		paymentPage.verifyTotalForPLCCNonHDCard();
	}

	@And("^I click edit link in payment page$")
	public void i_click_edit_link_in_payment_page() throws Exception {
		paymentPage.clickEditLink();
	}

	@And("^I verify new saved address in payment page$")
	public void i_verify_new_saved_address_in_payment_page() throws Exception {
		paymentPage.verifyNewSavedAddress();
	}

	@And("^I enter CVV for saved card and place order$")
	public void i_enter_CVV_for_saved_card_and_place_order() throws Throwable {
		paymentPage.verifyPaymentPage();
		paymentPage.enterCvvSavedCards();
		thankYouPage = paymentPage.submitOrder();
		thankYouPage.verifyThankYouPage();
	}

	@And("^I verify cvv tool tip$")
	public void i_verify_cvv_tool_tip() throws Throwable {
		paymentPage.verifyCVVTooltipImage();
	}

	@And("^I enter tax exempt$")
	public void i_enter_tax_exempt() throws Throwable {
		paymentPage.taxExemptNum();
	}
	
	@And("^I verify payment type section$")
	public void i_verify_payment_type_section() throws Throwable {
		paymentPage.verifyPaymentTypeSection();
	}
	
	@And("^I see payment page with no card details save$")
	public void i_see_payment_page_with_no_card_details_save() throws Exception
	{
		paymentPage.verifyNoSavedAddress();
	}
	
	@When("^I verify error messages in Payment page$")
	public void i_verify_error_messages_in_paymentpage() throws Throwable {
		paymentPage.verifyMandatoryFieldsErrMsg();
	}
	
	@And("^I verify tax exempt error$")
	public void i_verify_tax_exempt_error() throws Throwable {
		paymentPage.verifyTaxExemptError();
	}
	
	@And("^I switch to new card and submit order$")
	public void i_switch_to_new_card_and_submit_order() throws Throwable { 
		paymentPage.verifyPaymentPage();
		paymentPage.selectNewCardRadio();
		paymentPage.enterDiffCardDetails();
		thankYouPage = paymentPage.submitOrder();
		thankYouPage.verifyThankYouPage();
	}
	
	@And("^I enter invalid credit card number in payment page$")
	public void i_enter_invalid_credit_card_number_in_payment_page() throws Throwable {
		paymentPage.enterInvalidCreditCard();
	}
	
	@And("^I enter invalid email in payment page$")
	public void i_enter_invalid_email_in_payment_page() throws Throwable { 
		paymentPage.enterInvalidEmailId();
	}
	
	@And("^I clear first and last name and click submit order$")
	public void i_clear_first_and_last_name_and_click_submit_order() throws Throwable { 
		paymentPage.clearFirstLastNameClickSubmitOrder();
	}
	@And("^I enter invalid symbols in Phone number Payment page$")
	public void i_enter_invalid_symbols_in_Phone_number_Payment_page() throws Throwable { 
		paymentPage.enterInvalidSymbolsPhonePaymentPg();
	}

	@And("^I enter zeroes in Phone number Payment page$")
	public void i_enter_zeroes_in_Phone_number_Payment_page() throws Throwable { 
		paymentPage.enterZeroesPhoneNoPaymentPg();
	}
	
	@And("^I clear address and click continue submit order$")
	public void i_clear_address_and_click_continue_submit_order() throws Throwable {
		paymentPage.clearAddressClickSumbitOrder();
	}

	@And("^I clear zipcode and phone no and click submit order$")
	public void i_clear_zipcode_and_phone_no_and_click_submit_order() throws Throwable {
		paymentPage.clearZipcodeAndPhoneClickSubmitOrder();
	}
	
	@And("^I verify Phone no field is displayed below Last Name in payment page$")
	public void i_verify_Phone_no_field_is_displayed_below_Last_Name_in_payment_page() throws Throwable { 
		paymentPage.verifyPhoneFieldMovedUp();
	}
	
	@When("^I click new billing address link in payment page$")
	public void i_click_new_billing_address_link_in_payment_page() throws Throwable { 
		paymentPage.clickNewBillingAddress();	  
	}
	
	@Then("^I see new billing address overlay in payment page$")
	public void i_see_new_billing_address_overlay_in_payment_page() throws Throwable { 
		paymentPage.verifyNewBillingAddressOverlay();	  
	}

	@And("^I verify shipping charge from shipping page$")
	public void i_verify_shipping_charge_from_shipping_page() throws Throwable { 
		paymentPage.verifyShippingCharge();	  
	}
	@And("^I enter new registration pwd in payment page$")
	public void i_enter_new_registration_pwd_in_payment_page() throws Throwable { 
		paymentPage.enterNewRegPassword();
	}

	@And("^I enter strong registration pwd in payment page")
	public void i_enter_strong_registration_pwd_payment_page() throws Exception
	{
		paymentPage.registerInPaymentPgWithStrongPwd("testing12345678");
	}
	
	@And("^I enter Weak registration pwd in payment page")
	public void i_enter_weak_registration_pwd_payment_page() throws Exception
	{
		paymentPage.registerInPaymentPgWithWeakPwd("test");
	}
	
	@And("^I verify weak pwd msg$")
	public void i_verify_weak_pwd_msg() throws Throwable {
		paymentPage.verifyWeakPwdMsg();
	}
	
	@And("^I verify weak pwd strength meter$")
	public void i_verify_weak_pwd_strength_meter() throws Throwable { 
		paymentPage.verifyWeakPwdStrengthMeter();	  
	}
	@And("^I verify pwd strength criteria$")
	public void i_verify_pwd_strength_criteria() throws Throwable { 
		paymentPage.verifyPwdStrengthCriteria();	  
	}

	@And("^I verify good pwd strength meter$")
	public void i_verify_good_pwd_strength_meter() throws Throwable {
		paymentPage.verifyGoodPwdStrengthMeter();
	}

	@And("^I verify strong pwd strength meter$")
	public void i_verify_strong_pwd_strength_meter() throws Throwable {
		paymentPage.verifyStrongPwdStrengthMeter();
	}

	@And("^I enter mismatch pwd in payment page$")
	public void i_enter_mismatch_pwd_in_payment_page() throws Throwable {
		paymentPage.enterMismatchPwd();
	}
	
	@And("^I verify message for Registered user in payment")
	public void i_verify_message_for_existing_mail_id() throws Exception
	{
		paymentPage.verifyYouAlreadyRegistredAccount();
	}

	@And("^I verify pwd mismatch err msg$")
	public void i_verify_pwd_mismatch_err_msg() throws Throwable {
		paymentPage.verifyPwdMismatchErrMsg();
	}
	
	@And("^I verify POJOB mandatory err msg$")
	public void i_verify_POJOB_mandatory_err_msg() throws Throwable {
		paymentPage.verifyPOMandatoryErrMsg();
	}

	@And("^I click save card checkbox in payment page$")
	public void i_click_save_card_checkbox_in_payment_page() throws Throwable {
		paymentPage.clickSaveCardChkBox();
	}
	
	@Then("^I verify international billing link is not present$")
	public void i_verify_international_billing_link_is_not_present() throws Throwable { 
		paymentPage.verifyNoCanadaMexicoBillingLink();	  
	}

	@And("^I verify international billing link is present$")
	public void i_verify_international_billing_link_is_present() throws Throwable {
		paymentPage.verifyCanadaMexicoBillingLink();
	}
	@And("^I click international billing link$")
	public void i_click_international_billing_link() throws Throwable { 
		paymentPage.clickCanadaMexicoBillingLink();  
	}

	@And("^I save international billing address$")
	public void i_save_international_billing_address() throws Throwable { 
		paymentPage.enterCanadaMexicoBillingAddr();	 
		paymentPage.saveCanadaMexicoBillingAddr();
	}
	@And("^I verify err msg for no city/state returned$")
	public void i_verify_err_msg_for_no_city_state_returned() throws Throwable { 
		paymentPage.verifyErrMsgForCityStateBillingAddrOverlay();	  
	}

	@And("^I click mexico radio button in international billing address overlay$")
	public void i_click_mexico_radio_button_in_international_billing_address_overlay() throws Throwable {
		paymentPage.clickMexicoRadioButton();
	}
	
	@Then("^I verify user is able to enter city and state manually$")
	public void i_verify_user_is_able_to_enter_city_and_state_manually() throws Throwable { 
		paymentPage.verifyCityStateEditable();	  
	}
	@And("^I enter international billing address$")
	public void i_enter_international_billing_address() throws Throwable {
		paymentPage.enterCanadaMexicoBillingAddr();
	}

	@And("^I click save international billing address$")
	public void i_click_save_international_billing_address() throws Throwable {
		paymentPage.saveCanadaMexicoBillingAddr();
	}

	@And("^I verify phone number format in international billing address overlay$")
	public void i_verify_phone_number_format_in_international_billing_address_overlay() throws Throwable {
		paymentPage.verifyPhoneNumberFormat();
	}

	@And("^I verify phonenumber length in international billing address overlay$")
	public void i_verify_phonenumber_length_in_international_billing_address_overlay() throws Throwable {
		paymentPage.verifyPhoneNumberDigits();
	}

	@And("^I verify sales tax tool tip$")
	public void i_verify_sales_tax_tool_tip() throws Throwable {
		paymentPage.verifySalesTaxTooltipImage();
	}

	@And("^I apply promotion from right rail$")
	public void i_apply_promotion_from_right_rail() throws Throwable {
		paymentPage.verifyPromoCodeRightRail();
		paymentPage.enterPromoCodeRightRail();
	}

	@And("^I enter invalid credit card numbers and verify error message$")
	public void i_enter_invalid_credit_card_numbers_and_verify_error_message() throws Throwable {
		paymentPage.verifyInvalidCCErros();
	}

	@And("^I verify expiry month/year error$")
	public void i_verify_expiry_monthyear_error() throws Throwable {
		paymentPage.verifyExpiryMonthYearError();
	}

	@And("^I clear CVV$")
	public void i_clear_CVV() throws Throwable {
		paymentPage.clearCVV();
	}
	
	@And("^I clear PO field$")
	public void i_clear_po() throws Throwable {
		paymentPage.clearPO();
	}

	@And("^I verify invalid tax exempt error$")
	public void i_verify_invalid_tax_exempt_error() throws Throwable {
		paymentPage.verifyInvalidTaxExempt();
	}
	
	@Then("^I verify Gift Card text under payment & Billing section$")
	public void i_verify_Gift_Card_text_under_payment__Billing_section() throws Throwable { 
		paymentPage.verifyGiftCardText();	  
	}

	@When("^I click Apply a gift card link$")
	public void i_click_Apply_a_gift_card_link() throws Throwable { 
		paymentPage.clickApplyGiftCardLink();	  
	}
	
	@When("^I enter gift card details$")
	public void i_enter_gift_card_details() throws Throwable { 
		paymentPage.enterGiftCard();	  
	}

	@Then("^I verify gift card overlay Title$")
	public void i_verify_gift_card_overlay_Title() throws Throwable { 
		paymentPage.verifyGiftCardOverlayTitle();	  
	}

	@And("^I verify saved address in payment page$")
	public void i_verify_saved_address_in_payment_page() throws Throwable {
		paymentPage.verifySavedAddressTypeAheads();
	}
	
	@Then("^I verify error msg for blank fields$")
	public void i_verify_error_msg_for_blank_fields() throws Throwable { 
		paymentPage.verifyErrMsgBillingAddrOverlay();	  
	}
	
	@And("^I verify special characters error msg$")
	public void i_verify_special_characters_error_msg() throws Throwable { 
		paymentPage.enterSpecialCharCanadaMexicoBillingAddr();	  
	}
	
	@And("I provide \"(.*?)\" for Payment")
	public void i_provide_TestCard_for_Payment() throws Exception
	{
		paymentPage.enterCardDetails();
	}
	
	@And("^I verify PIE encryption for Saved card$")
	public void i_verify_pie_encryption_Saved_card_number() throws Exception
	{
		paymentPage.verifyPIEValueforSavedCard();
	}
	
	@And("^I verify PIE encryption for New card$")
	public void i_verify_pie_encryption_New_card_number() throws Exception
	{
		paymentPage.verifyPIEValueforNewCard();
	}
	
	@And("^I verify No PIE encryption card number$")
	public void i_verify_no_pie_encryption_card_number() throws Exception
	{
		paymentPage.verifyNoPIEValueOfCC();
	}
	
	@And("^I verify ZipCode length in international billing address overlay$")
	public void i_verify_ZipCode_length_in_international_billing_address_overlay() throws Throwable { 
		paymentPage.verifyZipCodeDigits();
	}
	
	@Then("^I verify phone no error msg for less than ten digits$")
	public void i_verify_phone_no_error_msg_for_less_than_ten_digits() throws Throwable { 
		paymentPage.verifyPhoneErrLessThanTenDigit();
	}
	
	@When("^I enter store credit card details under Gift card section$")
	public void i_enter_store_credit_card_details_under_gift_card_section() throws Throwable {
	
		paymentPage.enterStoreCreditCardDetails();
	}
	
	@When("^I verify store credit not allowed advisory message in Apply Gift Cards Overlay$")
	public void i_Verify_Store_Credit_Not_Allowed_In_Apply_Gift_Cards_Overlay() throws Throwable {
	
		paymentPage.verifyStoreCreditNotAllowedAdvisoryMsg();
	}
	
	@When("^I click online FAQs link on payment page$")
	public void i_Click_Online_FAQs_On_Payment_Page() throws Throwable {
	
		paymentPage.selectOnlineFAQsInPayment();
	}
	
	@When("^I verify GC and SC usage in customer support FAQ page$")
	public void i_Verify_GCSC_Usage_CFAQ_Page() throws Throwable {
	
		paymentPage.verifyCFAQquestions();
	}
	
	@When("^I verify GC and SC usage in Gift Card FAQ page$")
	public void i_Verify_GCSC_Usage_GCFAQ_Page() throws Throwable {
	
		paymentPage.verifyGiftCardFAQquestions();
	}
	
	@When("^I verify SC is excluded in form or payment$")
	public void i_Verify_SC_Is_Excluded_In_Payment() throws Throwable {
	
		paymentPage.verifyCustomerSupportAnswer();
	}
	
	@Then("^I verify Estimated Sales tax mismatch in payment and Shipping page$")
	public void i_verify_estimated_sales_tax_mismatch_in_payment_and_shipping_page() throws Exception
	{
		paymentPage.verifyEstimatedTaxAmountAndLabel();
		paymentPage.compareEstimatedTaxInPaymentAndShipping();
	}
	
	@When("^I fill security ID for existing user$")
	public void i_fill_Vecurity_ID_for_existing_user() throws Throwable {
		paymentPage.enterSecurityIdforExistingUser();
	}
	
	@And("^I enter invalid tax exempt$")
	public void i_enter_invalid_tax_exempt() throws Exception
	{
		paymentPage.taxExemptNum();
	}
	
	@And("^I see System is accepting characters other than special characters$")
	public void i_see_system_is_accepting_characters_other_than_special_characters()
	{
		paymentPage.verifyCardNameIsInvalid();
	}
	
	@And("^I verify card name field accepts a max of 16 characters$")
	public void i_verify_card_name_field_accepts_a_max_of_16_characters() throws Exception
	{
		paymentPage.verifyCardNameLength();
	}
	
	
	@Then("^I verify card security field accepts a max of 4 characters$")
	public void i_verify_card_security_field_accepts_a_max_of_4_characters()
	{
		paymentPage.verifyCardSecurityFieldLength();
	}
	
	@And("I clear and enter invalid Card Num length and cvv$")
	public void i_clear_and_enter_invalid_card_name_length_and_cvv() throws Exception
	{
		paymentPage.enterInvalidCardDetails();
	}
	
	@Then("^I see You saved Section is zero in payment page$")
	public void i_see_you_saved_secton_is_zero_in_payment_page() throws Exception
	{  
		paymentPage.verifyYouSavedZeroInPaymentPage();
	}
	
	@And("^I click cart Icon in BreadCrumb in payment$")
	public void i_click_cart_icon_in_breadcrumb_in_payment() throws Exception
	{
		paymentPage.clickCartBreadCrumb();
	}

	@And("^I enter new billing address overlay in payment page$")
	public void i_enter_new_billing_address_overlay_in_payment_page() throws Throwable {
		paymentPage.enterNewBillingAddressOverlay();
	}
	
	@When("^I enter POJOB$")
	public void i_enter_POJOB() throws Throwable {
		paymentPage.enterPOJob();
	}

	@And("^I verify POJOB error in payment page$")
	public void i_verify_POJOB_error_in_payment_page() throws Throwable {
		paymentPage.verifyPOJOBErrorInPaymentPg();
	}

	@Then("^I check the PLCC warning message for bank card in payment page$")
	public void i_check_the_PLCC_warning_message_for_bank_card_in_payment_page() throws Throwable {
		paymentPage.checkPlccWarningMessage();
	}

	@When("^I click on Modify link in Right rail in payment page$")
	public void i_click_on_Modify_link_in_Right_rail_in_payment_page() throws Throwable {
		paymentPage.clickModifyLinkInRightRailPayment();
	}
	
	@And("^I verify gift card zero balance error$")
	public void i_verify_gift_card_zero_balance_error() throws Throwable {
		paymentPage.verifyGCZeroBalanceError();
	}
	
	@And("^I verify gift card wrong pin error$")
	public void i_verify_gift_card_wrong_pin_error() throws Throwable {
		paymentPage.verifyGCWrongPinError();
	}
	
	@And("^I verify gift card wrong captcha error$")
	public void i_verify_gift_card_wrong_captcha_error() throws Throwable {
		paymentPage.verifyGCWrongCaptchaError();
	}

	@And("^I verify breadcrums in payment page$")
	public void i_verify_breadcrums_in_payment_page() throws Throwable {
		paymentPage.verifyBreadCrums();
	}

	@And("^I verify contact info in payment page$")
	public void i_verify_contact_info_in_payment_page() throws Throwable {
		paymentPage.verifyContactInfo();
	}
	
	@And("^I verify color of buttons in payment page$")
	public void i_verify_color_of_buttons_in_payment_page() throws Throwable {
		paymentPage.verifyButtonColor();
	}

	@And("^I verify err msg styling for credit card number$")
	public void i_verify_err_msg_styling_for_credit_card_number() throws Throwable {
		paymentPage.verifyErrMsgStylingCardNumber();
	}

	@And("^I verify err msg styling for expiry year$")
	public void i_verify_err_msg_styling_for_expiry_year() throws Throwable {
		paymentPage.verifyErrMsgStylingExpiryYear();
	}

	@And("^I verify err msg styling for security code$")
	public void i_verify_err_msg_styling_for_security_code() throws Throwable {
		paymentPage.verifyErrMsgStylingSecurityCode();
	}

	@And("^I verify err msg styling for PO code$")
	public void i_verify_err_msg_styling_for_PO_code() throws Throwable {
		paymentPage.verifyErrMsgStylingPOJobCode();
	}

	@When("^I enter different card details$")
	public void i_enter_different_card_details() throws Throwable {
		paymentPage.enterDiffCardDetails();
	}

	@And("^I verify err msg styling for billing section$")
	public void i_verify_err_msg_styling_for_billing_section() throws Throwable {
		paymentPage.verifyErrMsgStylingFirstName();
		paymentPage.verifyErrMsgStylingLastName();
		paymentPage.verifyErrMsgStylingAddress1();
		paymentPage.verifyErrMsgStylingPhone();
		paymentPage.verifyErrMsgStylingZipCd();
	}

	@And("^I verify err msg styling for billing address$")
	public void i_verify_err_msg_styling_for_billing_address() throws Throwable {
		paymentPage.verifyErrMsgStylingAddress1();
	}

	@And("^I verify err msg styling for zipcode$")
	public void i_verify_err_msg_styling_for_zipcode() throws Throwable {
		paymentPage.verifyErrMsgStylingZipCd();
	}

	@And("^I verify err msg styling for phone number$")
	public void i_verify_err_msg_styling_for_phone_number() throws Throwable {
		paymentPage.verifyErrMsgStylingPhone();
	}

	@And("^I verify err msg styling for invalid phone number$")
	public void i_verify_err_msg_styling_for_invalid_phone_number() throws Throwable {
		paymentPage.verifyErrMsgStylingInvalidPhone();
	}

	@And("^I verify err msg styling for email id$")
	public void i_verify_err_msg_styling_for_email_id() throws Throwable {
		paymentPage.verifyErrMsgStylingEmailId();
	}

	@And("^I verify err msg styling for gift card$")
	public void i_verify_err_msg_styling_for_gift_card() throws Throwable {
		paymentPage.verifyErrMsgStylingGiftCard();
	}
	
	
	@And("^I verify error message for Invalid Length Tax Exempt Id$")
	public void i_verify_error_message_for_invalid_length_tax_exempt_id() throws Throwable { 
		
		paymentPage.verifyInvalidTaxExemptIdLengthGU();
	}
	
	
	@And("^I verify error message for Registered Invalid Tax Exempt Id$")
	public void i_verify_error_message_for_registered_invalid_tax_exempt_id() throws Exception
	{
		paymentPage.verifyInvalidTXExemptIdRU();
	}
	
	
	
	@And("^I verify error message for Invalid Tax Exempt Id$")
	public void i_verify_error_message_for_invalid_tax_Exempt_id() throws Exception
	{
		paymentPage.verifyInvalidTXExemptIdGU();
	}
	
	
	@And("^I enter Tax Exempt Id in payment page$")
	public void i_enter_tax_exempt_id_in_payment_page() throws Exception
	{
		paymentPage.verifyEnterTaxExemptId();
	}
	 
	@And("^I click on Edit this Tax Exempt Id link to edit$")
	public void i_click_on_edit_this_tax_exempt_id_link_to_edit() throws Exception
	{
		paymentPage.verifyEditTaxExemptId();
	}
	
	
	@And("^I enter Tax Exempt Id and cancel$")
	public void i_enter_tax_exempt_id_and_cancel() throws Exception
	{
		paymentPage.verifyCancelTaxExemptId();
	}

	@And("^I verify Tax exempt Id is not displayed in payment page$")
	public void i_verify_tax_exempt_id_is_not_displayed_in_payment_page() throws Exception
	{
		paymentPage.verifyNoTaxExemptId();
	}

	@And("^I verify card name error for proxy commercial card$")
	public void i_verify_card_name_error_for_proxy_commercial_card() throws Exception
	{
		paymentPage.verifySameCardholdernameAsCommercialMsg();
	}
	@And("^I verify err msg styling for buyer name$")
	public void i_verify_err_msg_styling_for_buyer_name() throws Throwable { 
		paymentPage.verfiyBuyerNameStyling();	  
	}
	
	@And("^I verify error when we place order using cards other than HD$")
	public void i_verify_error_when_we_place_order_using_cards_other_than_HD() throws Exception
	{
		paymentPage.verifyErrorHDCards();
	}

	@Then("^I verify gift card applied$")
	public void i_verify_gift_card_applied() throws Throwable { 
		paymentPage.verifyGiftCardApplied();	  
	}
	
	@When("^I enter another gift card details$")
	public void i_enter_another_gift_card_details() throws Throwable { 
		paymentPage.enterAnotherGiftCard();	  
	}

	@And("^I clear email and click submit order$")
	public void i_clear_email_and_click_submit_order() throws Throwable { 
		paymentPage.clearEmailClickSubmitOrder();
	}
	
	@And("^I remove all gift cards$")
	public void i_remove_all_gift_cards() throws Throwable { 
		paymentPage.removeAllGiftCards();
	}
	

	@And("^I verify all item pods in all the checkout pages$")
	public void i_verify_all_item_pods_in_all_the_checkout_pages() throws Exception
	{
		paymentPage.verifyAllItemsPodsInAllPages();
	}

	@And("^I verify err msg styling for billing address in add address overlay$")
	public void i_verify_err_msg_styling_for_billing_address_in_add_address_overlay() throws Throwable {
		paymentPage.verifyErrMsgStylingAddress1Overlay();
	}
	
	@And("^I verify tax exempt overlay$")
	public void i_verify_tax_exempt_overlay() throws Exception
	{
		paymentPage.verifyTaxExemptOverlay();
	}
	
	

}
