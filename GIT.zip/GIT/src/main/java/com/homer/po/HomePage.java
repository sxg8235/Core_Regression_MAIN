package com.homer.po;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;
import com.homer.logger.HomerLogger;

public class HomePage extends PageBase<HomePage> {

	static By betaWebServerBtn = By.xpath("//*[@onclick='beta()']");
	static By testWebServerBtn = By.xpath("//button[@id='button1'][contains(text(),'Test Webserver')]");

	static final By signInErr = By.xpath("//div[@class='signInError'][contains(text(),'Your sign in is incorrect')]");
	static final By changeStoreLink = By.xpath("//a[@href='#localizationModalContent']");

	static final By storeFinderBox = By.id("txtStoreFinder");
	static final By storeFinderBtn = By.id("btnStoreFinder");
	static final By makeThisYourStoreLink = By.xpath("//a[contains(text(),'Make this your store')]");
	static final By localStoreName = By.xpath("//*[@id='myStore']//a[contains(@class,'locStoreName')]");
	static final By changeStoreOverlay = By.id("fancybox-content");
	static final By myAccountOverlay = By.id("fancybox-close");
	static final By miniCartBtn = By.id("headerCart");
	static final By verifyShoppingCartPage = By.id("cart-style-container");
	static final By zipCodeChangeStoreOverlay = By.xpath("//*[@id='sfYourStore']//span[@class='postal-code']");
	static final By verifyHomePage = By.id("headerFlyoutMenu");
	static final By lnkBeta_Tab = By.xpath("//button[contains(text(),'Beta')]");
	static final By lnkAccountProfile = By.xpath("//a[contains(text(),'Account Profile')]");
	static final By myStore = By.xpath("//*[@id='headerStoreFinder']");
	static final By myStoreID = By.xpath("//*[@class='headerStore__name']");
	static final By headerflyout = By.xpath("//*[@id='headerFlyoutDropdown']");

	static final By headerlogo = By.cssSelector("li .headerLogo");
	static final By allProd = By.id("all_products");

	static final By foreseepage = By.xpath("//*[@id='fsrAdmin']");
	static final By foreseeqty = By.xpath("//input[@name='browse']");
	static final By foreseepooling = By.xpath("//input[@name='pool']");
	static final By foreseepopup = By.cssSelector(".fsrInvite");
	static final By nothanksforesee = By.xpath("//a[@class='fsrDeclineButton']");
	static final By yesForesee = By.xpath("//a[@class='fsrAcceptButton']");
	static final By foreseeSet = By.xpath("//input[@value='Set']");
	static final By foreseeSurveyPage = By
			.xpath("//h1[@class='mb' and contains(text(),'Customer Satisfaction Survey')]");
	static final By foreseeComments = By.xpath("//textarea[@id='q27a1']");
	// Gift card
	static final By lnkgiftCard = By.xpath("//*[@class='list list--unstyled']/li//a[@title='Gift Cards']");

	public HomePage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to open Home Page
	 * 
	 * @throws Exception
	 */
	public void open() throws Exception {

		String userAgent = (String) ((JavascriptExecutor) driver).executeScript("return navigator.userAgent;");

		commonData.desktopUserAgent = !Boolean.valueOf(HelperClass.readRunConfigProperties("TabletMode"));

		if ((userAgent.toLowerCase().contains("windows") || userAgent.toLowerCase().contains("macintosh"))
				&& (commonData.desktopUserAgent)) {

			report.addReportStep("Verify Desktop Webdriver is Launched",
					"Desktop WebDriver is displayed with User Agent : " + userAgent, StepResult.DONE);
			open_Fullsite();

		} else if (userAgent.toLowerCase().contains("ipad") && !commonData.desktopUserAgent) {
			open_Fullsite();
			report.addReportStep("Verify Tablet Webdriver is Launched",
					"Tablet WebDriver is displayed with User Agent : " + userAgent, StepResult.DONE);

		} else {
			report.addReportStep("Verify Webdriver is Launched",
					"Tablet WebDriver is displayed with User Agent : " + userAgent, StepResult.WARNING);
		}
	}

	/**
	 * Method to open Home Page
	 * 
	 * @throws Exception
	 */
	public void open_Fullsite() throws Exception {

		String envUrl = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);

		envUrl = envUrl.toLowerCase();

		try {
			driver.manage().deleteAllCookies();
			driver.get(envUrl);
		} catch (Exception ex) {
			if (wh.isAlertPresent()) {
				wh.handleAlert();
			}
		}

		if (envUrl.contains("usebeta") || envUrl.contains("testpage")) {

			if (envUrl.contains("usebeta")) {
				if (wh.isAlertPresent()) {
					wh.handleAlert();
				}
				wh.jsClick(betaWebServerBtn);

			} else {
				try {
					wh.jsClick(testWebServerBtn);
				} catch (Exception ex) {
					HomerLogger.getInstance().info(ex.getMessage());
				}
			}

			if (wh.isAlertPresent()) {
				wh.handleAlert();
			}

			wh.waitForPageLoaded();

			final String thisWindow = driver.getWindowHandle();

			String newWindow = new WebDriverWait(driver, 30).until(new ExpectedCondition<String>() {
				public String apply(WebDriver d) {
					Set<String> handles = d.getWindowHandles();
					handles.remove(thisWindow);
					return handles.size() > 0 ? handles.iterator().next() : null;
				}
			});

			driver.close();
			driver.switchTo().window(newWindow);

			String betaStatus = driver.manage().getCookieNamed("HD_DC").getValue();

			expectedResult = rc.getAnalyticsValue("betaSite").equalsIgnoreCase("beta")
					|| wh.isElementPresent(verifyHomePage, 1) ? true : false;

			if (expectedResult && betaStatus.equalsIgnoreCase("beta")) {
				driver.manage().window().maximize();
				report.addReportStep("Verify Cookie is set as \'HD_DC=beta\'",
						"Cookie Name is Set as HD_DC '" + betaStatus + "'  displayed successfully", StepResult.PASS);
			} else {
				report.addReportStep("Verify Cookie is set as \'HD_DC=beta\'",
						"Cookie Name is Set as HD_DC '" + betaStatus + "'  displayed successfully",
						StepResult.FAIL_ENV);
				rc.terminateTestCase();
			}

		}

		driver.manage().window().maximize();
		((JavascriptExecutor) driver).executeScript("document.cookie='fsr.r=false'");
		((JavascriptExecutor) driver).executeScript("document.cookie='fsr.s=false'");

		/*
		 * driver.manage().addCookie(new Cookie("fsr.r", "false"));
		 * driver.manage().addCookie(new Cookie("fsr.s", "false"));
		 */

		expectedResult = rc.getAnalyticsValue("pageName").equalsIgnoreCase("HomePage")
				|| wh.isElementPresent(verifyHomePage, 1) ? true : false;

		if (expectedResult) {
			report.addReportStep("Open Home Depot page", "Open Home Depot page is displayed successfully",
					StepResult.PASS);
		} else {
			report.addReportStep("Open Home Depot page", "Open Home Depot page is not displayed successfully",
					StepResult.FAIL);
		}
	}

	/**
	 * Method to open Home Page in tablet device
	 * 
	 * @throws Exception
	 */
	public void openApp() throws ParserConfigurationException, Exception {

		String envUrl = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);

		try {

			if (envUrl.contains("usebeta")) {

				System.out.println("Here for Beta connection");

				if (envUrl.contains("www.homedepot.com")) {

					try {
						driver.get("http://t.homedepot.com/usebeta.html");
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

				} else if (envUrl.equalsIgnoreCase("hd-ps71")) {

					System.out.println("Here for ps71Beta connection");

					try {
						driver.get("http://t.hd-ps71.homedepotdev.com/usebeta.html");
					}

					catch (Exception e) {
						System.out.println(e.getMessage());
					}

				}
				// To click on use the beta connection button
				wh.clickElement(lnkBeta_Tab);

				String currentWin = driver.getWindowHandle();
				Set<String> strBrowsers = driver.getWindowHandles();

				if (strBrowsers.size() > 1) {
					strBrowsers.remove(currentWin);
					String strBrowsers1 = strBrowsers.iterator().next();
					driver.switchTo().window(strBrowsers1);
				} else {
					Cookie cookie = new Cookie("HD_DC", "Beta");
					driver.manage().addCookie(cookie);
					envUrl = envUrl.replace("/usebeta.html", "");
					driver.get(envUrl);
				}
			} else {
				System.out.println("No beta");
				driver.get(dataTable.getCommonData("EnvironmentUrl"));
			}

			Cookie ck = new Cookie("disableLivePerson", "true");
			driver.manage().addCookie(ck);
		}

		catch (UnreachableBrowserException e) {
			e.printStackTrace();
		}

		// To verify user navigated to home page
		if (wh.isElementPresent(verifyHomePage, 10)) {
			report.addReportStep("Validate the Home Page", "Tablet optimized Homedepot home page is displayed.",
					StepResult.PASS);
		} else {
			report.addReportStep("Validate the Home Page", "Tablet optimized Homedepot home page is not displayed.",
					StepResult.FAIL);
		}

		// Setting cookie value to avoid FORESEE pop-up
		driver.manage().addCookie(new Cookie("fsr.r", "false"));
		driver.manage().addCookie(new Cookie("fsr.s", "false"));
	}

	/**
	 * Component to help localise to a nearby store using jump uRL
	 * 
	 * 
	 * @since Mar 10, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public HomePage localiseJumpUrl() throws Exception {
		wh.waitForPageLoaded();
		String strJumpStore = dataTable.getData("LocalizeStore");
		String strCurrentEnvironment = HelperClass.baseModel.runEnvironment;
		String currentURL = driver.getCurrentUrl();

		wh.waitForPageLoaded();

		if (strCurrentEnvironment.toLowerCase().contains("prod")) {
			strCurrentEnvironment = "www.homedepot.com";
		} else if (strCurrentEnvironment.contains("beta")) {
			strCurrentEnvironment = strCurrentEnvironment.substring(0, strCurrentEnvironment.indexOf("beta"));

			strCurrentEnvironment = "hd-" + strCurrentEnvironment + ".homedepotdev.com";
		}

		else {
			strCurrentEnvironment = "hd-" + strCurrentEnvironment + ".homedepotdev.com";
		}

		try {
			String strJumpURL = "http://" + strCurrentEnvironment
					+ "/webapp/wcs/stores/servlet/THDStoreFinderStoreSet?storeId=10051&catalogId=10053&recordId="
					+ strJumpStore + "";
			String getCurrentlocalStore = getCurrentLocalStore();
			Thread.sleep(1000);
			if (!strJumpStore.equals(getCurrentlocalStore)) {
				driver.get(strJumpURL);
				wh.waitForPageLoaded();
				driver.get(currentURL);
				wh.waitForPageLoaded();
			}

			report.addReportStep("Localise using JumpURL", "JumpURL triggered \n" + strJumpURL + "", StepResult.PASS);
		} catch (Exception e) {
			report.addReportStep("Localise using JumpURL", "Unable to trigger JumpURL to localise", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Method to verify sign in error message
	 * 
	 * @return HomePage
	 * @throws Exception
	 */
	public HomePage signInErrMsg() throws Exception {

		String invalidErrMsg = driver.findElement(signInErr).getText();
		if (invalidErrMsg.contains("Your sign in is incorrect. Please re-enter your Email Address and Password.")) {
			report.addReportStep("Verify sign in error message is displayed on entering invalid credentials",
					"Sign in error message is displayed on entering invalid credentials", StepResult.PASS);
		} else {
			report.addReportStep("Verify sign in error message is displayed on entering invalid credentials",
					"Sign in error message is not displayed on entering invalid credentials", StepResult.FAIL);
		}

		return this;
	}

	/*
	 * Method to click Your Account in homepage header
	 */
	public void clickYourAccountInHomePg() throws Exception {

		if (wh.isElementPresent(lnkMyAccount)) {

			wh.clickElement(lnkMyAccount);
			wh.clickElement(lnkAccountProfile);

			if (wh.isElementPresent(myAccountOverlay, 5)) {
				wh.clickElement(myAccountOverlay);
			}

			report.addReportStep("Verify Your Account link is clicked", "Your Account link is clicked",
					StepResult.PASS);

		} else {

			report.addReportStep("Verify Your Account link is clicked", "Your Account link is not clicked",
					StepResult.FAIL);
		}

	}

	/**
	 * To click on mini cart button in header
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage clickMiniCartBtn() throws Exception {

		if (wh.isElementPresent(miniCartBtn)) {

			addMCCparamter();

			wh.clickElement(miniCartBtn);

			report.addReportStep("Click Mini cart button from header", "Mini cart button is clicked", StepResult.PASS);

		}

		else {

			report.addReportStep("Click Mini cart button from header", "Mini cart button is not clicked",
					StepResult.FAIL);
		}

		return new ShoppingCartPage(ic);

	}

	/**
	 * To add gift card item to cart
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage addGiftCardToCart() throws Exception {

		String strEnv = HelperClass.baseModel.runEnvironment;

		String gcURL = "http://hd-" + strEnv
				+ ".homedepotdev.com/webapp/wcs/stores/servlet/OrderItemAdd?GCDenomination=500.00&URL=OrderItemDisplay&allocate=*n&backorder=*n&calculationUsageId=-1&captchaVerification=&catEntryId_1=10640&catalogId=10053&check=*n&contractId=2081191&currentPage=quickShop&defaultQuantity=1&deleteme_attrName_1=&deleteme_attrName_1=&errorViewName=GiftCardProductDisplayErrorView&gcErrorMsgs=&giftCardNumber=&langId=-1&merge=*n&messageFrom_1_1=mallesh&messageFrom_1_2=&messageLine_1_1=asdf&messageLine_1_2=&messageLine_1_3=&orderId=.&partNum=199999959&pinNumber=&productId=10051&product_catEntryId_1=10051&quantity_1=1&remerge=*n&reverse=*n&shouldCachePage=false&storeId=10051";

		String strURL;

		if (strEnv.contains("prod") || strEnv.contains("prodbeta")

				|| strEnv.contains("testpage")) {

			strURL = "http://www.homedepot.com";

		}

		else if (strEnv.contains("ps71beta")) {

			strURL = "http://hd-ps71.homedepotdev.com";

		}

		else {

			strURL = "http://hd-" + strEnv + ".homedepotdev.com";

		}

		driver.get(gcURL);

		wh.waitForPageLoaded();

		driver.get(strURL

				+ "/MCCCheckout/Cart/ViewCart.do");
		wh.waitForPageLoaded();

		if (wh.isElementPresent(verifyShoppingCartPage)) {

			report.addReportStep("Verify cart page is displayed", "Cart page is displayed", StepResult.PASS);

		} else {

			report.addReportStep("Verify cart page is displayed", "Cart page is not displayed", StepResult.FAIL);
		}

		return new ShoppingCartPage(ic);

	}

	/**
	 * To close the browser window
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public HomePage deleteUserSessionCookie() throws Exception {

		Thread.sleep(commonData.LongWait);

		Set<?> cookies = driver.manage().getCookies();
		Iterator<?> iter = cookies.iterator();
		while (iter.hasNext()) {
			Cookie cookie = (Cookie) iter.next();
			String strCookieName = cookie.toString();

			if (strCookieName.contains("WC_USERACTIVITY")) {

				strCookieName = strCookieName.substring(0, strCookieName.indexOf("="));

				driver.manage().deleteCookieNamed(strCookieName);
				report.addReportStep("Delete the <b>User Session cookie</b>",
						"Session cookie for the active user was <b>deleted</b>", StepResult.DONE);
			}
		}

		return this;

	}

	/**
	 * Component to change store from (change ) link,Select different store
	 * other than current store modified by-rsm8521
	 */
	public HomePage clickChangeLinkInheader() throws Exception {

		By wElm;

		String strPrevStoreName = getCurrentLocalStore();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-550)", "");
		wh.clickElement(lnkStoreFinder);

		wElm = changeStoreLink;

		if (wh.isElementPresent(wElm)) {
			wh.clickElement(wElm);
			report.addReportStep("Click on (change ) link in the header", "Change link clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on (change ) link in the header", "Change link not present on header",
					StepResult.FAIL);

			rc.terminateTestCase("Change Link on header");
		}

		driver.switchTo().defaultContent();

		String zipcode = dataTable.getData(DataColumn.ChangeZipCode);

		// String strViewStore=wh.getAttribute(storeFinderBox, "value");

		String strViewStore = wh.getText(zipCodeChangeStoreOverlay);
		if (strViewStore.contains(zipcode)) {
			report.addReportStep("zipcode should be different", "current and changed store zipcodes are same",
					StepResult.WARNING);
		} else {
			wh.sendKeys(storeFinderBox, zipcode);
			wh.clickElement(storeFinderBtn);
			Thread.sleep(commonData.littleWait);
			wh.clickElement(makeThisYourStoreLink);

			if (wh.isElementNotPresent(changeStoreOverlay)) {
				String currLocalStore = getCurrentLocalStore();
				if (currLocalStore.contains(strPrevStoreName)) {
					report.addReportStep("Change Localization store", "Localization store not changed",
							StepResult.FAIL);
					rc.terminateTestCase("Change Local Store");
				} else {
					report.addReportStep("Change Localization store", "Localization store changed", StepResult.PASS);
				}
			} else {
				report.addReportStep("Change Localization store",
						"Localization store not changed, Change store overlay not closed", StepResult.FAIL);

				rc.terminateTestCase("Change Local Store");
			}
		}

		return this;
	}

	/**
	 * Refresh home page
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public HomePage refreshHome() throws Exception {

		// Thread.sleep(commonData.littleWait);

		String envUrl = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);

		driver.get(envUrl);
		Thread.sleep(commonData.littleWait);
		return this;

	}

	/**
	 * Component to change store from (change) link,Select different store other
	 * than current store modified by-rsm8521
	 */
	public HomePage localizeStoreHeader() throws Exception {

		By wElm;

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-550)", "");
		wh.clickElement(lnkStoreFinder);

		wElm = changeStoreLink;

		if (wh.isElementPresent(wElm)) {
			wh.waitForPageLoaded();
			wh.clickElement(wElm);

			report.addReportStep("Click on (change) link in the header", "Change link clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on (change ) link in the header", "Change link not present on header",
					StepResult.FAIL);

			rc.terminateTestCase("Change Link on header");
		}

		driver.switchTo().defaultContent();

		String localStore = dataTable.getData(DataColumn.LocalizeStore);

		if (wh.isElementPresent(changeStoreOverlay)) {

			wh.sendKeys(storeFinderBox, localStore);
			wh.clickElement(storeFinderBtn);
			Thread.sleep(commonData.littleWait);
			wh.clickElement(makeThisYourStoreLink);

			report.addReportStep("Change Localization store", "Localization store changed", StepResult.PASS);
		} else {
			report.addReportStep("Change Localization store",
					"Localization store not changed, Change store overlay not closed", StepResult.FAIL);

			rc.terminateTestCase("Change Local Store");
		}

		return this;
	}

	/**
	 * Navigate to SBOTD page
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public HomePage navigateToSbotd() throws Exception {

		String envUrl = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);

		driver.get(envUrl + "/SpecialBuy/SpecialBuyOfTheDay?redirect=true&NCNI-5&searchRedirect=sbotd");
		Thread.sleep(commonData.littleWait);
		return this;

	}

	/**
	 * Method to get the auto localized store and save it in common data
	 * 
	 * @throws Exception
	 */
	public void getAutoLocalizedStore() throws Exception {
		if (wh.isElementPresent(myStore, 4)) {
			wh.clickElement(myStore);
			Thread.sleep(100);
			String strStore = wh.getText(myStoreID);
			if (strStore != null) {
				String[] arrStroreName = strStore.split(" ");
				strStore = arrStroreName[0];
				String storeNo = arrStroreName[1].trim().split("#")[1].split(" ")[0].trim();
				System.out.println(storeNo);
				commonData.storeNO = storeNo;
				String storeName = strStore.split(" ")[0];
				System.out.println(storeName);
				commonData.storeNAME = storeName;

				report.addReportStep("verify auto localized store", "Your store section is displayed", StepResult.DONE);
			}
		} else {
			report.addReportStep("verify auto localized store", "Your store section is displayed", StepResult.FAIL);
		}
	}

	/**
	 * Method to verify the auto localized store displayed in al pages
	 * 
	 * @throws Exception
	 */
	public void verifyAutoLocalizedStoreInAllPages() throws Exception {
		if (wh.isElementPresent(myStore, 4)) {

			wh.clickElement(myStore);
			Thread.sleep(100);
			String strStore = wh.getText(myStoreID);
			if (strStore.contains(commonData.storeNO) && strStore.contains(commonData.storeNAME)) {
				report.addReportStep("verify auto localized store",
						"Auto localized store " + strStore + "is displayed in all pages", StepResult.PASS);
			} else {
				report.addReportStep("verify auto localized store",
						"Auto localized store" + strStore + "is not displayed in all pages", StepResult.FAIL);
			}
			report.addReportStep("verify auto localized store", "Your store section is displayed", StepResult.DONE);
		} else {
			report.addReportStep("verify auto localized store", "Your store section is displayed", StepResult.FAIL);
		}
	}

	/**
	 * Navigate porduct thorugh flyout
	 * 
	 * @throws Exception
	 */
	public void flyOutNav() throws Exception {
		if (wh.isElementPresent(headerlogo, 4)) {
			wh.clickElement(headerlogo);

			Thread.sleep(2000);
		}
		// verify flyout dropdown
		if (wh.isElementPresent(headerflyout)) {
			report.addReportStep("Verify flyout drop down", "Flyout drop down is displayed", StepResult.PASS);
		} else {
			wh.clickElement(verifyHomePage);
		}
		String strFlyOut = dataTable.getData("Search_Keyword");
		String strDepartment = strFlyOut.split(">")[0];
		String strSubCategory = strFlyOut.split(">")[1];
		String[] strClickLinks = strFlyOut.split(">");
		// makeBlock(driver.findElement(By.className("switches")));

		Thread.sleep(1000);
		try {
			WebElement element = driver.findElement(By.linkText(strDepartment));
			rc.highlightElement(driver, element);
			// makeBlock(element.findElement(By.xpath("./../div")));
			Actions builder = new Actions(driver);
			builder = new Actions(driver); //
			builder.moveToElement(element).build().perform();

			// There is a small lag for window to appear - NXS
			Thread.sleep(1000);

			driver.findElement(By
					.xpath("//*[contains(@class,'flyoutContainer__heading')]/a[contains(.,'" + strSubCategory + "')]"))
					.click();
		} catch (NoSuchElementException nsee) {
			System.out.println("no Such" + nsee);
		}

		Thread.sleep(2000);
		if (!wh.isElementPresent(By.id("hd_plp"), 5)) {
			flyOutAlternate();
		}

		if (wh.isElementPresent(allProd, 4)) {
			report.addReportStep("Verify PLP Page is displayed",
					"PLP Page is displayed for the metioned category <b>" + strFlyOut + "</b> ", StepResult.PASS);

		} else {
			report.addReportStep("Verify PLP Page is displayed", "PLP Page is not displayed", StepResult.FAIL);
		}

		PLPPage plpPage = new PLPPage(ic);
		plpPage.clickFirstPLPPOD();
	}

	/**
	 * Fly out alternate method
	 * 
	 * @throws Exception
	 */
	private void flyOutAlternate() throws Exception {

		System.out.println("flyOutAlternate method called");
		String strFlyOut = dataTable.getData("FlyOutCompatibility");
		String[] strClickLinks = strFlyOut.split(">");

		Thread.sleep(1000);
		/*
		 * wait15.until(ExpectedConditions.visibilityOf(driver.findElement(By
		 * .linkText(strClickLinks[0]))));
		 */
		// Clicking Department
		driver.findElement(By.linkText(strClickLinks[0].trim())).click();
		System.out.println("Clicked on the category: " + strClickLinks[0]);
		// Clicking SubCategories
		for (int i = 1; i < strClickLinks.length; i++) {
			System.out.println(strClickLinks[i]);

			/*
			 * wait.until(ExpectedConditions.visibilityOf(driver.findElement(By
			 * .partialLinkText(strClickLinks[i]))));
			 */
			clickSubCategory(strClickLinks[i].trim());
			// cf.clickLink(driver, "linkText", strClickLinks[i]);
		}
	}

	/**
	 * Component to Select the item Through Sub Category
	 * 
	 *
	 * @since Aug 5, 2015
	 * @author bxb8917
	 * @throws Exception
	 */
	private void clickSubCategory(String strItem) throws Exception {
		if (wh.isElementPresent(headerlogo, 4)) {
			Thread.sleep(1000);
			try {
				if (wh.isElementPresent(By.className("activeLevel"), 0)) {

					driver.findElement(By.className("activeLevel"))
							.findElement(By.xpath(".//a[text()='" + strItem + "']")).click();
					report.addReportStep("Verify the Product subcategory is clicked",
							"<b>Product Subcategory : " + strItem + " </b>is clicked", StepResult.PASS);

				} else {
					driver.findElement(By.className("left-rail"))
							.findElement(By.xpath(".//a[contains(text(),'" + strItem + "')]")).click();
				}
			} catch (Exception e) {
				report.addReportStep("click the category link ",
						"Unable to find the category link " + strItem + " in left rail of PLP page", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		}
	}

	public void clearCookies() {
		driver.manage().deleteAllCookies();
		report.addReportStep("ClearCookies", "Clear All the Cookies", StepResult.DONE);
	}

	/**
	 * 
	 * Description : launch the forsee url
	 * 
	 * @since Jun 02, 2014
	 * @author axr8235
	 * @throws InterruptedException
	 */
	public void LaunchForeseeUrl() throws InterruptedException {
		String strURL = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);
		// String strURL = HelperClass.baseModel.runEnvironment;
		strURL = strURL + "/static/scripts/foresee/fsrtest.html";
		if ((strURL.contains("testpage")) || (strURL.contains("usebeta"))) {
			openHomeDepotTestPage();
		} else {
			System.out.println(strURL);

			try {

				driver.get(strURL);

				try {
					driver.manage().deleteAllCookies();
					report.addReportStep("Delete the Browser cookies", "Browser Cookies Deleted", StepResult.DONE);
				} catch (Exception e) {
					report.addReportStep("Delete the Browser cookies", "Unable to delete the browser cookies",
							StepResult.WARNING);
				}

				driver.manage().addCookie(new Cookie("fsr.sp", "false"));
				driver.get(strURL);

				try {
					driver.manage().window().maximize();
					report.addReportStep("Maximize the browser window", "Browser Window Maximized", StepResult.DONE);
				} catch (Exception e) {
					report.addReportStep("Maximize the browser window", "Browser Window not Maximized",
							StepResult.WARNING);
				}

			} catch (Exception e) {
				report.addReportStep("Launch the URL <b>" + strURL + "</b>", "Failed to launch the URL",
						StepResult.FAIL);
				commonData.blnGracefulExit = true;

			}

		}
	}

	/**
	 * 
	 * Description : open home depot test page
	 * 
	 * @since May 24, 2013
	 * @author sxd8901
	 * @throws InterruptedException
	 */

	public void openHomeDepotTestPage() throws InterruptedException {
		String url = dataTable.getData("URL");
		System.out.println(url);

		System.out.println("Here for Beta connection");

		try {
			driver.get("http://homedepot.com/usebeta.html");
			Alert betaAlert = driver.switchTo().alert();
			betaAlert.accept();
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			Alert betaAlert = driver.switchTo().alert();
			betaAlert.accept();
			driver.switchTo().defaultContent();
		}

		// To click on use the beta connection button
		driver.findElement(By
				.xpath("//button[contains(.,'Use the HD_DC Beta Cookie') or contains(.,'Set Production Beta Cookie')]"))
				.click();
		Thread.sleep(3000);

		try {

			Alert betaAlert = driver.switchTo().alert();
			betaAlert.accept();
			driver.switchTo().defaultContent();

		} catch (Exception e) {

		}
		String currentWin = driver.getWindowHandle();
		Set<String> strBrowsers = driver.getWindowHandles();
		System.out.println(strBrowsers.size());
		strBrowsers.remove(currentWin);
		String strBrowsers1 = strBrowsers.iterator().next();
		driver.switchTo().window(strBrowsers1);
		// driver.get("http://t.homedepot.com/");
		Cookie cookie = new Cookie("HD_DC", "Beta");
		driver.manage().addCookie(cookie);
		System.out.println("Cookie added " + cookie);

	}

	/**
	 * 
	 * Description : verify Foresee page
	 * 
	 * @since June 02, 2014
	 * @author Axr8235
	 * @throws InterruptedException
	 */

	public void verifyForeseePage() throws InterruptedException {
		String strUrl = driver.getCurrentUrl();
		System.out.println(strUrl);

		try {
			if (wh.isElementPresent(foreseepage)) {
				report.addReportStep("Foresee Page should appear",
						"Foresee Page is displayed after opening the URL : <b>" + strUrl + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Foresee Page should appear",
						"Foresee Page is not displayed after opening the URL : <b>" + strUrl + "</b>", StepResult.FAIL);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			report.addReportStep("Foresee Page should appear",
					"Foresee Page is not displayed after opening the URL : <b>" + strUrl + "</b>", StepResult.FAIL);
		}
	}

	/**
	 * Component to enter the quantity in foresee page
	 * 
	 * 
	 * @since June 02, 2014
	 * @author Axr8235
	 * @throws AWTException
	 */
	public void enterBrowseQtyInForeseePg() throws AWTException {
		// String strUrl = dataTable.getData("URL");
		String strUrl = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);
		System.out.println(strUrl);

		String strQty = dataTable.getData("Browse_Qty");

		try {
			if (wh.isElementPresent(foreseeqty)) {
				wh.clearElement(foreseeqty);
				wh.sendKeys(foreseeqty, strQty);
				wh.clickElement(foreseepooling);
				Thread.sleep(100);
				wh.clickUsingActions(foreseeSet);
				// wh.jsClick(foreseeSet);
				Thread.sleep(100);
				commonData.blnGracefulExit = true;

				report.addReportStep("Update the quantity in browse field  and click set button in Foresee page ",
						"Quantity " + strQty + " is entered in  browse field", StepResult.PASS);
			} else {

				report.addReportStep("Update the quantity in browse field  and click set button in Foresee page ",
						"Quantity " + strQty + " not entered in  browse field", StepResult.FAIL);
			}

		} catch (Exception e) {
			report.addReportStep("Update the quantity in browse field  and click set button in Foresee page ",
					"Quantity field is not displayed in  browse field", StepResult.FAIL);
			commonData.blnGracefulExit = true;

		}

		driver.get(strUrl);

	}

	/**
	 * Component to launch the foresee URL
	 * 
	 * 
	 * @since June 02, 2014
	 * @author Axr8235
	 * @throws Exception
	 */
	public void verifyForeseePopup() throws Exception {
		String strURL = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);
		// String strURL = dataTable.getData("URL");

		int intCount = 0;

		while ((!verifyForeseePopupWindow()) && intCount <= 6) {
			driver.get(strURL);
			Thread.sleep(1000);
			intCount++;
		}

	}

	/**
	 * 
	 * Description : verify Foresee pop up window s *
	 * 
	 * @since June 02, 2014
	 * @author Axr8235
	 * @throws Exception
	 */

	public boolean verifyForeseePopupWindow() throws Exception {

		if (wh.isElementPresent(foreseepopup)) {
			report.addReportStep("Foresee Page should appear", "Foresee popup window is displayed in Home page",
					StepResult.PASS);
			return true;

		} else {
			return false;
		}

	}

	/**
	 * Component to click NoThanks Button In Foresee Popup window
	 * 
	 * 
	 * @since June 02, 2014
	 * @author axr8235
	 * @throws InterruptedException
	 */
	public void clickNoThanksBtnInForeseePopup() throws InterruptedException {

		try {
			if (wh.isElementPresent(nothanksforesee)) {
				wh.clickElement(nothanksforesee);
				report.addReportStep("<b>Click NoThanks</b> button in Foresee Popup window",
						"<b>NoThanks</b> button is clicked in Foresee Popup window", StepResult.PASS);
			} else {
				report.addReportStep("<b>Click NoThanks</b> button in Foresee Popup window",
						"<b>NoThanks</b> button is not clicked in Foresee Popup window", StepResult.FAIL);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			report.addReportStep("<b>Click NoThanks</b> button in Foresee Popup window",
					"Unable to find Foresee Popup window", StepResult.FAIL);

		}
	}

	/**
	 * Component to click Yes, I'll give feedback Button In Foresee Popup window
	 * 
	 * 
	 * @since June 02, 2014
	 * @author axr8235
	 * @throws InterruptedException
	 */
	public void clickYesBtnInForeseePopup() throws InterruptedException {

		try {
			if (wh.isElementPresent(yesForesee)) {
				JavascriptExecutor js = null;
				js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].click();",
						driver.findElement(By.xpath("//a[@class='fsrAcceptButton']")));
				report.addReportStep("<b>Click Yes, I'll give feedback</b> button in Foresee Popup window",
						"<b>Yes, I'll give feedback</b> button is clicked in Foresee Popup window", StepResult.PASS);
			} else {
				report.addReportStep("<b>Click Yes, I'll give feedback</b> button in Foresee Popup window",
						"<b>Yes, I'll give feedback</b> button is not clicked in Foresee Popup window",
						StepResult.FAIL);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			report.addReportStep("<b>Click Yes, I'll give feedback</b> button in Foresee Popup window",
					"Unable to find Foresee Popup window", StepResult.FAIL);

		}
	}

	/**
	 * Component to switch handle to the new window opened
	 * 
	 * 
	 * @since Jun 3, 2014
	 * @author PXM8043
	 */
	public void switchWindow() {
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());

		if (tabs.size() > 1) {

			for (int i = 0; i < tabs.size(); i++) {
				String strTitle = driver.switchTo().window(tabs.get(i)).getTitle();

				if (strTitle.toLowerCase().contains("survey")) {
					report.addReportStep("Set Focus on Survey window", "Focus set on survey window", StepResult.PASS);

				} else {
					driver.close();
					report.addReportStep("Close the window with title : " + strTitle + "", "Window Close",
							StepResult.DONE);
				}

			}

		} else {
			report.addReportStep("Verify that there are multiple windows opened", "Multiple are not present",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify Customer Survey Page
	 * 
	 * 
	 * @since June 02, 2014
	 * @author axr8235
	 * @throws Exception
	 */
	public boolean verifyCustSurveyPage() throws Exception {

		if (wh.isElementPresent(foreseeSurveyPage)) {
			report.addReportStep("Verify the Customer Satisfaction Survey page should be displayed ",
					"Customer Satisfaction Survey page is displayed", StepResult.PASS);
			return true;
		} else {
			report.addReportStep("Verify the Customer Satisfaction Survey page should be displayed ",
					"Unable to find the Customer Satisfaction Survey page", StepResult.FAIL);
			return false;
		}

	}

	/**
	 * Component to enter comments in Customer Survey Page
	 * 
	 * 
	 * @since June 02, 2014
	 * @author axr8235
	 * @throws Exception
	 */
	public boolean enterCommentsInCustSurveyPage() throws Exception {

		if (wh.isElementPresent(foreseeComments)) {

			wh.sendKeys(foreseeComments, "Browse");
			report.addReportStep("Verify the comments should be entered in Customer Satisfaction Survey page",
					"Comments entered in feedback field", StepResult.PASS);
			return true;

		} else {
			report.addReportStep("Verify the comments should be entered in Customer Satisfaction Survey page",
					"Comments are not entered in feedback field", StepResult.FAIL);
			return false;
		}
	}

	/**
	 * Component to click on gift card link
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void clickGiftCard() throws Exception {

		if (wh.isElementPresent(lnkgiftCard)) {
			wh.clickElement(lnkgiftCard);
			report.addReportStep("Verify the gift card link", "Gift Card link is displayed and clicked",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify the gift card link", "Gift Card link is not displayed", StepResult.FAIL);
		}
		return;

	}

	/**
	 * Navigate to PLP using flyout
	 * 
	 * @throws Exception
	 */
	public void flyOutNavToPLP() throws Exception {
		if (wh.isElementPresent(headerlogo, 4)) {
			wh.clickElement(headerlogo);

			Thread.sleep(2000);
		}
		// verify flyout dropdown
		if (wh.isElementPresent(headerflyout)) {
			report.addReportStep("Verify flyout drop down", "Flyout drop down is displayed", StepResult.PASS);
		} else {
			wh.clickElement(verifyHomePage);
		}
		String strFlyOut = dataTable.getData("Search_Keyword");
		String strDepartment = strFlyOut.split(">")[0];
		String strSubCategory = strFlyOut.split(">")[1];
		String[] strClickLinks = strFlyOut.split(">");
		// makeBlock(driver.findElement(By.className("switches")));

		Thread.sleep(1000);
		try {
			WebElement element = driver.findElement(By.linkText(strDepartment));
			rc.highlightElement(driver, element);
			// makeBlock(element.findElement(By.xpath("./../div")));
			Actions builder = new Actions(driver);
			builder = new Actions(driver); //
			builder.click(element).build().perform();

			// There is a small lag for window to appear - NXS
			Thread.sleep(1000);

		} catch (NoSuchElementException nsee) {
			System.out.println("no Such" + nsee);
		}
		// Department page

		driver.findElement(By.xpath("//*[@class='linkList l']//li//a[contains(.,'" + strSubCategory + "')]")).click();
		Thread.sleep(2000);

		// Category page
		if (!wh.isElementPresent(By.id("hd_plp"), 5)) {
			driver.findElement(By.xpath("(//ul[contains(@class,'linkList')]//li//a)[1]")).click();
			Thread.sleep(2000);
		}

		if (wh.isElementPresent(allProd, 4)) {
			report.addReportStep("Verify PLP Page is displayed",
					"PLP Page is displayed for the metioned category <b>" + strFlyOut + "</b> ", StepResult.PASS);

		} else {
			report.addReportStep("Verify PLP Page is displayed", "PLP Page is not displayed", StepResult.FAIL);
		}

	}
	
	public void navigateToHomePage() throws Exception {

		if (wh.isElementPresent(headerlogo)) {
			wh.clickElement(headerlogo);
			report.addReportStep("Verify home page is displayed", "Home Page is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify home page is displayed", "Home Page is not displayed", StepResult.FAIL);
		}
		return;

	}
}
