package com.homer.po;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;


public class BSSOverlay extends PageBase<BSSOverlay> {
	
	static final By FSOverlay = By.cssSelector("#smartOverlay");
	static final By FSAddToCartBtn=By.cssSelector("#addToCartContainer .btn.btn-orange");
	static final By TSOverlay=By.id("fancybox-content");
	static final By TSAddToCartBtn=By.xpath("//*[contains(text(),'UPDATE CART')]"); 
	static final By FSTxtItemNotAvail=By.xpath("//div[@class='smrtOv-PgLevlErr btn-clear b']/span");
	static final By FSAddToCart=By.xpath("//a[@class='overlayCartTrigger btn btn-orange']");
	static final By FSZipcodeBox=By.id("smrtSearchInput");
	static final By FSsearchBtn=By.cssSelector("a#smtOvbtnStoreFinder");
	
	
	

	 
	  public BSSOverlay(InstanceContainer ic) {
		super(ic);
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Component to enter qty for BOSS
	 * @throws Exception 
	 */
	public void verifyBSSOverlayForBoss() throws Exception {
		String tablet = HelperClass.readRunConfigProperties("TabletMode");
		
		if (tablet.equalsIgnoreCase("false")) {
			if(wh.isElementPresent(FSOverlay, 10))
			{
				List<WebElement> webOver = driver
						.findElements(By
								.xpath("//div[@class='storeInfo-Col store-Fullfillment']/div[1]"));
				List<WebElement> elemQTY = driver.findElements(By
						.xpath("//*[@id='bssStores']//input[@type='text']"));
				System.out.println(webOver.size());
				boolean blnOverBSS = false;
				boolean blnPIckUp = false;
				for (WebElement web : webOver) {
					String strOverlay = web.getText();
					System.out.println(strOverlay);
					if (strOverlay.contains("Ship To Store")) {
						blnOverBSS = true;
					} else if (strOverlay.contains("Pick Up In Store")) {
						blnPIckUp = true;
					} else if (strOverlay
							.contains("Visit your local store as quantities")) {

					} else {
						//blnOverBSS = false;
						break;
					}
				}
				if (blnOverBSS && blnPIckUp) {
					report.addReportStep(
							"BOSS-BOPIS overlay should be displayed",
							"BOSS-BOPIS overlay is displayed", StepResult.PASS);
				} else {
					report.addReportStep(
							"BOSS-BOPIS overlay should be displayed",
							"BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
				}
				boolean blnSTS = false;
				int i = 0;
				for (WebElement webStock : webOver) {
					System.out.println(webStock.getText());
					if (webStock.getText().contains("Ship To Store")
							&& elemQTY.get(i).isDisplayed()) {
						elemQTY.get(i).clear();
						elemQTY.get(i).sendKeys("1");
						report.addReportStep("Quantity should be entered",
								"Quantity is entered", StepResult.PASS);
						blnSTS = true;
						break;
					}
					i++;
				}
				if (blnSTS) {
					report.addReportStep("Quantity should be enter for STS",
							"Quantity is entered for STS", StepResult.PASS);
				} else {
					report.addReportStep("Quantity should be enter for STS",
							"Quantity is not entered for STS", StepResult.FAIL);
				}
                wh.jsClick(FSAddToCartBtn);
				report.addReportStep(
						"Click <b>add to cart</b> button in the BSS Overlay",
						"<b>Add to cart</b> button is clicked", StepResult.DONE);
			} else {
				report.addReportStep("BOSS-BOPIS overlay should be displayed",
						"BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
			   commonData.blnGracefulExit = true;
			}
		}
		// Tablet
		if (tablet.equalsIgnoreCase("true")) {
			if(wh.isElementPresent(TSOverlay,10))
			{
				List<WebElement> webOver = driver
						.findElements(By
								.xpath("//*[@class='flex align-items-center module-normal border-bottom sborder border-default']//div[contains(@class,'bopis-fulfillment')]"));
				System.out.println(webOver.size());
				List<WebElement> elemQTY = driver
						.findElements(By
								.xpath("//*[@class='flex align-items-center module-normal border-bottom sborder border-default']//input[@class='quantity bopis-input bopis-qty sborder border-all border-secondary']"));
				boolean blnOverBSS = false;
				boolean blnPIckUp = false;
				for (WebElement web : webOver) {
					String strOverlay = web.getText();
					System.out.println(strOverlay);
					if (strOverlay.contains("Ship To Store")) {
						blnOverBSS = true;
					} else if (strOverlay.contains("Pick Up In Store")) {
						blnPIckUp = true;
					} else if (strOverlay
							.contains("Visit your local store as quantities")) {

					} else {
						blnOverBSS = false;
						break;
					}
				}
				if (blnOverBSS && blnPIckUp) {
					report.addReportStep(
							"BOSS-BOPIS overlay should be displayed",
							"BOSS-BOPIS overlay is displayed", StepResult.PASS);
				} else {
					report.addReportStep(
							"BOSS-BOPIS overlay should be displayed",
							"BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
				}
				boolean blnSTS = false;
				int i = 0;
				for (WebElement webStock : webOver) {
					System.out.println(webStock);
					if (webStock.getText().contains("Ship To Store")
							&& elemQTY.get(i).isDisplayed()) {
						elemQTY.get(i).clear();
						elemQTY.get(i).sendKeys("1");
						report.addReportStep("Quantity should be entered",
								"Quantity is entered", StepResult.PASS);
						blnSTS = true;
						break;
					}
					i++;
				}
				if (blnSTS) {
					report.addReportStep("Quantity should be enter for STS",
							"Quantity is entered for STS", StepResult.PASS);
				} else {
					report.addReportStep("Quantity should be enter for STS",
							"Quantity is not entered for STS", StepResult.FAIL);
				}
                wh.isElementPresent(TSAddToCartBtn, 5);
				Thread.sleep(10000);
				report.addReportStep(
						"Click <b>add to cart</b> button in the BSS Overlay",
						"<b>Add to cart</b> button is clicked", StepResult.DONE);
			} else {
				report.addReportStep("BOSS-BOPIS overlay should be displayed",
						"BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		}
	}
	
	
	/**
	 * Component to select Pick up in store
	 * @throws Exception 
	 */
	public void verifyBSSOverlayForBOPIS() throws Exception {
      String tablet = HelperClass.readRunConfigProperties("TabletMode");
      if (tablet.equalsIgnoreCase("false")) {
    	  if(wh.isElementPresent(FSOverlay, 10))
    	  {
    		  List<WebElement> webOver = driver
    				  .findElements(By
    						  .xpath("//div[@class='storeInfo-Col store-Fullfillment']/div[1]"));
    		  List<WebElement> elemQTY = driver.findElements(By
    				  .xpath("//*[@id='bssStores']//input[@type='text']"));
    		  System.out.println(webOver.size());

    		  boolean blnOverBSS = false;
    		  boolean blnPIckUp = false;
    		  for (WebElement web : webOver) {

    			  String strOverlay = web.getText();
    			  System.out.println(strOverlay);
    			  if (strOverlay.contains("Ship To Store")) {
    				  blnOverBSS = true;
    			  } else if (strOverlay.contains("Pick Up In Store")) {
    				  blnPIckUp = true;
    			  } else if (strOverlay
    					  .contains("Visit your local store as quantities")) {

    			  } else {
    				  //blnOverBSS = false;
    				  break;
    			  }
    		  }

    		  if (blnOverBSS && blnPIckUp) {
    			  report.addReportStep(
    					  "BOSS-BOPIS overlay should be displayed",
    					  "BOSS-BOPIS overlay is displayed", StepResult.PASS);
    		  } else {
    			  report.addReportStep(
    					  "BOSS-BOPIS overlay should be displayed",
    					  "BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
    		  }
    		  boolean blnBOPIS = false;
    		  int i = 0;
    		  for (WebElement webStock : webOver) {
    			  System.out.println(webStock);
    			  if (webStock.getText().contains("Pick Up In Store")
    					  && elemQTY.get(i).isDisplayed()) {
    				  elemQTY.get(i).clear();
    				  elemQTY.get(i).sendKeys("1");
    				  report.addReportStep("Quantity should be entered",
    						  "Quantity is entered", StepResult.PASS);
    				  blnBOPIS = true;
    				  break;
    			  }
    			  i++;
    		  }
    		  if (blnBOPIS) {
    			  report.addReportStep("Quantity should be enter for BOPIS",
    					  "Quantity is entered for BOPIS", StepResult.PASS);
    		  } else {
    			  report.addReportStep("Quantity should be enter for BOPIS",
    					  "Quantity is not entered for BOPIS", StepResult.FAIL);
    		  }
    		  wh.jsClick(FSAddToCartBtn);
    		  report.addReportStep(
    				  "Click <b>add to cart</b> button in the BSS Overlay",
    				  "<b>Add to cart</b> button is clicked", StepResult.DONE);
    	  }
    	  else {
    		  report.addReportStep("BOSS-BOPIS overlay should be displayed",
    				  "BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
    		  commonData.blnGracefulExit = true;
    	  }
      }
		if (tablet.equalsIgnoreCase("true")) {
			if(wh.isElementPresent(TSOverlay, 10))
			{
				List<WebElement> webOver = driver
						.findElements(By
								.xpath("//*[@class='flex align-items-center module-normal border-bottom sborder border-default']//div[contains(@class,'bopis-fulfillment')]"));
				List<WebElement> elemQTY = driver
						.findElements(By
								.xpath("//*[@class='flex align-items-center module-normal border-bottom sborder border-default']//input[@class='quantity bopis-input bopis-qty sborder border-all border-secondary']"));
				System.out.println(webOver.size());

				boolean blnOverBSS = false;
				boolean blnPIckUp = false;
				for (WebElement web : webOver) {

					String strOverlay = web.getText();
					System.out.println(strOverlay);
					if (strOverlay.contains("Ship To Store")) {
						blnOverBSS = true;
					} else if (strOverlay.contains("Pick Up In Store")) {
						blnPIckUp = true;
					} else if (strOverlay
							.contains("Visit your local store as quantities")) {

					} else {
						blnOverBSS = false;
						break;
					}
				}
				if (blnOverBSS && blnPIckUp) {
					report.addReportStep(
							"BOSS-BOPIS overlay should be displayed",
							"BOSS-BOPIS overlay is displayed", StepResult.PASS);
				} else {
					report.addReportStep(
							"BOSS-BOPIS overlay should be displayed",
							"BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
				}
				boolean blnBOPIS = false;
				int i = 0;
				for (WebElement webStock : webOver) {
					System.out.println(webStock);
					if (webStock.getText().contains("Pick Up In Store")
							&& elemQTY.get(i).isDisplayed()) {
						elemQTY.get(i).clear();
						elemQTY.get(i).sendKeys("1");
						report.addReportStep("Quantity should be entered",
								"Quantity is entered", StepResult.PASS);
						blnBOPIS = true;
						break;
					}
					i++;
				}
				if (blnBOPIS) {
					report.addReportStep("Quantity should be enter for BOPIS",
							"Quantity is entered for BOPIS", StepResult.PASS);
				} else {
					report.addReportStep("Quantity should be enter for BOPIS",
							"Quantity is not entered for BOPIS", StepResult.FAIL);
				}
                wh.jsClick(TSAddToCartBtn);
				report.addReportStep(
						"Click <b>add to cart</b> button in the BSS Overlay",
						"<b>Add to cart</b> button is clicked", StepResult.DONE);
			} else {
				report.addReportStep("BOSS-BOPIS overlay should be displayed",
						"BOSS-BOPIS overlay is not displayed", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}

		}

	}

	
	/**
	 * Component to verify the smart overlay text "This item is not available in any store" and Click on ADD to CART
	 * @throws Exception 
	 */
	public void verifyBopisSmartOverlay() throws Exception{
		String getText="";
		if(wh.isElementPresent(FSOverlay, 10)){
			getText=wh.getText(FSTxtItemNotAvail);
			if(getText.contains("This item is not available in any stores within 100 miles")){
				report.addReportStepWithScreenshots("Verify the text Message in Overlay", "Mmessage is displayed as : "+getText, StepResult.PASS);

				//Click on ADD to CART Button
				wh.jsClick(FSAddToCart);
				report.addReportStep(
						"Click <b>add to cart</b> button in the BSS Overlay",
						"<b>Add to cart</b> button is clicked", StepResult.DONE);
				
			} else {
				report.addReportStep("Verify the text in BSS Overlay", "Expected text is not displayed", StepResult.FAIL);
			}
		}
		
	}
	
}
