package com.homer.po;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class ScheduleDeliveryPage extends PageBase<HomePage> {

	static final By scheduleDeliveryPageTitle = By.xpath("//h3[contains(text(),'Express Delivery from Store')]");
	static final By sysUnavailErrMsg = By
			.xpath("//h3[contains(text(),'Sorry, the system is currently unavailable and a delivery cannot be scheduled at this time')]");
	static final By clickBackToCart = By.xpath("//a[contains(text(),'back to cart')]");
	static final By btnBack = By.xpath("//a[contains(text(),'Back')]");
	static final By specialInstructionBox = By.id("specialInstructions");
	static final By expDelTxt = By.xpath("//span[contains(text(),'Express Delivery from Store:')]");
	static final By limQtyErrMsg = By
			.xpath("//span[contains(text(),'Sorry, some items in your order have  limited availability for delivery')]");
	static final By scheduleDeliveryDate = By.id("scheduledDeliveryDate");
	static final By changeCalendarBtn = By
			.xpath("//*[@id='scheduleDeliverySection']//span[contains(@class,'view-calendar') and text()='change']");
	static final By noCalendarTxt = By
			.xpath("//*[@class='bodfs-options']//div[@class='flex no-calendar-bodfs-delivery']");
	static final By datePickerModal = By.xpath("//*[@id='scheduleDatePickerModal' and contains(@class,'md-show')]");
	static final By servicelevelDropDown = By
			.xpath("//*[@id='scheduleDatePickerModal' and contains(@class,'md-show')]//select[@id='servicelevel-select']");
	static final By continueBtnCalOverlay = By
			.xpath("//*[@id='scheduleDatePickerModal' and contains(@class,'md-show')]//*[@id='apply-scheduled-date']");
	static final By scheduleDeliveryInstructionTxt = By
			.xpath("//ul[contains(@class,'scheduledDeliveryInstruction ')]//li");
	static final By SchDeliverAddress1 = By.name("address1");
	static final By SchDeliverAddress2 = By.name("address2");
	static final By continueBtnScheduleDelivery = By
			.xpath("//a[contains(@class,'sliderNextButton')]/span[contains(text(),'CONTINUE')]");
	static final By poBoxErrMsg = By.xpath("//*[contains(text(),'Orders cannot be shipped to a P.O.Box.')]");
	static final By addNewAddressLink = By.xpath("//a[contains(text(),'add new address')]");
	static final By addAddressOverlay = By.xpath("//*[@id='add-address-overlay']");
	static final By editAddressOverlay = By.xpath("//*[@id='edit-address-overlay']");
	static final By editAddressLink = By.xpath("//a[contains(text(),'edit this address')]");
	static final By newAddressForm = By.xpath("//*[@id='add-address-overlay']//*[@class='address-form']");
	static final By fNameAddOverlay = By.xpath("//*[@id='add-address-overlay']//input[@name='firstName']");
	static final By LNameAddOverlay = By.xpath("//*[@id='add-address-overlay']//input[@name='lastName']");
	static final By Add1AddOverlay = By.xpath("//*[@id='add-address-overlay']//input[@name='address1']");
	static final By zipcodeAddOverlay = By.xpath("//*[@id='add-address-overlay']//input[@name='zipcode']");
	static final By PhAddOverlay = By.xpath("//*[@id='add-address-overlay']//input[@name='phone']");
	static final By saveBtnNewAddOverlay = By.xpath("//*[@id='add-address-overlay']//a[text()='SAVE']");
	static final By fNameErrMsg = By.xpath("//*[@for='firstName']");
	static final By lNameErrMsg = By.xpath("//*[@for='lastName']");
	static final By add1ErrMsg = By.xpath("//*[@for='address1']");
	static final By phoneErrMsg = By.xpath("//*[@for='phone']");
	static final By deliveryReservationTxt = By.xpath("//*[text()='Delivery Reservation']");
	static final By radioYesDeliveryUnattended = By
			.xpath("//*[@class='canBLeftUnattendedDiv']//label[@for='left-unattended-yes']");
	static final By deliveryUnattendedTxt = By
			.xpath("//*[@id='scheduleCalendar']//*[contains(text(),'The delivery will be left unattended.')]");
	static final By changeLink = By.xpath("//span[contains(text(),'change')]");
	static final By outsideDelivery = By.xpath("//*[@id='scheduledServiceLevel']");
	static final By outsideDelServiceText = By.xpath("//*[contains(@class,'scheduledDeliveryInstruction')]//li");
	static final By outsideDelServiceTextInCalendar = By.xpath("//*[@class='bodfscal_left_instruction']");
	static final By thresholdDelInCalendar = By.xpath("//button[@class='select-servicelevel-label']");
	static final By delveryPrice = By.xpath("//*[contains(text(),'Express Delivery :')]/../h4[2]");
	static final By bodfsAddrPhone = By.xpath("//h3[contains(text(),'Appliance Delivery')]/..//label[contains(text(),'Last Name')]/../following-sibling::div[2]");
	static final By bodfsAddr = By.xpath("//span[contains(text(),'Express Delivery from Store:')]/../../h3[2]");
	static final By Add1EditOverlay = By.xpath("//*[@id='edit-address-overlay']//input[@name='address1']");
	static final By BodfsOptionsSection=By.xpath("//*[@class='bodfs-options']");
	static final By colorOption=By.xpath("//*[@class='flex no-calendar-bodfs-delivery']");
	static final By FontSize=By.xpath("//*[@class='flex no-calendar-bodfs-delivery']");
	static final By TextMsg=By.xpath("//*[@class='flex no-calendar-bodfs-delivery']");
	static final By ScheduleDlvryTxt=By.xpath("//*[contains(text(),'Suggested Delivery')]");
	static final By updateBtnEditOverlay = By.xpath("//a[@class='btn btn-gray edit-address-button md-submit']");
	
	public ScheduleDeliveryPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify Schedule delivery Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ScheduleDeliveryPage verifyScheduleDeliveryPage() throws Exception {

		wh.waitForPageLoaded();
		Thread.sleep(5000);
		wh.waitForElementPresent(scheduleDeliveryPageTitle, 5);

		if (wh.isElementPresent(scheduleDeliveryPageTitle, 2)) {
			wh.waitForPageLoaded();

			report.addReportStep("Verify Schedule Delivery page is displayed", "Schedule Delivery page is displayed",
					StepResult.PASS);
		} else {

			report.addReportStep("Verify Schedule Delivery page is displayed",
					"Schedule Delivery page is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Schedule Delivery page");
		}

		return this;
	}

	/**
	 * Method to verify system unavail error message
	 * 
	 * @return
	 * @throws Exception
	 */
	public ScheduleDeliveryPage verifySystemUnavailErrMsg() throws Exception {

		if (wh.isElementPresent(sysUnavailErrMsg, 2)) {
			String errMsg = driver.findElement(sysUnavailErrMsg).getText();
			if (errMsg
					.contains("Sorry, the system is currently unavailable and a delivery cannot be scheduled at this time.")) {
				report.addReportStep("Verify the system unavailable error message is displayed", "Error message<b>"
						+ errMsg + "</b>is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify the system unavailable error message is displayed", "Error message<b>"
						+ errMsg + "</b>is not  displayed properly", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify the system unavailable error message is displayed",
					"Error message page is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to Click back to cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ScheduleDeliveryPage clickBackToCart() throws Exception {

		if (wh.isElementPresent(clickBackToCart, 2)) {
			wh.clickElement(clickBackToCart);

			report.addReportStep("Verify Back To Cart button is clicked in Schedule Delivery page",
					"Back To Cart button is clicked in Schedule Delivery page", StepResult.PASS);
		} else {

			report.addReportStep("Verify Back To Cart button is clicked in Schedule Delivery page",
					"Back To Cart button is not clicked in Schedule Delivery page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-click back button on Express delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage clickBackButton() throws Exception {

		if (wh.isElementPresent(btnBack, 5)) {
			wh.clickElement(btnBack);

			report.addReportStep("Verify Back button is clicked in Schedule Delivery page",
					"Back button is clicked in Schedule Delivery page", StepResult.PASS);
		} else {

			report.addReportStep("Verify Back button is clicked in Schedule Delivery page",
					"Back button is not clicked in Schedule Delivery page", StepResult.FAIL);
			rc.terminateTestCase("Back Button on Schedule Delivery page");
		}

		return this;
	}

	/**
	 * Description-verify max char entry '255'char in Special Instruction field
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage VerifyMaxCharEntryInSpecialInstField() throws Exception {

		int iLen;
		wh.waitForPageLoaded();

		if (wh.isElementPresent(specialInstructionBox, 20)) {

			String strMaxChar = RandomStringUtils.randomAlphabetic(256);
			wh.sendKeys(specialInstructionBox, strMaxChar);
			wh.waitForPageLoaded();

			if (commonData.desktopUserAgent) {
				iLen = wh.getAttribute(specialInstructionBox, "value").length();

			} else { // for device emulator not fetching the correct value
				iLen = Integer.parseInt(wh.getAttribute(specialInstructionBox, "maxlength"));
			}

			if (iLen == 255) {
				report.addReportStep(
						"Verify User is allowed to enter maximum of 255 char in special instruction field",
						"Successfully able to enter max of " + iLen + " char in special instruction field",
						StepResult.PASS);

			} else if (iLen > 255) {
				report.addReportStep(
						"Verify User is allowed to enter maximum of 255 char in special instruction field",
						"User is allwoed to enter after max of 255 char,user is allowed to enter '" + iLen
								+ "' char in special instruction field", StepResult.FAIL);

			} else {

				report.addReportStep(
						"Verify User is allowed to enter maximum of 255 char in special instruction field",
						"User is not allwoed to enter max of 255 char,user is only allowed to enter '" + iLen
								+ "' char in special instruction field", StepResult.FAIL);
			}

		} else {

			report.addReportStep(
					"Verify User is allowed to enter maximum of 255 char in special instruction field",
					"Unable to verify max char entry, Special Instruction Field is not present on Express Delivery page",
					StepResult.FAIL);
			rc.terminateTestCase("Special Instruction Field");

		}

		return this;
	}

	/**
	 * Description-verify exceeding max char entry '256'char in Special
	 * Instruction field
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage VerifyExceedingMaxCharLimitInSpecialInstField() throws Exception {

		if (wh.isElementPresent(specialInstructionBox, 2)) {

			String strMaxChar = RandomStringUtils.randomAlphabetic(256);
			wh.sendKeys(specialInstructionBox, strMaxChar);
			wh.waitForPageLoaded();
			int iLength = wh.getAttribute(specialInstructionBox, "value").trim().length();
			if (iLength == 255) {
				report.addReportStep(
						"Verify User is not allowed to enter after max of 255 char in special instruction field",
						"User is not allwoed to enter beyond 255 char in special instruction field", StepResult.PASS);

			} else if (iLength > 255) {
				report.addReportStep(
						"Verify User is not allowed to enter after max of 255 char in special instruction field",
						"User is allwoed to enter after max of 255 char,user is allowed to enter '" + iLength
								+ "' char in special instruction field", StepResult.FAIL);

			} else {
				report.addReportStep(
						"Verify User is not allowed to enter after max of 255 char in special instruction field",
						"User is not allwoed to enter max of 255 char,user is only allowed to enter '" + iLength
								+ "' char in special instruction field", StepResult.FAIL);
			}

		} else {

			report.addReportStep(
					"Verify User is allowed to enter maximum of 255 char in special instruction field",
					"Unable to verify max char entery, Special Instruction Field is not present on Express Delivery page",
					StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Method to verify right rail express delivery text
	 * 
	 * @return
	 * @throws Exception
	 */
	public ScheduleDeliveryPage rightRailExpressDelTxt() throws Exception {

		if (wh.isElementPresent(expDelTxt, 2)) {
			String expDeliveryTxt = driver.findElement(expDelTxt).getText();
			if (expDeliveryTxt.contains("Express Delivery from Store:")) {
				report.addReportStep(
						"Verify that Express Delivery From Store text in right rail is displayed in Schedule Delivery page",
						"In right rail<b>" + expDeliveryTxt + "</b>text is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify that Express Delivery From Store text in right rail is displayed in Schedule Delivery page",
						"In right rail<b>" + expDeliveryTxt + "</b>text is not displayed properly", StepResult.FAIL);
			}
		} else {

			report.addReportStep(
					"Verify that Express Delivery From Store text in right rail is displayed in Schedule Delivery page",
					"In right rail express delivery text is not displayed", StepResult.PASS);
		}

		return this;
	}

	/**
	 * Method to verify limit quantity error message
	 * 
	 * @return
	 * @throws Exception
	 */
	public ScheduleDeliveryPage verifyLimitQtyErrMsg() throws Exception {

		if (wh.isElementPresent(limQtyErrMsg, 2)) {
			String errMsg = driver.findElement(limQtyErrMsg).getText();
			if (errMsg
					.contains("Sorry, some items in your order have limited availability for delivery in the selected ZIP code. Please go back to cart and update your quantity or select another fulfillment method.")) {
				report.addReportStep("Verify the limited quantity error message is displayed", "Error message<b>"
						+ errMsg + "</b>is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify the limited quantity error message is displayed", "Error message<b>"
						+ errMsg + "</b>is not  displayed properly", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify the  limited quantity error message is displayed",
					"Error message page is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to enter scheduled delivery address
	 * 
	 * @return
	 * @throws Exception
	 */
	public ScheduleDeliveryPage enterScheduledDeliveryAddressMCC() throws Exception {

		if (wh.isElementPresent(By.xpath("//h3[contains(text(),'Express Delivery from Store')]"), 4)) {
			report.addReportStep("Verify Scheduled Delivery Address field section is displayed",
					"<b>Scheduled Delivery Address field</b> section is displayed", StepResult.PASS);

			String firstName = dataTable.getCommonData(CommonDataColumn.ShippingFirstName);
			String lastName = dataTable.getCommonData(CommonDataColumn.ShippingLastName);
			String sPhonenum = dataTable.getCommonData(CommonDataColumn.ShippingPhNo);
			String strAddress1 = dataTable.getCommonData(CommonDataColumn.ShippingAddr);
			String strZIPcode = "";
			if (wh.isElementPresent(By.name("firstName"), 2)) {

				wh.sendKeys(By.name("firstName"), firstName);
				wh.waitForPageLoaded();
				wh.sendKeys(By.name("lastName"), lastName);
				wh.waitForPageLoaded();
				wh.sendKeys(By.name("address1"), strAddress1);
				wh.waitForPageLoaded();
				if (wh.isElementPresent(By.cssSelector("input.phone.valid-phone"))) {
					wh.sendKeys(By.cssSelector("input.phone.valid-phone"), sPhonenum);
					report.addReportStep("<b>Enter the Phone Number value</b>", "Phone Number: <b>" + sPhonenum
							+ "</b> entered", StepResult.PASS);
				}
				try {
					strZIPcode = driver.findElement(By.cssSelector("input.zipcode-lookup.zipcode")).getText().trim();

				} catch (Exception e) {
					report.addReportStep("Validate teh ZIPcode in Scheduled delivery address page", "Zipcode <b>"
							+ strZIPcode + "</b> is not prepopulated", StepResult.FAIL);
				}

			} else {

				String strAddress = "";
				if (wh.isElementPresent(By.xpath("//div[@id='savedAddresssection_0']/p"), 7)) {
					strAddress = driver.findElement(By.xpath("//div[@id='savedAddresssection_0']/p")).getText();
					report.addReportStep("Enter the Address in Scheduled Delivery Address page", "Address: <b>"
							+ strAddress + "</b> was default selected in Scheduled Delivery Address page",
							StepResult.PASS);
				}

				else {
					report.addReportStep("Enter the Address in Scheduled Delivery Address page", "Address: <b>"
							+ strAddress
							+ "Unable to validate the address populated in Scheduled Delivery Address page",
							StepResult.FAIL);
				}
			}
		}

		else {
			report.addReportStep("Verify  Scheduled Delivery Address field section is displayed",
					"<b>Scheduled Delivery Address field</b> section is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description-verify and select calendar on Schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage clickCalendar() throws Exception {

		if (wh.isElementPresent(noCalendarTxt, 5)) {
			report.addReportStep(
					"Verify calendar link is clicked in schedule delivery page",
					"Calendar is not displayed in schedule delivery page <br /> Failure reason:"
							+ wh.getText(noCalendarTxt), StepResult.FAIL);
			rc.terminateTestCase("Calendar");
		} else if (wh.isElementPresent(scheduleDeliveryDate, 5) && wh.isElementPresent(changeCalendarBtn, 5)) {
			wh.clickElement(changeCalendarBtn);
			report.addReportStep("Verify calendar link is clicked in schedule delivery page",
					"Calendar link is clicked in schedule delivery page", StepResult.PASS);

		} else {
			report.addReportStep("Verify calendar link is clicked in schedule delivery page",
					"Calendar link is not displayed in schedule delivery page", StepResult.FAIL);
			rc.terminateTestCase("Calendar");
		}

		return this;
	}

	/**
	 * Description-verify Calendar Overlay displayed
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage VerifyCalendarOverlay() throws Exception {

		if (wh.isElementPresent(datePickerModal, 7)) {
			report.addReportStep("Verify calendar date picker overlay displayed",
					"Calendar date picker overlay is displayed", StepResult.PASS);

		} else {
			report.addReportStep("Verify calendar date picker overlay displayed",
					"Calendar date picker overlay is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Calendar overlay");
		}
		return this;
	}

	/**
	 * Description-To select service level in calendar overlay
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage selectServiceLevelCalendarOverlay() throws Exception {
		Boolean isSelected = false;
		String strServiceToSelect = commonData.serviceLevelToSelect;

		// if(wh.isElementPresent(servicelevelDropDown, 2)){
		try {

			Select drop = new Select(driver.findElement(servicelevelDropDown));
			if (drop.getFirstSelectedOption().getText().contains(strServiceToSelect)) {
				report.addReportStep(
						"Select service level <b>" + strServiceToSelect + "</b> in calendar overlay",
						"Service level <b>" + strServiceToSelect + "</b> is selected and displayed in calendar overlay",
						StepResult.PASS);

			} else {

				List<WebElement> options = drop.getOptions();
				for (WebElement option : options) {

					String strDropOption = option.getText();

					if (strDropOption.contains(strServiceToSelect)) {
						drop.selectByVisibleText(strDropOption);
						isSelected = true;
						// drop.getFirstSelectedOption().getText();
						report.addReportStep("Select service level <b>" + strServiceToSelect
								+ "</b> in calendar overlay", "Service level <b>" + strServiceToSelect
								+ "</b> is selected and displayed in calendar overlay", StepResult.PASS);
						break;
					}

				}

				if (!isSelected) {
					report.addReportStep("Select service level <b>" + strServiceToSelect + "</b> in calendar overlay",
							"Service level <b>" + strServiceToSelect
									+ "</b> is not available in service level drop down", StepResult.FAIL);
				}

			}

		} catch (Exception e) {
			report.addReportStep("Select service level <b>" + strServiceToSelect + "</b> in calendar overlay",
					"Service level drop down is not displayed in calendar overlay", StepResult.FAIL);
		}

		/*
		 * }else{ report.addReportStep(
		 * "Select service level <b>"+strServiceToSelect
		 * +"</b> in calendar overlay",
		 * "Service level drop down is not displayed in calendar overlay",
		 * StepResult.FAIL); }
		 */

		return this;

	}

	/**
	 * Description-Select continue button calendar overlay
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage clickContinueCalenderOverlay() throws Exception {

		if (wh.isElementPresent(continueBtnCalOverlay, 2)) {
			wh.jsClick(continueBtnCalOverlay);
			report.addReportStep("Verify Continue button is clicked in calendar overlay",
					"Continue button is clicked in calendar overlay", StepResult.PASS);

			if (!wh.isElementNotPresent(datePickerModal)) {

				report.addReportStep("Verify Continue button is selected in calendar overlay",
						"Continue button clicked,Calendar overlay did not close", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Continue button is selected in calendar overlay",
					"Continue button is not displayed in calendar overlay", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Verify Adult text must be present in schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyAdultTextScheduleDelivery() throws Exception {

		String strAdultTxtToVerify = commonData.adultText;
		Boolean nAdultTxtFound = false;

		if (strAdultTxtToVerify.isEmpty()) {
			strAdultTxtToVerify = "An adult must be present for delivery.";
		}

		List<WebElement> webElms = wh.getElements(scheduleDeliveryInstructionTxt);
		if (webElms.size() > 0) {

			for (WebElement wElm : webElms) {

				if (wElm.getText().contains(strAdultTxtToVerify)) {
					nAdultTxtFound = true;
					report.addReportStep("Verify Adult Text:'" + strAdultTxtToVerify
							+ "' is displayed in schedule delivery page", "Adult text '" + wElm.getText()
							+ "' is displayed in schedule delivery page", StepResult.PASS);
					break;
				}
			}
			if (!nAdultTxtFound) {
				report.addReportStep("Verify Adult Text:'" + strAdultTxtToVerify
						+ "' is displayed in schedule delivery page", "Adult text not found in schedule delivery page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Adult Text:'" + strAdultTxtToVerify
					+ "' is displayed in schedule delivery page", "Adult text not found in schedule delivery page",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description-Enter PO box in schedule delivery address field
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage EnterPOBoxInAddressLine() throws Exception {

		if (wh.isElementPresent(SchDeliverAddress1) && wh.isElementPresent(SchDeliverAddress2)) {

			wh.sendKeys(SchDeliverAddress1, "P.O Box");
			wh.sendKeys(SchDeliverAddress2, "P.O Box");
			report.addReportStep("Enter text 'P.O Box' in Address1 and Address2 field",
					"P.O Box text entered in Address1 and Address2 fields", StepResult.PASS);

		} else {
			report.addReportStep("Enter text 'P.O Box' in Address1 and Address2 field",
					"Address1 or Address2 fields are not displayed in Schedule delivery page", StepResult.FAIL);

		}

		return this;

	}

	/**
	 * Description-Click Continue button on Schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage clickContinueScheduleDelivery() throws Exception {

		if (wh.isElementPresent(continueBtnScheduleDelivery)) {
			wh.jsClick(continueBtnScheduleDelivery);
			Thread.sleep(5000);
			report.addReportStep("Verify Continue button is clicked in the Scheduled Delivery page.",
					"Continue button is clicked in the Scheduled Delivery page ", StepResult.PASS);
		} else {
			report.addReportStep("<b>Verify Continue button is clicked in the Scheduled Delivery page.",
					"Continue button is not clicked in the Scheduled Delivery page ", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description-Verify Orders cannot be shipped to a P.O.Box error message
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyPOBoxErrMsg() throws Exception {

		if (wh.isElementPresent(poBoxErrMsg, 5)) {

			if (wh.getText(poBoxErrMsg).trim().contains("Orders cannot be shipped to a P.O.Box.")) {
				report.addReportStep(
						"Verify <b>Orders cannot be shipped to a P.O.Box</b> error message should be displayed ",
						"Error Message <b>Orders cannot be shipped to a P.O.Box</b> is displayed in schedule delivery page",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify <b>Orders cannot be shipped to a P.O.Box</b> error message should be displayed ",
						"Error Message <b>Orders cannot be shipped to a P.O.Box</b> is not displayed in schedule delivery page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify <b>Orders cannot be shipped to a P.O.Box</b> error message should be displayed ",
					"Error Message <b>Orders cannot be shipped to a P.O.Box</b> is not displayed in schedule delivery page",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description-Component to click on add new address link on schedule
	 * delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage clickAddNewAddrLink() throws Exception {
		if (wh.isElementPresent(addNewAddressLink, 5)) {
			wh.clickElement(addNewAddressLink);

			report.addReportStep("Click on Add New address link", "Add New Address link is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on Add New address link", "Add New Address link is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to verify add address overlay on schedule delivery
	 * page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyAddAddressOverlay() throws Exception {

		if (wh.isElementPresent(addAddressOverlay, 5)) {

			report.addReportStep("Verify Add Address overlay displayed", "Add Address overlay is displayed",
					StepResult.PASS);

			// /Check for blank fields...

		} else {
			report.addReportStep("Verify Add Address overlay displayed", "Add Address overlay is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to set all fields to default on add address overlay
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage defaultAddressSectionNewAddOverlay() throws Exception {

		if (wh.isElementPresent(newAddressForm)) {
			report.addReportStep("Verify Scheduled Delivery Address field section is displayed",
					"<b>Scheduled Delivery Address field</b> section is displayed", StepResult.PASS);

			String strZipCode = dataTable.getData("ZipCode");

			// String strCity = dataTable.getData("BODFS_City");
			// String strState = dataTable.getData("BODFS_State");
			String strZIPcode = "";

			if (wh.isElementPresent(fNameAddOverlay)) {
				wh.clearElement(fNameAddOverlay);
				report.addReportStep("Verify <b>First Name </b> field is present and is blank",
						"<b>First Name </b> field is present and is blank", StepResult.PASS);
			} else {
				report.addReportStep("Verify <b>First Name </b> field is present",
						"<b>First Name </b> field is not present", StepResult.FAIL);
			}

			if (wh.isElementPresent(LNameAddOverlay)) {
				wh.clearElement(LNameAddOverlay);
				report.addReportStep("Verify <b>Last Name </b> field is present and is blank",
						"<b>Last Name </b> field is present and is blank", StepResult.PASS);
			} else {
				report.addReportStep("Verify <b>Last Name </b> field is present",
						"<b>Last Name </b> field is not present", StepResult.FAIL);
			}
			if (wh.isElementPresent(Add1AddOverlay)) {
				wh.clearElement(Add1AddOverlay);
				report.addReportStep("Verify <b>address</b> field is present and is blank",
						"<b>Address </b> field is present and is blank", StepResult.PASS);
			} else {
				report.addReportStep("Verify <b>address</b> field is present", "<b>Address </b> field is not present",
						StepResult.FAIL);
			}

			if (wh.isElementPresent(PhAddOverlay)) {
				wh.clearElement(PhAddOverlay);
				report.addReportStep("Verify <b>phone number</b> field is present and is blank",
						"<b>Phone Number </b> field is present and is blank", StepResult.PASS);
			} else {
				report.addReportStep("Verify <b>phone number</b> field is present",
						"<b>Phone Number </b> field is not present", StepResult.FAIL);
			}

			try {

				strZIPcode = wh.getAttribute(zipcodeAddOverlay, "value").trim();
				// System.out.println(strZIPcode);
				if (strZIPcode.contains(strZipCode)) {
					report.addReportStep("Verify the ZIPcode is prepopulated", "Zipcode <b>" + strZIPcode
							+ "</b> is prepopulated", StepResult.PASS);
				} else {
					report.addReportStep("Verify the ZIPcode is prepopulated", "Zipcode <b>" + strZIPcode
							+ "</b> is not same as in PIP page ", StepResult.FAIL);

				}
			} catch (Exception e) {
				report.addReportStep("Verify the ZIPcode is prepopulated", "Zipcode <b>" + strZIPcode
						+ "</b> is not prepopulated", StepResult.FAIL);

			}

		}

		else {
			report.addReportStep("Verify Scheduled Delivery Address field section is displayed",
					"<b>Scheduled Delivery Address field</b> section is not displayed", StepResult.FAIL);

		}

		return this;

	}

	/**
	 * Description-Component to enter first name in add address overlay on
	 * schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage EnterFnameNewAddOverlay() throws Exception {

		if (wh.isElementPresent(fNameAddOverlay, 5)) {
			wh.sendKeys(fNameAddOverlay, "FName");

			report.addReportStep("Enter First Name in Add Address Overlay", "First Name entered", StepResult.PASS);

		} else {
			report.addReportStep("Enter First Name in Add Address Overlay", "First Name field is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to enter Last name in add address overlay on
	 * schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage EnterLnameNewAddOverlay() throws Exception {

		if (wh.isElementPresent(LNameAddOverlay, 5)) {
			wh.sendKeys(LNameAddOverlay, "LName");

			report.addReportStep("Enter Last Name in Add Address Overlay", "Last Name entered", StepResult.PASS);

		} else {
			report.addReportStep("Enter Last Name in Add Address Overlay", "Last Name field is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to enter Address1 in add address overlay on
	 * schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage EnterAdd1NewAddOverlay() throws Exception {

		if (wh.isElementPresent(Add1AddOverlay, 5)) {
			String newAddr = "Addr1";
			wh.sendKeys(Add1AddOverlay, newAddr);
			commonData.bodfsAddress = newAddr;
			report.addReportStep("Enter Address1 in Add Address Overlay", "Address1 entered", StepResult.PASS);

		} else {
			report.addReportStep("Enter Address1 in Add Address Overlay", "Address1 field is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to enter Phone number in add address overlay on
	 * schedule delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage EnterPhoneNewAddOverlay() throws Exception {

		if (wh.isElementPresent(PhAddOverlay, 5)) {
			wh.sendKeys(PhAddOverlay, "7372476300");

			report.addReportStep("Enter Phone number in Add Address Overlay", "Phone number entered", StepResult.PASS);

		} else {
			report.addReportStep("Enter Phone number in Add Address Overlay", "Phone field is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-click back button on Express delivery page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage clickSaveButtonNewAddOverlay() throws Exception {

		if (wh.isElementPresent(saveBtnNewAddOverlay, 5)) {
			wh.clickElement(saveBtnNewAddOverlay);

			report.addReportStep("Verify Save button is clicked in Add Address Overlay",
					"Save button is clicked in Add Address Overlay", StepResult.PASS);
		} else {

			report.addReportStep("Verify Save button is clicked in Add Address Overlay",
					"Save button is not found in Add Address Overlay", StepResult.FAIL);

			rc.terminateTestCase("Save Button on Add Address Overlay");
		}

		return this;
	}

	/**
	 * Description-Component to verify error message for First name
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgFName() throws Exception {

		Thread.sleep(200);

		if (wh.isElementPresent(fNameErrMsg)) {
			if (wh.getText(fNameErrMsg).trim().equals("First name is required. Please enter your first name")) {

				report.addReportStep(
						"Verify Error message :<b>First name is required. Please enter your first name</b> is displayed",
						"Error message is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Error message :<b>First name is required. Please enter your first name</b> is displayed",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify Error message :<b>First name is required. Please enter your first name</b> is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to verify error message for Last name
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgLName() throws Exception {

		Thread.sleep(200);

		if (wh.isElementPresent(lNameErrMsg)) {
			if (wh.getText(lNameErrMsg).trim().equals("Last name is required. Please enter your last name")) {

				report.addReportStep(
						"Verify Error message :<b>Last name is required. Please enter your last name</b> is displayed",
						"Error message is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Error message :<b>Last name is required. Please enter your last name</b> is displayed",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify Error message :<b>Last name is required. Please enter your last name</b> is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to verify error message for Address1
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgAdd1() throws Exception {

		Thread.sleep(200);

		if (wh.isElementPresent(add1ErrMsg)) {
			if (wh.getText(add1ErrMsg).trim().equals("Address Line 1 required. Please enter your address")) {

				report.addReportStep(
						"Verify Error message :<b>Address Line 1 required. Please enter your address</b> is displayed",
						"Error message is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Error message :<b>Address Line 1 required. Please enter your address</b> is displayed",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify Error message :<b>Address Line 1 required. Please enter your address</b> is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to verify error message for Phone number
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgPhone() throws Exception {

		Thread.sleep(200);

		if (wh.isElementPresent(phoneErrMsg)) {
			if (wh.getText(phoneErrMsg).trim().equals("Phone is required. Please enter your phone number")) {

				report.addReportStep(
						"Verify Error message :<b>Phone is required. Please enter your phone number</b> is displayed",
						"Error message is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Error message :<b>Phone is required. Please enter your phone number</b> is displayed",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify Error message :<b>Phone is required. Please enter your phone number</b> is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description-Component to verify error message for last name address and
	 * phone
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgLNameAddress1Ph() throws Exception {

		verifyErrorMsgLName();
		verifyErrorMsgAdd1();
		verifyErrorMsgPhone();

		return this;
	}

	/**
	 * Description-Component to verify error message for First name address and
	 * phone
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgFNameAddress1Ph() throws Exception {

		verifyErrorMsgFName();
		verifyErrorMsgAdd1();
		verifyErrorMsgPhone();

		return this;
	}

	/**
	 * Description-Component to verify error message for First name address and
	 * phone
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgFNameLNamePh() throws Exception {

		verifyErrorMsgFName();
		verifyErrorMsgLName();
		verifyErrorMsgPhone();

		return this;
	}

	/**
	 * Description-Component to verify error message for First name LName
	 * address and Address
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ScheduleDeliveryPage verifyErrorMsgFNameLNameAdd1() throws Exception {

		verifyErrorMsgFName();
		verifyErrorMsgLName();
		verifyErrorMsgAdd1();

		return this;
	}

	/**
	 * Description : To Verify delivery reservation text
	 * 
	 * @since Apr 24,2015
	 * @author RXP8655, modified by RSM8521 on Nov 11,2015
	 * @throws InterruptedException
	 */
	public ScheduleDeliveryPage verifyDeliveryReservationText() throws Exception {

		if (wh.isElementPresent(deliveryReservationTxt, 2)) {
			report.addReportStep("Verify Delivery Reservation text is displayed",
					"Delivery Reservation text is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify Delivery Reservation text is displayed",
					"Delivery Reservation text is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description : To select YES radio button of delivery left unattended. *
	 * 
	 * @throws Exception
	 */
	public ScheduleDeliveryPage selectYESRadioButtonOfDeliveryUnattended() throws Exception {

		if (wh.isElementPresent(radioYesDeliveryUnattended, 7)) {
			wh.clickElement(radioYesDeliveryUnattended);
			report.addReportStep("YES Radio button", "Yes Radio button for delivery unattended is clicked",
					StepResult.PASS);
		} else {
			report.addReportStep("YES Radio button", "Yes Radio button for delivery unattended is not clicked",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description : To Verify Delivery unattended text in calendar overlay
	 * 
	 * @since May 06,2015
	 * @author RXP8655,Modified by RSM8521 on Nov 20, 2015
	 * @throws InterruptedException
	 */
	public ScheduleDeliveryPage verifyDeliveryUnattendedTextInOverlay() throws Exception {

		if (wh.isElementPresent(datePickerModal, 5)) {

			if (wh.isElementPresent(deliveryUnattendedTxt)) {

				if (wh.getText(deliveryUnattendedTxt).contains("The delivery will be left unattended.")) {
					report.addReportStep(
							"Verify text <b>The delivery will be left unattended.</b> is displayed in Calendar Overlay",
							"Delivery left unattended text displayed in calendar overlay", StepResult.PASS);
				} else {
					report.addReportStep(
							"Verify text <b>The delivery will be left unattended.</b> is displayed in Calendar Overlay",
							"Delivery left unattended text is not displayed in calendar overlay", StepResult.FAIL);
				}

			} else {
				report.addReportStep(
						"Verify text <b>The delivery will be left unattended.</b> is displayed in Calendar Overlay",
						"Delivery left unattended text is not displayed in calendar overlay", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify text <b>The delivery will be left unattended.</b> is displayed in Calendar Overlay",
					"Calendar overlay is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description : Component to verify default service level in calander
	 * overlay RSM8521
	 * 
	 * @throws Exception
	 */
	public ScheduleDeliveryPage verifyDefaultServiceLevelCalendarOverlay() throws Exception {

		Select drop = new Select(driver.findElement(servicelevelDropDown));
		WebElement wElm = drop.getFirstSelectedOption();
		if (wElm.getText().trim().contains("Outside Delivery")) {
			report.addReportStep("Default Service level in Calendar Overlay",
					"<b>Outside Delivery</b> is displayed as default service level", StepResult.PASS);
		} else {
			report.addReportStep("Default Service level in Calendar Overlay",
					"<b>Outside Delivery</b> is not displayed as default service level", StepResult.PASS);
		}

		return this;

	}

	/**
	 * Description : Component to verify default service level service
	 * description in calendar overlay RXP8655
	 * 
	 * @throws Exception
	 */
	public ScheduleDeliveryPage verifyOutsideDeliveryDescription() throws Exception {

		String strtext = wh.getText(outsideDelServiceTextInCalendar);
		System.out.println(strtext);
		if (strtext
				.contains("Service includes delivery to area outside the house which is accessible by delivery equipment.")) {
			report.addReportStep("Default Service level in Calendar Overlay", "Service description" + strtext
					+ "is displayed as default service level", StepResult.PASS);
		} else {
			report.addReportStep("Default Service level in Calendar Overlay",
					"service description is not displayed as default service level", StepResult.FAIL);
		}

		return this;

	}

	public ScheduleDeliveryPage clickChangeDeliveryZipCode() throws Exception {

		if (wh.isElementPresent(changeLink, 7)) {
			wh.clickElement(changeLink);
			report.addReportStep("Click change zipcode link", "Change zipcode link clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click change zipcode link", "Change zipcode link not clicked", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description : Component to verify outside delivery selected by default
	 * and service level in schedule delivery page RXP8655
	 * 
	 * @throws Exception
	 */
	public void verifyOutsideDeliveryInPage() throws Exception {
		if (wh.isElementPresent(outsideDelivery, 2)) {
			String strOutsideDel = wh.getText(outsideDelivery);
			System.out.println(strOutsideDel);
			String strOutsideDelText = wh.getText(outsideDelServiceText);
			System.out.println(strOutsideDelText);
			if (strOutsideDel.contains("Outside Delivery")
					&& strOutsideDelText
							.contains("Service includes delivery to area outside the house which is accessible by delivery equipment.")) {

				report.addReportStep("Outside Delivery",
						"Outside Delivery is selected by default and the service description is present",
						StepResult.PASS);
			} else {
				report.addReportStep("Outside Delivery",
						"Outside Delivery is not selected by default and the service description is not present",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Outside Delivery", "Schedule delivery page is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Description : Component to verify Threshold delivery and service
	 * description in calendar RXP8655
	 * 
	 * @throws Exception
	 */
	public void verifyThresholdDeliveryInCalendar() throws Exception {
		if (wh.isElementPresent(thresholdDelInCalendar, 3)) {
			String strThreshold = wh.getText(thresholdDelInCalendar);
			System.out.println(strThreshold);
			String strThresholdText = wh.getText(outsideDelServiceTextInCalendar);
			System.out.println(strThresholdText);
			if (strThreshold.contains("Threshold")
					&& strThresholdText
							.contains("Service includes delivery across your first doorway or threshold (ie. garage, backyard, deck, first room of the home).")) {

				report.addReportStep("Threshold Delivery",
						"Threshold Delivery is selected and the service description is present", StepResult.PASS);
			} else {
				report.addReportStep("Threshold",
						"Threshold Delivery is not selected and the service description is not present",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Threshold Delivery", "Schedule delivery page is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Description : Component to verify delivery price RXP8655
	 * 
	 * @throws Exception
	 */
	public void verifySameDeliveryPrice() throws Exception {
		String strDeliveryPrice = "";

		String strPrice = commonData.strDeliveryPrice;
		double strpriceInCart = Double.parseDouble(strPrice);
		if (wh.isElementPresent(delveryPrice, 7)) {
			strDeliveryPrice = wh.getText(delveryPrice).split("\\$")[1].trim();
			double strpriceInDelvPage = Double.parseDouble(strDeliveryPrice);
			System.out.println("Delivery price: " + strDeliveryPrice);
			if (strpriceInCart <= strpriceInDelvPage) {
				report.addReportStep("Verify delivery price is same in cart", "Delivery price <b>" + strpriceInDelvPage
						+ "</b> is displayed in delivery page", StepResult.PASS);

			} else {
				report.addReportStep("Verify delivery price is same in cart page", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is not same as <b>" + strPrice + "</b> in cart", StepResult.FAIL);
			}
		}
	}
	
	/**
	 * Component to verify the Phone field is moved up
	 * AXB8034
	 * @throws Exception 
	 */
	public void verifyPhoneFieldMovedUp() throws Exception {
		if (wh.isElementPresent(bodfsAddrPhone, 3)) {
			String phone = wh.getText(bodfsAddrPhone);
			if (phone.contains("Phone")) {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is moved up and displayed below Last Name field", StepResult.PASS);
			} else {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is not moved up and not displayed below Last Name field", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
					"Shipping address fields are not displayed properly", StepResult.FAIL);
		}
	}
	
	/**
	 * Description-Component to click on edit this address link on schedule
	 * delivery page
	 * 
	 * @throws Exception
	 * @author AXB8034
	 */
	public ScheduleDeliveryPage clickEditThisAddrLink() throws Exception {
		if (wh.isElementPresent(editAddressLink, 5)) {
			wh.clickElement(editAddressLink);

			report.addReportStep("Click on edit this address link", "edit this Address link is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on edit this address link", "edit this Address link is not displayed",
					StepResult.FAIL);
		}

		return this;
	}
	
	/**
	 * Description-Component to verify edit address overlay on schedule delivery
	 * page
	 * 
	 * @throws Exception
	 * @author AXB8034
	 */
	public ScheduleDeliveryPage verifyEditAddressOverlay() throws Exception {

		if (wh.isElementPresent(editAddressOverlay, 5)) {

			report.addReportStep("Verify Edit Address overlay displayed", "Edit Address overlay is displayed",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify Edit Address overlay displayed", "Edit Address overlay is not displayed",
					StepResult.FAIL);
		}

		return this;
	}
	
	public ScheduleDeliveryPage verifyRightRailAddress() throws Exception {

		if (wh.isElementPresent(bodfsAddr, 2)) {
			String expDeliveryAddr = driver.findElement(bodfsAddr).getText();
			if (expDeliveryAddr.contains(commonData.bodfsAddress)) {
				report.addReportStep("Verify that Address in right rail is displayed in Schedule Delivery page",
						"In right rail<b>" + expDeliveryAddr + "</b>address is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Address in right rail is displayed in Schedule Delivery page",
						"In right rail<b>" + expDeliveryAddr + "</b>address is not displayed properly",
						StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify that Address in right rail is displayed in Schedule Delivery page",
					"In right rail Address is not displayed", StepResult.PASS);
		}

		return this;
	}
	
	public ScheduleDeliveryPage editdAddr1InEditAddrOverlay() throws Exception {

		if (wh.isElementPresent(Add1EditOverlay, 5)) {
			String newAddr = "Address1Edit";
			wh.sendKeys(Add1EditOverlay, newAddr);

			commonData.bodfsAddress = newAddr;
			report.addReportStep("Edit Address1 in Edit Address Overlay", "Address1 entered", StepResult.PASS);

		} else {
			report.addReportStep("Edit Address1 in Edit Address Overlay", "Address1 field is not displayed",
					StepResult.FAIL);
		}

		return this;
	}
	
	/**
	 * 
	 * Description : Verify that Interstitial Image is displayed with please
	 * wait text and continue button is disabled
	 * @throws Exception 
	 */

	public void verifyInterstitialImageSection() throws Exception {
		if(wh.isElementPresent(BodfsOptionsSection,10))
		{
			String Strcolour = driver.findElement(colorOption).getCssValue("color");
			String StrImagesize = driver.findElement(FontSize).getCssValue(
					"font-size");
			String StrPlswaitTxt = driver.findElement(TextMsg).getText();
			System.out.println(StrPlswaitTxt);
			System.out.println(Strcolour);
			System.out.println(StrImagesize);
			String StrsuggestedReservation = driver.findElement(ScheduleDlvryTxt)
					.getText();
			System.out.println(StrsuggestedReservation);
			report.addReportStep(
					"Verify that interstitial image is displayed is displayed in scheduled delivery page",
					"The interstitial spinner is displayed in scheduled delivery page",
					StepResult.PASS);
			report.addReportStep(
					"Verify </b> Please wait while we check availability..</b> is displayed and continue button is disabled in scheduled delivery page",
					"The </b> Please wait while we check availability..</b>  is displayed and continue button is disabled in scheduled delivery page",
					StepResult.PASS);
			Thread.sleep(10000);
		}
		else
		{
			report.addReportStep(
					"Verify that interstitial image is displayed in sheduled delivery page",
					"The interstitial spinner is not displayed in sheduled delivery page",
					StepResult.WARNING);
		}

	}

	public ScheduleDeliveryPage clickUpdateButtonEditOverlay() throws Exception {

		if (wh.isElementPresent(updateBtnEditOverlay, 5)) {
			wh.clickElement(updateBtnEditOverlay);

			report.addReportStep("Verify update button is clicked in Edit Address Overlay",
					"Update button is clicked in Edit Address Overlay", StepResult.PASS);
		} else {

			report.addReportStep("Verify update button is clicked in Edit Address Overlay",
					"Update button is not found in Edit Address Overlay", StepResult.FAIL);

			rc.terminateTestCase("update Button on Edit Address Overlay");
		}

		return this;
	}

}
