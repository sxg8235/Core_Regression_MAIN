package com.homer.po;

import java.text.DecimalFormat;

import org.openqa.selenium.By;

import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class ATCOverlay extends PageBase<ATCOverlay> {

	static final By applianceATCProductDetails = By.cssSelector(".text-secondary.m-bottom-large");
	static final By applianceSubtotal = By
			.xpath("//span[@class='xlarge current-special-price' or @class='xlarge current-unit-price']");
	static final By applinacedeliveryMsg = By.xpath("//*[@id='mccAtcCartTotal']/following-sibling::p");
	static final By applianceDeliveryMsgZip = By
			.cssSelector("section.flex.m-right-large > div > div.m-bottom-small > p");
	static final By btnCheckOutOverLay = By.xpath("//a[contains(text(),'Checkout Now')]");
	static final By btnCheckOutOverLayTab = By.id("editCartBtn");
	static final By atcProductImage = By.xpath("//*[@id='productImgMccAtc']/img");
	static final By atcProductQty = By.xpath("//*[@class='pricedetailMCC']//*[contains(text(),'Quantity')]");
	static final By atcProductqty = By
			.cssSelector("#cartModelSummaryCntrMCC > div > div.left.atcPricingSec > div.right.m-left-xsmall > h3.m-bottom-xsmall");
	static final By atcProduct_TotalPrice = By.xpath("//*[@id='atcGMUnitPrice']");
	static final By atcProductTotalPrice = By.xpath("//*[@class='pricedetailMCC']//*[contains(text(),'Total Price')]");
	static final By closeOverlay = By.cssSelector("button.md-close");
	static final By atcProductImageAppliance = By.xpath("//a[contains(@class,'no-shrink')]/img");
	static final By atcProductPriceAppliance = By
			.xpath("//*[@class='atc-price-info-section']//span[contains(@class,'price')]");
	static final By unitPriceSTH = By.xpath("//div[@class='offerprice']/*/*[@class='xlarge']");
	static final By unitPriceAppliance = By
			.xpath("//span[@class='xlarge current-unit-price' or @class='xlarge current-special-price']");
	static final By unitPriceApplianceSB = By.xpath("//p[@class='bold current-special-price']/span[@class='xlarge']");
	static final By promooffer = By.xpath("//span[@class='strike-through']/following-sibling::span");
	static final By strikeThroPrice = By.xpath("//span[@class='strike-through']");
	static final By atcTotalPriceSTH = By.id("atcGMUnitPrice");
	static final By atcTotalPriceAppliance = By.xpath("//p[@id='mccAtcCartTotal']/span");
	static final By atcTotalQuantity = By
			.xpath("//div[contains(@class,'cartModelCurrentSummaryMCC')]/div[@class='left atcPricingSec']/div[contains(@class,'right')]/h3[1]");
	static final By atcSubTotalPriceSTH = By.id("atcGMSubTotal"); // By.xpath("//div[@class='innerValuesCartDetailTotalMCC']/span");
	static final By continueShopping = By.id("continueBtn");
	static final By atcPayPal = By.id("atcCheckoutPP");
	static final By continueShoppingLink = By.xpath("//a[contains(text(),'Continue Shopping')]");
	static final By atcClosed = By.xpath("//a[@class='md-content']");

	// *************This section is for HDPP******************************
	static final By atcTotal = By.cssSelector("div.cartModelBody1");
	static final By hddpMsg = By.xpath("//*[@id='HDPPDecSec']");
	static final By hddpPrc = By.xpath("//*[@id='hdppPrice']");
	static final By addPlan = By.xpath("//*[@id='addHDPPBtn']");
	static final By addedToCart = By.xpath("//*[@class='md-title']");
	static final By failureMsg = By.xpath("//a[contains(@class,'no-shrink')]/img");
	static final By tickMark = By.xpath("//a[contains(@class,'no-shrink')]/img");
	static final By subTotalBefore = By.xpath("//*[@id='atcGMSubTotal']");
	static final By subTotalAfter = By.xpath("//a[contains(@class,'no-shrink')]/img");
	static final By ViewCart = By.xpath("//*[@id='hdppViewCart']");
	static final By removeLinkoverlay = By.xpath("//a[contains(@class,'no-shrink')]/im");
	static final By certonaATC = By.cssSelector("div.certona1main.grid");
	static final By promotextoverlay = By.cssSelector("span.text-success");
	static final By close = By
			.cssSelector("body > div.md-modal-atc.md-modal.md-effect-1.md-modal-wide.md-show > div > h3 > button");
	static final By certonaAddToCartBtn = By.xpath("//*[@id='cartModalBtnContainer']/a/span[contains(@class,'plus')]");
	static final By certonaAddToCartLink = By
			.xpath("//*[@id='cartModalBtnContainer']/a/span[contains(@class,'plus')]/..");
	static final By certonaAddToCartLinkAppl = By
			.xpath("//*[@id='cartModalBtnContainer']/a/span[contains(@class,'plus')]/..");
	static final By atcPrice = By.xpath("//*[@id='cartModelSummaryCntrMCC']/div/div[1]/div[2]/h3[2]");
	static final By hdppPlanDesc = By.id("HDPPdesc");
	// ***************************************************************************************

	// **********Instant Rebate**********************//
	static final By InstantRebateMsg = By.xpath("//div[@class='atc-item-message']/p");

	// **********End of Instant Rebate**********//

	public ATCOverlay(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Verify appliance delivery charge message displayed in zip code overlay
	 * 
	 * @since Sep 1,2015
	 * @author YXG8356
	 * @throws Exception
	 * 
	 */

	public ATCOverlay verifyADCMessageInATCOverlay() throws Exception {

		if (wh.isElementPresent(applianceATCProductDetails, 2)) {

			report.addReportStep("Product details should be displayed in overlay",
					"Product details is displayed in overlay", StepResult.PASS);

			// Verify appliance delivery message in check availability overlay

			String applianceDeliveryMsg;
			if (wh.isElementPresent(applinacedeliveryMsg)) {
				applianceDeliveryMsg = wh.getText(applinacedeliveryMsg);
			} else {
				applianceDeliveryMsg = wh.getText(applianceDeliveryMsgZip);
			}

			String applianceSubtotalAmt = wh.getText(applianceSubtotal);
			String aSubtotal = applianceSubtotalAmt.replaceAll("[$,]", "");
			double aSubtotalAmt = Double.parseDouble(aSubtotal);

			if (aSubtotalAmt >= 396.00) {

				if (applianceDeliveryMsg.equalsIgnoreCase("free delivery")
						|| applianceDeliveryMsg.equals("FREE Delivery")) {
					report.addReportStep("Verify appliance delivery message in zip code overlay",
							"Appliance delivery message is displayed as <b>Free Delivery</b> for appliance subtotal amount <b>"
									+ applianceSubtotalAmt + "</b>", StepResult.PASS);
				} else {
					report.addReportStep("Verify appliance delivery message in zip code overlay",
							"Appliance delivery message is not displayed as <b>FREE</b> for appliance subtotal amount <b>"
									+ applianceSubtotalAmt + "</b>", StepResult.FAIL);
				}
			}

			else {
				if ((applianceDeliveryMsg.contains("Free delivery on") || (applianceDeliveryMsg
						.contains("FREE Delivery on"))) && applianceDeliveryMsg.contains("appliance purchases of $396")) {
					report.addReportStep("Verify appliance delivery message in zip code overlay",
							"Appliance delivery message is displayed <b>" + applianceDeliveryMsg
									+ "</b> for appliance subtotal amount <b>" + applianceSubtotalAmt + "</b>",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify appliance delivery message in zip code overlay",
							"Appliance delivery message is displayed as <b>" + applianceDeliveryMsg
									+ "</b> for appliance subtotal amount <b>" + applianceSubtotalAmt + "</b>",
							StepResult.FAIL);
				}
			}

		} else {
			report.addReportStep("Product details should be displayed in overlay",
					"Product details is not  displayed in overlay", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to Click checkout now button in an overlay
	 * 
	 * @return ATCOverlay
	 * @throws Exception
	 */
	public ATCOverlay clickCheckoutNow() throws Exception {

		if (wh.isElementPresent(btnCheckOutOverLay)) {

			wh.jsClick(btnCheckOutOverLay);

			report.addReportStep("Click Checkout Now in Overlay", "Checkout Now button is clicked", StepResult.PASS);
		}

		else if (wh.isElementPresent(btnCheckOutOverLayTab)) {

			wh.jsClick(btnCheckOutOverLayTab);

			report.addReportStep("Click Checkout Now in Overlay", "Checkout Now button is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click Checkout Now in Overlay", "Checkout Now button is not clicked", StepResult.FAIL);
			rc.terminateTestCase("Add to Cart Overlay");
		}

		return this;
	}

	/**
	 * Method to verifying product image on ATC Overlay
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ATCOverlay verifyProductImageInATCOverlay() throws Exception {

		if (wh.isElementPresent(atcProductImage) || wh.isElementPresent(atcProductImageAppliance)) {

			report.addReportStep("Verify ATC Modal with product Image", "Product image displayed on ATC Modal",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify ATC Modal with product Image", "Product image not displayed on ATC Modal",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to verifying product Quantity on ATC Overlay
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ATCOverlay verifyProductQtyInATCOverlay() throws Exception {
		int iPipQty = commonData.pipQty;

		if (wh.isElementPresent(atcProductQty)) {
			String[] aSplit = wh.getText(atcProductQty).split(":");
			int iAtcQty = Integer.parseInt(aSplit[1].trim());

			if (iAtcQty == iPipQty) {

				report.addReportStep("Verify Product Quantity '" + iPipQty + "' should be displayed on ATC Modal",
						"Product quantity '" + iPipQty + "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep("Verify Product Quantity '" + iPipQty + "' should be displayed on ATC Modal",
						"Product quantity '" + iPipQty + "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Product Quantity '" + iPipQty + "' should be displayed on ATC Modal",
					"Product quantity '" + iPipQty + "' is not displayed on ATC Modal", StepResult.DONE);
		}

		return this;
	}

	/**
	 * Method to verifying product Total price on ATC Overlay
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ATCOverlay verifyTotalPriceInATCOverlay() throws Exception {

		String strTotalPrice = "";

		if (wh.isElementPresent(atcTotalPriceSTH)) {
			if (wh.getText(atcTotalPriceSTH).contains(strTotalPrice)) {

				report.addReportStep("Verify Total Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
						"Total Price '$" + strTotalPrice + "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep("Verify Total Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
						"Total Price '$" + strTotalPrice + "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(atcProductPriceAppliance)) {

			if (wh.getText(atcProductPriceAppliance).contains(strTotalPrice)) {

				report.addReportStep(
						"Verify Appliance Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
						"Appliance Price '$" + strTotalPrice + "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep(
						"Verify Appliance Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
						"Appliance Price '$" + strTotalPrice + "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Total Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
					"Total Price '$" + strTotalPrice + "' is not displayed on ATC Modal", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To click continue shopping
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay clickContinueShopping() throws Exception {

		if (wh.isElementPresent(closeOverlay)) {
			Thread.sleep(commonData.littleWait);
			wh.clickElement(closeOverlay);

			report.addReportStep("Click Continue Shopping in Overlay", "Continue Shopping button is clicked",
					StepResult.PASS);
		} else {
			report.addReportStep("Click Continue Shopping in Overlay", "Continue Shopping button is not clicked",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To verify atc price with Db
	 * 
	 * @throws Exception
	 */
	public void verifyATCPriceWithDB() throws Exception {
		String priceType = dataTable.getData("PriceType");

		if (priceType.contains("promo")) {

			String promoMsg = wh.getText(promooffer);
			promoMsg = promoMsg.replace("Save", "");
			promoMsg = promoMsg.trim();

			if (promoMsg.contains("%")) {
				promoMsg = promoMsg.replace("%", "");
				if (commonData.strikeThroPriceDB.equals("0.0")) {
					commonData.strikeThroPriceDB = commonData.unitPriceDB;
				}
				double currentPrice = Double.parseDouble(commonData.unitPriceDB);
				double updatedUnitPrice1 = currentPrice - ((Double.parseDouble(promoMsg) / 100) * currentPrice);

				DecimalFormat df = new DecimalFormat("#.##");
				commonData.unitPriceDB = df.format(updatedUnitPrice1);
				commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
			}
		}

		if (wh.isElementPresent(unitPriceSTH, 7)) {

			String unitPrice = driver.findElement(unitPriceSTH).getText();

			String totPrice = unitPrice.replaceAll("each", "").trim();
			String totalPrice = totPrice.substring(1);

			// To get the price from api
			if (rc.isProdEnvironment()
					&& (Double.parseDouble(totalPrice) - Double.parseDouble(commonData.unitPriceDB) != 0)) {
				commonData.unitPriceDB = totalPrice;
				commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
			}

			if (Double.parseDouble(totalPrice) - Double.parseDouble(commonData.unitPriceDB) == 0) {
				report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
						"Unit price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b> "
								+ commonData.unitPriceDB + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
						"Unit price <b>" + totalPrice + "</b> in ATC is not equivalent to Expected Price<b> "
								+ commonData.unitPriceDB + "</b>", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(unitPriceAppliance, 7)) {

			String unitPrice = driver.findElement(unitPriceAppliance).getText();
			String totPrice = unitPrice.replaceAll("each", "").trim();
			String totalPrice = totPrice.substring(1);

			// To get the price from api
			if (rc.isProdEnvironment()
					&& (Double.parseDouble(totalPrice) - Double.parseDouble(commonData.unitPriceDB) != 0)) {
				commonData.unitPriceDB = totalPrice;
				commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
			}

			if (totalPrice.contains(commonData.unitPriceDB)) {
				report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
						"Unit price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b> "
								+ commonData.unitPriceDB + "</b>", StepResult.PASS);
			} else {

				if (priceType.contains("promo")) {
					commonData.unitPriceDB = totalPrice;
					commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
					report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
							"Unit price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b> "
									+ commonData.unitPriceDB + "</b>", StepResult.WARNING);
				} else {
					report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
							"Unit price <b>" + totalPrice + "</b> in ATC is not equivalent to Expected Price<b> "
									+ commonData.unitPriceDB + "</b>", StepResult.FAIL);
				}
			}

		} else if (wh.isElementPresent(unitPriceApplianceSB, 7)) {

			String unitPrice = driver.findElement(unitPriceApplianceSB).getText();
			String totPrice = unitPrice.replaceAll("each", "").trim();
			String totalPrice = totPrice.substring(1);

			// To get the price from api
			if (rc.isProdEnvironment()
					&& (Double.parseDouble(totalPrice) - Double.parseDouble(commonData.unitPriceDB) != 0)) {
				commonData.unitPriceDB = totalPrice;
				commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
			}

			if (totalPrice.contains(commonData.unitPriceDB)) {
				report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
						"Unit price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b> "
								+ commonData.unitPriceDB + "</b>", StepResult.PASS);
			} else {
				if (priceType.contains("promo")) {
					commonData.unitPriceDB = totalPrice;
					commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
					report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
							"Unit price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b> "
									+ commonData.unitPriceDB + "</b>", StepResult.WARNING);
				} else {
					report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
							"Unit price <b>" + totalPrice + "</b> in ATC is not equivalent to Expected Price<b> "
									+ commonData.unitPriceDB + "</b>", StepResult.FAIL);
				}
			}

		} else {
			report.addReportStep("Verify whether the unit price in ATC is equivalent to Expected Price",
					"Unit price in ATC is not displayed", StepResult.FAIL);
		}

		if (priceType.contains("strikethro")) {
			verifyStrikeThroPriceATC();
		}

	}

	/**
	 * Verify Strike through price
	 * 
	 * @throws Exception
	 */
	public void verifyStrikeThroPriceATC() throws Exception {

		if (wh.isElementPresent(strikeThroPrice, 5)) {
			String strikePrice = wh.getText(strikeThroPrice);
			if (strikePrice.contains(commonData.strikeThroPriceDB)) {
				report.addReportStep("Verify strike thro price is equal to Expected Strike Through price",
						"Strike thro price" + strikePrice + "is equal to Expected Strike Through price"
								+ commonData.strikeThroPriceDB, StepResult.PASS);

			} else {
				report.addReportStep("Verify strike thro price is equal to Expected Strike Through price",
						"Strike thro price" + strikePrice + "is not equal Expected Strike Through price"
								+ commonData.strikeThroPriceDB, StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify strike thro price is equal to DB price",
					"Strike thro price is not equal to DB price", StepResult.FAIL);
		}

	}

	/**
	 * To verify atc total price with Db
	 * 
	 * @throws Exception
	 */
	public void verifyATCTotalPriceWithDB() throws Exception {

		if (wh.isElementPresent(atcTotalPriceSTH, 7)) {

			String tot = wh.getText(atcTotalPriceSTH);
			String totPrice = tot.replaceAll("Total Price :", "").trim();
			String totalPrice = totPrice.substring(1);

			String totQuantity = wh.getText(atcTotalQuantity);
			String expectedTotPrice = Double.toString(Double.parseDouble(commonData.unitPriceDB)
					* Double.parseDouble(totQuantity));

			DecimalFormat df = new DecimalFormat("#.##");
			expectedTotPrice = df.format(Double.parseDouble(expectedTotPrice));

			if (totalPrice.contains(expectedTotPrice)) {
				report.addReportStep("Verify whether the total price in ATC is equivalent to Expected Price",
						"Total price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b>"
								+ expectedTotPrice + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify whether the total price in ATC is equivalent to Expected Price",
						"Total price  <b>" + totalPrice + "</b> in ATC is not equivalent to Expected Price<b>"
								+ expectedTotPrice + "</b>", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(atcTotalPriceAppliance, 7)) {
			String totalPrice = driver.findElement(atcTotalPriceAppliance).getText();
			commonData.unitSubTotal = commonData.unitSubTotal + Double.parseDouble(commonData.unitPriceDB);
			String total = Double.toString(commonData.unitSubTotal);
			if (totalPrice.contains(total)) {
				report.addReportStep("Verify whether the total price in ATC is equivalent to Expected Price",
						"Total price <b>" + totalPrice + "</b> in ATC is equivalent to Expected Price<b>"
								+ commonData.unitPriceDB + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify whether the total price in ATC is equivalent to Expected Price",
						"Total price  <b>" + totalPrice + "</b> in ATC is not equivalent to Expected Price<b>"
								+ commonData.unitPriceDB + "</b>", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify whether the total price in ATC is equivalent to Expected Price",
					"Total price in ATC is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * To verify atc sub total price with Db
	 * 
	 * @throws Exception
	 */
	public void verifyATCSubTotalPriceWithDB() throws Exception {

		String estSubTot;

		if (wh.isElementPresent(atcSubTotalPriceSTH, 7)) {

			String tot = driver.findElement(atcSubTotalPriceSTH).getText();
			String totPrice = tot.substring(1);

			// If BODFS add the delivery charge to the subtotal
			if (!commonData.estDeliveryBODFS.isEmpty()) {

				Double unitPri = Double.parseDouble(commonData.unitPriceDB);
				unitPri += Double.parseDouble(commonData.estDeliveryBODFS);

				estSubTot = Double.toString(commonData.dblSubTotalCart + unitPri);
				commonData.dblSubTotalCart = Double.parseDouble(estSubTot);
				estSubTot = Double.toString(commonData.unitSubTotal + Double.parseDouble(estSubTot));
				commonData.unitSubTotal = Double.parseDouble(estSubTot);
				DecimalFormat df = new DecimalFormat("#.##");
				estSubTot = df.format(Double.parseDouble(estSubTot));

			} else {

				String totQuantity = wh.getText(atcTotalQuantity);
				String expectedTotPrice = Double.toString(Double.parseDouble(commonData.unitPriceDB)
						* Double.parseDouble(totQuantity));

				DecimalFormat df = new DecimalFormat("#.##");
				expectedTotPrice = df.format(Double.parseDouble(expectedTotPrice));

				estSubTot = Double.toString(commonData.dblSubTotalCart + Double.parseDouble(expectedTotPrice));
				estSubTot = Double.toString(commonData.unitSubTotal + Double.parseDouble(estSubTot));
				commonData.unitSubTotal = Double.parseDouble(estSubTot);
			}

			// Compare the expected subtotal with actual subtotal
			if (totPrice.contains(estSubTot)) {
				report.addReportStep("Verify whether the sub total in ATC is sum of unit price of all items in cart",
						"Sub total <b>" + totPrice + "</b> in ATC is sum of unit price of all items in cart<b>"
								+ estSubTot + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify whether the sub total in ATC is sum of unit price of all items in cart",
						"Sub total <b>" + totPrice + "</b> in ATC is not the sum of unit price of all items in cart<b>"
								+ estSubTot + "</b>", StepResult.FAIL);
			}

		} else if (commonData.isAppliance) {
			report.addReportStep("Verify Appliance sub total", "Appliance sub total is as expected", StepResult.PASS);
		} else {
			report.addReportStep("Verify whether the sub total in ATC is sum of unit price of all items in cart",
					"Sub total in ATC is not displayed properly", StepResult.FAIL);
		}

	}

	public void clickPayPal() throws Exception {
		if (wh.isElementPresent(atcPayPal, 3)) {
			wh.jsClick(atcPayPal);
			Thread.sleep(2000);
			report.addReportStep("verify checkout with PayPal in ATC",
					"Checkout with PayPal is verified and clicked from ATC", StepResult.PASS);
		} else {
			report.addReportStep("verify checkout with PayPal in ATC", "Checkout with PayPal is not displayed in ATC",
					StepResult.FAIL);
		}
	}

	// ************This section is for HDPP********************

	/**
	 * Component to verify HDPP item in Overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyHDPPInATCOverlay() throws Exception {

		wh.waitForPageLoaded();

		String msg_exp = dataTable.getData(DataColumn.HDPP);
		// String PRC_exp= dataTable.getData(DataColumn.HDPP_PRICE);
		// String Prc_act=wh.getText(hddpPrc);

		String msg_act = wh.getText(hddpMsg);

		if (msg_act.contains(msg_exp) && (msg_act != "")) {
			report.addReportStep("Verify HDPP message is displayed  in overlay",
					"HDPP message is displayed  in overlay", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify HDPP message is displayed  in overlay",
					"HDPP message is not displayed  in overlay", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify Add Plan option
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay verifyAddPlanInATCOverlay() throws Exception {
		wh.waitForPageLoaded();

		if (wh.isElementPresent(addPlan, 5)) {

			report.addReportStep("Verify Add Plan Option is displayed  in overlay",
					"Add Plan Option is displayed  in overlay", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Add Plan Option is displayed  in overlay",
					"Add Plan Option is not displayed  in overlay", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify no Add Plan
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay verifyNoAddPlanInATCOverlay() throws Exception {
		wh.waitForPageLoaded();

		if (wh.isElementPresent(addPlan, 5)) {

			report.addReportStep("Verify Add Plan Option is displayed  in overlay",
					"Add Plan Option is displayed  in overlay", StepResult.FAIL);
		}

		else {
			report.addReportStep("Verify Add Plan Option is displayed  in overlay",
					"Add Plan Option is not displayed  in overlay", StepResult.PASS);
		}

		return this;

	}

	/**
	 * Component to click Add Plan
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay clickAddPlan() throws Exception {

		if (wh.isElementPresent(addPlan, 5)) {

			wh.clickElement(addPlan);
			Thread.sleep(3000l);
			report.addReportStep("Click Add Plan Option in overlay", "Clicked Add Plan Option in overlay",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Click Add Plan Option in overlay", "Add Plan Option is not clicked  in overlay",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to click Add Plan
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickViewCart() throws Exception {

		if (wh.isElementPresent(ViewCart, 5)) {

			wh.clickElement(ViewCart);
			report.addReportStep("Click View cart in overlay", "Clicked View cart in overlay", StepResult.PASS);
		}

		else {
			report.addReportStep("Click View cart in overlay", "View cart is not clicked  in overlay", StepResult.FAIL);
		}

		return new ShoppingCartPage(ic);

	}

	/**
	 * Component to verify HDPP item 'added to cart' msg
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyAddedToCartInATCOverlay() throws Exception {
		wh.waitForPageLoaded();

		if (wh.isElementPresent(addedToCart, 5)) {

			String msg = wh.getText(addedToCart);

			if (msg.contains("ADDED TO CART") || msg.contains("Added in Cart") || msg.contains("Added to Cart")) {
				report.addReportStep("Verify Added to Cart message is displayed  in overlay",
						"Added to Cart message is displayed  in overlay", StepResult.PASS);
			}

			else {
				report.addReportStep("Verify Added to Cart message is displayed  in overlay",
						"Added to Cart message is not displayed  in overlay", StepResult.FAIL);
			}

		}
		return this;

	}

	/**
	 * Component to get the sub total from Overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void getSubTotal() throws Exception {

		String strTemp_subtotal = wh.getText(subTotalBefore);
		System.out.println("ATC Overlay SubTotal value is" + strTemp_subtotal);

		if (strTemp_subtotal.contains("$")) {
			strTemp_subtotal = strTemp_subtotal.substring(strTemp_subtotal.indexOf("$") + 1, strTemp_subtotal.length())
					.trim();

			if (strTemp_subtotal.contains(",")) {
				strTemp_subtotal = strTemp_subtotal.replace(",", "");
			}
		}

		commonData.doubATCSubtotal = Double.parseDouble(strTemp_subtotal);

	}

	/**
	 * Component to verify updated sub total after adding HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyUpdatedSubTotal() throws Exception {

		Double SubTotal_Before_HDPP = commonData.doubATCSubtotal;
		System.out.println(SubTotal_Before_HDPP);
		/*
		 * String msg = wh.getText(hddpMsg); if (msg.contains("$")) { msg =
		 * msg.substring(msg.indexOf("$") + 1, msg.length()).trim();
		 * 
		 * if (msg.contains(",")) { msg = msg.replace(",", ""); } }
		 * 
		 * Double HDPP_Dollar_val = Double.parseDouble(msg);
		 * 
		 * Double SubTotal_After_HDPP_Exp = SubTotal_Before_HDPP +
		 * HDPP_Dollar_val;
		 */

		String strTemp_subtotal = wh.getText(subTotalBefore);

		if (strTemp_subtotal.contains("$")) {
			strTemp_subtotal = strTemp_subtotal.substring(strTemp_subtotal.indexOf("$") + 1, strTemp_subtotal.length())
					.trim();

			if (strTemp_subtotal.contains(",")) {
				strTemp_subtotal = strTemp_subtotal.replace(",", "");
			}
		}

		Double SubTotal_After_HDPP_Act = Double.parseDouble(strTemp_subtotal);

		if (SubTotal_After_HDPP_Act > SubTotal_Before_HDPP) {
			report.addReportStep("Verify updated SubTotal  in overlay", "Verified updated SubTotal in overlay",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify updated SubTotal  in overlay", "Incorrect subtotal is displayed  in overlay",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify HDPP Failure msg in Overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay verifyFailureMsgInATCOverlay() throws Exception {
		wh.waitForPageLoaded();

		if (wh.isElementPresent(failureMsg, 5)) {

			String msg = wh.getText(failureMsg);

			if (msg.contains("Sorry")) {
				report.addReportStep("Verify Failure message is displayed  in overlay",
						"Failure message is displayed  in overlay", StepResult.PASS);
			}

			else {
				report.addReportStep("Verify Failure message is displayed  in overlay",
						"Failure message is not displayed  in overlay", StepResult.FAIL);
			}

		}
		return this;

	}

	/**
	 * Component to verify certona section in Overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyCertonaSectionOverlay() throws Exception {

		if (wh.isElementPresent(certonaATC, 4)) {
			report.addReportStep("Verify <b>Certona</b> section is displayed", "<b>Certona</b> section is displayed",
					StepResult.PASS);

			/*
			 * String sku = null; if (wh.isElementPresent(certonaAddToCartLink))
			 * { String href = wh.getAttribute(certonaAddToCartLink, "href");
			 * String[] href1 = href.split("catEntryId=");
			 * 
			 * sku = href1[1].substring(0, 9);
			 * 
			 * } else if (wh.isElementPresent(certonaAddToCartLinkAppl)) { sku =
			 * wh.getAttribute(certonaAddToCartLinkAppl, "data-prodid"); }
			 * 
			 * if (!sku.equals(null)) { commonData.sku = sku;
			 * commonData.skuList.clear(); commonData.skuList.add(sku); }
			 */

		} else {
			report.addReportStep("Verify <b>Certona</b> section is displayed",
					"<b>Certona</b> section is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Certona Section");
		}
		return this;

	}

	/**
	 * Component to click first product from Certona section
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay clickATCCertona() throws Exception {
		if (wh.isElementPresent(certonaAddToCartBtn, 5)) {

			wh.clickElement(certonaAddToCartBtn);

			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is clicked in certona section", StepResult.PASS);

		} else {
			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is not clicked in certona section", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to verify price from PCP in overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyTotalPricefromPCPInATCOverlay() throws Exception {

		String strTotalPricepcp = commonData.pcpPrice.replace("/ each", "").trim();

		if (wh.isElementPresent(atcTotal)) {

			if (wh.getText(atcTotal).contains(strTotalPricepcp)) {

				report.addReportStep("Verify Total Price '$" + strTotalPricepcp + "' should be displayed on ATC Modal",
						"Total Price '$" + strTotalPricepcp + "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep("Verify Total Price '$" + strTotalPricepcp + "' should be displayed on ATC Modal",
						"Total Price '$" + strTotalPricepcp + "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		}

		return this;
	}

	/**
	 * Component to verify tick mark for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay verifyTickMark() throws Exception {
		wh.waitForPageLoaded();

		if (wh.isElementPresent(tickMark, 5)) {

			report.addReportStep("Verify Failure message is displayed  in overlay",
					"Failure message is displayed  in overlay", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Failure message is displayed  in overlay",
					"Failure message is not displayed  in overlay", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify quantity after change in PCP page
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay verifyQuantity() throws Exception {

		int pcpquantity = commonData.pcpQuantity;

		if (pcpquantity == 1) {

			report.addReportStep("Verify Product Quantity '" + pcpquantity + "' should be displayed on ATC Modal",
					"Product quantity '" + pcpquantity + "' displayed on ATC Modal", StepResult.PASS);

		} else {

			report.addReportStep("Verify Product Quantity '" + pcpquantity + "' should be displayed on ATC Modal",
					"Product quantity '" + pcpquantity + "' is not displayed on ATC Modal", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify increase in item quantity after increasing qty in pip
	 * page
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyincreasedQuantity() throws Exception {

		String pipquantityincreased = commonData.increasepipqty;
		int pipquantityincreasedint = Integer.parseInt(pipquantityincreased);

		if (wh.isElementPresent(atcProductqty)) {
			String[] aSplit = wh.getText(atcProductqty).split(":");
			int iAtcQty = Integer.parseInt(aSplit[0].trim());

			if (iAtcQty == pipquantityincreasedint) {

				report.addReportStep("Verify Product Quantity '" + pipquantityincreasedint
						+ "' should be displayed on ATC Modal", "Product quantity '" + pipquantityincreasedint
						+ "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep("Verify Product Quantity '" + pipquantityincreasedint
						+ "' should be displayed on ATC Modal", "Product quantity '" + pipquantityincreasedint
						+ "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Product Quantity '" + pipquantityincreasedint
					+ "' should be displayed on ATC Modal", "Product quantity '" + pipquantityincreasedint
					+ "' is not displayed on ATC Modal", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify increased price
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay verifyTotalincraesedPriceInATCOverlay() throws Exception {

		String strTotalPrice_str = commonData.pipPrice;
		Double strTotalPrice_int = Double.valueOf(strTotalPrice_str);
		String incqty_str = commonData.increasepipqty;
		Double incqty_int = Double.valueOf(incqty_str);

		Double increasedprice = strTotalPrice_int * incqty_int;
		String strTotalPrice = String.valueOf(increasedprice);

		if (wh.isElementPresent(atcProduct_TotalPrice)) {
			if (wh.getText(atcProduct_TotalPrice).contains(strTotalPrice)) {

				report.addReportStep("Verify Total Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
						"Total Price '$" + strTotalPrice + "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep("Verify Total Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
						"Total Price '$" + strTotalPrice + "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Total Price '$" + strTotalPrice + "' should be displayed on ATC Modal",
					"Total Price '$" + strTotalPrice + "' is not displayed on ATC Modal", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify presence of Remove link
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyRemoveLink() throws Exception {

		if (wh.isElementPresent(removeLinkoverlay)) {

			report.addReportStep("Verify remove link on ATC Modal", "Remove link is  displayed on ATC Modal",
					StepResult.FAIL);

		} else {

			report.addReportStep("Verify remove link on ATC Modal on ATC Modal",
					"Remove link is  not displayed on ATC Modal", StepResult.PASS);
		}

		return this;

	}

	/**
	 * Component to verify promo text in overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifypromo() throws Exception {

		if (wh.isElementPresent(promotextoverlay)) {

			report.addReportStep("Verify Promo should be displayed on ATC Modal", "Promo is  displayed on ATC Modal",
					StepResult.PASS);

		} else {

			report.addReportStep("Verify Promo should be displayed on ATC Modal", "Promo is  displayed on ATC Modal",
					StepResult.FAIL);
		}

		return this;

	}

	public ATCOverlay verifyQtyfromPLPInATCOverlay() throws Exception, Exception {

		if (wh.isElementPresent(atcProductQty)) {
			String[] aSplit = wh.getText(atcProductQty).split(":");
			int iAtcQty = Integer.parseInt(aSplit[1].trim());

			if (iAtcQty == 1) {

				report.addReportStep("Verify Product Quantity '" + iAtcQty + "' should be displayed on ATC Modal",
						"Product quantity '" + iAtcQty + "' displayed on ATC Modal", StepResult.PASS);

			} else {

				report.addReportStep("Verify Product Quantity '" + iAtcQty + "' should be displayed on ATC Modal",
						"Product quantity '" + iAtcQty + "' is not displayed on ATC Modal", StepResult.FAIL);
			}

		}
		return this;

	}

	public ATCOverlay verifyPricefromPLPInATCOverlay() throws Exception, Exception {

		String exp_price = commonData.plpPrice;
		String act_price = wh.getText(atcPrice);
		if (exp_price.contains(wh.getText(atcPrice))) {

			report.addReportStep("Verify Total Price " + act_price + "' should be displayed on ATC Modal",
					"Total Price '$" + exp_price + "' displayed on ATC Modal", StepResult.PASS);

		} else {

			report.addReportStep("Verify Total Price " + act_price + "' should be displayed on ATC Modal",
					"Total Price '$" + exp_price + "' is not displayed on ATC Modal", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify HDPP protection plan is not displayed in ATC overlay
	 * 
	 * @author axb8034
	 * @return
	 * @throws Exception
	 */

	public void closeOverlay() throws Exception {

		if (wh.isElementPresent(close)) {
			wh.clickElement(close);
			Thread.sleep(3000l);
			report.addReportStep("Close the overlay", "Overlay is closed", StepResult.PASS);

		} else {

			report.addReportStep("Close the overlay", "Overlay is not displayed on ATC Modal", StepResult.FAIL);
		}

	}

	public ATCOverlay verifyHDPPNotDisplayed() throws Exception {

		if (wh.isElementNotPresent(hdppPlanDesc)) {

			report.addReportStep("Verify HDPP protection plan field and Add plan link is not displayed in ATC",
					"HDPP protection plan field and Add plan link is not displayed in ATC", StepResult.PASS);

		} else {

			report.addReportStep("Verify HDPP protection plan field and Add plan link is not displayed in ATC",
					"HDPP protection plan field and Add plan link is displayed in ATC", StepResult.FAIL);
		}

		return this;
	}

	public ATCOverlay verifyContinueShoppingButton() throws Exception {

		if (wh.isElementPresent(continueShopping)) {
			Thread.sleep(commonData.littleWait);
			String strText = wh.getText(continueShopping);
			if (strText.contains("Continue Shopping")) {
				report.addReportStep("Verify Continue Shopping button in Overlay",
						"Continue Shopping button is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify Continue Shopping button in Overlay",
						"Continue Shopping button is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Continue Shopping button in Overlay",
					"Continue Shopping button is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To verify continue shopping link in ATC overlay
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyContinueShoppingLink() throws Exception {

		if (wh.isElementPresent(continueShoppingLink)) {
			report.addReportStep("Verify Continue Shopping in Overlay", "Continue Shopping link is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Continue Shopping in Overlay", "Continue Shopping link is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To click continue shopping link in ATC overlay
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay clickContinueShoppingLink() throws Exception {

		if (wh.isElementPresent(continueShoppingLink)) {
			Thread.sleep(commonData.littleWait);
			wh.clickElement(continueShoppingLink);

			report.addReportStep("Click Continue Shopping link in Overlay", "Continue Shopping link is clicked",
					StepResult.PASS);
		} else {
			report.addReportStep("Click Continue Shopping link in Overlay", "Continue Shopping link is not clicked",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To verify continue shopping link is not present in appliance ATC overlay
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay verifyContinueShoppingLinkNotPresent() throws Exception {

		if (wh.isElementNotPresent(continueShoppingLink)) {
			report.addReportStep("Verify Continue Shopping link not present in Overlay",
					"Continue Shopping link is not displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify Continue Shopping is not present in Overlay",
					"Continue Shopping link is displayed", StepResult.FAIL);
		}

		return this;
	}

	public ATCOverlay verifyContinueShoppingButtonNotPresent() throws Exception {

		if (wh.isElementNotPresent(continueShopping)) {
			report.addReportStep("Verify Continue Shopping button in Overlay",
					"Continue Shopping button is not displayed", StepResult.PASS);

		} else {
			report.addReportStep("Verify Continue Shopping button in Overlay", "Continue Shopping button is displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description: verify PayPal button is not present in ATC overlay
	 * 
	 * @throws Exception
	 * @author RXP8655
	 */

	public ATCOverlay checkoutWithPaypalNotDisplayed() throws Exception {

		if (wh.isElementNotPresent(atcPayPal)) {

			report.addReportStep("Verify <b>Checkout with Paypal</b> button should not be displayed in ATC overlay",
					"<b>Checkout with Paypal</b> button is NOT displayed in ATC overlay", StepResult.PASS);

		} else {
			report.addReportStep(
					"Verify <b>Checkout with Paypal</b> button should not be displayed in the ATC overlay",
					"<b>Checkout with Paypal</b> button is displayed in ATC overlay", StepResult.FAIL);
		}
		return this;
	}

	public ATCOverlay verifyATCOverlayClosed() throws Exception {

		if (wh.isElementNotPresent(atcClosed)) {
			report.addReportStep("Verify ATC overlay is closed", "ATC overlay is closed", StepResult.PASS);

		} else {
			report.addReportStep("Verify ATC overlay is closed", "ATC overlay is not closed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Instant Rebate Component to change the pick up store based on the input
	 * in the storeID column in Instant Rebate Data sheet.
	 * 
	 * @author vxr8682 & u93wcs
	 * @return
	 * @throws Exception
	 */

	public void verifyInstantRebateMsgATC() throws Exception {

		String StorePromo1 = commonData.IRList.get(0);
		String StorePromo2 = commonData.IRList.get(1);

		double val1 = Double.parseDouble(commonData.PriceList.get(0));
		System.out.println(val1);
		double val2 = Double.parseDouble(commonData.PriceList.get(1));
		System.out.println(val2);

		// double val1 = Double.parseDouble(commonData.pipPrice);
		// double val2 = Double.parseDouble(commonData.changedstoreprice);
		String IREligMsg = "";
		String IRIneligMsg = "";

		IREligMsg = commonData.InstantRebateEligMsg_ATC;
		IRIneligMsg = commonData.InstantRebateIneligMsg_ATC;

		if ((val2 < val1)) {

			if (wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES"))
					&& ((StorePromo2).contains("INSTANT_REBATES"))) {
				String Msg = wh.getText(InstantRebateMsg);

				if (Msg.contains(IREligMsg)) {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is equal to Expected Msg" + IREligMsg, StepResult.PASS);

				} else {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is not equal to Expected Msg" + IREligMsg, StepResult.FAIL);

				}

			}

			else if (wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
					&& ((StorePromo2).contains("INSTANT_REBATES"))) {
				String Msg = wh.getText(InstantRebateMsg);

				if (Msg.contains(IREligMsg)) {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is equal to Expected Msg" + IREligMsg, StepResult.PASS);

				} else {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is not equal to Expected Msg" + IREligMsg, StepResult.FAIL);

				}

			}

			else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && (!(StorePromo2)
					.contains("INSTANT_REBATES")))) {
				String Msg = wh.getText(InstantRebateMsg);

				if (Msg.contains(IRIneligMsg)) {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is equal to Expected Msg" + IRIneligMsg, StepResult.PASS);

				} else {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is not equal to Expected Msg" + IRIneligMsg, StepResult.FAIL);

				}
			} else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
				report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed", StepResult.PASS);
			}
		}

		else if ((val2 > val1))

		{
			if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && (!(StorePromo2)
					.contains("INSTANT_REBATES")))) {
				String Msg = wh.getText(InstantRebateMsg);
				if (Msg.contains(IRIneligMsg)) {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is equal to Expected Msg" + IRIneligMsg, StepResult.PASS);

				} else {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is not equal to Expected Msg" + IRIneligMsg, StepResult.FAIL);

				}

			}

			else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2)
					.contains("INSTANT_REBATES")))) {
				String Msg = wh.getText(InstantRebateMsg);
				if (Msg.contains(IREligMsg)) {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is equal to Expected Msg" + IREligMsg, StepResult.PASS);

				} else {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is not equal to Expected Msg" + IREligMsg, StepResult.FAIL);

				}

			}

			else if ((wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2)
					.contains("INSTANT_REBATES")))) {
				String Msg = wh.getText(InstantRebateMsg);
				if (Msg.contains(IREligMsg)) {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is equal to Expected Msg" + IREligMsg, StepResult.PASS);

				} else {
					report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
							+ "is not equal to Expected Msg" + IREligMsg, StepResult.FAIL);

				}

			}

			else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
				report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed", StepResult.PASS);
			}

		} else if ((val2 == val1)) {

			if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
				report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed", StepResult.PASS);
			}

			else if ((wh.isElementPresent(InstantRebateMsg, 5))) {
				report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is displayed", StepResult.FAIL);

			}

		}
	}
	
	public ATCOverlay verifyCloseButton() throws Exception {

		if (wh.isElementPresent(closeOverlay)) {
			report.addReportStep("Verify ATC overlay close buton", "Close button is displayed in ATC overlay", StepResult.PASS);

		} else {
			report.addReportStep("Verify ATC overlay close buton", "Close button is not displayed in ATC overlay", StepResult.FAIL);
		}

		return this;
	}
}
