package com.homer.po;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.homer.dao.CommonData;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class PickupOptionPage extends PageBase<PickupOptionPage> {

	static final By pickupOptionPageTitle = By.xpath("//h1[text()='Pick Up In Store']");
	static final By bySaveTripOverlay = By.id("smart-pickup");
	static final By btnNoThanks = By.xpath("//*[contains(text(),'NO THANKS')]");
	static final By radioStoreOverlay = By.xpath("//label[contains(@for,'smart_pickup_store_')]");
	static final By updateStoreBtn = By.xpath("//a[contains(text(),'UPDATE STORE SELECTION')]");
	static final By AddressSection = By.xpath("//*[@class='address-wrapper m-bottom-normal']//h4[1]");

	static final By PickUpTime = By.xpath("//select[contains(@id,'pickup-times')]");
	static final By savePickupTime = By.id("pickupTimingsChange");
	static final By PickUptimedetails = By.xpath("//div[@class='pickupDateTime']");
	static final By choosenDate = By.xpath("//h3[@class='pickup-date']");
	static final By choosentime = By.xpath("//h3[@class='m-bottom-normal pickup-time']");
	static final By pickupdateOverlay = By.id("change-pickup-time-slot");
	static final By PickUpDate = By.xpath("//select[contains(@id,'pickup-dates')]");
	static final By totalRightRail = By.xpath("//h3[contains(text(),'Total')]/span");
	static final By pickUpToday = By.xpath("//span[contains(text(),'Pick Up TODAY At:')]");
	static final By continueBtn = By
			.xpath("//div[@class='tablet-checkout-right-rail']/descendant::a[contains(.,'CONTINUE')]");
	static final By backBtn = By.xpath("//div[@class='tablet-checkout-right-rail']/descendant::a[contains(.,'Back')]");
	static final By chooseInstore = By.xpath("//h3[contains(text(),'Choose In-Store Pickup Location')]");
	static final By deskTxt = By.xpath("//div[@class='clear radio-btns-wrapper left']");
	static final By pickupPersonOverlay = By.id("pickup-another-person");
	static final By WhoFirstName = By.xpath("//input[@id='pickup-first-name']");
	static final By WhoLasttName = By.xpath("//input[@id='pickup-last-name']");
	static final By WhoEmail = By.xpath("//input[@id='pickup-email']");
	static final By MobileNum = By.xpath("//input[@id='pickup-phone-no']");
	static final By savechangePerson = By.xpath("//a[@id='pickupPersonChange']");
	static final By chooseAnotherPerson = By.xpath("//h4[contains(text(),'Choose another person')]");
	static final By MobilePh = By.id("pickup-mobile-phone");
	static final By img = By.xpath("//div[@class='m-top-medium product-item']/img");
	static final By saveTripHeadin = By.xpath("//*[@class='md-content']//h3[contains(text(),'Single Store')]");
	static final By firstStoreInSaveTrip = By
			.xpath("//*[@class='md-content']//*[@class='radio-set m-bottom-normal'][1]");
	static final By updateStoreSelection = By.xpath("//*[contains(text(),'UPDATE STORE SELECTION')]");
	static final By storeSection = By.xpath("//*[@class='pickup-options-layout overflowHidden']");
	static final By WhoFirstNameErr = By.xpath("//div[@for='pickup-first-name']");
	static final By WhoLastNameErr = By.xpath("//div[@for='pickup-last-name']");
	static final By STSPod = By.xpath(
			"//*[contains(@class,'fulFillmentPods')]//*[contains(text(),'Ship To	Store')]/ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='rightRailitemTitle']");
	static final By PodAmount = By
			.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalIteamChargesAmt']");
	static final By PodQty = By
			.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalItemsQtyNum']");
	static final By QuickViewModal = By.cssSelector("#fancybox-content .miniQvCntr");
	static final By ProductTitle = By.xpath(".//*[@class='rightRailprodTitle']");
	static final By ProductAttribute = By.xpath(".//*[@class='custom-attr-cntr']");
	static final By PickUpOptionMessage = By.xpath(
			"(//div[@class='phone-details m-top-normal']//h3)[1]|//*[contains(text(),'Text Me When My Order is Ready')]");
	static final By PhoneNumtextBox = By.xpath("//input[@id='pickup-mobile-phone']");
	static final By InvalidPhNumerror = By.cssSelector("div[class='error error-in-container']");
	static final By FirstNameErr = By.xpath("//*[@for='pickup-first-name' and @class='error error-in-container']");
	static final By LastNameErr = By.xpath("//*[@for='pickup-last-name' and @class='error error-in-container']");
	static final By pickUpOptionsContiner = By.xpath("//div[@class='pickup-pane m-left-normal m-right-large']");
	static final By rightRailContinueBtn = By.xpath("//div[@class='p-right-normal']//span[text()='CONTINUE']");
	static final By rightRailSubmitOrderBtn = By.xpath("//div[@class='p-right-normal']//span[text()='SUBMIT ORDER']");
	static final By storelist = By.xpath("//div[@class='address-wrapper m-bottom-normal']");
	static final By itemList = By.xpath("//span[@class='order-quantity-count']");
	static final By CartinProgressBar = By.xpath("//ul[@id='progressBar']/li[1]");
	static final By choosePUPmsg = By.xpath("//h4[@class='normal']");
	static final By proDesk = By.xpath("//h4[contains(.,'Pro Desk')]");
	static final By storeDetails = By.xpath("//div[@class='address-wrapper m-bottom-normal']//h4[@class='bold']");
	static final By WhoEmailErr = By.xpath("//div[@for='pickup-email']");
	static final By FirstRadioButtonText = By.xpath("//*[contains(text(),'I will pick up the item(s)')]");

	// ***************************Instant
	// Rebates**********************************************

	static final By updatestoreselection = By.xpath("//*[text()='UPDATE STORE SELECTION']");
	static final By InstantRebateMsg = By.xpath(".//*[@id='irContent']/div[1]/p");

	// ***************************End of Instant
	// Rebates**********************************************

	private Object element;
	boolean isMulti;

	public PickupOptionPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify Shipping Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PickupOptionPage verifyPickupOptionPage() throws Exception {

		wh.waitForElementPresent(pickupOptionPageTitle, 5);

		if (wh.isElementPresent(pickupOptionPageTitle, 2)) {

			report.addReportStep("Verify Pickup Option page is displayed", "Pickup Option page is displayed",
					StepResult.PASS);
		} else {

			report.addReportStep("Verify Pickup Option page is displayed", "Pickup Option page is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Verify Save trip overlay and close
	 * 
	 */

	public PickupOptionPage verifyAndCloseSaveTripOverlay() throws Exception {

		if (wh.isElementPresent(bySaveTripOverlay)) {
			report.addReportStep("Verify that Save trip overlay is displayed", "The overlay is displayed",
					StepResult.PASS);

			if (wh.isElementPresent(btnNoThanks)) {
				report.addReportStep("Verify that No Thanks button is displayed", "Button is displayed",
						StepResult.PASS);
				wh.clickElement(btnNoThanks);
			} else {
				report.addReportStep("Verify that No Thanks button is displayed", "Button is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that Save trip overlay is displayed", "The overlay is not displayed",
					StepResult.WARNING);
		}

		return this;

	}

	/**
	 * Verify Save trip overlay and close
	 * 
	 */

	public PickupOptionPage verifyAndSelectStoreSaveTripOverlay() throws Exception {

		if (wh.isElementPresent(bySaveTripOverlay)) {
			report.addReportStep("Verify that smart fulfillment overlay is displayed",
					"Smart fulfillment overlay is displayed", StepResult.PASS);

			if (wh.isElementPresent(radioStoreOverlay)) {

				wh.clickElement(radioStoreOverlay);
				String store = driver.findElement(radioStoreOverlay).getAttribute("for");
				commonData.selectedStore = store;

				report.addReportStep("Verify that Store option radio is displayed and clicked",
						"Store option radio is displayed and clicked", StepResult.PASS);

				if (wh.isElementPresent(updateStoreBtn)) {
					wh.clickElement(updateStoreBtn);

					report.addReportStep("Verify that Update Store button is clicked", "Update Store button is clicked",
							StepResult.PASS);
				}

				else {
					report.addReportStep("Verify that Update Store button is clicked",
							"Update Store button is not clicked", StepResult.FAIL);
				}

				Thread.sleep(commonData.smallWait);
			} else {
				report.addReportStep("Verify that Store option radio is displayed",
						"Store option radio is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that smart fulfillment overlay is displayed",
					"Smart fulfillment overlay is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * verify that 2 sku's are added to same store
	 * 
	 * @throws Exception
	 */
	public void verifyBothSkuAddedToSameStore() throws Exception {
		if (wh.isElementPresent(pickupOptionPageTitle, 2)) {

			String strPageTitle = driver
					.findElement(By.xpath("//*[@class='title m-bottom-normal'][contains(text(),'Pick Up In Store')]"))
					.getText();

			if (strPageTitle.contains("Pick Up In Store")) {
				System.out.println(commonData.lstStoreNames.get(0));
				System.out.println(commonData.lstStoreNames.get(1));

				String strStore1 = "no store";
				String strStore2 = "no store";

				try {
					strStore1 = commonData.lstStoreNames.get(0);
				} catch (Exception e) {

					try {
						strStore1 = commonData.lstStoreNames.get(0);
					} catch (Exception e1) {
						strStore1 = "no store";
					}

				}

				try {
					strStore2 = commonData.lstStoreNames.get(1).substring(
							commonData.lstStoreNames.get(1).lastIndexOf("at") + 2,
							commonData.lstStoreNames.get(1).indexOf("..."));
				} catch (Exception e) {

					try {
						strStore2 = commonData.lstStoreNames.get(1);
					} catch (Exception e1) {
						strStore1 = "no store";
					}

				}

				String strStoreName = "";

				if (wh.isElementPresent(AddressSection, 2)) {
					strStoreName = driver.findElement(By.xpath("//*[@class='address-wrapper m-bottom-normal']//h4[1]"))
							.getText().split(",")[0].trim();
					System.out.println(strStoreName);

				}

				// strStoreName =
				// strStoreName.substring(strStoreName.indexOf("-") +
				// 1,strStoreName.indexOf("#")).trim();
				if (strStore1.trim().toLowerCase().contains(strStoreName.trim().toLowerCase())
						&& strStore2.trim().toLowerCase().contains(strStoreName.trim().toLowerCase())) {
					report.addReportStep(
							"Verify the both BOSS products are selected same store for Pick Up", "Same Store:<b> "
									+ commonData.lstStoreNames.get(0) + "</b> is selected for the both BOSS products",
							StepResult.PASS);

				}

				else {
					report.addReportStep("Verify the both BOSS  products are selected same store for Pick Up",
							"Same Store was not selected for the both BOSS products", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify the both BOSS  products are selected same store for Pick Up",
						"Currently displayed is not pick up options page", StepResult.FAIL);
			}

		}
	}

	public void verifyPickUpOptionLocations() throws Exception {
		verifyAndCloseSaveTripOverlay();
		if (wh.isElementPresent(By.xpath("//div[contains(@class,'pick-up-store-wrapper')]"), 7)) {
			try {
				List<WebElement> lstViewLineItem = driver
						.findElements(By.xpath("//div[contains(@class,'pick-up-store-wrapper')]"));
				System.out.println(lstViewLineItem.size());
				List<String> lstStrProd = new ArrayList<String>();
				for (WebElement lineItems : lstViewLineItem) { //
					lineItems.findElement(By.xpath(".//i[@class='icon-plus-orange']")).click();
					String strStore = "";
					if (wh.isElementPresent(lineItems, By.xpath("//div[contains(@class,'pick-up-store-wrapper')]"),
							7)) {
						strStore = lineItems
								.findElement(
										By.xpath("//*[@class='address-wrapper m-bottom-normal']//*[@class='bold']"))
								.getText().split("#")[1];
						System.out.println(strStore);
						List<WebElement> lstViewProductNames = driver
								.findElements(By.xpath("//*[@class='products-list m-left-small']//h3[1]"));
						for (WebElement webSingleProductDesc : lstViewProductNames) {
							String strProd = webSingleProductDesc.getText();
							System.out.println(strProd + "_Store#" + strStore + "_bopis");

							lstStrProd.add(strProd + "_Store#" + strStore + "_bopis");
						}

						for (int i = 0; i < commonData.lstProductNames.size(); i++) {

							if (commonData.lstProductNames.get(i).contains("_bopis")) {

								String strTempProdName = commonData.lstProductNames.get(i).substring(0,
										commonData.lstProductNames.get(i).indexOf("_bopis"));
								boolean blnStringCompare = compareTwoStrings(strTempProdName, lstStrProd.get(i));

								System.out.println(commonData.lstProductNames);
								System.out.println(strTempProdName);

								if (blnStringCompare || (i == (commonData.lstProductNames.size()))) {
									if (blnStringCompare) {

										report.addReportStep(
												"Verify <b>Product Name:" + commonData.lstProductNames.get(i)
														+ "</b> in Pick Up Option page",
												"<b>Product Name</b> is displayed in Pick Up Option page",
												StepResult.PASS);
										break;

									} else {
										report.addReportStep("Verify <b>Product Name</b> in Pick Up Option page",
												"Product Name<b>" + commonData.lstProductNames.get(i)
														+ "</b> does not match with the product" + " name <b>"
														+ lstStrProd.get(i) + "</b> in Pick Up Option page",
												StepResult.FAIL);
									}

								}
							}

						}

					} else {
						report.addReportStep("Verify that Pick up store details are displayed",
								"The store details are displayed", StepResult.FAIL);
					}
				}

			}

			catch (Exception e) {
				report.addReportStep("Verify <b>Product</b> in Pick Up Option page",
						"<b>Product</b> is not displayed in Pick Up Option page", StepResult.WARNING);
			}

		} else {
			report.addReportStep("Verify that product section is displayed in Pick up options page",
					"Unable to find the product section", StepResult.FAIL);
		}

	}

	/**
	 * Component to compare two strings and results out the percentage of match
	 * 
	 * 
	 * @since Jul 1, 2013
	 * @author PXM8043
	 */
	public boolean compareTwoStrings(String strProduct1, String strProduct2) {

		Double intNameMatchCount = 0.0;

		Double intNameMatchPercent = 0.0;

		String strProductNameArray[] = strProduct1.split(" ");

		String strProductNameDesc = strProduct2;

		for (int i = 0; i < strProductNameArray.length; i++)

		{

			if (strProductNameDesc.toLowerCase().contains(strProductNameArray[i].toLowerCase()))

			{

				intNameMatchCount++;

			}

		}

		intNameMatchPercent = ((intNameMatchCount / strProductNameArray.length) * 100);

		System.out.println(intNameMatchPercent);

		if (intNameMatchPercent > 30.0)

		{

			return true;

		} else {
			return false;
		}

	}

	public void choosePickupDateAndTimeAndVerify() throws Exception {

		verifyAndCloseSaveTripOverlay();
		Thread.sleep(10000);
		By ChoosePickUpTime = By.xpath("//h4[contains(.,'Choose a pick up date and time')]");

		wh.clickElement(ChoosePickUpTime);
		report.addReportStep(" click on Choose Pick Up Date and Time radio button in PickUp optio  page.",
				"<b>Choose Pick Up Date and Time</b> radio button is selected", StepResult.DONE);
		if (wh.isElementPresent(pickupdateOverlay, 2)) {

			try {
				Select selPickUpdate = new Select(driver.findElement(PickUpDate));
				selPickUpdate.selectByIndex(2);

				String strTempDate = selPickUpdate.getFirstSelectedOption().getText();
				commonData.strSelectDate.add(strTempDate);
				commonData.overlaySelectedDate = strTempDate;

				report.addReportStep("Select a date from the Pickup date drop down",
						"Date <b>" + strTempDate + "</b> selected", StepResult.PASS);

			} catch (Exception e) {
				report.addReportStep("Select a date from the Pickup date drop down",
						"Unable to select a Date from the drop down", StepResult.FAIL);
			}

		}

		// if (cf.waitForElement(driver,PickUpTime, 2)) {

		try {
			Select selPickUpTime = new Select(driver.findElement(PickUpTime));
			selPickUpTime.selectByIndex(2);

			String strTempTime = selPickUpTime.getFirstSelectedOption().getText();
			commonData.strSelectTime.add(strTempTime);
			commonData.overlaySelectedTime = strTempTime;
			report.addReportStep("Select a date from the Pickup Time drop down",
					"Time <b>" + strTempTime + "</b> selected", StepResult.PASS);

		} catch (Exception e) {
			report.addReportStep("Select a Time from the Pickup Time drop down",
					"Unable to select a Time from the drop down", StepResult.FAIL);
		}

		wh.jsClick(savePickupTime);
		// }

		if (wh.isElementPresent(PickUptimedetails, 3)) {

			String strchoosenDate = wh.getText(choosenDate);
			String strchoosentime = wh.getText(choosentime);

			report.addReportStep(" verify choosen date and time details are displayed",
					"choose date and time  details:<b>" + strchoosenDate + "and" + strchoosentime
							+ "</b>are displayed ",
					StepResult.PASS);

		} else {

			report.addReportStep("Select a date Time the Pickup Time drop down", "Unable to find the drop down",
					StepResult.FAIL);
		}
	}

	public WebElement getFirstSelectedOption() {
		for (WebElement option : getOptions()) {
			if (option.isSelected()) {
				return option;
			}
		}

		throw new NoSuchElementException("No options are selected");
	}

	public List<WebElement> getOptions() {
		List<WebElement> lstoption = driver.findElements(By.tagName("option"));
		return lstoption;
	}

	public void selectByIndex(int index) {
		String match = String.valueOf(index);

		boolean matched = false;
		for (WebElement option : getOptions()) {
			if (match.equals(option.getAttribute("index"))) {
				setSelected(option);
				if (!(isMultiple())) {
					return;
				}
				matched = true;
			}
		}
		if (!(matched))
			throw new NoSuchElementException("Cannot locate option with index: " + index);
	}

	private void setSelected(WebElement option) {
		if (!(option.isSelected()))
			option.click();
	}

	public boolean isMultiple() {
		return this.isMulti;
	}

	public void verifyTotalPickUpOptionsPage() throws Exception {
		String total = null;
		if (wh.isElementPresent(totalRightRail, 7)) {
			total = wh.getText(totalRightRail);
			report.addReportStep("Verify whether total is displayed in pickup options page",
					"Total" + total + " is displayed in pickup options page", StepResult.PASS);
		} else {
			report.addReportStep("Verify whether total is displayed in pickup options page",
					"Total" + total + " is not displayed in pickup options page", StepResult.FAIL);
		}

	}

	public void verifyPickUpText() throws Exception {

		if (wh.isElementPresent(pickUpToday, 7)) {
			String txt = wh.getText(pickUpToday);
			if (txt.contains("Pick Up TODAY At:")) {
				report.addReportStep("Verify pickup text in pick up options page",
						"Pick up text" + txt + " is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify pickup text in pick up options page",
						"Pick up text" + txt + " is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify pickup text in pick up options page", "Pick up text is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyContinueAndBackBtn() throws Exception {

		if (wh.isElementPresent(continueBtn, 7)) {
			String txt = wh.getText(continueBtn);
			if (txt.contains("CONTINUE")) {
				report.addReportStep("Verify Continue button is present in pick up options page",
						txt + " button is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify Continue button is present in pick up options page",
						txt + " button is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Continue button is present in pick up options page",
					"Continue button is not displayed", StepResult.FAIL);
		}
		if (wh.isElementPresent(backBtn, 7)) {
			String txt = wh.getText(backBtn);
			if (txt.contains("BACK")) {
				report.addReportStep("Verify Back button is present in pick up options page",
						txt + " button is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify Back button is present in pick up options page",
						txt + " button is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Back button is present in pick up options page",
					"Back button is not displayed", StepResult.FAIL);
		}

	}

	public void verifyChooseInStorePickUp() throws Exception {

		if (wh.isElementPresent(deskTxt, 7)) {
			String txt = wh.getText(deskTxt);
			if (txt.contains("Choose In-Store Pickup Location")) {
				report.addReportStep("Verify Choose In-Store Pickup Location is present in pick up options page",
						txt + " is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify Choose In-Store Pickup Location is present in pick up options page",
						txt + " is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Choose In-Store Pickup Location is present in pick up options page",
					"Choose In-Store Pickup Location is not displayed", StepResult.FAIL);
		}

	}

	public void verifyChooseAnotherPersonDetailsSaved() throws Exception {
		wh.jsClick(chooseAnotherPerson);

		if (wh.isElementPresent(pickupPersonOverlay, 7)) {
			wh.sendKeys(WhoFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(WhoLasttName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(WhoEmail, dataTable.getCommonData(CommonDataColumn.GuestEmail));

			wh.sendKeys(MobileNum, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.jsClick(savechangePerson);
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is saved", StepResult.PASS);
		} else {
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is not saved", StepResult.FAIL);
		}

	}

	public void verifyMobileNumberAutoFormat() throws Exception {

		if (wh.isElementPresent(MobilePh, 7)) {
			wh.sendKeys(MobilePh, "4546565656");
			String txt = wh.getAttribute(MobilePh, "value");
			if (txt.contains("(454) 656-5656")) {
				report.addReportStep("Verify that mobile number is auto formatted in pickup options page",
						"Mobile number is auto formatted in pickup options page", StepResult.PASS);

			} else {
				report.addReportStep("Verify that mobile number is auto formatted in pickup options page",
						"Mobile number is not auto formatted in pickup options page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that mobile number is auto formatted in pickup options page",
					"Mobile number is not displayed in pickup options page", StepResult.FAIL);
		}

	}

	public void verifyImageInRightRail() throws Exception {

		if (wh.isElementPresent(img, 7)) {
			report.addReportStep("Verify image is displayed in pick up options page",
					"Image is displayed in pick up options page", StepResult.PASS);

		} else {
			report.addReportStep("Verify image is displayed in pick up options page",
					"Image is not displayed in pick up options page", StepResult.FAIL);
		}

	}

	public void verifyAddressPickUpOptionsPg() throws Exception {

		if (wh.isElementPresent(AddressSection, 7)) {
			String address = wh.getText(AddressSection);
			report.addReportStep("Verify address is displayed in pick up options page",
					"Address" + address + " is displayed in pick up options page", StepResult.PASS);

		} else {
			report.addReportStep("Verify address is displayed in pick up options page",
					"Address is not displayed in pick up options page", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify save trip section
	 * 
	 * @since Feb 05, 2016
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifySaveTripOption() throws Exception {
		verifyNoOfProdSaveTripSec();
		if (wh.isElementPresent(saveTripHeadin)) {
			report.addReportStep("Verify that bopis savetrip overlay is displayed", "Savetrip is displayed",
					StepResult.PASS);

			String strTxt = driver
					.findElement(By
							.xpath("//*[@class='single-store-pickup-options float-clear radio-btns-wrapper flex-box']"))
					.getText().toLowerCase();
			System.out.println(strTxt);
			System.out.println(commonData.liststoresCart);
			// String strstoresCart[] = scriptHelper.commonData.liststoresCart;

			for (int i = 0; i < commonData.liststoresCart.size(); i++)

			{
				if (strTxt.contains(commonData.liststoresCart.get(i).toLowerCase())) {
					report.addReportStep("Verify Stores in Save Trip Overlay Section",
							"Selected Stores " + commonData.liststoresCart + " are displaeyd in Save Trip Section",
							StepResult.PASS);
				}

				else {
					report.addReportStep("Verify Stores in Save Trip Overlay Section",
							"Selected Stores are not displaeyd in Save Trip Section", StepResult.FAIL);
				}
			}
			System.out.println(driver.findElement(By.xpath("(//*[@name='smart_pickup_store'])[1]")).getText());
			// driver.findElement(By.xpath("//div[@class='storesContainer']/div[1]/div")).click();
			wh.clickElement(firstStoreInSaveTrip);

			report.addReportStep("Click the Radio button for a store displayed in the SAVE trip section",
					"Radio button selected", StepResult.PASS);

			/*
			 * cf.selectRadiobutton(driver, "xpath",
			 * "//div[@class='storesContainer']/div[2]/div");
			 */

			if (wh.isElementPresent(updateStoreSelection, 2)) {

				wh.jsClick(updateStoreSelection);
			}
			if (wh.isElementPresent(storeSection, 3)) {
				int intStores = driver.findElements(By.xpath("//*[@class='pickup-options-layout overflowHidden']"))
						.size();
				System.out.println(intStores);
				Thread.sleep(3000);
				if (intStores == 1) {
					report.addReportStep(
							"Verify Only one store is displayed in Pickup Option page After Save trip selection",
							"Only one store is displayed in Pickup Option page After Save trip selection",
							StepResult.PASS);
				} else {
					report.addReportStep(
							"Verify Only one store is displayed in Pickup Option page After Save trip selection",
							"Stores are not displayed in Pickup Option page After Save trip selection",
							StepResult.FAIL);
				}
			} else {
				report.addReportStep(
						"Verify Only one store is displayed in Pickup Option page After Save trip selection",
						"Unable to find the View items link", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Click the 'update store selection' button", "Button not found", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
		// driver.findElement(By.id("smartOverlayButton")).click();

	}

	/**
	 * To get no of products in pick up option page before save trip selection
	 * 
	 * @since Jul 4, 2013
	 * @author sxd8901
	 * @throws Exception
	 */
	public void verifyNoOfProdSaveTripSec() throws Exception {
		wh.isElementPresent(saveTripHeadin);

		int intStores = driver
				.findElements(By.cssSelector(
						".single-store-pickup-options.float-clear.radio-btns-wrapper.flex-box .radio-set.m-bottom-normal"))
				.size();
		System.out.println(intStores);
		report.addReportStep("Verify Number of Stores displayed in Pickup Option page before Save trip selection",
				"" + intStores + " stores are displayed in  PickUpOption page before Save Trip selection",
				StepResult.DONE);

	}

	public void clickChooseAnotherPersonDetails() throws Exception {

		if (wh.isElementPresent(chooseAnotherPerson, 7)) {
			wh.jsClick(chooseAnotherPerson);
			report.addReportStep("Verify Choose another person details is clicked in pick up options page",
					"Choose another person details is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Verify Choose another person details is clicked in pick up options page",
					"Choose another person details is not clicked", StepResult.FAIL);
		}

	}

	public void enterValidSymbolsPickUpFirstName(String symbol) throws Exception {

		String fName = "John" + symbol;
		if (wh.isElementPresent(WhoFirstName, 3)) {
			wh.clearElement(WhoFirstName);
			wh.sendKeys(WhoFirstName, fName);
			report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify " + fName + " is entered", "First name text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterChooseAnotherPersonDetails() throws Exception {
		wh.jsClick(chooseAnotherPerson);

		if (wh.isElementPresent(pickupPersonOverlay, 7)) {
			wh.sendKeys(WhoFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(WhoLasttName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(WhoEmail, dataTable.getCommonData(CommonDataColumn.GuestEmail));

			wh.sendKeys(MobileNum, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is saved", StepResult.PASS);
		} else {
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is not saved", StepResult.FAIL);
		}

	}

	public void clickSaveAnotherPersonDetails() throws Exception {

		if (wh.isElementPresent(savechangePerson, 7)) {
			wh.jsClick(savechangePerson);
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is saved", StepResult.PASS);
		} else {
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is not saved", StepResult.FAIL);
		}

	}

	public void enterValidSymbolsPickUpLastName(String symbol) throws Exception {

		String fName = "John" + symbol;
		if (wh.isElementPresent(WhoLasttName, 3)) {
			wh.clearElement(WhoLasttName);
			wh.sendKeys(WhoLasttName, fName);
			report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify " + fName + " is entered", "First name text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsPickUpFirstName() throws Exception {

		int i = 0;

		if (wh.isElementPresent(WhoFirstName, 3)) {
			for (i = 0; i < commonData.symbolName.length; i++) {
				String fName = "John" + commonData.symbolName[i];
				wh.clearElement(WhoFirstName);
				wh.sendKeys(WhoFirstName, fName);
				report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);
				wh.clickElement(WhoLasttName);
				if (wh.isElementPresent(WhoFirstNameErr, 5)) {
					String err = wh.getText(WhoFirstNameErr);
					if (err.contains("We are sorry, but the system does not recognize special characters such as")) {
						report.addReportStep("Verify error message is displayed for " + fName + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + fName + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				}

				else {
					report.addReportStep("Verify error message is displayed for " + fName + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(WhoFirstName);
				wh.sendKeys(WhoFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
				wh.clickElement(WhoLasttName);
			}

		} else

		{
			report.addReportStep("Verify First Name is entered with invalid symbol",
					"First name text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsPickUpLastName() throws Exception {

		int i = 0;

		if (wh.isElementPresent(WhoLasttName, 3)) {
			for (i = 0; i < commonData.symbolName.length; i++) {
				String lName = "John" + commonData.symbolName[i];
				wh.clearElement(WhoLasttName);
				wh.sendKeys(WhoLasttName, lName);
				report.addReportStep("Verify " + lName + " is entered", lName + " is entered", StepResult.PASS);
				wh.clickElement(WhoFirstName);
				if (wh.isElementPresent(WhoLastNameErr, 5)) {
					String err = wh.getText(WhoLastNameErr);
					if (err.contains("We are sorry, but the system does not recognize special characters such as")) {
						report.addReportStep("Verify error message is displayed for " + lName + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + lName + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + lName + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(WhoLasttName);
				wh.sendKeys(WhoLasttName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
				wh.clickElement(WhoFirstName);
			}

		} else

		{
			report.addReportStep("Verify Last Name is entered with invalid symbol",
					"Last name text box is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify that the details of STS item added to cart is
	 * displayed in STS POD
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifySTSPODItemDetails() throws Exception {
		verifyDisplayedItemInPOD("Ship to Store", STSPod);
	}

	/**
	 * Component to verify that the details of item added to cart is displayed
	 * in rightrail POD
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyDisplayedItemInPOD(String strPODname, By strLocator) throws Exception {

		if (wh.isElementPresent(strLocator, 4)) {
			report.addReportStep("Verify that " + strPODname + " POD is displayed with the Item title",
					"POD is displayed with the item title", StepResult.PASS);

			WebElement webPOD = driver.findElement(strLocator);
			if (wh.isElementPresent(PodAmount, 5)) {
				String strTempCharge = webPOD.findElement(PodAmount).getText();

				report.addReportStep("Verify that Price is displayed for the product",
						"" + strTempCharge + " is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Price is displayed for the product", "Unable to find the price",
						StepResult.FAIL);
			}

			if (wh.isElementPresent(PodQty, 4)) {
				String strTempQty = webPOD.findElement(PodQty).getText();
				report.addReportStep("Verify that Quantity is displayed for the product",
						"" + strTempQty + " is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify that Quantity is displayed for the product", "Unable to find the Quantity",
						StepResult.FAIL);
			}

			try {
				driver.findElement(strLocator).click();
				report.addReportStep("Click the item description displayed in the " + strPODname + " POD",
						"Description clicked", StepResult.PASS);
				if (wh.isElementPresent(QuickViewModal, 4)) {
					report.addReportStep("Verify that Item quick view- modal  is displayed", "The modal is displayed",
							StepResult.PASS);

					WebElement webQvModal = driver.findElement(QuickViewModal);
					if (wh.isElementPresent(ProductTitle, 2)) {
						String strProdTitle = webQvModal.findElement(ProductTitle).getText();
						report.addReportStep("Verify that product title is displayed in the QV modal",
								"Product title is displayed as " + strProdTitle + "", StepResult.PASS);
					} else {
						report.addReportStep("Verify that product title is displayed in the QV modal",
								"Product title is not displayed", StepResult.FAIL);
					}
					if (wh.isElementPresent(ProductAttribute, 2)) {
						String strProdAttribute = webQvModal.findElement(ProductAttribute).getText();
						report.addReportStep("Verify that product Attributes are displayed in the QV modal",
								"Product Attributes are displayed as " + strProdAttribute + "", StepResult.PASS);
					} else {
						report.addReportStep("Verify that product Attributes are displayed in the QV modal",
								"Product Attributes are not displayed", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify that Item quick view- modal  is displayed",
							"The modal is not displayed", StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep("Click the item description displayed in the " + strPODname + "POD",
						"Description not clicked", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that " + strPODname + " POD is displayed", "Unable to find the item title",
					StepResult.FAIL);
		}

	}

	/**
	 * To Click Back button on pickup option page
	 * 
	 * @throws Exception
	 */
	public void clickBackBtn() throws Exception {

		if (wh.isElementPresent(backBtn, 7)) {
			String txt = wh.getText(backBtn);
			if (txt.contains("BACK")) {
				wh.clickElement(backBtn);
				report.addReportStep("Verify Back button is clicked in pick up options page",
						txt + " button is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify Back button is clicked in pick up options page",
						txt + " button is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Back button is clicked in pick up options page",
					"Back button is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * component to verify that error message is displayed on entering a invalid
	 * phone number in pick up options page
	 * 
	 * @throws Exception
	 */
	public void verifyInvalidPhoneNumberErrorInPickup() throws Exception {
		// Verify the PICKUP OPTIONS Page
		if (wh.isElementPresent(PickUpOptionMessage, 5)) {
			report.addReportStep(
					"Verify that <b>Text Me When  My Order  Is Ready?</b> section is displayed below the <b>'Pick Up Options '</b> text and mobile number entry field is displayed.",
					"<b>Text Me When  My Order  Is Ready?</b>section followed by mobile number entry field is displayed below the <b>'Pick Up Options' </b>text.",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"Verify that <b>Text Me When  My Order  Is Ready?</b> section is displayed below the <b>'Pick Up Options '</b> text and mobile number entry field is displayed.",
					"<b>Text Me When  My Order  Is Ready?</b>section followed by mobile number entry field is not displayed below the <b>'Pick Up Options' </b>text.",
					StepResult.FAIL);
		}

		// verify the error message
		if (wh.isElementPresent(PhoneNumtextBox, 2)) {
			wh.sendKeys(PhoneNumtextBox, "00000000");
			wh.jsClick(continueBtn);
			wh.isElementPresent(InvalidPhNumerror, 10);
			String strerr = driver.findElement(InvalidPhNumerror).getText();
			System.out.println(strerr);
			if (strerr.contains("Please enter a valid phone number"))
				report.addReportStep("The error messge should be displayed as <b>Invaid format</b>",
						"<b>Invaid format</b> error message is displayed", StepResult.PASS);
		} else {
			report.addReportStep("The error messge should be displayed as <b>Invaid format</b>",
					"<b>Invaid format</b> error message is not displayed", StepResult.FAIL);
		}
	}

	public void verifyErrorMsgInChooseAnotPersonOverlay() {
		String strPickupPersonErrMsg = driver.findElement(FirstNameErr).getText();
		if (strPickupPersonErrMsg.trim().contains("First name is required. Please enter a first name")) {
			report.addReportStep(
					"verify that </b>First name is required. Please enter a first name</b> should be displayed when first name is left blank",
					"</b>Please enter a First Name.</b> is displayed when first name is left blank", StepResult.PASS);
		} else {
			report.addReportStep(
					"verify that </b>First name is required. Please enter a first name</b> should be displayed when first name is left blank",
					"</b>Please enter a First Name.</b> is not displayed when first name is left blank",
					StepResult.FAIL);
		}
		String strPickupPersonErrMsg2 = driver.findElement(LastNameErr).getText();
		if (strPickupPersonErrMsg2.trim().contains("Last name is required. Please enter a last name")) {
			report.addReportStep(
					"verify that </b>Last name is required. Please enter a last name</b> should be displayed when  Last Name is left blank",
					"</b>Please enter a Last Name.</b> is displayed when Last name is left blank", StepResult.PASS);

		} else {
			report.addReportStep(
					"verify that </b>Last name is required. Please enter a last name</b> should be displayed when Last Name is left blank",
					"</b>Please enter a Last Name.</b> is not displayed when Last name is left blank", StepResult.FAIL);
		}
	}

	/**
	 * Method to validate Instant Rebate Message in Shipping Options Page
	 * 
	 * @author u93wcs
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public void verifyStorePresentInPickupPage() throws InterruptedException {
		try {

			String StrPickUpStore = driver
					.findElement(By.cssSelector(".address-wrapper.m-bottom-normal > h4:nth-of-type(1)")).getText()
					.split("\\#")[1].trim();
			System.out.println(StrPickUpStore);
			System.out.println(commonData.cartStoreName);
			System.out.println(commonData.cartStatecity);
			if (StrPickUpStore.contains(commonData.cartStoreName)) {

				report.addReportStep(
						"verify the Store details are Cart Page", "<b>Store details</b> " + commonData.cartStoreName
								+ " & " + commonData.cartStatecity + " displayed in pickup page  is same as cart page",
						StepResult.PASS);
			}

			else {
				report.addReportStep("Verify the Store details are same in both Cart and Pickup Page",
						"Store details are not same", StepResult.FAIL);
			}

		} catch (Exception e) {
			report.addReportStep("Verify the Store details are same in both Cart and Pickup Page",
					"Store details are not same", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify Estimated sales tax
	 * 
	 * @throws Exception
	 */
	public void verifyEstimatedSalesTaxPymtPg() throws Exception {
		if (wh.isElementPresent(By.cssSelector("#sales-tax"), 3)) {
			String strEst = driver.findElement(By.cssSelector("#sales-tax")).getText();
			System.out.println(strEst);
			CommonData.TotalTax = strEst;
			if (strEst.matches("\\$[0-9]*.[0-9]{2}")) {
				report.addReportStep("Estimated sales should be displayed", "<b>" + strEst + " </b> is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Estimated sales should be displayed", "Estimated sales is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Estimated sales should be displayed", "Estimated sales is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * component to verify price present in pickup page
	 * 
	 * @throws InterruptedException
	 */
	public void verifyPriceInPickupPage() throws InterruptedException {
		try {

			String strPickUpPrice = driver.findElement(By.cssSelector("#total-price")).getText();
			System.out.println(strPickUpPrice);
			String Totalprice = strPickUpPrice + CommonData.TotalTax;
			System.out.println(commonData.strPrice);
			if (strPickUpPrice.contains(commonData.strPrice)) {
				report.addReportStep("Verify the Price details are same in both Cart and Pickup Page",
						"<b>Unit Price :</b>  " + commonData.strPrice + " is displayed same as in Cart page",
						StepResult.PASS);
			}
		} catch (Exception e) {
			report.addReportStep("Verify the Price details are same in both Cart and Pickup Page",
					"Price details are not same in both cart and pickup page", StepResult.FAIL);
		}

	}
	// ***************** Instant Rebates ************************//

	/**
	 * To select the pick up store in save trip overlay based on the multistore
	 * ID column in data sheet
	 * 
	 * @author rxk8443
	 * @throws Exception
	 */

	public PickupOptionPage clickpickupstores() throws Exception {
		String store = dataTable.getData(DataColumn.multistoreID);
		Thread.sleep(3000);
		By pickupstore = By.xpath(String.format("//*[@id='smart_pickup_store_%s']/../label", store));
		if (wh.isElementPresent(pickupstore)) {
			wh.clickElement(pickupstore);
			wh.clickElement(updatestoreselection);
			report.addReportStep("Pick store should be selected", "Pick store is selected", StepResult.PASS);
		} else {
			report.addReportStep("Pick store should be selected", "Pick store is not selected", StepResult.FAIL);
			rc.terminateTestCase("Radio button Not selected");
		}
		return this;
	}

	/**
	 * Method to get the price and store promo from the Pricing API
	 * 
	 * @author u93wcs
	 * @throws Exception
	 */

	public PickupOptionPage getpricedetails(DataBase database) throws Exception {

		int noOfItems = commonData.BOPISSKUList.size();
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.BOPISSKUList.get(i);
			String store = dataTable.getData(DataColumn.multistoreID);
			database.getUnitPriceFromPricingService(sku, store);
			commonData.IRList1.add(commonData.shortdesc);
			commonData.PriceList1.add(commonData.unitPriceDB);
		}
		return null;
	}

	/**
	 * Method to validate Instant Rebate Message in Pickup Options Page
	 * 
	 * @author u93wcs
	 * @return PickupOption page
	 * @throws Exception
	 */

	public PickupOptionPage verifyIRmessage() throws Exception {

		String IREligMsg1 = "";
		String IREligMsg3 = "";
		String IREligMsg4 = "";
		String IRInEligMsg1 = "";

		IREligMsg1 = commonData.InstantRebateEligMsg1_CC;
		IREligMsg3 = commonData.InstantRebateEligMsg3_CC;
		IRInEligMsg1 = commonData.InstantRebateIneligMsg1_CC;
		IREligMsg4 = commonData.InstantRebateEligMsg4_CC;

		int itemcount = commonData.BOPISSKUList.size();

		if ((itemcount > 1)) {

			IREligMsg1 = commonData.InstantRebateEligMsg2_CC;
			IRInEligMsg1 = commonData.InstantRebateIneligMsg2_CC;

		}

		for (int i = 0; i < itemcount; i++) {

			if ((commonData.mixedcart == true))

			{
				i = i + 1;
			}

			String sku = commonData.skuList.get(i);

			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);

			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));

			// Need to change based on the xpath for pickupoptions page
			// By InstantRebateMsg = By.xpath(".//*[@value='" + sku +
			// "']/../descendant::div[@class='cart-item-message']");

			if ((val2 < val1)) {

				if (wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IREligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is equal to Expected Msg" + IREligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is not equal to Expected Msg" + IREligMsg1, StepResult.FAIL);

					}

				}

				else if (wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IREligMsg3)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is equal to Expected Msg" + IREligMsg3, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is not equal to Expected Msg" + IREligMsg3, StepResult.FAIL);

					}

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
						&& (!(StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);

					}

				} else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}

			}

			else if ((val2 > val1))

			{
				if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
						&& (!(StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);

					}

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);

					}

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg",
								"IR Msg" + Msg + "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);

					}

				}

				else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}

			}

			else if ((val2 == val1)) {
				if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}
			}
			continue;
		}
		return this;
	}

	// ***************************End of Instant
	// Rebates**********************************************

	public void verifyPickUpOptionsContiner() throws Exception {

		if (wh.isElementPresent(pickUpOptionsContiner, 7))
			report.addReportStep("Pick Up Options Continer is displayed", "Pick Up Options Continer is displayed",
					StepResult.PASS);
		else {
			report.addReportStep("Pick Up Options Continer is displayed", "Pick Up Options Continer is not displayed",
					StepResult.FAIL);
			rc.terminateTestCase("PickUpOptionsPage");
		}
	}

	public void clickRightRailContinueBtn() throws Exception {
		if (wh.isElementPresent(rightRailContinueBtn)) {
			wh.clickElement(rightRailContinueBtn);
			report.addReportStep("click on 'Continue' button on Top of Right Rail in PickUp Options Page",
					"'Continue' button is clicked in PickUp Options Page ", StepResult.PASS);
		} else {
			report.addReportStep("click on 'Continue' button on Top of Right Rail in PickUp Options Page",
					"'Continue' button is not clicked in PickUp Options Page ", StepResult.FAIL);
		}
	}

	public void clickrigtRailSubmitOrderBtn() throws Exception {
		if (wh.isElementPresent(rightRailSubmitOrderBtn)) {
			wh.clickElement(rightRailSubmitOrderBtn);
			Thread.sleep(4000);
			report.addReportStep("click on 'Submit Order' button on Top of Right Rail in PickUp Options Page",
					"'Submit Order' button is clicked in PickUp Options Page ", StepResult.PASS);
		} else {
			report.addReportStep("click on 'Submit Order' button on Top of Right Rail in PickUp Options Page",
					"'Submit Order' button is not clicked in PickUp Options Page ", StepResult.FAIL);
		}
	}

	/**
	 * 
	 * Description : verify boss & bopis trip together in same store in pick up
	 * option page.
	 * 
	 * @since May 23, 2013
	 * @author sxd8901
	 */

	public void verifyBossBopisGrpToGthrForSameStr() {

		List<WebElement> listOfStores = driver.findElements(storelist);
		int intStoreCount = listOfStores.size();
		String[] strnoOfItems = driver.findElement(itemList).getText().split(" ");
		String strQty = strnoOfItems[0];
		System.out.println(strQty);
		int intnoOfItems = Integer.parseInt(strQty);
		System.out.println(intnoOfItems);
		if (intStoreCount == 1 && intnoOfItems == 2) {
			report.addReportStep("Verify BOPIS and BOSS items should be grouped together for same store ",
					"BOPIS and BOSS items are grouped together for same store ", StepResult.PASS);

		} else {
			report.addReportStep("Verify BOPIS and BOSS items should be grouped together for same store ",
					"BOPIS and BOSS items are not  grouped together for same store ", StepResult.FAIL);
		}

	}

	/**
	 * Click CART Bread Curb in pickup option page
	 * 
	 * @throws InterruptedException
	 */
	public void clickCartLinkinProgressBar() throws Exception {
		if (wh.isElementPresent(CartinProgressBar)) {
			wh.clickElement(CartinProgressBar);
			report.addReportStep("click on 'CART' Bread Crub on Top of Progress Bar in PickUp Options Page",
					"'CART' Bread Crub is clicked in PickUp Options Page ", StepResult.PASS);
		} else {
			report.addReportStep("click on 'CART' Bread Crub on Top of Progress Bar in PickUp Options Page",
					"'CART' Bread Crub  is not clicked in PickUp Options Page ", StepResult.FAIL);
		}
	}

	public PickupOptionPage msgChoosePupSection() throws Exception {

		if (wh.isElementPresent(choosePUPmsg, 5)) {
			String strErrMsg = wh.getText(choosePUPmsg);
			if (strErrMsg
					.contains("You will receive email notification(s) when your Item(s) are available for pickup.")) {
				report.addReportStep(
						"Verify  message <b>'You will receive email notification(s) when your Item(s) are available for pickup is'</b> displayed",
						"error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify message: 'You will receive email notification(s) when your Item(s) are available for pickup.' displayed",
						"Page level error message <b>'You will receive email notification(s) when your Item(s) are available for pickup.'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify message: 'You will receive email notification(s) when your Item(s) are available for pickup.' displayed",
					"Page level error message <b>'You will receive email notification(s) when your Item(s) are available for pickup.'</b> is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	public void verifySelectedtimeanddate() throws Exception {
		if (wh.isElementPresent(PickUptimedetails, 3)) {

			String strchoosenDate = wh.getText(choosenDate);
			String strchoosentime = wh.getText(choosentime);
			System.out.println(strchoosenDate);
			System.out.println(strchoosentime);
			String Date = commonData.overlaySelectedDate;
			String[] parts = Date.split(" ");

			String month = parts[parts.length - 2];
			String month_updated = month.substring(0, 3);

			String selectedDate = parts[parts.length - 4] + parts[parts.length - 3] + " " + month_updated + " "
					+ parts[parts.length - 1];
			String selectedTime = commonData.overlaySelectedTime;
			System.out.println(selectedTime);
			System.out.println(selectedDate);

			if ((selectedDate.equalsIgnoreCase(strchoosenDate)) && (selectedTime.equalsIgnoreCase(strchoosentime))) {
				report.addReportStep(" verify choosen date and time details are displayed",
						"choose date and time  details:<b>" + strchoosenDate + "and" + strchoosentime + "</b>are same ",
						StepResult.PASS);
			} else {

				report.addReportStep(" verify choosen date and time details are displayed",
						"choose date and time  details are not same ", StepResult.FAIL);
			}
		}

	}

	public void changePickupInstoreLocation() throws Exception {
		if (wh.isElementPresent(proDesk)) {
			wh.clickElement(proDesk);

			report.addReportStep("Verify that pro desk radio button is clicked", "Pro Desk Radio button is clicked",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify that pro desk radio button is clicked", "Pro Desk Radio button is not clicked",
					StepResult.FAIL);
		}

	}

	public void verifyStoreDetailsAfterSaveTripUpdate() throws Exception {
		if (wh.isElementPresent(storeDetails)) {
			String storeInPage = wh.getText(storeDetails);
			String[] parts = commonData.selectedStore.split("\\_");
			String storeInOverlay = parts[3];
			// String storeInOverlay =
			// commonData.selectedStore.substring(commonData.selectedStore.length()-4);
			System.out.println(storeInOverlay);
			if (storeInPage.contains(storeInOverlay))

			{
				report.addReportStep("Verify that Store details",
						"Selected store is displayed in PUOP Page after store update in save trip overlay",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify that Store details",
						"Selected store is not displayed in PUOP Page after store update in save trip overlay",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify that Store details",
					"Store Details not displayed in PUOP Page after store update in save trip overlay",
					StepResult.FAIL);
		}
	}

	public void verifyStoreDetailsAfterNoThanksSelected() throws Exception {

		String storeInCart = dataTable.getData(DataColumn.LocalizeStore);
		By storeDetail = By.xpath("//h4[contains(text(),'" + storeInCart + "')]");
		if (wh.isElementPresent(storeDetail)) {
			report.addReportStep("Verify the store in PUOP", "Store" + storeInCart + "is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify the store in PUOP", "Store" + storeInCart + "is not displayed",
					StepResult.FAIL);
		}
	}

	public void enterInvalidPickupEmail() throws Exception {

		if (wh.isElementPresent(WhoEmail, 3)) {

			wh.sendKeys(WhoFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(WhoLasttName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.clearElement(WhoEmail);
			wh.sendKeys(WhoEmail, commonData.zipcdSymbol);
			wh.clickElement(MobileNum);
			if (wh.isElementPresent(WhoEmailErr, 5)) {
				String err = wh.getText(WhoEmailErr);
				if (err.contains("Enter an email address such as name@domain.com")) {
					report.addReportStep("Verify error message is displayed",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {

					report.addReportStep("Verify error message is displayed",
							"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);
				}
			}
		}
	}

	public void editPickupDateAndTimeAndVerify() throws Exception {

		verifyAndCloseSaveTripOverlay();
		Thread.sleep(10000);
		By editPickUpTime = By.xpath("//a[@class='text-primary bold edit-date-time']");

		wh.clickElement(editPickUpTime);
		Thread.sleep(10000);
		report.addReportStep(" click on Choose Pick Up Date and Time radio button in PickUp optio  page.",
				"<b>Choose Pick Up Date and Time</b> radio button is selected", StepResult.DONE);

		if (wh.isElementPresent(pickupdateOverlay, 2)) {

			try {
				Select selPickUpdate = new Select(driver.findElement(PickUpDate));
				selPickUpdate.selectByIndex(3);

				String strTempDate = selPickUpdate.getFirstSelectedOption().getText();
				commonData.overlaySelectedDate = strTempDate;
				report.addReportStep("Select a date from the Pickup date drop down",
						"Date <b>" + strTempDate + "</b> selected", StepResult.PASS);

			} catch (Exception e) {
				report.addReportStep("Select a date from the Pickup date drop down",
						"Unable to select a Date from the drop down", StepResult.FAIL);
			}

		}

		try {
			Select selPickUpTime = new Select(driver.findElement(PickUpTime));
			selPickUpTime.selectByIndex(3);

			String strTempTime = selPickUpTime.getFirstSelectedOption().getText();
			commonData.overlaySelectedTime = strTempTime;
			report.addReportStep("Select a date from the Pickup Time drop down",
					"Time <b>" + strTempTime + "</b> selected", StepResult.PASS);

		} catch (Exception e) {
			report.addReportStep("Select a Time from the Pickup Time drop down",
					"Unable to select a Time from the drop down", StepResult.FAIL);
		}

		wh.jsClick(savePickupTime);
		// }

		if (wh.isElementPresent(PickUptimedetails, 3)) {

			String strchoosenDate = wh.getText(choosenDate);
			String strchoosentime = wh.getText(choosentime);
			System.out.println(strchoosenDate);
			System.out.println(strchoosentime);

			report.addReportStep(" verify choosen date and time details are displayed",
					"choose date and time  details:<b>" + strchoosenDate + "and" + strchoosentime
							+ "</b>are displayed ",
					StepResult.PASS);

		} else {

			report.addReportStep("Select a date Time the Pickup Time drop down", "Unable to find the drop down",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify Pickup 'Date and Time' Drop Down does not display
	 * Blackout Days on Pickup Options page
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyPickUpDateTimeNotPresent() throws Exception {
		if (wh.isElementPresent(By.id("pickupDate"))) {
			report.addReportStep(
					"User should verify Pickup 'Date and Time' Drop Down is not displaying Blackout Days on Pickup Options page",
					"System is displaying the blackout days in the time and date drop down in pickup options page",
					StepResult.FAIL);
		} else {
			report.addReportStep(
					"User should verify Pickup 'Date and Time' Drop Down is not displaying Blackout Days on Pickup Options page",
					"System is not displaying the blackout days in the time and date drop down in pickup options page",
					StepResult.PASS);
		}
	}

	/*
	 * Component to verify "I will pick up the item" text is displayed by
	 * default
	 */
	public void verifyIwillPickUpItemtext(String arg1) throws Exception {
		String testMessage = arg1;
		if (wh.isElementPresent(FirstRadioButtonText, 2)) {
			report.addReportStep("verify I will Pick up the item text is displayed",
					"I will Pick up the item text is displayed", StepResult.PASS);
			String text = driver.findElement(FirstRadioButtonText).getText();
			String color = driver.findElement(FirstRadioButtonText).getCssValue("color");
			if ((text.equals(testMessage)) && (color.equals("rgba"))) {
				report.addReportStep("verify I will Pick up the item text is selected by default in Orange color",
						"I will Pick up the item text is selected by default in Orange color", StepResult.PASS);
			} else {
				report.addReportStep("verify I will Pick up the item text is selected by default in Orange color",
						"I will Pick up the item text is not selected by default in Orange color", StepResult.WARNING);
			}

		} else {
			report.addReportStep("verify I will Pick up the item text is displayed",
					"I will Pick up the item text is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * 
	 * Description : verify pick up date & time drop down in pick up option page
	 * 
	 * @since May 24, 2013
	 * @author sxd8901
	 */

	public void verifyPickUpDateTimeDropDown() {
		List<WebElement> lstDate = driver.findElements(By.xpath("//select[contains(@id,'pickupDate')]"));
		List<WebElement> lstTime = driver.findElements(By.xpath("//select[contains(@id,'pickupTime')]"));
		System.out.println(lstDate.size());
		System.out.println(lstTime.size());
		for (WebElement objDate : lstDate) {
			System.out.println("Date DropDown: " + objDate.isDisplayed());
		}
		for (WebElement objTime : lstTime) {
			System.out.println("Time DropDown: " + objTime.isDisplayed());
		}
		report.addReportStep(
				"Verify the Date and Time field are not  editable by user by changing different dates and times from Date and Time Drop Down",
				"User is not able to edit both the date and time drop downs", StepResult.DONE);
	}

	/**
	 * 
	 * Description : get current pick up date for all items added to the cart
	 * 
	 */

	public List<WebElement> getCurrentPickUpDate() {
		List<WebElement> pickUpDate = driver.findElements(By.xpath("//*[@class='pickup-date']"));
		return pickUpDate;
	}

	/**
	 * Description : get current pick up time for all items added to the cart
	 * 
	 */

	public List<WebElement> getCurrentPickUpTime() {
		List<WebElement> pickUpTime = driver.findElements(By.xpath("//*[contains(@class,'pickup-time')]"));
		return pickUpTime;

	}

	/**
	 * Component to get the currently selected pickup date and time from pick up
	 * options page To be used for 2 stores only
	 */
	public void getCurrentPickUpDatesTwoStores() {
		try {
			int count = 0;
			for (WebElement web : getCurrentPickUpDate()) {
				commonData.strSelectDate.add(web.getText().trim());
			}
			for (WebElement web : getCurrentPickUpTime()) {
				commonData.strSelectTime.add(web.getText().trim());
			}
			report.addReportStep("Extract the pickup date and time details", "Fetched the details", StepResult.PASS);
		} catch (Exception e) {
			report.addReportStep("Extract the pickup date and time details", "Unable to fetch the details",
					StepResult.FAIL);
		}
	}

	public void verifyRRPricePPOP() throws Exception {
		int itemcount = commonData.BOPISSKUList.size();

		for (int i = 0; i < itemcount; i++) {
			String proddesc = commonData.Proddesc.get(i);
			By prodrightrailPrice = By.xpath(
					"//div[@class='tablet-checkout-right-rail']//h3[contains(text(),'" + proddesc + "')]/../h3[2]");
			By prodrightrailqty = By.xpath("//div[@class='tablet-checkout-right-rail']//h3[contains(text(),'" + proddesc
					+ "')]/../h3[3]/span[2]");

			String price = wh.getText(prodrightrailPrice).replace("$", "");
			String qty = wh.getText(prodrightrailqty);
			System.out.println("price:" + price);

			double price1 = Double.parseDouble(price);
			double qty1 = Double.parseDouble(qty);
			// Double totalprice = price1 * qty1;

			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));
			double qtypriceval1 = val1 * qty1;
			double qtypriceval2 = val2 * qty1;

			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);
			System.out.println("val1:" + qtypriceval1);
			System.out.println("val2:" + qtypriceval2);
			System.out.println("price1:" + price1);

			if ((val2 < val1) || (val2 > val1)) {

				if (((StorePromo1).contains("INSTANT_REBATES")) || ((StorePromo2).contains("INSTANT_REBATES"))) {
					if (price1 == qtypriceval2) {
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
								StepResult.PASS);
					} else {
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
								StepResult.FAIL);

					}
				} else if ((!(StorePromo1).contains("INSTANT_REBATES"))
						|| (!(StorePromo2).contains("INSTANT_REBATES"))) {
					if (price1 != qtypriceval2) {
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
								StepResult.PASS);
					} else {
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
								StepResult.FAIL);

					}
				}

			} else if (val1 == val2) {
				if (price1 == qtypriceval2) {
					report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
							StepResult.PASS);
				} else {
					report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
							StepResult.FAIL);

				}
			}

		}

	}
	
	public void verifyPodValueinPickUp() throws Exception
	{
		if(wh.isElementPresent(By.xpath("(//*[@class='checkout-summary clear']//div)[6]//h3[1]"),4))
		{
			String Prodname=driver.findElement(By.xpath("(//*[@class='checkout-summary clear']//div)[6]//h3[1]")).getText();
			report.addReportStepNoScreenshots("Verify Product name is displayed in right rail pod", "Verify Product name"  + Prodname +  "is displayed in right rail pod", StepResult.PASS);
		}
		else
		{
			report.addReportStepNoScreenshots("Verify Product name is displayed in right rail pod", "Verify Product name is displayed in right rail pod", StepResult.PASS);
		}
		
		if(wh.isElementPresent(By.xpath("(//*[@class='checkout-summary clear']//div)[6]//h3[2]"),4))
		{
			String ProdPrice=driver.findElement(By.xpath("(//*[@class='checkout-summary clear']//div)[6]//h3[2]")).getText();
			report.addReportStepNoScreenshots("Verify Product Price is displayed in right rail pod", "Verify Product price"  + ProdPrice +  "is displayed in right rail pod", StepResult.PASS);
		}
		else
		{
			report.addReportStepNoScreenshots("Verify Product Price is displayed in right rail pod", "Verify Product Price is displayed in right rail pod", StepResult.PASS);
		}
		
		if(wh.isElementPresent(By.xpath("(//*[@class='checkout-summary clear']//div)[6]//h3[3]//span[1]"),4))
		{
			String ProdQty=driver.findElement(By.xpath("(//*[@class='checkout-summary clear']//div)[6]//h3[3]//span[2]")).getText();
			report.addReportStepNoScreenshots("Verify Product Qty is displayed in right rail pod", "Verify Product Qty"  + ProdQty +  "is displayed in right rail pod", StepResult.PASS);
		}
		else
		{
			report.addReportStepNoScreenshots("Verify Product Qty is displayed in right rail pod", "Verify Product Qty is displayed in right rail pod", StepResult.PASS);
		}
	}

}
