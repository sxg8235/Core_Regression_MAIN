package com.homer.po;

import java.awt.MouseInfo;
import java.awt.PointerInfo;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class ShippingPage extends PageBase<ShippingPage> {

	static final By verifyShippingPage = By.xpath("//h3[@class='title m-bottom-small'][text()='Shipping']");
	static final By firstNameTxtBox = By.xpath("//input[@name='firstName']");
	static final By lastNameTxtBox = By.xpath("(//input[@name='lastName'])[1]");
	static final By addr1TxtBox = By.xpath("(//input[@name='address1'])[1]");
	static final By zipCodeTxtBox = By.xpath("(//input[@name='zipcode'])[1]");
	static final By phNoTxtBox = By.xpath("(//input[@name='phone'])[1]");
	static final By continueBtn = By
			.xpath("//div[@class='tablet-checkout-right-rail']//*[@class='sliderNextButtonLabel-right-rail']");
	static final By backBtn = By.xpath("//div[@class='tablet-checkout-right-rail']/descendant::a[contains(.,'Back')]");
	static final By applyBtnZipCode = By.xpath("(//a[contains(text(),'APPLY')])[1]");
	static final By shippingInfo = By.xpath("///a[contains(.,'add new address')]");
	static final By standardShipping = By.xpath("//h4[contains(text(),'Standard Shipping')]/span");
	static final By priorityGroundShipping = By.xpath("//h4[contains(text(),'Priority Ground Shipping')]/span");
	static final By checkoutErrMsg = By.xpath("//span[@class='checkout-error-message']");
	static final By shipmoderdbtn = By
			.xpath("//label[contains(@for,'LLA') or contains(@for,'LLA1') or contains(@for,'LLB') or contains(@for,'PGA') or contains(@for,'PGB') or contains(@for,'PGC') or contains(@for,'PGD') or contains(@for,'HBA') or contains(@for,'HBB') or contains(@for,'HBB1') or contains(@for,'HTA') or contains(@for,'HWB')]");
	static final By editAddress = By.xpath("//a[contains(@class,'edit-address')]");
	static final By sameShipmode = By.xpath("//h4[contains(text(),'use multiple shipping methods')]");
	static final By differentShipmode = By.xpath("//h4[contains(.,'to view your shipping options')]");
	static final By shipmode = By.xpath("//label[contains(@for,'shippingOption_')]");
	static final By OverlayZipcode = By.name("zipcode");
	static final By CurrentCity = By.xpath("//*[@id='edit-address-overlay-content_city_select']");
	static final By CurrentState = By.id("edit-address-overlay-content_state_label");
	static final By UpdateButtonInOverlay = By.xpath("//*[@class='btn btn-gray edit-address-button md-submit']");
	static final By hdpprail = By
			.xpath("//h3[@class='m-bottom-small bold text-ellipse' and contains(.,'The Home Depot')]");
	static final By fNameErr = By.xpath("//div[@for='firstName']");
	static final By lNameErr = By.xpath("//div[@for='lastName']");
	static final By addr2TxtBox = By.xpath("(//input[@name='address2'])[1]");
	static final By addrErr = By.xpath("//div[@for='address1']");
	static final By zipCdErr = By.xpath("//div[@for='zipcode']");
	static final By phErr = By.xpath("//div[@for='phone']");
	static final By zeroZipCdErr = By.xpath("//*[contains(text(),'Invalid zip code')]");
	static final By addr2Err = By.xpath("//div[@for='address2']");
	static final By youSaved = By.xpath("(//*[contains(text(),'You Saved ')]/../..)[1]");
	static final By shippingAddr = By.xpath("//h4[contains(text(),'Shipping Address')]/..//fieldset//label");
	static final By shippingAddrFName = By.xpath("//h4[contains(text(),'Shipping Address')]/..//fieldset/div[2]/label");
	static final By shippingAddrPhone = By
			.xpath("//h4[contains(text(),'Shipping Address')]/..//label[contains(text(),'Last Name')]/../following-sibling::div[2]");
	static final By shippingAddrPhoneEditOverlay = By
			.xpath("//div[@id='edit-address-overlay']//label[contains(text(),'Last Name')]/../following-sibling::div[2]");
	static final By shippingAddrPhoneAddOverlay = By
			.xpath("//div[@id='add-address-overlay']//label[contains(text(),'Last Name')]/../following-sibling::div[2]");
	static final By editThisAddrLink = By.xpath("//a[contains(text(),'edit this address')]");
	static final By editAddrOverlay = By.id("edit-address-overlay");
	static final By addNewAddrLink = By.xpath("//a[contains(text(),'add new address')]");
	static final By addAddrOverlay = By.id("add-address-overlay");

	static final By shipToMultiAddr = By.xpath("//*[@class='address-form']//h4[2]");
	static final By shipValue = By.xpath("(//*[@class='p-custom-inner-block']//h4[2])[1]");
	static final By cityLabel = By.xpath("//*[@id='edit-address-overlay-content_city_label']");
	static final By secureSignInContinueBtn = By.xpath("//a[text()='CONTINUE']");
	static final By checkoutNowBtn = By.id("checkout-btn");
	static final By shipToHomeinPod = By
			.xpath("//*[contains(@class,'fulFillmentPods')]//*[contains(text(),'Ship to Home')]/ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='rightRailitemTitle']");
	static final By PodAmount = By
			.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalIteamChargesAmt']");
	static final By PodQty = By
			.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalItemsQtyNum']");
	static final By QuickViewModal = By.cssSelector("#fancybox-content .miniQvCntr");
	static final By ProductTitle = By.xpath(".//*[@class='rightRailprodTitle']");
	static final By ProductAttribute = By.xpath(".//*[@class='custom-attr-cntr']");
	static final By shipMsg = By.xpath("//h4[@class='shipping-msg m-bottom-normal']");
	static final By promo = By
			.xpath("//*[@class='p-custom-inner-block']//div[@class='display-row']//h3[contains(text(),'-')]");
	static final By promoorderconf = By.xpath("(//*[@class='bold sales-tax-section PLCC-section2'])[1]");
	static final By orderSummary = By.xpath("//*[@class='p-custom-inner-block']");
	static final By yousaved = By.xpath("//*[contains(text(),'You Saved ')]/./../..");
	static final By estTotal = By.xpath("//*[contains(text(),'Total ')]/./../..");
	static final By shippingmethod = By.cssSelector(".shipModeSection");
	static final By TotalShippingAmount = By.cssSelector(".totalItemsContainer");
	static final By ShippingMethodText = By.xpath("//*[@id='shipModeSection_0']");
	static final By localityErrorMessage = By.className("checkout-error-message");
	static final By addrTypeAhead = By
			.xpath("//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content']");
	static final By typeMyselfTxt = By.xpath("//a[@class='title text-gray small']");
	static final By clickOutside = By.xpath("//h1[contains(text(),'Questions? We Can Help.')]");
	static final By firstNameAddAddr = By.xpath("//div[@id='add-address-overlay']//input[@name='firstName']");
	static final By lastNameAddAddr = By.xpath("//div[@id='add-address-overlay']//input[@name='lastName']");
	static final By phNoAddAddr = By.xpath("//div[@id='add-address-overlay']//input[@name='phone']");
	static final By address1AddAddr = By.xpath("//div[@id='add-address-overlay']//input[@name='address1']");
	static final By zipCodeAddAddr = By.xpath("//div[@id='add-address-overlay']//input[@name='zipcode']");
	static final By saveBtn = By.xpath("//a[@class='btn btn-gray add-address-button md-submit']");
	static final By address1EditAddr = By.xpath("//div[@id='edit-address-overlay']//input[@name='address1']");
	static final By InstantRebateMsg = By.xpath(".//*[@id='irContent']/div[1]/p");
	static final By EditAddrzipcode = By
			.xpath(".//*[@id='edit-address-overlay-content']//../descendant::input[@name='zipcode']");
	static final By EstimatedSalesTax = By.xpath("//*[@data-modal-content='#estimated-sales-tax-tip-content']/..");
	static final By SalesTax = By.id("sales-tax");
	static final By PriceChangeOverlay = By.id("instant-rebate-overlay");
	static final By unitPrice = By.xpath("//*[@class='cell p-bottom-small bold pricing-section']");
	static final By clickaddressdrpdwn = By.xpath("(//select[@class='address-select'])[1]");
	static final By clickaddressdrpdwnBtn = By.xpath("(//button[@class='select-address-label'])[1]");
	static final By selectstandardShipping = By.xpath("//h4[contains(text(),'Standard')]");
	static final By selectpgShipping = By.xpath("//h4[contains(text(),'Priority Ground')]");
	static final By selectexpeditedShipping = By.xpath("//h4[contains(text(),'Expedited')]");
	static final By expresshipping = By.xpath(" //h4[contains(text(),'Express Shipping')]");
	static final By expresShippingValue = By.xpath(" //h4[contains(text(),'Express Shipping')]/span");
	static final By singleAddress=By.xpath("//div[@class='address-module m-bottom-normal']");
	static final By grrAddressLine1=By.xpath("//div[@class='checkout-summary clear']//..//div[@class='top-header']/h3[2]");
	static final By grrAddressLine2=By.xpath("//div[@class='checkout-summary clear']//..//div[@class='top-header']/h3[3]");
	static final By grrAddressLine3=By.xpath("//div[@class='checkout-summary clear']//..//div[@class='top-header']/h3[4]");
	static final By upsAddrOverlay = By.xpath("//*[contains(text(),'Address Verification')]");
	static final By suggestAddr = By.xpath("//div[@class='radio-set m-bottom-normal alternate-list-of-addresses']//label[@for='suggestedAddress0']");
	static final By applySuggestAddr = By.id("apply-suggested-address");
	static final By Expshipping=By.xpath("(//*[contains(text(),'Express Shipping')])[1]");
	static final By stdShipping=By.xpath("(//*[contains(text(),'Standard Shipping')])[1]");
	static final By ShippingValue=By.xpath("(//*[contains(text(),'Express Shipping')])[1]//span");
	static final By stdShippingValue=By.xpath("(//*[contains(text(),'Standard Shipping')])[1]//span");
	static final By currentStep = By.xpath("//*[contains(@class,'current-step')]");
	static final By GuestUserPersistenceAddress=By.xpath("//div[@class='address-module m-bottom-normal']");

	public ShippingPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify Shipping Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage verifyShippingPage() throws Exception {

		wh.waitForPageLoaded();

		wh.waitForElementPresent(verifyShippingPage, 5);

		if (wh.isElementPresent(verifyShippingPage, 2)) {

			report.addReportStep("Verify Shipping page is displayed", "Shipping page is displayed", StepResult.PASS);
		} else {

			report.addReportStep("Verify Shipping page is displayed", "Shipping page is not displayed", StepResult.FAIL);
			// rc.terminateTestCase("Shipping Page");
		}
		Thread.sleep(commonData.littleWait);
		return this;
	}

	/**
	 * Method to enter shipping details
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage enterShippingDetails() throws Exception {
		commonData.strIsShipAddrSaved = false;
		String zipWithDiffCity = dataTable.getData("Shipping_ZipCode");

		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));

			if (!zipWithDiffCity.isEmpty()) {
				wh.sendKeys(zipCodeTxtBox, zipWithDiffCity);
			} else {
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			}
			
			wh.waitForLoaderImage();
			//wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			if (wh.isElementPresent(applyBtnZipCode, 3)) {
				wh.clickElement(applyBtnZipCode);
			}

			wh.waitForElementPresent(shippingInfo, 5);
			/*wh.sendKeys(phNoTxtBox, "");
			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));*/
		}

		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		wh.waitForPageLoaded();

		return this;
	}

	/**
	 * Method to click continue button
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage verifyAllFields() throws Exception {
		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			String strFN = wh.getAttribute(firstNameTxtBox, "value");
			String strLN = wh.getAttribute(lastNameTxtBox, "value");
			String stradd1 = wh.getAttribute(addr1TxtBox, "value");
			String strzip = wh.getAttribute(zipCodeTxtBox, "value");
			String strph = wh.getAttribute(phNoTxtBox, "value");
			if (strFN.contains("") && strLN.contains("") && stradd1.contains("") && strzip.contains("")
					&& strph.contains("")) {
				report.addReportStep("Verify all fields in shipping page",
						"Shipping page is displayed with mandatory fields", StepResult.PASS);
			} else {
				report.addReportStep("Verify all fields in shipping page",
						"Shipping page is not displayed with mandatory fields", StepResult.FAIL);
			}

			if (wh.isElementPresent(continueBtn, 1) && wh.isElementPresent(backBtn, 1)) {
				report.addReportStep("Verify all fields in shipping page",
						"Shipping page is displayed with mandatory buttons", StepResult.PASS);
			}

		}
		return this;
	}

	/**
	 * Method to click continue button
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage clickContinueBtn() throws Exception {

		String currentPage = wh.getText(currentStep);
		
		wh.clickElement(continueBtn);
		// wh.jsClick(continueBtn);
		
		wh.waitForLoaderImage();
		
		if(wh.getText(currentStep).equals(currentPage)){
			wh.clickElement(continueBtn);
		}
		
		report.addReportStep("Click checkout now button in Checkout Page",
				"Clicked check out now button in Checkout Page", StepResult.PASS);


		return new PaymentPage(ic);
	}

	/**
	 * Method to verify standard shipping charge
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage verifyStandardShippingCharge() throws Exception {

		if (wh.isElementPresent(standardShipping, 2) || wh.isElementPresent(priorityGroundShipping)) {

			report.addReportStep("Verify Shipping charge is displayed as per standard shipping mode",
					"Shipping charge is displayed correctly", StepResult.PASS);

			String shippingTxt;

			if (wh.isElementPresent(priorityGroundShipping)) {
				shippingTxt = wh.getText(priorityGroundShipping);
			} else {
				shippingTxt = wh.getText(standardShipping);
			}

			By shippingChr = By.xpath("//h4[contains(text(),'Shipping :')]/../h4[2]");
			String shippingCharge = wh.getText(shippingChr);
			if (shippingCharge.contains(shippingTxt)) {
				report.addReportStep("Verify Shipping charge is displayed as per standard shipping mode",
						"Shipping charge<b>" + shippingTxt + "is displayed correctly as<b>" + shippingCharge + "</b>",
						StepResult.PASS);
			} else {
				/*
				 * report.addReportStep(
				 * "Verify Shipping charge is displayed as per standard shipping mode"
				 * , "Shipping charge<b>" + shippingTxt +
				 * "is not displayed correctly as<b>" + shippingCharge + "</b>",
				 * StepResult.FAIL);
				 */
			}

		} else {
			report.addReportStep("Verify Shipping charge is displayed as per standard shipping mode",
					"Shipping charge is not displayed correctly", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Method to enter zip code for restricted area details
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage enterZipCodeForRestrictedStates() throws Exception {
		String strCity = null;
		String strState = null;

		if (wh.isElementPresent(zipCodeTxtBox, 2)) {

			wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCodeRestricted));
			driver.findElement(zipCodeTxtBox).sendKeys(Keys.TAB);
			report.addReportStep("Enter Restricted zip code", "Restricted zip code entered", StepResult.PASS);

			/* Verify City and state field pre-populated after entering zip */
			Thread.sleep(commonData.mediumWait);
			if (wh.isElementPresent(By.xpath("//select[@class='city-select']//option[contains(@id,'city_')]"), 2)) {

				Select drop = new Select(driver.findElement(By
						.xpath("//div[contains(@class,'shipping-options-container')]//select[@id='_city_select']")));
				strCity = drop.getFirstSelectedOption().getText();

				report.addReportStep("Verify after entering zipCode the city is prepopulated", "City <b>" + strCity
						+ "</b> is prepopulated after entering the zip code", StepResult.PASS);

			} else if (wh.isElementPresent(By.xpath("//*[@id='add-address-overlay']//*[@class='city-select']"), 2)) {

				strCity = wh.getText(By.xpath("//*[@id='_city_label']"));
				report.addReportStep("Verify after entering zipCode the city is prepopulated", "City <b>" + strCity
						+ "</b> is prepopulated after entering the zip code", StepResult.PASS);

			} else if (wh
					.isElementPresent(By.xpath("//*[@id='_city_label'][not(contains(@style,'display: none'))]"), 2)) {

				strCity = wh.getText(By.xpath("//*[@id='_city_label'][not(contains(@style,'display: none'))]"));
				report.addReportStep("Verify after entering zipCode the city is prepopulated", "City <b>" + strCity
						+ "</b> is prepopulated after entering the zip code", StepResult.PASS);

			} else {
				report.addReportStep("Verify after entering zipCode the city is prepopulated",
						"City is not prepopulated after entering the zip code", StepResult.FAIL);
			}

			if (wh.isElementPresent(By.xpath("(//span[contains(@id,'_state_label')])[1]"), 2)) {
				strState = wh.getText(By.xpath("(//span[contains(@id,'_state_label')])[1]"));
				report.addReportStep("Verify after entering zipCode the state is prepopulated", "state <b>" + strState
						+ "</b> is prepopulated after entering the zip code", StepResult.PASS);
			} else {
				report.addReportStep("Verify after entering zipCode the state is prepopulated",
						"state is not prepopulated after entering the zip code", StepResult.FAIL);
			}

			if (wh.isElementPresent(applyBtnZipCode, 3)) {
				wh.clickElement(applyBtnZipCode);
			}

			wh.waitForElementPresent(shippingInfo, 5);
		} else {
			report.addReportStep("Enter Restricted zip code", "Zip code field not displayed", StepResult.FAIL);
		}

		Thread.sleep(3000);

		return this;
	}

	/**
	 * verify Error message for Restricted State
	 * 
	 * 
	 * @since Feb 20, 2013
	 * @author sxd8901
	 */
	public ShippingPage verifyErrorMsgForRestrictedState() throws Exception {
		String strTitle = driver.getTitle();
		System.out.println(strTitle);

		if (wh.isElementPresent(checkoutErrMsg, 5)) {

			String strError = wh.getText(checkoutErrMsg);
			System.out.println(strError);

			if (strError
					.contains("Shipping is not available for this address. Please provide a new shipping address below.")) {
				report.addReportStep(
						"verify the error message <b>Shipping is not available for this address</b> is displayed",
						"Error message <b>" + strError + "</b> is displayed at the top of the page", StepResult.PASS);
			} else {
				report.addReportStep(
						"verify the error message <b>Shipping is not available for this address</b> is displayed",
						"Error message <b>" + strError + "</b> is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"verify the error message <b>Shipping is not available for this address</b> is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

		if (wh.isElementPresent(By.cssSelector(".multi-shipping-unavail-service.m-bottom-normal.pod-errors.bold"), 5)) {

			String strInlineError = wh.getText(By
					.cssSelector(".multi-shipping-unavail-service.m-bottom-normal.pod-errors.bold"));

			System.out.println(strInlineError);

			if (strInlineError.contains("Change shipping address or remove item from your order")) {
				report.addReportStep(
						"verify the error message <b>Change shipping address or remove it from your order</b> displayed",
						"The error message :<b>" + strInlineError + "</b> is displayed next to the SKU in the <b>",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"verify the error message <b>Change shipping address or remove it from your order</b> displayed",
						"The error message is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"verify the error message <b>Change shipping address or remove it from your order</b> displayed",
					"The error message is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to verify that there is persistant address
	 * 
	 * @return
	 * @throws Exception
	 */

	public void verifyPersistAddress() throws Exception {
		if (wh.isElementPresent(editAddress, 5)) {
			report.addReportStep("Check edit address link is displayed in shipping Page",
					"Edit Addrees link is displayed in shipping Page", StepResult.PASS);
		} else {
			report.addReportStep("Check edit address link is displayed in shipping Page",
					"Edit Addrees link is not displayed in shipping Page", StepResult.FAIL);
		}

	}

	/**
	 * Method to verify that DETA shipmode is displayed
	 * 
	 * @return
	 * @throws Exception
	 */

	public ShippingPage verifyDETAShipmode() throws Exception {
		if (wh.isElementPresent(verifyShippingPage, 10)) {
			List<WebElement> shipModeArr = driver.findElements(shipmode);
			Boolean isDeta = false;
			for (WebElement we : shipModeArr) {
				String DetaShipmode = we.getAttribute("for");
				System.out.println(DetaShipmode);

				if (DetaShipmode.contains(("LLA")) || DetaShipmode.contains(("LLA1")) || DetaShipmode.contains(("LLB"))
						|| DetaShipmode.contains(("PGA")) || DetaShipmode.contains(("PGB"))
						|| DetaShipmode.contains(("PGC")) || DetaShipmode.contains(("PGD"))
						|| DetaShipmode.contains(("HBA")) || DetaShipmode.contains(("HBB"))
						|| DetaShipmode.contains(("HBB1")) || DetaShipmode.contains(("HTA"))
						|| DetaShipmode.contains(("HWB"))) {
					report.addReportStep("Check DETA ship mode is present", "DETA ship mode is Present",
							StepResult.PASS);
					isDeta = true;
					System.out.println(isDeta);
					break;
				}
			}
			if (isDeta == false) {
				report.addReportStep("Check DETA ship mode is present", "DETA ship mode is not Present",
						StepResult.FAIL);
			}

		}

		return new ShippingPage(ic);
	}

	/**
	 * Method to verify that the apply button is displayed
	 * 
	 * @return
	 * @throws Exception
	 */

	public ShippingPage verifyApplyBtnDisplay() throws Exception {
		if (wh.isElementPresent(applyBtnZipCode, 5)) {
			report.addReportStep("Check Apply Button displayed in shipping Page",
					"Apply Button is  displayed in shipping Page", StepResult.PASS);
		} else {
			report.addReportStep("Check Apply Button displayed in shipping Page",
					"Apply Button is not displayed in shipping Page", StepResult.FAIL);
		}
		return new ShippingPage(ic);

	}

	/**
	 * Method to verify that the SKU doesn't have DETA shipmode
	 * 
	 * @throws Exception
	 */

	public ShippingPage verifyNotDETAShipmode() throws Exception {
		if (wh.isElementPresent(verifyShippingPage, 10)) {
			List<WebElement> shipModeArr = driver.findElements(shipmode);
			Boolean isDeta = false;
			for (WebElement we : shipModeArr) {
				String NonDetaShipmode = we.getAttribute("for");
				System.out.println(NonDetaShipmode);

				if (!(NonDetaShipmode.contains(("LLA")) || NonDetaShipmode.contains(("LLA1"))
						|| NonDetaShipmode.contains(("LLB")) || NonDetaShipmode.contains(("PGA"))
						|| NonDetaShipmode.contains(("PGB")) || NonDetaShipmode.contains(("PGC"))
						|| NonDetaShipmode.contains(("PGD")) || NonDetaShipmode.contains(("HBA"))
						|| NonDetaShipmode.contains(("HBB")) || NonDetaShipmode.contains(("HBB1"))
						|| NonDetaShipmode.contains(("HTA")) || NonDetaShipmode.contains(("HWB")))) {
					report.addReportStep("Check Non-DETA ship mode is present", "Non-DETA ship mode is Present",
							StepResult.PASS);
					isDeta = true;
					System.out.println(isDeta);

				} else {
					isDeta = false;
					report.addReportStep("Check Non-DETA ship mode is present", "Non-DETA ship mode is not Present",
							StepResult.FAIL);
					// break;
				}

			}
		}
		return new ShippingPage(ic);
	}

	/**
	 * Method to verify that the apply button is not displayed
	 * 
	 * @return
	 * @throws Exception
	 */

	public ShippingPage verifyApplyBtnNotDisplayed() throws Exception {
		if (!wh.isElementPresent(applyBtnZipCode, 5)) {
			report.addReportStep("Check Apply Button displayed in shipping Page",
					"Apply Button is not displayed in shipping Page", StepResult.PASS);
		} else {
			report.addReportStep("Check Apply Button displayed in shipping Page",
					"Apply Button is displayed in shipping Page", StepResult.FAIL);
		}
		return new ShippingPage(ic);

	}

	/**
	 * Method to verify if the shipping page has same ship modes
	 * 
	 * @return
	 * @throws Exception
	 */

	public void verifySameShipType() throws Exception {
		if (wh.isElementPresent(sameShipmode, 5)) {
			report.addReportStep(
					"Check use Multiple Shipping methods link is displayed",
					"Multiple Shipping methods link is displayed in shipping Page. And the items are of same ship type",
					StepResult.PASS);

		} else {
			report.addReportStep(
					"Check use Multiple Shipping methods link is displayed",
					"Multiple Shipping methods link is not displayed in shipping Page. And the items are of not same ship type",
					StepResult.FAIL);
		}

	}

	/**
	 * Method to verify if the shipping page has different ship modes
	 * 
	 * @return
	 * @throws Exception
	 */

	public void verifyDiffShipType() throws Exception {
		if (wh.isElementPresent(differentShipmode, 5)) {
			report.addReportStep(
					"Check Enter address and click apply to view shipping methods is displayed",
					"Enter address and click apply to view shipping methods is displayed in shipping Page And the items are of different Ship type",
					StepResult.PASS);

		} else {
			report.addReportStep(
					"Check Enter address and click apply to view shipping methods is displayed",
					"Enter address and click apply to view shipping methods is displayed in shipping Page And the items are not of different Ship type",
					StepResult.FAIL);
		}

	}

	public void enterZipcodeInOverlay() throws Exception {
		boolean blnIsSavedAddr = commonData.strIsShipAddrSaved;
		if (!blnIsSavedAddr) {

			if (wh.isElementPresent(OverlayZipcode)) {
				String Zipcode = dataTable.getData("Shipping_ZipCode");
				commonData.NewZipcode = Zipcode;
				wh.sendKeys(OverlayZipcode, Zipcode);
				driver.findElement(zipCodeTxtBox).sendKeys(Keys.TAB);

				Thread.sleep(10000);

				String strCity = "";
				String strState = "";
				try {
					if (wh.isElementPresent(CurrentCity, 5)) {
						try {
							wh.jsClick(CurrentCity);
							strCity = driver.findElement(CurrentCity).getText();
						} catch (Exception e) {
							strCity = new Select(driver.findElement(By
									.xpath("//*[@id='edit-address-overlay-content_city_select']//option[1]")))
									.getFirstSelectedOption().getText();
						}
					} else if (wh.isElementPresent(CurrentCity, 5)) {
						strCity = new Select(driver.findElement(CurrentCity)).getFirstSelectedOption().getText();
					}
					strState = driver.findElement(CurrentState).getText();
					System.out.println("Value of city from excel is :" + strCity);
					System.out.println("Value of state from excel is :" + strState);
				} catch (Exception e) {
					System.out.println("");
				}

				if (!(strCity.equals("") && strState.equals(""))) {
					report.addReportStep("Verify that City & State details are displayed", "City : " + strCity
							+ " & State : " + strState + " is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify that City & State details are displayed",
							"Unable to get the City or State detail from the page", StepResult.FAIL);
				}

				commonData.shortShipState = strState;
				commonData.Zipcode = CommonDataColumn.ShippingZipCode;
			} else {
				report.addReportStep("Verify that ZipCode field is displayed", "Unable to find the zipCode Field",
						StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}

		} else {
			report.addReportStep("Verify that zipCode field is displayed", "Saved shipping address is displayed",
					StepResult.PASS);
		}

		if (wh.isElementPresent(UpdateButtonInOverlay, 5)) {
			wh.jsClick(UpdateButtonInOverlay);
			report.addReportStep("verify Update is clicked", "address is updated", StepResult.PASS);
		} else {
			report.addReportStep("verify Update is clicked", "address is not updated", StepResult.FAIL);
		}
	}

	public void verifyHDPPrightrail() throws Exception {
		if (wh.isElementPresent(hdpprail, 8)) {

			report.addReportStep("Verify hdpp in right rail", "Verified hdpp in right rail", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify hdpp in right rail", "HDPP is not present in right rail", StepResult.FAIL);
		}

	}

	public void enterValidSymbolsFirstName(String symbol) throws Exception {

		String fName = "John" + symbol;
		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			wh.clearElement(firstNameTxtBox);
			wh.sendKeys(firstNameTxtBox, fName);
			report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify " + fName + " is entered", "First name text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsFirstName() throws Exception {

		int i = 0;

		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			for (i = 0; i < commonData.symbolName.length; i++) {
				String fName = "John" + commonData.symbolName[i];
				wh.clearElement(firstNameTxtBox);
				wh.sendKeys(firstNameTxtBox, fName);
				report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);
				wh.clickElement(lastNameTxtBox);
				if (wh.isElementPresent(fNameErr, 5)) {
					String err = wh.getText(fNameErr);
					if (err.contains("We are sorry, but the system does not recognize special characters such as")) {
						report.addReportStep("Verify error message is displayed for " + fName + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + fName + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				}

				else {
					report.addReportStep("Verify error message is displayed for " + fName + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(firstNameTxtBox);
				wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
				wh.clickElement(lastNameTxtBox);
			}

		} else

		{
			report.addReportStep("Verify First Name is entered with invalid symbol",
					"First name text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterValidSymbolsLastName(String symbol) throws Exception {

		String lName = "John" + symbol;
		if (wh.isElementPresent(lastNameTxtBox, 3)) {
			wh.clearElement(lastNameTxtBox);
			wh.sendKeys(lastNameTxtBox, lName);
			wh.clickElement(phNoTxtBox);
			report.addReportStep("Verify " + lName + " is entered", lName + " is entered", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify " + lName + " is entered", "Last name text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsLastName() throws Exception {

		int i = 0;

		if (wh.isElementPresent(lastNameTxtBox, 3)) {
			for (i = 0; i < commonData.symbolName.length; i++) {
				String lName = "John" + commonData.symbolName[i];
				wh.clearElement(lastNameTxtBox);
				wh.sendKeys(lastNameTxtBox, lName);
				report.addReportStep("Verify " + lName + " is entered", lName + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(lNameErr, 5)) {
					String err = wh.getText(lNameErr);
					if (err.contains("We are sorry, but the system does not recognize special characters such as")) {
						report.addReportStep("Verify error message is displayed for " + lName + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + lName + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + lName + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(lastNameTxtBox);
				wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Last Name is entered with invalid symbol",
					"Last name text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterValidSymbolsAddress(String symbol) throws Exception {

		String address = "Address" + symbol;
		if (wh.isElementPresent(addr1TxtBox, 3)) {
			wh.clearElement(addr1TxtBox);
			wh.sendKeys(addr1TxtBox, address);
			report.addReportStep("Verify <b>" + address + "</b> is entered", "<b>" + address + "</b> is entered",
					StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify <b>" + address + "</b> is entered", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterValidSymbolsAddress2Fiels(String symbol) throws Exception {

		String address = "Address" + symbol;
		if (wh.isElementPresent(addr2TxtBox, 3)) {
			wh.clearElement(addr2TxtBox);
			wh.sendKeys(addr2TxtBox, address);
			report.addReportStep("Verify <b>" + address + " is entered", "</b>" + address + " is entered",
					StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify <b>" + address + "</b> is entered", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterAddressStartingInvalidSymbols() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			for (i = 0; i < commonData.addrStartingSymb.length; i++) {
				String addr = commonData.addrStartingSymb[i] + "Address";
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, addr);
				report.addReportStep("Verify " + addr + " is entered", addr + " is entered", StepResult.PASS);
				wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(addrErr, 5)) {
					String err = wh.getText(addrErr);
					if (err.contains("Please enter a valid address")) {
						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(addr2TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterAddress2fieldStartingInvalidSymbols() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr2TxtBox, 3)) {
			for (i = 0; i < commonData.addrStartingSymb.length; i++) {
				String addr = commonData.addrStartingSymb[i] + "Address";
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, addr);
				report.addReportStep("Verify " + addr + " is entered", addr + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(addr2Err, 5)) {
					String err = wh.getText(addr2Err);
					if (err.contains("Please enter a valid address")) {
						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidPoBoxAddress() throws Exception {

		int i = 0;
		int j = 0;

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			for (i = 0; i < commonData.addrPOBOX.length; i++) {
				String addr = commonData.addrPOBOX[i];
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, addr);
				report.addReportStep("Verify <b>" + addr + "</b> is entered", "<b>" + addr + "</b> is entered",
						StepResult.PASS);
				clickContinueBtn();
				// wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(checkoutErrMsg, 5)) {
					String err = wh.getText(checkoutErrMsg);
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr) + j++);
				driver.findElement(addr1TxtBox).sendKeys(Keys.TAB);
				Thread.sleep(commonData.mediumWait);
				wh.clickElement(addr2TxtBox);
				report.addReportStep("Verify <b>" + CommonDataColumn.ShippingAddr + "</b> is entered", "<b>"
						+ CommonDataColumn.ShippingAddr + "</b> is entered", StepResult.PASS);
			}

			/*
			 * wh.clickElement(backBtn); Thread.sleep(commonData.mediumWait);
			 * wh.clickElement(checkoutNowBtn);
			 * Thread.sleep(commonData.littleWait);
			 * wh.clickElement(secureSignInContinueBtn);
			 * Thread.sleep(commonData.littleWait); verifyShippingPage();
			 */
			// Shipping address is already prepopulated no need of entering
			// again
			// enterShippingDetails();

		} else {
			report.addReportStep("Verify Address is entered with invalid PoBox", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidPoBoxAddress2() throws Exception {

		int i = 0;
		int j = 0;

		if (wh.isElementPresent(addr2TxtBox, 3)) {
			for (i = 0; i < commonData.addrPOBOX.length; i++) {
				String addr = commonData.addrPOBOX[i];
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, addr);
				report.addReportStep("Verify <b>" + addr + "</b> is entered", "<b>" + addr + "</b> is entered",
						StepResult.PASS);
				driver.findElement(addr2TxtBox).sendKeys(Keys.TAB);
				// clickContinueBtn();
				// wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(checkoutErrMsg, 5)) {
					String err = wh.getText(checkoutErrMsg);
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr) + j++);
				driver.findElement(addr2TxtBox).sendKeys(Keys.TAB);
				Thread.sleep(commonData.mediumWait);
				wh.clickElement(addr1TxtBox);
				report.addReportStep("Verify <b>" + CommonDataColumn.ShippingAddr + "</b> is entered", "<b>"
						+ CommonDataColumn.ShippingAddr + "</b> is entered", StepResult.PASS);
				/*
				 * wh.clickElement(backBtn);
				 * Thread.sleep(commonData.mediumWait);
				 * wh.clickElement(checkoutNowBtn);
				 * Thread.sleep(commonData.littleWait);
				 * wh.clickElement(secureSignInContinueBtn);
				 * Thread.sleep(commonData.littleWait); verifyShippingPage();
				 * enterShippingDetails();
				 */

			}
		} else

		{
			report.addReportStep("Verify Address2 is entered with invalid PoBox", "Address2 text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsAddress() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			for (i = 0; i < commonData.addrSymbols.length; i++) {
				String addr = "Address" + commonData.addrSymbols[i];
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, addr);
				report.addReportStep("Verify " + addr + " is entered", addr + " is entered", StepResult.PASS);
				wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(addrErr, 5)) {
					String err = wh.getText(addrErr);
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(addr2TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsAddress2Field() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr2TxtBox, 3)) {
			for (i = 0; i < commonData.addrSymbols.length; i++) {
				String addr = "Address" + commonData.addrSymbols[i];
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, addr);
				report.addReportStep("Verify " + addr + " is entered", addr + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(addr2Err, 5)) {
					String err = wh.getText(addr2Err);
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsZipcd() throws Exception {

		int i = 0;
		if (wh.isElementPresent(zipCodeTxtBox, 3)) {
			for (i = 0; i < commonData.zipcdSymbols.length; i++) {
				String zipCd = commonData.zipcdSymbols[i];
				wh.clearElement(zipCodeTxtBox);
				wh.sendKeys(zipCodeTxtBox, zipCd + zipCd + zipCd + zipCd + zipCd);

				report.addReportStep("Verify " + zipCd + " is entered", zipCd + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(zipCdErr, 5)) {
					String err = wh.getText(zipCdErr);
					if (err.contains("Please enter a value greater than or equal to 0."))
						report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Zipcode is entered with invalid symbol", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsPhoneNum() throws Exception {

		int i = 0;

		if (wh.isElementPresent(phNoTxtBox, 3)) {
			for (i = 0; i < commonData.phSymbols.length; i++) {
				String phNum = commonData.phSymbols[i];
				wh.clearElement(phNoTxtBox);
				wh.sendKeys(phNoTxtBox, phNum);
				report.addReportStep("Verify " + phNum + " is entered", phNum + " is entered", StepResult.PASS);
				wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(phNoTxtBox, 3)) {
					String strph = wh.getText(phNoTxtBox);
					if (strph.contains(""))
						report.addReportStep("Verify ph number field", "Unable to enter any spl char in ph no field",
								StepResult.PASS);
					else {
						report.addReportStep("Verify ph number field", "Able to enter any spl char in ph no field",
								StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + phNum + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(phNoTxtBox);
				wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
				wh.clickElement(addr2TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Phone Number is entered with invalid symbol",
					"Phone Number text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterZeroesInZipcd() throws Exception {
		int i = 0;
		if (wh.isElementPresent(zipCodeTxtBox, 3)) {
			for (i = 0; i < commonData.zeroZipCd.length; i++) {
				wh.clearElement(zipCodeTxtBox);
				wh.sendKeys(zipCodeTxtBox, commonData.zeroZipCd[i]);

				report.addReportStep("Verify " + commonData.zeroZipCd[i] + " is entered", commonData.zeroZipCd[i]
						+ " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(zeroZipCdErr, 5)) {
					String err = wh.getText(zeroZipCdErr);
					if (err.contains("Invalid zip code"))
						report.addReportStep("Verify error message is displayed for " + commonData.zeroZipCd[i]
								+ " entered", "Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + commonData.zeroZipCd[i]
								+ " entered", "Error message <b>" + err + "</b> is not displayed properly",
								StepResult.PASS);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + commonData.zeroZipCd[i]
							+ " entered", "Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Zipcode is entered with invalid numbers", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterNumbersWithSymbolsZipcd() throws Exception {

		int i = 0;
		if (wh.isElementPresent(zipCodeTxtBox, 3)) {
			for (i = 0; i < commonData.zipcdSymbols.length; i++) {
				String zipCd = "3006" + commonData.zipcdSymbols[i];
				wh.clearElement(zipCodeTxtBox);
				wh.sendKeys(zipCodeTxtBox, zipCd);

				report.addReportStep("Verify " + zipCd + " is entered", zipCd + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(zipCdErr, 5)) {
					String err = wh.getText(zipCdErr);
					if (err.contains("The zip code must be five numbers"))
						report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Zipcode is entered with invalid symbol", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsInMiddleFirstName() throws Exception {

		int i = 0;

		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			for (i = 0; i < commonData.symbolNameInMiddle.length; i++) {
				String fName = "O" + commonData.symbolNameInMiddle[i] + "John";
				wh.clearElement(firstNameTxtBox);
				wh.sendKeys(firstNameTxtBox, fName);
				report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);
				wh.clickElement(lastNameTxtBox);
				if (wh.isElementPresent(fNameErr, 5)) {
					String err = wh.getText(fNameErr);
					if (err.contains("We are sorry, but the system does not recognize special characters such as")) {
						report.addReportStep("Verify error message is displayed for " + fName + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + fName + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				}

				else {
					report.addReportStep("Verify error message is displayed for " + fName + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(firstNameTxtBox);
				wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
				wh.clickElement(lastNameTxtBox);
			}

		} else

		{
			report.addReportStep("Verify First Name is entered with invalid symbol",
					"First name text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterInvalidSymbolsMiddleLastName() throws Exception {

		int i = 0;

		if (wh.isElementPresent(lastNameTxtBox, 3)) {
			for (i = 0; i < commonData.symbolNameInMiddle.length; i++) {
				String lName = "O" + commonData.symbolNameInMiddle[i] + "John";
				wh.clearElement(lastNameTxtBox);
				wh.sendKeys(lastNameTxtBox, lName);
				report.addReportStep("Verify " + lName + " is entered", lName + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(lNameErr, 5)) {
					String err = wh.getText(lNameErr);
					if (err.contains("We are sorry, but the system does not recognize special characters such as")) {
						report.addReportStep("Verify error message is displayed for " + lName + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + lName + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + lName + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(lastNameTxtBox);
				wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Last Name is entered with invalid symbol",
					"Last name text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterAddressInvalidSymbolsInMiddle() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			for (i = 0; i < commonData.addrSymbolInMiddle.length; i++) {
				String addr = "O" + commonData.addrSymbolInMiddle[i] + "John";
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, addr);
				report.addReportStep("Verify " + addr + " is entered", addr + " is entered", StepResult.PASS);
				wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(addrErr, 5)) {
					String err = wh.getText(addrErr);
					if (err.contains("Please enter a valid address")) {
						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(addr2TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterAddress2FieldInvalidSymbolsInMiddle() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr2TxtBox, 3)) {
			for (i = 0; i < commonData.addrSymbolInMiddle.length; i++) {
				String addr = "O" + commonData.addrSymbolInMiddle[i] + "John";
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, addr);
				report.addReportStep("Verify " + addr + " is entered", addr + " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(addr2Err, 5)) {
					String err = wh.getText(addr2Err);
					if (err.contains("Please enter a valid address")) {
						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					} else {

						report.addReportStep("Verify error message is displayed for " + addr + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify error message is displayed for " + addr + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(addr1TxtBox);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterSymbolsZipcd() throws Exception {

		if (wh.isElementPresent(zipCodeTxtBox, 3)) {
			String zipCd = commonData.zipcdSymbol;
			wh.clearElement(zipCodeTxtBox);
			wh.sendKeys(zipCodeTxtBox, zipCd);

			report.addReportStep("Verify " + zipCd + " is entered", zipCd + " is entered", StepResult.PASS);
			wh.clickElement(addr1TxtBox);
			if (wh.isElementPresent(zipCdErr, 5)) {
				String err = wh.getText(zipCdErr);
				if (err.contains("Please enter a value greater than or equal to 0."))
					report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
							"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
				}

			} else {
				report.addReportStep("Verify error message is displayed for " + zipCd + " entered",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify Zipcode is entered with invalid symbol", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterZeroesPhoneNo() throws Exception {

		if (wh.isElementPresent(phNoTxtBox, 3)) {
			String phNo = dataTable.getCommonData(CommonDataColumn.InvalidPhoneNumber);
			wh.clearElement(phNoTxtBox);
			wh.sendKeys(phNoTxtBox, phNo);

			report.addReportStep("Verify " + phNo + " is entered", phNo + " is entered", StepResult.PASS);
			wh.clickElement(addr1TxtBox);
			if (wh.isElementPresent(phErr, 5)) {
				String err = wh.getText(phErr);
				if (err.contains("Please enter a valid phone number"))
					report.addReportStep("Verify error message is displayed for " + phNo + " entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed for " + phNo + " entered",
							"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
				}

			} else {
				report.addReportStep("Verify error message is displayed for " + phNo + " entered",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify phone number is entered with zeroes", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void clearFirstLastNameClickContinue() throws Exception {

		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			wh.clearElement(firstNameTxtBox);
			wh.clearElement(lastNameTxtBox);

			wh.clickElement(continueBtn);
			if (wh.isElementPresent(fNameErr, 5)) {
				String fnameErr = wh.getText(fNameErr);
				String lnameErr = wh.getText(lNameErr);
				if (fnameErr.contains("First name is required. Please enter your first name")
						&& lnameErr.contains("Last name is required. Please enter your last name"))
					report.addReportStep("Verify error message is displayed", "Error message <b>" + fnameErr
							+ "</b> <b>" + lnameErr + "</b>is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed", "Error message <b>" + fnameErr
							+ "</b> <b>" + lnameErr + "</b>is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify error message is displayed", "FirstName text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void clearAddressClickContinue() throws Exception {

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			wh.clearElement(addr1TxtBox);

			wh.clickElement(continueBtn);
			if (wh.isElementPresent(addrErr, 5)) {
				String err = wh.getText(addrErr);
				if (err.contains("Address Line 1 required. Please enter your address"))
					report.addReportStep("Verify error message is displayed", "Error message <b>" + err
							+ "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed", "Error message <b>" + err
							+ "</b> is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify error message is displayed", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void clearZipcodeAndPhoneClickContinue() throws Exception {

		if (wh.isElementPresent(zipCodeTxtBox, 3)) {
			wh.clearElement(zipCodeTxtBox);
			wh.clearElement(phNoTxtBox);

			wh.clickElement(continueBtn);
			if (wh.isElementPresent(zipCdErr, 5)) {
				String zipErr = wh.getText(zipCdErr);
				String phoneErr = wh.getText(phErr);
				if (zipErr.contains("This field is required.")
						&& phoneErr.contains("Phone is required. Please enter your phone number"))
					report.addReportStep("Verify error message is displayed", "Error message <b>" + zipErr + "</b> <b>"
							+ phoneErr + "</b>is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed", "Error message <b>" + zipErr + "</b> <b>"
							+ phoneErr + "</b>is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify error message is displayed", "FirstName text box is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify the was price in checkout pages RXP8655
	 * 
	 * @throws Exception
	 */
	public void verifyWasPriceInCheckoutPage() throws Exception {
		if (wh.isElementPresent(youSaved, 3)) {
			System.out.println(commonData.pipSave);
			String strWas = wh.getText(youSaved);
			System.out.println(strWas);
			if (strWas.contains(commonData.pipSave)) {
				report.addReportStep("Verify you saved is displayed", "you saved section" + strWas + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify you saved is displayed", "you saved section is not displayed",
						StepResult.FAIL);
			}
			report.addReportStep("Verify you saved is displayed", "you saved section" + strWas + "is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify you saved is displayed", "you saved section is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the Phone field is moved up AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyPhoneFieldMovedUp() throws Exception {
		if (wh.isElementPresent(shippingAddrPhone, 3)) {
			String phone = wh.getText(shippingAddrPhone);
			if (phone.contains("Phone")) {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is moved up and displayed below Last Name field", StepResult.PASS);
			} else {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is not moved up and not displayed below Last Name field", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
					"Shipping address fields are not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the Phone field is moved up in edit address overlay
	 * AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyPhoneFieldMovedUpEditOverlay() throws Exception {
		if (wh.isElementPresent(shippingAddrPhoneEditOverlay, 3)) {
			String phone = wh.getText(shippingAddrPhoneEditOverlay);
			if (phone.contains("Phone")) {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is moved up and displayed below Last Name field", StepResult.PASS);
			} else {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is not moved up and not displayed below Last Name field", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
					"Shipping address fields are not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the Phone field is moved up in add address overlay
	 * AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyPhoneFieldMovedUpAddOverlay() throws Exception {
		if (wh.isElementPresent(shippingAddrPhoneAddOverlay, 3)) {
			String phone = wh.getText(shippingAddrPhoneAddOverlay);
			if (phone.contains("Phone")) {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is moved up and displayed below Last Name field", StepResult.PASS);
			} else {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is not moved up and not displayed below Last Name field", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
					"Shipping address fields are not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * Component to click edit this address link in shipping page AXB8034
	 * 
	 * @throws Exception
	 */
	public void clickEditThisAddress() throws Exception {
		if (wh.isElementPresent(editThisAddrLink, 3)) {
			wh.clickElement(editThisAddrLink);
			report.addReportStep("Click Edit this Address link in shipping page",
					"Edit this Address link is clicked in shipping page", StepResult.PASS);
		} else {
			report.addReportStep("Click Edit this Address link in shipping page",
					"Edit this Address link is not clicked in shipping page", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify edit address overlay is displayed in shipping page
	 * AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyEditAddressOverlay() throws Exception {
		if (wh.isElementPresent(editAddrOverlay, 3)) {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to click Add new address link in shipping page AXB8034
	 * 
	 * @throws Exception
	 */
	public void clickAddNewAddress() throws Exception {
		if (wh.isElementPresent(addNewAddrLink, 3)) {
			wh.clickElement(addNewAddrLink);
			report.addReportStep("Click Add new Address link in shipping page",
					"Add new Address link is clicked in shipping page", StepResult.PASS);
		} else {
			report.addReportStep("Click Add new Address link in shipping page",
					"Add new Address link is not clicked in shipping page", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify add address overlay is displayed in shipping page
	 * AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyAddAddressOverlay() throws Exception {
		if (wh.isElementPresent(addAddrOverlay, 3)) {
			report.addReportStep("Verify Add Address overlay is displayed", "Add Address overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Add Address overlay is displayed", "Add Address overlay is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Click on ship to multiple addresses in the shipping method page
	 * 
	 * @since Dec 18, 2012
	 * @author SXS8104
	 * @throws Exception
	 */
	public void clickShipToMultipleAddrInShipPg() throws Exception {

		if (wh.isElementPresent(By.xpath("//span[contains(text(),'ship to multiple addresses')]"))) {
			wh.clickElement(By.xpath("//span[contains(text(),'ship to multiple addresses')]"));
			report.addReportStep("Click on the <b>Ship to multiple address</b> link",
					"<b>Shipping address with Add Adress and edit address</b> link is displayed below each line item",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"Click on the <b>Ship to multiple address</b> link",
					"<b>Shipping address with Add Adress and edit address</b> link is not displayed below each line item",
					StepResult.FAIL);
		}

		/*
		 * if ((wh.isElementPresent(editThisAddrLink, 7)) &&
		 * (wh.isElementPresent(addNewAddrLink, 7))) {
		 * wh.jsClick(shipToMultiAddr); Thread.sleep(3000);
		 * 
		 * report.addReportStep(
		 * "Click on the <b>Ship to multiple address</b> link",
		 * "<b>Shipping address with Add Adress and edit address</b> link is displayed below each line item"
		 * , StepResult.PASS);
		 * 
		 * } else { report.addReportStep(
		 * "Click on the <b>Ship to multiple address</b> link",
		 * "<b>Shipping address with Add Adress and edit address</b> link is not displayed"
		 * , StepResult.FAIL); }
		 */

	}

	/**
	 * Component to verify multiple address details in shipping page
	 * 
	 * @since Jan 17, 2013
	 * @author sxd8901
	 * @throws Exception
	 */
	public void verifyMultiAddressInShippingPage() throws Exception {

		if (wh.isElementPresent(By.xpath("//*[@class='multiple-shipping-item-wrapper']"))) {
			List<WebElement> lstAddr = driver.findElements(By.xpath("//*[@class='multiple-shipping-item-wrapper']"));
			System.out.println(lstAddr.size());

			for (WebElement eachItem1 : lstAddr) {

				String title = eachItem1.getText();
				System.out.println(title);

				report.addReportStep("Verify Different Addresses are displayed in shipping page",
						"Diffrent Addresses are  <b>" + title + "</b> displayed in shipping page", StepResult.DONE);
			}
		} else {
			report.addReportStep("Verify Different Addresses are displayed in shipping page",
					"Different addresses is not displayed", StepResult.FAIL);
		}
	}

	public void getShippingCharge() throws Exception {
		if (wh.isElementPresent(shipValue)) {

			String strShipCharge = wh.getText(shipValue);
			System.out.println(shipValue);
			commonData.strshipvalue = strShipCharge;
			report.addReportStep("verify shipping charge", "Shipping charge is displayed", StepResult.PASS);
		} else {
			report.addReportStep("verify shipping charge", "Shipping charge is not displayed", StepResult.FAIL);
		}

	}

	public ShippingPage enterShippingDetailsWithRestrictedState() throws Exception {
		commonData.strIsShipAddrSaved = false;
		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCodeRestricted));

			driver.findElement(zipCodeTxtBox).sendKeys(Keys.TAB);

			if (wh.isElementPresent(applyBtnZipCode, 3)) {
				wh.clickElement(applyBtnZipCode);
			}

			wh.waitForElementPresent(shippingInfo, 15);
		}

		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		Thread.sleep(commonData.mediumWait);

		return this;
	}

	public ShippingPage verifyErrorMsgForRestrictedStateForMultipleSkus() throws Exception {
		String strTitle = driver.getTitle();
		System.out.println(strTitle);
		String skuNumber = dataTable.getData(DataColumn.SKU);

		if (wh.isElementPresent(checkoutErrMsg, 5)) {

			String strError = wh.getText(checkoutErrMsg);
			System.out.println(strError);

			if (strError
					.contains("Shipping is not available for this address. Please provide a new shipping address below.")) {
				report.addReportStep(
						"verify the error message <b>Shipping is not available for this address</b> is displayed",
						"Error message <b>" + strError + "</b> is displayed at the top of the page", StepResult.PASS);
			} else {
				report.addReportStep(
						"verify the error message <b>Shipping is not available for this address</b> is displayed",
						"Error message <b>" + strError + "</b> is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"verify the error message <b>Shipping is not available for this address</b> is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

		if (wh.isElementPresent(
				By.xpath("//div[@sku='" + skuNumber
						+ "']/../../..//span[contains(text(),'Change shipping address or')]"), 5)) {

			String strInlineError = wh.getText(By.xpath("//div[@sku='" + skuNumber
					+ "']/../../..//span[contains(text(),'Change shipping address or')]"));

			System.out.println(strInlineError);

			if (strInlineError.contains("Change shipping address")) {
				report.addReportStep(
						"verify the error message <b>Change shipping address or remove it from your order</b> displayed",
						"The error message :<b>" + strInlineError + "</b> is displayed next to the SKU in the <b>",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"verify the error message <b>Change shipping address or remove it from your order</b> displayed",
						"The error message is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"verify the error message <b>Change shipping address or remove it from your order</b> displayed",
					"The error message is not displayed", StepResult.FAIL);
		}

		return this;

	}

	public void clickEditThisAddressForMultipleSkus() throws Exception {
		String skuNumber = dataTable.getData(DataColumn.SKU);

		if (wh.isElementPresent(
				By.xpath("//div[@sku='" + skuNumber + "']/div//a[contains(text(),'edit this address')]"), 5)) {
			wh.clickElement(By.xpath("//div[@sku='" + skuNumber + "']/div//a[contains(text(),'edit this address')]"));
			report.addReportStep("Click Edit this Address link in shipping page",
					"Edit this Address link is clicked in shipping page", StepResult.PASS);
		} else {
			report.addReportStep("Click Edit this Address link in shipping page",
					"Edit this Address link is not clicked in shipping page", StepResult.FAIL);
		}
	}

	public ShippingPage clickRemoveLinkForRestrictedStateMultipleSkus() throws Exception {
		String strTitle = driver.getTitle();
		System.out.println(strTitle);
		String skuNumber = dataTable.getData(DataColumn.SKU);

		if (wh.isElementPresent(
				By.xpath("//div[@sku='" + skuNumber
						+ "']/../../..//span[contains(text(),'Change shipping address or')]/a"), 5)) {

			wh.clickElement(By.xpath("//div[@sku='" + skuNumber
					+ "']/../../..//span[contains(text(),'Change shipping address or')]/a"));

			report.addReportStep("Verify remove link is clicked", "Remove link is clicked", StepResult.PASS);

		} else {
			report.addReportStep("Verify remove link is clicked", "Remove link is not clicked", StepResult.FAIL);
		}

		return this;

	}

	public ShippingPage clickRemoveLinkForRestrictedState() throws Exception {
		String strTitle = driver.getTitle();
		System.out.println(strTitle);

		if (wh.isElementPresent(By.xpath("//a[contains(text(),'remove item from your order')]"), 5)) {

			wh.clickElement(By.xpath("//a[contains(text(),'remove item from your order')]"));

			report.addReportStep("Verify remove link is clicked", "Remove link is clicked", StepResult.PASS);

		} else {
			report.addReportStep("Verify remove link is clicked", "Remove link is not clicked", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to enter phone no and delete 4th digit in shipping page AXB8034
	 * 
	 * @throws Exception
	 */
	public void enterPhoneNoDeleteFourthDigit() throws Exception {
		if (wh.isElementPresent(phNoTxtBox, 3)) {
			WebElement element = driver.findElement(phNoTxtBox);
			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			Thread.sleep(commonData.littleWait);
			for (int i = 0; i < 7; i++) {
				element.sendKeys(Keys.ARROW_LEFT);
			} // for
			/*
			 * PointerInfo a = MouseInfo.getPointerInfo(); java.awt.Point b =
			 * a.getLocation(); int x = (int) b.getX(); int y = (int) b.getY();
			 */
			element.sendKeys(Keys.BACK_SPACE);
			report.addReportStep("Verify Phone no is entered and 4th digit is deleted using BACKSPACE or DEL",
					"Phone no is entered and 4th digit is deleted using BACKSPACE or DEL", StepResult.PASS);
		} else {
			report.addReportStep("Verify Phone no is entered and 4th digit is deleted using BACKSPACE or DEL",
					"Phone no tect box is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify cursor position is retained properly AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyCursorPosition() throws Exception {
		/*
		 * Point element = driver.findElement(phNoTxtBox).getLocation();
		 * element.moveBy(0, 0); element.getX();
		 */
		/*
		 * PointerInfo a = MouseInfo.getPointerInfo(); java.awt.Point b =
		 * a.getLocation(); int x = (int) b.getX(); int y = (int) b.getY();
		 */
		Thread.sleep(commonData.littleWait);

		// element.getX();
		report.addReportStep("Verify Cursor position is retained properly", "Cursor position is retained properly",
				StepResult.PASS);
		/*
		 * else { report.addReportStep(
		 * "Verify Phone no is entered and 4th digit is deleted using BACKSPACE or DEL"
		 * , "Phone no tect box is not displayed", StepResult.FAIL); }
		 */
	}

	public void verifyAddressFormExpanded() throws Exception {

		if ((wh.isElementNotPresent(editThisAddrLink)) && (wh.isElementNotPresent(addNewAddrLink))) {

			report.addReportStep("Verify address form remain expanded", "Address form remain expaned", StepResult.PASS);

		} else {
			report.addReportStep("Verify address form remain expanded", "Address form is not expaned", StepResult.FAIL);
		}

	}

	public void verifyEditAddrOverlayForMultipleCities() throws Exception {

		if ((wh.isElementPresent(CurrentCity, 5)) && (wh.isElementNotPresent(cityLabel))) {

			report.addReportStep("Verify edit address overlay for multiple cities",
					"City field is dispalyed with drop box", StepResult.PASS);

		} else {
			report.addReportStep("Verify edit address overlay for multiple cities",
					"City field is not dispalyed with drop box", StepResult.FAIL);
		}

	}

	public void verifyEditAddrOverlayForSingleCity() throws Exception {

		if ((wh.isElementNotPresent(CurrentCity)) && (wh.isElementPresent(cityLabel))) {

			report.addReportStep("Verify edit address overlay for single city",
					"City field is dispalyed without drop box", StepResult.PASS);

		} else {
			report.addReportStep("Verify edit address overlay for single city",
					"City field is dispalyed with drop box", StepResult.FAIL);
		}

	}

	public void verifyAddressFormCollapsed() throws Exception {

		if ((wh.isElementPresent(editThisAddrLink)) && (wh.isElementPresent(addNewAddrLink))) {

			report.addReportStep("Verify address form collapsed", "Address form collapsed", StepResult.PASS);

		} else {
			report.addReportStep("Verify address form collapsed", "Address form is not collapsed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify that the details of STH item added to cart is
	 * displayed in STH POD
	 * 
	 * @throws Exception
	 * 
	 */

	public void verifySTHPODItemDetails() throws Exception {
		verifyDisplayedItemInPOD("Ship to Home", shipToHomeinPod);

	}

	/**
	 * Component to verify that the details of item added to cart is displayed
	 * in rightrail POD
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyDisplayedItemInPOD(String strPODname, By strLocator) throws Exception {

		if (wh.isElementPresent(strLocator, 4)) {
			report.addReportStep("Verify that " + strPODname + " POD is displayed with the Item title",
					"POD is displayed with the item title", StepResult.PASS);

			WebElement webPOD = driver.findElement(strLocator);
			if (wh.isElementPresent(PodAmount, 5)) {
				String strTempCharge = webPOD.findElement(PodAmount).getText();

				report.addReportStep("Verify that Price is displayed for the product", "" + strTempCharge
						+ " is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Price is displayed for the product", "Unable to find the price",
						StepResult.FAIL);
			}

			if (wh.isElementPresent(PodQty, 4)) {
				String strTempQty = webPOD.findElement(PodQty).getText();
				report.addReportStep("Verify that Quantity is displayed for the product", "" + strTempQty
						+ " is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify that Quantity is displayed for the product",
						"Unable to find the Quantity", StepResult.FAIL);
			}

			try {
				driver.findElement(strLocator).click();
				report.addReportStep("Click the item description displayed in the " + strPODname + " POD",
						"Description clicked", StepResult.PASS);
				if (wh.isElementPresent(QuickViewModal, 4)) {
					report.addReportStep("Verify that Item quick view- modal  is displayed", "The modal is displayed",
							StepResult.PASS);

					WebElement webQvModal = driver.findElement(QuickViewModal);
					if (wh.isElementPresent(ProductTitle, 2)) {
						String strProdTitle = webQvModal.findElement(ProductTitle).getText();
						report.addReportStep("Verify that product title is displayed in the QV modal",
								"Product title is displayed as " + strProdTitle + "", StepResult.PASS);
					} else {
						report.addReportStep("Verify that product title is displayed in the QV modal",
								"Product title is not displayed", StepResult.FAIL);
					}
					if (wh.isElementPresent(ProductAttribute, 2)) {
						String strProdAttribute = webQvModal.findElement(ProductAttribute).getText();
						report.addReportStep("Verify that product Attributes are displayed in the QV modal",
								"Product Attributes are displayed as " + strProdAttribute + "", StepResult.PASS);
					} else {
						report.addReportStep("Verify that product Attributes are displayed in the QV modal",
								"Product Attributes are not displayed", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify that Item quick view- modal  is displayed",
							"The modal is not displayed", StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep("Click the item description displayed in the " + strPODname + "POD",
						"Description not clicked", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that " + strPODname + " POD is displayed", "Unable to find the item title",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify Revised copy shipping msg AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyRevisedShippingMsg() throws Exception {

		if (wh.isElementPresent(shipMsg)) {
			String msg = wh.getText(shipMsg);
			if (msg.contains("See your options once you've entered your address")) {
				report.addReportStep("Verify Revised shipping message is displayed in shipping message",
						"Revised shipping message <b>" + msg + "</b> is displayed in shipping message", StepResult.PASS);
			} else {
				report.addReportStep("Verify Revised shipping message is displayed in shipping message",
						"Revised shipping message is not displayed properly in shipping message", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Revised shipping message is displayed in shipping message",
					"Revised shipping message is not displayed in shipping message", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify Revised copy shipping msg DXP8263
	 * 
	 * @throws Exception
	 */
	public void verifyRevisedShippingMsgNotDisplayed() throws Exception {

		if (wh.isElementNotPresent(shipMsg)) {
			report.addReportStep("Verify Revised shipping message is not displayed in shipping page",
					"Revised shipping message is not displayed in shipping message", StepResult.PASS);

		} else {
			report.addReportStep("Verify Revised shipping message is not displayed in shipping message",
					"Revised shipping message is displayed in shipping message", StepResult.FAIL);
		}

	}

	/**
	 * Description-click back button on shipping page
	 * 
	 * @throws Exception
	 *
	 */
	public ShippingPage clickBackButton() throws Exception {

		if (wh.isElementPresent(backBtn, 5)) {
			wh.clickElement(backBtn);

			report.addReportStep("Verify Back button is clicked in Shipping page",
					"Back button is clicked in Shipping page", StepResult.PASS);
		} else {

			report.addReportStep("Verify Back button is clicked in Shipping page",
					"Back button is not clicked in Shipping page", StepResult.FAIL);
			rc.terminateTestCase("Back Button on Shipping Delivery page");
		}

		return this;
	}

	/**
	 * Description-to verify order level promo in shipping, payment pages
	 * 
	 * @throws Exception
	 *
	 */
	public ShippingPage verifyOrderLevelPromo() throws Exception {

		if (wh.isElementPresent(promo, 5)) {
			report.addReportStep("Order level promo", "Order level promo is displayed", StepResult.PASS);
			String strpro = wh.getText(promo);
			System.out.println(commonData.promovalue);
			if (strpro.contains(commonData.promovalue)) {
				report.addReportStep("Order level promo", "Promo value " + strpro + "is same", StepResult.PASS);
			} else {
				report.addReportStep("Order level promo", "Promo value " + strpro + "is not same", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(promoorderconf, 5)) {
			report.addReportStep("Order level promo", "Order level promo is displayed", StepResult.PASS);
			String strpro = wh.getText(promoorderconf);
			System.out.println(commonData.promovalue);
			if (strpro.contains(commonData.promovalue)) {
				report.addReportStep("Order level promo", "Promo value " + strpro + "is same", StepResult.PASS);
			} else {
				report.addReportStep("Order level promo", "Promo value " + strpro + "is not same", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Order level promo", "Order level promo is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to check the discounted amount after applying promotion
	 * 
	 * 
	 * @since Aug 7, 2013
	 * @author PXM8043
	 * @throws Exception
	 */
	public void verifyPromotionDiscountForCheckoutPg() throws Exception {

		if (wh.isElementPresent(orderSummary, 5)) {

			getAllTotalsfromCheckoutPages();

			double doubMerchandiseSubTotalCart = commonData.doubMerchandiseSubTotalCart;
			double doubSubtTotalCart = commonData.doubSubtTotalCart;
			double doubShipChargesCart = commonData.doubShipChargesCart;
			double doubEstimatedTaxCart = commonData.doubEstimatedTaxCart;
			double doubPickupTotalCart = commonData.doubPickupTotalCart;
			double doubApplianceDeliveryCart = commonData.doubApplianceDeliveryCart;
			double doubApplianceSubtotalCart = commonData.doubApplianceSubtotalCart;

			double doubEstimatedTotalCart = commonData.doubEstimatedTotalCart;
			double doubtotalCart = commonData.doubtotalCart;

			double doubItemLevelTotal = (doubApplianceSubtotalCart + doubApplianceDeliveryCart + doubPickupTotalCart
					+ doubEstimatedTaxCart + doubMerchandiseSubTotalCart + doubShipChargesCart);
			System.out.println("Item level total : " + doubItemLevelTotal);
			double doubGrandTotal = (doubEstimatedTotalCart + doubtotalCart + doubSubtTotalCart);
			System.out.println("Grand Total : " + doubGrandTotal);

			if (doubItemLevelTotal == doubGrandTotal) {
				report.addReportStep("verify that Item level total and grand total are the same",
						"Both Totals are displayed equal as " + doubGrandTotal, StepResult.PASS);

			} else {
				report.addReportStep("verify that Item level total and grand total are the same",
						"Both Totals are not equal", StepResult.PASS);
			}

			// clickPromotionLink();
			// enterPromoCode();
			// clickUpdatePrice();

			Thread.sleep(2000);
			getAllTotalsfromCheckoutPages();
			// getAllTotalsfromShoppingCartPage(); // getting the total after
			// applying promo code

			double doubYouSaved = commonData.doubYouSavedCart;
			double doubEstimatedTotalCart1 = commonData.doubEstimatedTotalCart;
			double doubtotalCart1 = commonData.doubtotalCart;
			double doubSubTotalCart1 = commonData.doubSubtTotalCart;

			double doubGrandTotal1 = (doubEstimatedTotalCart1 + doubtotalCart1 + doubSubTotalCart1);
			commonData.finalDiscountTotalcart = doubGrandTotal1;
			System.out.println("Grand Total : " + doubEstimatedTotalCart1 + doubtotalCart1 + doubSubTotalCart1);

		} else {
			report.addReportStep("verify the discount offer after applying promotion code",
					"Unable to validate the checkout page", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	public void getAllTotalsfromCheckoutPages()

	{

		try {
			List<WebElement> lstShipPageTotals = driver.findElements(By
					.xpath("//*[@class='clear order-summary-content']//div[@class='display-row']"));
			System.out.println(lstShipPageTotals.size());

			for (WebElement webTotals : lstShipPageTotals) {
				String strTemp = webTotals.getText();
				System.out.println(strTemp);
				// Subtotal
				if (strTemp.toLowerCase().contains("Subtotal")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubMerchandiseSubTotalCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the Merchandise subtotal in Cart page", "Subtotal : "
								+ commonData.doubMerchandiseSubTotalCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the merchandise subtotal");
						commonData.doubMerchandiseSubTotalCart = 0;
						report.addReportStep("Verify the Merchandise subtotal in Cart page",
								"Subtotal is not displayed", StepResult.FAIL);
					}
				}

				if (strTemp.toLowerCase().contains("subtotal") && (!strTemp.toLowerCase().contains("merchandise"))
						&& (!strTemp.toLowerCase().contains("appliance"))) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubSubtTotalCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the subtotal in Cart page", "Subtotal : "
								+ commonData.doubSubtTotalCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the subtotal");
						commonData.doubSubtTotalCart = 0;
						report.addReportStep("Verify the subtotal in Cart page", "Subtotal is not displayed",
								StepResult.FAIL);
					}
				}

				if (strTemp.toLowerCase().contains("shipping")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {

						commonData.doubShipChargesCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the shipping charges in Cart page", "Shipping charge : "
								+ commonData.doubShipChargesCart + " is displayed", StepResult.PASS);

					} catch (Exception e) {
						if (strTemp.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the shipping charges in Cart page",
									"Shipping charge is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Shipping charges");
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the shipping charges in Cart page",
									"Shipping charge is not displayed", StepResult.FAIL);
						}
					}
				}

				if (strTemp.toLowerCase().contains("estimated sales")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubEstimatedTaxCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the Estimated tax in Cart page", "Estimated tax : "
								+ commonData.doubEstimatedTaxCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the Estimated tax");
						commonData.doubEstimatedTaxCart = 0;
						report.addReportStep("Verify the Estimated tax in Cart page", "Estimated tax is not displayed",
								StepResult.FAIL);
					}
				}

				if (strTemp.toLowerCase().contains("estimated total")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubEstimatedTotalCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the Estimated total in Cart page", "Estimated total : "
								+ commonData.doubEstimatedTotalCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the Estimated tax");
						commonData.doubEstimatedTotalCart = 0;
						report.addReportStep("Verify the Estimated total in Cart page",
								"Estimated total is not displayed", StepResult.FAIL);
					}
				}

				if (strTemp.toLowerCase().contains("pick up in")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubPickupTotalCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the pick up in store total in Cart page",
								"Pick up in store total : " + commonData.doubPickupTotalCart + " is displayed",
								StepResult.PASS);
					} catch (Exception e) {
						if (strTemp.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the  Pick up in store total in Cart page",
									"Pick up in store total is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Estimated tax");
							commonData.doubPickupTotalCart = 0;
							report.addReportStep("Verify the pick up in store total in Cart page",
									"Pick up in store total is not displayed", StepResult.FAIL);
						}
					}
				}

				if (strTemp.toLowerCase().contains("appliance delivery")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();
						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubApplianceDeliveryCart = Double.parseDouble(strTemp);
						report.addReportStep(
								"Verify the Appliance delivery Charge in Cart page",
								"Appliance delivery Charge : " + commonData.doubApplianceDeliveryCart + " is displayed",
								StepResult.PASS);

					} catch (Exception e) {
						if (strTemp.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the  Appliance deliver charges in Cart page",
									" Appliance deliver charge is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Appliance delivery");
							commonData.doubApplianceDeliveryCart = 0;
							report.addReportStep("Verify the Appliance delivery Charge in Cart page",
									"Appliance delivery Charge is not displayed", StepResult.FAIL);
						}

					}
				}

				if (strTemp.toLowerCase().contains("appliance subtotal")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}

					}

					try {
						commonData.doubApplianceSubtotalCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the Appliance subtotal in Cart page", "Appliance subtotal : "
								+ commonData.doubApplianceSubtotalCart + " is displayed", StepResult.PASS);

					} catch (Exception e) {
						System.out.println("Unable to fetch the Appliance subtotal");
						commonData.doubApplianceSubtotalCart = 0;
						report.addReportStep("Verify the Appliance subtotal in Cart page",
								"Appliance subtotal is not displayed", StepResult.FAIL);

					}
				}

				if (strTemp.toLowerCase().contains("total") && (!strTemp.toLowerCase().contains("estimated"))
						&& (!strTemp.toLowerCase().contains("shipping"))) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}

					}

					try {
						commonData.doubtotalCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the total in Cart page", "Total : " + commonData.doubtotalCart
								+ " is displayed", StepResult.PASS);

					} catch (Exception e) {
						System.out.println("Unable to fetch the Appliance subtotal");
						commonData.doubtotalCart = 0;
						report.addReportStep("Verify the total in Cart page", "Total is not displayed", StepResult.FAIL);

					}
				}

				if (strTemp.toLowerCase().contains("you saved")) {
					if (strTemp.contains("$")) {
						strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

						if (strTemp.contains(",")) {
							strTemp = strTemp.replace(",", "");
						}
					}

					try {
						commonData.doubYouSavedCart = Double.parseDouble(strTemp);
						report.addReportStep("Verify the 'You saved' total in Cart page", "You saved : "
								+ commonData.doubYouSavedCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the you save total");
						commonData.doubYouSavedCart = 0;
						report.addReportStep("Verify the 'You saved' total in Payment page",
								"'You saved' is not displayed", StepResult.FAIL);
					}
				}

			}

			System.out.println(commonData.doubMerchandiseSubTotalCart);
			System.out.println(commonData.doubSubtTotalCart);
			System.out.println(commonData.doubShipChargesCart);
			System.out.println(commonData.doubEstimatedTaxCart);
			System.out.println(commonData.doubPickupTotalCart);
			System.out.println(commonData.doubApplianceDeliveryCart);
			System.out.println(commonData.doubApplianceSubtotalCart);
			System.out.println(commonData.doubYouSavedCart);
			System.out.println(commonData.doubEstimatedTotalCart);
			System.out.println(commonData.doubtotalCart);

			System.out.println("Done'");

		} catch (Exception e) {
			System.out.println("Unable to get the totals from Shopping page");
			report.addReportStep("Verify that Items totals in Order summary table", "Unable to validate the Totals",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * 
	 * Description : get the item price in cart page
	 * 
	 * @since May 23, 2013
	 * @author pxm8946
	 * @throws Exception
	 */
	public void verifyDiscountAmt() throws Exception {
		String strYouSaved = "";

		if (wh.isElementPresent(yousaved, 3)) {
			strYouSaved = wh.getText(yousaved);
			System.out.println(strYouSaved);

			report.addReportStep("Verify you Saved amount in checkout page", "You Saved amount:" + strYouSaved
					+ " is displayed  in checkout page ", StepResult.PASS);
		}

		else if (wh.isElementPresent(estTotal, 3)) {
			strYouSaved = wh.getText(estTotal);

			System.out.println(strYouSaved);

			report.addReportStep("Verify you Saved amount in checkout page", "You Saved amount:" + strYouSaved
					+ " is  displayed in checkout page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify you Saved amount in checkout page ",
					"You Saved amount is not displayed in checkout page", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify that all the products in the expanded shipping page
	 * (ship to multiple address/methods) are mapped with a individual shipping
	 * method
	 * 
	 * @throws Exception
	 */
	public void verifyShippingMethodDefaultOption() throws Exception {
		if (wh.isElementPresent(shippingmethod, 2)) {
			List<WebElement> lstProdMethods = driver.findElements(shippingmethod);
			try {

				List<WebElement> lstProducts = driver.findElements(TotalShippingAmount);
				String strText = driver.findElement(ShippingMethodText).getText();
				System.out.println(strText);

				if (lstProducts.size() <= (lstProdMethods.size())) {
					report.addReportStep("Verify the Shipping Method in Shipping page", "The default option:<b> "
							+ strText + "</b>as Shipping methods is displayed  in Shipping page", StepResult.PASS);
				} else {
					report.addReportStep(
							"Verify the Shipping Method should be displayed in Shipping page",
							"Standard UPS/FedEx Ground | FREE' the default option as Shipping methods is not displayed  in Shipping page",
							StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep("Verify that each product in the shipping page has its own shipping method ",
						"Products in the shipping page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that each product in the shipping page has its own shipping method ",
					"Unable to find the shipping methods", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify the error messages when user enter invalid input in
	 * shipping page
	 * 
	 * @throws Exception
	 */
	public void verifyFNError() throws Exception {
		if (wh.isElementPresent(fNameErr, 2)) {
			report.addReportStep("verify First name error", "First name error field is displayed", StepResult.PASS);
			String strFN = wh.getText(fNameErr);
			if (strFN.contains("We are sorry, but the system does not recognize special characters")) {
				report.addReportStep("verify First name error", "First name error " + strFN + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("verify First name error", "First name error is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify First name error", "First name error field is not displayed", StepResult.FAIL);
		}
	}

	public void verifyLNError() throws Exception {
		if (wh.isElementPresent(lNameErr, 2)) {
			report.addReportStep("verify last name error", "Last name error field is displayed", StepResult.PASS);
			String strLN = wh.getText(lNameErr);
			if (strLN.contains("We are sorry, but the system does not recognize special characters")) {
				report.addReportStep("verify Last name error", "Last name error " + strLN + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("verify Last name error", "Last name error is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify Last name error", "Last name error field is not displayed", StepResult.FAIL);
		}
	}

	public void verifyZipcodeErr() throws Exception {
		if (wh.isElementPresent(zeroZipCdErr, 2)) {
			report.addReportStep("verify zipcode error", "zipcode error field is displayed", StepResult.PASS);
			String strZip = wh.getText(zeroZipCdErr);
			if (strZip.contains("Invalid zip code")) {
				report.addReportStep("verify zipcode error", "zipcode error " + strZip + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("verify zipcode error", "zipcode error is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify zipcode error", "zipcode error field is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to enter non taxable zipcode and verify sales tax becomes zero
	 * 
	 * @throws Exception
	 */
	public void enterNonTaxableZipcode() throws Exception {
		if (wh.isElementPresent(zipCodeTxtBox, 2)) {
			report.addReportStep("verify zip code field", "Zip code field is displayed", StepResult.PASS);
			wh.sendKeys(zipCodeTxtBox, "97080");
			Thread.sleep(1000);
		} else {
			report.addReportStep("verify zip code field", "Zip code field is displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to clear all input fields in shipping page
	 * 
	 * @throws Exception
	 */
	public void clearAllFields() throws Exception {
		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			wh.clearElement(firstNameTxtBox);
			wh.clearElement(lastNameTxtBox);
			wh.clearElement(addr1TxtBox);
			wh.clearElement(zipCodeTxtBox);
			wh.clearElement(phNoTxtBox);
			report.addReportStep("clear fields", "All fields are cleared", StepResult.PASS);
		} else {
			report.addReportStep("clear fields", "All fields are not cleared", StepResult.FAIL);
		}

	}

	public void enterInvalidPhNumbers() throws Exception {
		int i = 0;
		if (wh.isElementPresent(phNoTxtBox, 3)) {
			for (i = 0; i < commonData.invalidPhNo.length; i++) {
				wh.clearElement(phNoTxtBox);
				wh.sendKeys(phNoTxtBox, commonData.invalidPhNo[i]);

				report.addReportStep("Verify " + commonData.invalidPhNo[i] + " is entered", commonData.invalidPhNo[i]
						+ " is entered", StepResult.PASS);
				wh.clickElement(addr1TxtBox);
				if (wh.isElementPresent(phErr, 5)) {
					String err = wh.getText(phErr);
					if (err.contains("Please enter a valid phone number"))
						report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
								+ " entered", "Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
								+ " entered", "Error message <b>" + err + "</b> is not displayed properly",
								StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
							+ " entered", "Error message is not displayed", StepResult.FAIL);
				}
			}
		} else {
			report.addReportStep("Verify Zipcode is entered with invalid numbers", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public ShippingPage enterShippingDetailsWithAPOAddress() throws Exception {
		commonData.strIsShipAddrSaved = false;
		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.APOZipcode));

			driver.findElement(zipCodeTxtBox).sendKeys(Keys.TAB);

			if (wh.isElementPresent(applyBtnZipCode, 3)) {
				wh.clickElement(applyBtnZipCode);
			}

			wh.waitForElementPresent(shippingInfo, 15);
		}

		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		Thread.sleep(commonData.mediumWait);

		return this;
	}

	public ShippingPage enterShippingDetailsWithFPOAddress() throws Exception {
		commonData.strIsShipAddrSaved = false;
		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			wh.clearElement(zipCodeTxtBox);
			if (wh.isElementPresent(zipCodeTxtBox, 2)) {
				System.out.println(dataTable.getCommonData(CommonDataColumn.FPOZipcode));
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.FPOZipcode));
			}
			driver.findElement(zipCodeTxtBox).sendKeys(Keys.TAB);

			if (wh.isElementPresent(applyBtnZipCode, 3)) {
				wh.clickElement(applyBtnZipCode);
			}

			wh.waitForElementPresent(shippingInfo, 15);
		}

		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		Thread.sleep(commonData.mediumWait);

		return this;
	}

	public ShippingPage enterShippingDetailsWithDPOAddress() throws Exception {
		commonData.strIsShipAddrSaved = false;
		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.clearElement(zipCodeTxtBox);
			if (wh.isElementPresent(zipCodeTxtBox, 2)) {
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.DPOZipcode));
			}

			driver.findElement(zipCodeTxtBox).sendKeys(Keys.TAB);

			if (wh.isElementPresent(applyBtnZipCode, 3)) {
				wh.clickElement(applyBtnZipCode);
			}

			wh.waitForElementPresent(shippingInfo, 15);
		}

		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		Thread.sleep(commonData.mediumWait);

		return this;
	}

	/**
	 * Component to verify the presence of error message: the address you have
	 * provided is in a locality that is not eligible for purchases on
	 * homedepot.com.
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyLocalityNotEligibleErrMsg() throws Exception {
		if (wh.isElementPresent(localityErrorMessage, 2)) {
			report.addReportStep(
					"Verify <b> The address you have provided is in a locality that is not eligible for purchases on homedepot.com.</b> Message should be displayed in the shopping cart page",
					"<b> The address you have provided is in a locality that is not eligible for purchases on homedepot.com.</b> Message is displayed in the shopping cart page",
					StepResult.PASS);

			String strErrMsg = driver.findElement(By.className("checkout-error-message")).getText();
			System.out.println(strErrMsg);
			if (strErrMsg
					.contains("The address you have provided is in a locality that is not eligible for purchases on homedepot.com")) {
				System.out.println("The error message is displayed.Add the next address");
			}
		} else {

			report.addReportStep(
					"Verify <b> The address you have provided is in a locality that is not eligible for purchases on homedepot.com.</b> Message should be displayed in the shopping cart page",
					"<b> The address you have provided is in a locality that is not eligible for purchases on homedepot.com.</b> Message is NOT displayed in the shopping cart page",
					StepResult.FAIL);

		}

	}

	/**
	 * Component to enter address type aheads
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void enterTypeAheadAddress() throws Exception {

		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			//wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.sendKeys(addr1TxtBox, dataTable.getData("Address_TypeAhead"));

			wh.waitForElementPresent(shippingInfo, 15);
		}

		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		Thread.sleep(3000);

	}

	/**
	 * Component to verify type aheads not displayed
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyTypeAheadsNotDisplayed() throws Exception {
		if (wh.isElementNotPresent(addrTypeAhead)) {
			report.addReportStep("Verify address type ahead not displayed", "Address Type ahead is not dispalyed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify address type ahead not displayed", "Address Type ahead is dispalyed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify type aheads not displayed
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyTypeAheadsDisplayed() throws Exception {
		if (wh.isElementPresent(addrTypeAhead)) {
			String strMsg = driver.findElement(addrTypeAhead).getAttribute("style");
			System.out.println(strMsg);
			if (strMsg.contains("block")) {
				report.addReportStep("Verify address type ahead displayed", "Address Type ahead is dispalyed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify address type ahead displayed", "Address Type ahead is not dispalyed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify address type ahead displayed", "Address Type ahead section not available",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify I'll type myself text
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyTypeMyselfText() throws Exception {
		if (wh.isElementPresent(typeMyselfTxt)) {
			String strMsg = wh.getText(typeMyselfTxt);
			System.out.println(strMsg);
			if (strMsg.contains("I'll type it myself")) {
				report.addReportStep("Verify address type ahead dismiss text displayed", "<b> " + strMsg
						+ " </b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify address type ahead dismiss text displayed", "<b> " + strMsg
						+ " </b> is not displayed properly", StepResult.PASS);
			}
		} else {
			report.addReportStep("Verify address type ahead dismiss text displayed",
					"Address Type ahead dismiss text not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to click I'll type myself text
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickTypeMyselfText() throws Exception {
		if (wh.isElementPresent(typeMyselfTxt)) {
			wh.clickElement(typeMyselfTxt);
			report.addReportStep("Verify address type ahead dismiss is clicked",
					"Address Type ahead dismiss text is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Verify address type ahead dismiss is clicked",
					"Address Type ahead dismiss text is not clicked", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify type aheads dismissed
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyTypeAheadsDismissed() throws Exception {
		if (wh.isElementNotPresent(addrTypeAhead)) {
			report.addReportStep("Verify address type ahead dismissed", "Address Type ahead is dismissed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify address type ahead not dismissed", "Address Type ahead is dismissed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify type aheads dismissed
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickOutside() throws Exception {
		if (wh.isElementPresent(clickOutside)) {
			wh.clickElement(clickOutside);
			report.addReportStep("Verify click happened on anywhere outside the page", "Clicked outside the page",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify click happened on anywhere outside the page", "Not Clicked outside the page",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to click address from type aheads
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickAddressTypeAhead() throws Exception {
		if (wh.isElementPresent(addrTypeAhead)) {

			wh.clickElement(By
					.xpath("//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content']//li[not(contains(@style,'display:none'))]"));
			report.addReportStep("Verify address is selected from type ahead", "Address is selected from type ahead",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify address is selected from type ahead",
					"Address is not selected from type ahead", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify zipcd,city,state prepopulated
	 * 
	 * @since Mar 09,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyZipcdCityStatePopulated() throws Exception {
		String strCity = null;
		String strState = null;
		String strZipcd = null;

		if (wh.isElementPresent(zipCodeTxtBox, 2)) {
			strZipcd = wh.getAttribute(zipCodeTxtBox, "value");
			System.out.println(strZipcd);
			report.addReportStep("Verify after selecting address the zipcode is prepopulated", "Zipcode <b>" + strZipcd
					+ "</b> is prepopulated after selecting the address", StepResult.PASS);
		} else {
			report.addReportStep("Verify after selecting address the zipcode is prepopulated", "Zipcode <b>" + strZipcd
					+ "</b> is not prepopulated after selecting the address", StepResult.FAIL);
		}
		if (wh.isElementPresent(By.xpath("//select[@class='city-select']//option[contains(@id,'city_')]"), 2)) {

			Select drop = new Select(driver.findElement(By
					.xpath("//div[contains(@class,'shipping-options-container')]//select[@id='_city_select']")));
			strCity = drop.getFirstSelectedOption().getText();

			report.addReportStep("Verify after selecting address the city is prepopulated", "City <b>" + strCity
					+ "</b> is prepopulated after selecting the address", StepResult.PASS);

		} else if (wh.isElementPresent(By.xpath("//*[@id='_city_label'][not(contains(@style,'display: none'))]"), 2)) {

			strCity = wh.getText(By.xpath("//*[@id='_city_label'][not(contains(@style,'display: none'))]"));
			report.addReportStep("Verify after entering zipCode the city is prepopulated", "City <b>" + strCity
					+ "</b> is prepopulated after entering the zip code", StepResult.PASS);

		} else {
			report.addReportStep("Verify after selecting address the city is prepopulated",
					"City is not prepopulated after selecting the address", StepResult.FAIL);
		}

		if (wh.isElementPresent(By.xpath("(//span[contains(@id,'_state_label')])[1]"), 2)) {
			strState = wh.getText(By.xpath("(//span[contains(@id,'_state_label')])[1]"));
			report.addReportStep("Verify after selecting address the state is prepopulated", "state <b>" + strState
					+ "</b> is prepopulated after selecting the address", StepResult.PASS);
		} else {
			report.addReportStep("Verify after selecting address the state is prepopulated",
					"state is not prepopulated after selecting the address", StepResult.FAIL);
		}

		wh.waitForElementPresent(shippingInfo, 5);

		Thread.sleep(3000);

	}

	/**
	 * Component to verify I'll type myself text not dispalyed
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyTypeMyselfTextNotDisplayed() throws Exception {
		if (wh.isElementNotPresent(typeMyselfTxt)) {
			report.addReportStep("Verify address type ahead dismiss text not displayed",
					"Addressmtype ahead dismiss text is not displayed", StepResult.PASS);

		} else {
			report.addReportStep("Verify address type ahead dismiss text not displayed",
					"Address Type ahead dismiss text displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to enter address in add address overlay
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void enterAddressInAddAdressOverlay() throws Exception {
		if (wh.isElementPresent(firstNameAddAddr, 2)) {

			wh.sendKeys(firstNameAddAddr, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameAddAddr, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.sendKeys(phNoAddAddr, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.sendKeys(address1AddAddr, dataTable.getData("Address_TypeAhead"));
			report.addReportStep("Enter Shipping Details in add address overlay",
					"Shipping Details entered in add address overlay", StepResult.PASS);

		} else {
			report.addReportStep("Enter Shipping Details in add address overlay",
					"Shipping Details not entered in add address overlay", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify zipcd,city,state prepopulated in add address overlay
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyZipcdCityStatePopulatedAddAddrOverlay() throws Exception {
		String strCity = null;
		String strState = null;
		String strZipcd = null;

		if (wh.isElementPresent(zipCodeAddAddr, 2)) {
			strZipcd = wh.getAttribute(zipCodeAddAddr, "value");
			System.out.println(strZipcd);
			commonData.typeAheadZipCd = strZipcd;
			report.addReportStep("Verify after selecting address the zipcode is prepopulated", "Zipcode <b>" + strZipcd
					+ "</b> is prepopulated after selecting the address", StepResult.PASS);
		} else {
			report.addReportStep("Verify after selecting address the zipcode is prepopulated", "Zipcode <b>" + strZipcd
					+ "</b> is not prepopulated after selecting the address", StepResult.FAIL);
		}
		if (wh.isElementPresent(
				By.xpath("//select[@id='add-address-overlay-content_city_select']//option[contains(@id,'city_')]"), 2)) {

			Select drop = new Select(driver.findElement(By
					.xpath("//select[@id='add-address-overlay-content_city_select']")));
			strCity = drop.getFirstSelectedOption().getText();
			commonData.typeAheadCity = strCity;

			report.addReportStep("Verify after selecting address the city is prepopulated", "City <b>" + strCity
					+ "</b> is prepopulated after selecting the address", StepResult.PASS);

		} else if (wh.isElementPresent(By.xpath("//span[@id='add-address-overlay-content_city_label']"), 2)) {

			strCity = wh.getText(By.xpath("//span[@id='add-address-overlay-content_city_label']"));
			commonData.typeAheadCity = strCity;
			report.addReportStep("Verify after entering address the city is prepopulated", "City <b>" + strCity
					+ "</b> is prepopulated after entering the zip code", StepResult.PASS);

		} else {
			report.addReportStep("Verify after selecting address the city is prepopulated",
					"City is not prepopulated after selecting the address", StepResult.FAIL);
		}

		if (wh.isElementPresent(By.xpath("//span[@id='add-address-overlay-content_state_label']"), 2)) {
			strState = wh.getText(By.xpath("//span[@id='add-address-overlay-content_state_label']"));
			commonData.typeAheadState = strState;
			report.addReportStep("Verify after selecting address the state is prepopulated", "state <b>" + strState
					+ "</b> is prepopulated after selecting the address", StepResult.PASS);
		} else {
			report.addReportStep("Verify after selecting address the state is prepopulated",
					"state is not prepopulated after selecting the address", StepResult.FAIL);
		}

		wh.waitForElementPresent(addAddrOverlay, 5);

		Thread.sleep(3000);

	}

	/**
	 * Component to click save button in add address overlay
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickSaveBtnAddAddrOverlay() throws Exception {
		if (wh.isElementPresent(saveBtn)) {
			wh.clickElement(saveBtn);
			report.addReportStep("Verify save button is clicked in add address overlay",
					"Save button is clicked in add address overlay", StepResult.PASS);

		} else {
			report.addReportStep("Verify save button is clicked in add address overlay",
					"Save button is not clicked in add address overlay", StepResult.FAIL);
		}
		Thread.sleep(commonData.smallWait);

	}

	/**
	 * Component to verify and click type aheads in add address overlay
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyAndClickTypeAheadsAddAddressOverlay() throws Exception {
		if (wh.isElementPresent(By.id("ui-id-3"))) {
			String strMsg = driver.findElement(By.id("ui-id-3")).getAttribute("style");
			System.out.println(strMsg);
			if (strMsg.contains("block")) {
				report.addReportStep("Verify address type ahead displayed", "Address Type ahead is dispalyed",
						StepResult.PASS);

				wh.clickElement(By.xpath("//ul[@id='ui-id-3']//li[not(contains(@style,'display:none'))]"));
				report.addReportStep("Verify address is selected from type ahead",
						"Address is selected from type ahead", StepResult.PASS);

			} else {
				report.addReportStep("Verify address type ahead displayed", "Address Type ahead is not dispalyed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify address type ahead displayed", "Address Type ahead section not available",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to enter spl chars in address field
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void enterSpecialCharAddressField() throws Exception {

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			wh.sendKeys(addr1TxtBox, commonData.zipcdSymbol);
			driver.findElement(addr1TxtBox).sendKeys(Keys.TAB);
			if (wh.isElementPresent(addrErr, 5)) {
				String err = wh.getText(addrErr);
				if (err.contains("Please enter a valid address")) {
					report.addReportStep("Verify error message is displayed for invalid address", "Error message <b>"
							+ err + "</b> is displayed", StepResult.PASS);
					wh.clearElement(addr1TxtBox);
				} else {

					report.addReportStep("Verify error message is displayed for invalid address", "Error message <b>"
							+ err + "</b> is not displayed properly", StepResult.FAIL);

				}
			} else {
				report.addReportStep("Verify error message is displayed for invalid address",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify Address is entered with invalid symbol", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to enter address in edit address overlay
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void enterAndVerifyTypeAheadEditAdressOverlay() throws Exception {
		if (wh.isElementPresent(editAddrOverlay, 2)) {

			wh.sendKeys(address1EditAddr, dataTable.getData("Address_TypeAhead"));

			report.addReportStep("Enter Shipping Details in edit address overlay",
					"Shipping Details entered in edit address overlay", StepResult.PASS);
			if (wh.isElementPresent(By.id("ui-id-2"))) {
				String strMsg = driver.findElement(By.id("ui-id-2")).getAttribute("style");
				System.out.println(strMsg);
				if (strMsg.contains("block")) {
					report.addReportStep("Verify address type ahead displayed", "Address Type ahead is dispalyed",
							StepResult.PASS);

				} else {
					report.addReportStep("Verify address type ahead displayed", "Address Type ahead is not dispalyed",
							StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify address type ahead displayed", "Address Type ahead section not available",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Enter Shipping Details in add address overlay",
					"Shipping Details not entered in edit address overlay", StepResult.FAIL);
		}

	}

	/**
	 * Method to validate Instant Rebate Message in Shipping Options Page
	 * 
	 * @author u93wcs
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public ShippingPage verifyIRmessage() throws Exception {

		String IREligMsg1 = "";
		String IREligMsg3 = "";
		String IREligMsg4 = "";
		String IRInEligMsg1 = "";

		IREligMsg1 = commonData.InstantRebateEligMsg1_CC;
		IREligMsg3 = commonData.InstantRebateEligMsg3_CC;
		IRInEligMsg1 = commonData.InstantRebateIneligMsg1_CC;
		IREligMsg4 = commonData.InstantRebateEligMsg4_CC;

		int itemcount = commonData.STHSKUList.size();

		if ((itemcount > 1)) {

			IREligMsg1 = commonData.InstantRebateEligMsg2_CC;
			IRInEligMsg1 = commonData.InstantRebateIneligMsg2_CC;

		}

		for (int i = 0; i < itemcount; i++) {

			String sku = commonData.STHSKUList.get(i);

			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);

			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));
			System.out.println("Val1:"+val1);
			System.out.println("Val2:"+val2);

			// Need to change based on the xpath for SO page
			// By InstantRebateMsg = By.xpath(".//*[@value='" + sku +
			// "']/../descendant::div[@class='cart-item-message']");

			if ((val2 < val1)) {

					if (wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IREligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg1, StepResult.FAIL);

					}

				}

					else if (wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IREligMsg3)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg3, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg3, StepResult.FAIL);

					}

				}

					else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))&& (!(StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);

					}

					}
					else if (!(wh.isElementPresent(InstantRebateMsg,5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}

			}

			else if ((val2 > val1))

			{
					if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))&& (!(StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);

					}

				}

					else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))&& ((StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);

					}

				}

					else if ((wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES"))&& ((StorePromo2).contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);

					}

				}

				else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}

			}

			else if ((val2 == val1)) {

				if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5))) {
						report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is displayed",
								StepResult.FAIL);

				}
			}
			continue;
		}

		try {

			By Msgclose = By.xpath(".//a[contains(@class,'md-close')]");
			wh.clickElement(Msgclose);

		} catch (Exception e) {

		}

		return this;

	}

	/**
	 * Method to enter shipping Address
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage enterShippingAddress() throws Exception {
		commonData.strIsShipAddrSaved = false;
		String zipcode = dataTable.getData(DataColumn.ChangeZipCode);

		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			if (!zipcode.isEmpty()) {
				wh.sendKeys(zipCodeTxtBox, zipcode);
			} else {
				wh.sendKeys(zipCodeTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			}

			report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);
			wh.waitForElementPresent(shippingInfo, 15);

		}

		return this;

	}

	/**
	 * Component to verify multiple address details in shipping page
	 * 
	 * @since Mar 3, 2016
	 * @author u93wcs
	 * @throws Exception
	 */
	public void editAddress() throws Exception {

		if (wh.isElementPresent(editThisAddrLink, 3)) {
			wh.clickElement(editThisAddrLink);
			wh.sendKeys(EditAddrzipcode, commonData.Zipcode);
			wh.clickElement(UpdateButtonInOverlay);
			report.addReportStep("Edit the zipcode", "zipcode has been edited", StepResult.PASS);

		}

		else if (!(wh.isElementPresent(editThisAddrLink, 3))) {

			report.addReportStep("Edit the zipcode", "Edit Address Link is not present", StepResult.FAIL);

		}
	}

	public void enterStoreAddAndVerifyErr() throws Exception {
		wh.clearElement(addr1TxtBox);
		wh.sendKeys(addr1TxtBox, "2450 Cumberland Pkwy");
		wh.clearElement(zipCodeTxtBox);
		wh.sendKeys(zipCodeTxtBox, "30339");
		String Msg = driver.findElement(By.className("checkout-error-message")).getText();
		System.out.println(Msg);
	    if(Msg.trim().contains("Items in your order cannot be shipped to Home Depot's store locations using Ship to Home."))
	    {
	    	report.addReportStep(
					"verify that </b>Items in your order cannot be shipped to Home Depot's store locations using Ship to Home</b> should be displayed in cart Page on entering store address in shipping Address fiels",
					"verify that </b>Items in your order cannot be shipped to Home Depot's store locations using Ship to Home</b> is displayed in cart Page on entering store address in shipping Address fiels",
					StepResult.PASS);
	    }
	    else
	    {
	    	report.addReportStep(
					"verify that </b>Items in your order cannot be shipped to Home Depot's store locations using Ship to Home</b> should be displayed in cart Page on entering store address in shipping Address fiels",
					"verify that </b>Items in your order cannot be shipped to Home Depot's store locations using Ship to Home</b> is not displayed in cart Page on entering store address in shipping Address fiels",
					StepResult.FAIL);
		}

	}

	/**
	 * 
	 * Description : verify the estimated sales tax is present
	 * 
	 * @throws Exception
	 */

	public String verifyEstimatedSaleTxt() throws Exception {
		if (wh.isElementPresent(EstimatedSalesTax, 3)) {
			String strEstimatedSalexText = driver.findElement(EstimatedSalesTax).getText();
			System.out.println(strEstimatedSalexText);
			return strEstimatedSalexText;
		} else {
			return null;
		}

	}

	/**
	 * Component to verify User checks for the tax amount displayed in the
	 * shipping page and Verify whether system calculates 'Estimated Sales Tax'
	 * and display it in Order summary part in 'Shipping' page
	 * 
	 * @throws Exception
	 */
	public void verifyEstimatedSalesTaxInShippingPage() throws Exception {
		if (wh.isElementPresent(EstimatedSalesTax, 4)) {
			report.addReportStep("User checks for the tax amount displayed in the shipping page",
					"System <b>displays the tax amount </b>in the shipping  page.", StepResult.PASS);

			String strEstimatedSalexText = verifyEstimatedSaleTxt();
			if (wh.isElementPresent(SalesTax, 10)) {
				String strEstimatedSalesTaxValue = driver.findElement(SalesTax).getText();
				System.out.println(strEstimatedSalesTaxValue);
				commonData.strEstimatedSalesTaxValue = strEstimatedSalesTaxValue;

				if (strEstimatedSalexText.contains("Estimated Sales Tax")) {
					report.addReportStep(
							"Verify whether system calculates <b>'Estimated Sales Tax' </b>and display it in Order summary part in </b>'Shipping' page </b>",
							"System calculates <b>'Estimated Sales Tax' and display" + strEstimatedSalesTaxValue
									+ " </b>under 'Order summary' in <b>'SHIPPING' page </b>", StepResult.PASS);

				} else {
					report.addReportStep(
							"Verify whether system calculates <b>'Estimated Sales Tax' </b>and display it in Order summary part in <b>'Shipping' page </b>",
							"System <b>not calculates 'Estimated Sales Tax' </b>and display  under 'Order summary' in <b>'SHIPPING' page </b>",
							StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify that Estimated Sales Tax is displayed in the order summary table",
						"Unable to identify the field", StepResult.FAIL);
			}

		} else {
			report.addReportStep("User checks for the tax amount displayed in the shipping page",
					"System <b>not displays the tax amount </b>in the shipping  page.", StepResult.FAIL);
		}

	}

	public void closePriceChangeOverlay() throws Exception
	{
	 if(wh.isElementPresent(PriceChangeOverlay, 5))
	 {
			wh.jsClick(By.xpath("//*[@id='ir-overlay']//a"));
		report.addReportStep("Verify Price Change overlay is closed if displayed", "Price Change overlay is closed if displayed", StepResult.PASS); 
		}
	 else
	 {
		 report.addReportStep("Verify Price Change overlay is closed if displayed", "Price Change overlay is not closed if displayed", StepResult.WARNING);
	}
	
	}
	/**
	 * Component to Select a Express shipping method from the Shipping method
	 * drop and reverting back
	 *
	 * @throws Throwable 
	 */
	public void selectDiffShippingAndRevertBack() throws Throwable {
		wh.jsClick(Expshipping);
		Thread.sleep(2000);
		String strshippingchargeexp = driver
				.findElement(ShippingValue).getText();
		System.out.println(strshippingchargeexp);
		commonData.strShipExp = strshippingchargeexp;
		if (!commonData.strFromPrice
				.contains(commonData.strShipExp)) {
			report.addReportStep(
					"Shipping charge should differ when we switch between shipping method",
					"Shipping charge changes accordingly", StepResult.PASS);
		} else {
			report.addReportStep(
					"Shipping charge should differ when we switch between shipping method",
					"Shipping charge does not changes accordingly", StepResult.FAIL);
		}
		// Revert to std shipping
		wh.jsClick(stdShipping);
		Thread.sleep(2000);
	}
	
	/**
	 * Component to from value near stad shipping method
	 * 
	 * @throws InterruptedException
	 */
	public void verifyFromValueNearStdShipping() throws InterruptedException {
		String strship = driver
				.findElement(stdShippingValue)
				.getText();
	    commonData.strshipprice = strship;
		Thread.sleep(2000);
		String strshippingchargeexp = driver
				.findElement(stdShippingValue)
				.getText();
		System.out.println(strshippingchargeexp);
	   commonData.strShipExp = strshippingchargeexp;
		if (commonData.strFromPrice
				.contains(commonData.strshipprice)) {
			report.addReportStep(
					"Ship value should be the same in cart page and in shipping page",
					"Ship value is same in cart and shipping page", StepResult.PASS);
		} else {
			report.addReportStep(
					"Ship value should be the same in cart page and in shipping page",
					"Ship value is not same in cart and shipping page",
					StepResult.FAIL);
		}

	}


	/** Instant Rebate-Selecting Multiple address ****/
	// /
	public void selshipaddrfrmdropdown() throws Exception {
		boolean shipmuladdclickchange = false;
		String sku = dataTable.getData(DataColumn.SKU);
		if (wh.isElementPresent(By.xpath("//span[contains(text(),'ship to multiple addresses')]")))  
		{
			wh.clickElement(By.xpath("//span[contains(text(),'ship to multiple addresses')]"));
			report.addReportStep("Click on the <b>Ship to multiple address</b> link",
					"Ship to Muliple address is clicked",
					StepResult.PASS);
			Thread.sleep(3000);

			Actions builder = new Actions(driver);
         builder.moveToElement(driver.findElement(By.xpath("//div[@sku='"+ sku +"']//button[@class='select-address-label']")),driver.findElement(By.xpath("//div[@sku='"+ sku +"']//button[@class='select-address-label']")).getSize().width-1,0).click().build().perform();
		 Select selectshipToaddress = new Select(driver.findElement(By.xpath("//div[@sku='"+ sku +"']//button[@class='select-address-label']/../select")));
			selectshipToaddress.selectByIndex(0);
			Thread.sleep(8000);

			report.addReportStep("Select different Zip code", "Different zip code selected", StepResult.PASS);
		 shipmuladdclickchange = true;
		 commonData.shipmuladdcheck = shipmuladdclickchange;

		}

		else if (wh.isElementPresent(By.xpath("//span[contains(text(),'ship to multiple addresses')]")))
		{
		
			report.addReportStep("Click on the <b>Ship to multiple address</b> link",
					"<b>Shipping address with Add Adress and edit address</b> link is not displayed below each line item",
					StepResult.FAIL);
		}

	}

	/** END of Instant Rebate-Selecting Multiple address ****/
	// /

	/**
	 * Method to get price & store promotion from pricing API
	 * 
	 * @author u93wcs
	 * @return
	 * @throws Exception
	 */
	public String getpricedetails(DataBase database) throws Exception {

if(commonData.shipmuladdcheck == false)
{
		int noOfItems = commonData.STHSKUList.size();
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.STHSKUList.get(i);
			String store = dataTable.getData(DataColumn.storeID);
	database.getUnitPriceFromPricingService(sku, store);	
	commonData.IRList1.add(commonData.shortdesc);
	commonData.PriceList1.add(commonData.unitPriceDB);
	}
}
	else if(commonData.shipmuladdcheck == true)
	{
		int noOfItems = commonData.skuList.size();
		int storecount = commonData.StoreList1.size();
		String store = null;
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.skuList.get(i);							
			store = commonData.StoreList1.get(i);
			database.getUnitPriceFromPricingService(sku, store);
			System.out.println("Shipping API SKU"+sku);
			System.out.println("Shipping API Store"+store);
			commonData.IRList1.add(commonData.shortdesc);
			commonData.PriceList1.add(commonData.unitPriceDB);
			}	
		}
		return null;

	}

	/** Instant Rebate-Verifying Right Rail Sku Prices ****/
	// /

	public void verifyRRprice() throws Exception {
		int itemcount = commonData.STHSKUList.size();

		for (int i = 0; i < itemcount; i++) {


			String proddesc = commonData.Proddesc.get(i);
			By prodrightrailPrice = By.xpath("//div[@class='tablet-checkout-right-rail']//h3[contains(text(),'"+proddesc+"')]/../h3[2]");
			By prodrightrailqty = By.xpath("//div[@class='tablet-checkout-right-rail']//h3[contains(text(),'"+proddesc+"')]/../h3[3]/span[2]");
			String price = wh.getText(prodrightrailPrice).replace("$", "");
			String qty = wh.getText(prodrightrailqty);
			System.out.println("price:" + price);

			double price1 = Double.parseDouble(price);
			double qty1 = Double.parseDouble(qty);
			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));
			double qtypriceval1 = val1 * qty1;
			double qtypriceval2 = val2 * qty1;
			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);
			System.out.println("val1:"+qtypriceval1);
			System.out.println("val2:"+qtypriceval2);
			System.out.println("price1:" + price1);

			if ((val2 < val1) || (val2 > val1)) {

					if(((StorePromo1).contains("INSTANT_REBATES")) || ((StorePromo2).contains("INSTANT_REBATES")))
					{
						if(price1 == qtypriceval2)
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
								StepResult.PASS);
						}
						else
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
								StepResult.FAIL);
						}
					}
					else if((!(StorePromo1).contains("INSTANT_REBATES")) || (!(StorePromo2).contains("INSTANT_REBATES")))
					{
						if(price1 != qtypriceval2)
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
								StepResult.PASS);
						}
						else
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
								StepResult.FAIL);

					}
				}
				}
				else if (val1 == val2)
				{
					if(price1 == qtypriceval2)
					{
					report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
							StepResult.PASS);
					}
					else
					{
					report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
							StepResult.FAIL);

				}
			}

		}

	}
	/** END of Instant Rebate-Validating right Rail price ****/
	// /
	
	/** Instant Rebate-Verifying Left Pod Sku Prices ****////

	public void verifyleftpodprice() throws Exception{
		int itemcount = commonData.STHSKUList.size();
		for (int i = 0; i < itemcount; i++) {
			String proddesc = commonData.Proddesc.get(i);			
			By prodleftpodprice = By.xpath("//div[@class='multiple-shipping-item-wrapper']//h3[contains(text(),'"+proddesc+"')]/../h3[2]");
			By prodleftpodqty = By.xpath("//div[@class='multiple-shipping-item-wrapper']//h3[contains(text(),'"+proddesc+"')]/../h3[3]/span[2]");
					
			String price = wh.getText(prodleftpodprice).replace("$", "");
			String qty = wh.getText(prodleftpodqty);
			System.out.println("price:"+price);
			
				double price1 = Double.parseDouble(price);
			double qty1 = Double.parseDouble(qty);
			//Double totalprice = price1 * qty1;
			
			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));
			double qtypriceval1 = val1 * qty1;
			double qtypriceval2 = val2 * qty1;
					
			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);
			System.out.println("val1:"+qtypriceval1);
			System.out.println("val2:"+qtypriceval2);
			System.out.println("price1:"+price1);
			
				if ((val2 < val1)|| (val2 > val1)) {
					
					if(((StorePromo1).contains("INSTANT_REBATES")) || ((StorePromo2).contains("INSTANT_REBATES")))
					{
						if(price1 == qtypriceval2)
						{
							report.addReportStep("Validate Left pod price is changed", "Left pod price is changed",
									StepResult.PASS);
						}
						else
						{
							report.addReportStep("Validate Left pod price is changed", "Left pod price is not changed",
								StepResult.FAIL);
							
						}
					}
					else if((!(StorePromo1).contains("INSTANT_REBATES")) || (!(StorePromo2).contains("INSTANT_REBATES")))
					{
						if(price1 != qtypriceval2)
						{
							report.addReportStep("Validate Left pod price is changed", "Left pod price is not changed",
									StepResult.PASS);
						}
						else
						{
							report.addReportStep("Validate Left pod price is changed", "Left pod price is changed",
								StepResult.FAIL);
							
						}
					}
					
					
					
				}
				else if (val1 == val2)
				{
					if(price1 == qtypriceval2)
					{
						report.addReportStep("Validate Left pod price is changed", "Left Pod price is not changed",
								StepResult.PASS);
					}
					else
					{
						report.addReportStep("Validate Left Pod price is changed", "Left Pod price is changed",
							StepResult.FAIL);
						
					}
				}

				
		
	}


		
	}

		
	/**
	 * Method to do tax calculation using formula
	 * @author rxp8655
	 * @return
	 * @throws Exception
	 */
	public String taxCalculation() throws Exception {
		if(wh.isElementPresent(SalesTax)){
		//Tax formula: (sales tax for state or county(I.e state, City, county, Sec Country))* (unit price of the Product + Shipping Charge)
		String strActualTax = wh.getText(SalesTax).split("\\$")[1].trim();
		double doubActualTax = Double.parseDouble(strActualTax);
		String strZipcodeTax = dataTable.getData("TaxValue_Zipcode");
		int strzip = Integer.parseInt(strZipcodeTax);
		String strship = commonData.strshipvalue.split("\\$")[1].trim();
		double doubship = Double.parseDouble(strship);
		String strunit = wh.getText(unitPrice).split("\\$")[1].trim();
		double doubUnit = Double.parseDouble(strunit);
		System.out.println(strzip);
		System.out.println(doubship);
		System.out.println(doubUnit);
		double total = doubship + doubUnit;
		System.out.println(total);
		double taxvalue = (total*strzip/100);
		BigDecimal bd = new BigDecimal(taxvalue);
		bd = bd.setScale(2, RoundingMode.HALF_UP);
	    
		System.out.println(bd);
		if(doubActualTax==taxvalue) {
			report.addReportStep("Tax calculation", "Exact tax value " + taxvalue + "is calculated", StepResult.PASS);
		} else {
			report.addReportStep("Tax calculation", "Exact tax value is not calculated", StepResult.WARNING);
		}
		}else{
			report.addReportStep("Tax value", "Tax value is not displayed", StepResult.FAIL);
		}
		return null;

	}
	
	public ShippingPage enterAddressdetailsInAddAddressOverlay() throws Exception {

		if (wh.isElementPresent(firstNameAddAddr, 2)) {

			wh.sendKeys(firstNameAddAddr, dataTable.getCommonData(CommonDataColumn.ShippingFirstName1));

			wh.sendKeys(lastNameAddAddr, dataTable.getCommonData(CommonDataColumn.ShippingLastName1));
			wh.sendKeys(phNoAddAddr, dataTable.getCommonData(CommonDataColumn.ShippingPhNo1));

			wh.sendKeys(address1AddAddr, dataTable.getCommonData(CommonDataColumn.ShippingAddr1));
			wh.sendKeys(zipCodeAddAddr, dataTable.getData(DataColumn.ChangeZipCode));

			report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		}

		else {
			report.addReportStep("Enter Shipping Details in add address overlay",
					"Shipping Details not entered in add address overlay", StepResult.FAIL);
		}
		return this;

	}

	public void clickEditCart() throws Exception {

		By editCartLink = By.xpath("//h3[@class='text-primary right bold edit-cart-link pointer']");

		if (wh.isElementPresent(editCartLink, 7)) {

			wh.clickElement(editCartLink);
			report.addReportStep("Click on Edit cart link ", "Edit cart link is clicked", StepResult.PASS);

		}

	}

	public void selectMultipleaddress() throws Exception {
		if (wh.isElementPresent(clickaddressdrpdwnBtn, 5)) {
			wh.clickElement(clickaddressdrpdwnBtn);
			Select selectshipToaddress = new Select(driver.findElement(clickaddressdrpdwn));
			selectshipToaddress.selectByIndex(0);
			Thread.sleep(9000);
			report.addReportStep("Verify drop down captured", "it is selected", StepResult.PASS);
		} else {
			report.addReportStep("Verify drop down captured", "it is not selected", StepResult.FAIL);
		}

	}
	
	public void selectStandardshipping() throws Exception {
		if (wh.isElementPresent(selectstandardShipping, 5)) {
			wh.jsClick(selectstandardShipping);
			report.addReportStep("verify Standard shipping is clicked", "it is updated", StepResult.PASS);
		} else {
			report.addReportStep("verify Standard shipping is clicked", "it is not updated", StepResult.FAIL);
		}

	}

	public void selectPriorityGroundShipping() throws Exception {
		if (wh.isElementPresent(selectpgShipping, 5)) {
			wh.jsClick(selectpgShipping);
			report.addReportStep("verify Priority ground is clicked", "it is updated", StepResult.PASS);
		} else {
			report.addReportStep("verify Priority ground is clicked", "it is not updated", StepResult.FAIL);
		}
	}
	
	public void selectExpeditedShipping() throws Exception {
		if (wh.isElementPresent(selectexpeditedShipping, 5)) {
			wh.jsClick(selectexpeditedShipping);
			report.addReportStep("verify Expedited shipping is clicked", "it is updated", StepResult.PASS);
		} else {
			report.addReportStep("verify Expedited shipping is clicked", "it is not updated", StepResult.FAIL);
		}

	}
	
	public ShippingPage selectExpressShipping() throws Exception {

		if (wh.isElementPresent(expresshipping))

		{
			wh.jsClick(expresshipping);

			report.addReportStep("Verify Express shipping mode is selected", "Express Shipping is selected correctly",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify Express shipping mode is selected",
					"Express Shipping is not selected correctly", StepResult.FAIL);
		}
		return this;
	}

	public ShippingPage verifyExpressShippingCharge() throws Exception {

		if (wh.isElementPresent(expresShippingValue)) {

			report.addReportStep("Verify Shipping charge is displayed as per express shipping mode",
					"Shipping charge is displayed correctly", StepResult.PASS);
			String expShippingTxt;

			if (wh.isElementPresent(expresShippingValue)) {
				expShippingTxt = wh.getText(expresShippingValue);
			} else {
				expShippingTxt = wh.getText(expresShippingValue);
			}

			By expShippingChr = By.xpath("//h4[contains(text(),'Shipping :')]/../h4[2]");
			String expShippingCharge1 = wh.getText(expShippingChr);
			if (expShippingCharge1.contains(expShippingTxt)) {
				report.addReportStep(
						"Verify Shipping charge is displayed as per Express shipping mode", "Shipping charge<b>"
								+ expShippingTxt + "is displayed correctly as<b>" + expShippingCharge1 + "</b>",
						StepResult.PASS);
			} else {

				report.addReportStep(
						"Verify Shipping charge is displayed as per standard shipping mode", "Shipping charge<b>"
								+ expShippingTxt + "is not displayed correctly as<b>" + expShippingCharge1 + "</b>",
						StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify Shipping charge is displayed as per standard shipping mode",
					"Shipping charge is not displayed correctly", StepResult.FAIL);

		}

		return this;
	}
	
	public ShippingPage selectAlternateAddressFromUPSOverlay() throws Exception {

		if (wh.isElementPresent(upsAddrOverlay, 2)) {

			wh.clickElement(suggestAddr);
			wh.clickElement(applySuggestAddr);
			report.addReportStep("Select alternate address from UPS address overlay",
					"Alternate address selected from UPS address overlay", StepResult.PASS);
		}

		else {
			report.addReportStep("Select alternate address from UPS address overlay",
					"UPS address overlay is not displayed", StepResult.FAIL);

		}
		return this;
	}

	public ShippingPage verifySelectedAddressInGrr() throws Exception {
		if (wh.isElementPresent(editAddress, 2)) {

			String strText = driver.findElement(singleAddress).getText();
			System.out.println(strText);
			Thread.sleep(commonData.smallWait);
			String strText1 = driver.findElement(grrAddressLine1).getText();
			String strText2 = driver.findElement(grrAddressLine2).getText();
			String strText3 = driver.findElement(grrAddressLine3).getText();
			System.out.println(strText1);
			System.out.println(strText2);
			System.out.println(strText3);
			if ((strText.contains(strText1)) && (strText.contains(strText2)) && (strText.contains(strText3))) {
				report.addReportStep("Verify selected address displayed in overlay",
						"Selected address<b>" + strText1 + strText2 + strText3 + " </b>is displayed in GRR",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify selected address displayed in overlay",
						"Selected address is not displayed in GRR", StepResult.FAIL);
			}
		}

		else {

			report.addReportStep("Verify if address is displayed in shipping page", "Address not available",
					StepResult.FAIL);

		}
		return this;

	}
	
	/**
	 * Method to verify Shipping Address Not pre-populated for a guest user
	 * 
	 * @return
	 * @throws Exception
	 */

	public void verifyShippingAddressNotPrepopulatedforGuest() throws Exception {
		if (wh.isElementNotPresent(GuestUserPersistenceAddress)) {
			report.addReportStep("verify Shipping Address is Not Prepopulated for a guest user",
					"Shipping Address is Not Prepopulated for a guest user", StepResult.PASS);
		} else {
			report.addReportStep("verify Shipping Address is Not Prepopulated for a guest user",
					"Shipping Address is Prepopulated for a guest user", StepResult.FAIL);
		}

	}

	public void verifyRRPriceMixed() throws Exception {

		int itemcount = commonData.STHSKUList.size();
		int itemcount1 = commonData.BOPISSKUList.size();
		int totalitemcount = itemcount + itemcount1;

		for (int i = 0; i < totalitemcount; i++) {

			String proddesc = commonData.Proddesc.get(i);
			By prodrightrailPrice = By.xpath("//div[@class='tablet-checkout-right-rail']//h3[contains(text(),'"+proddesc+"')]/../h3[2]");
			By prodrightrailqty = By.xpath("//div[@class='tablet-checkout-right-rail']//h3[contains(text(),'"+proddesc+"')]/../h3[3]/span[2]");

			String price = wh.getText(prodrightrailPrice).replace("$", "");
			String qty = wh.getText(prodrightrailqty);
			System.out.println("price:" + price);

			double price1 = Double.parseDouble(price);
			double qty1 = Double.parseDouble(qty);
			// Double totalprice = price1 * qty1;

			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));
			double qtypriceval1 = val1 * qty1;
			double qtypriceval2 = val2 * qty1;

			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);
			System.out.println("val1:" + qtypriceval1);
			System.out.println("val2:" + qtypriceval2);
			System.out.println("price1:" + price1);

			if ((val2 < val1) || (val2 > val1)) {

					if(((StorePromo1).contains("INSTANT_REBATES")) || ((StorePromo2).contains("INSTANT_REBATES")))
					{
						if(price1 == qtypriceval2)
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
								StepResult.PASS);
						}
						else
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
								StepResult.FAIL);
						}
					}
					else if((!(StorePromo1).contains("INSTANT_REBATES")) || (!(StorePromo2).contains("INSTANT_REBATES")))
					{
						if(price1 != qtypriceval2)
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
								StepResult.PASS);
						}
						else
						{
						report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
								StepResult.FAIL);

					}
				}
				}
				else if (val1 == val2)
				{
					if(price1 == qtypriceval2)
					{
					report.addReportStep("Validate Right Rail price is changed", "Right Rail price is not changed",
							StepResult.PASS);
					}
					else
					{
					report.addReportStep("Validate Right Rail price is changed", "Right Rail price is changed",
							StepResult.FAIL);

				}
			}

		}

	}
}
