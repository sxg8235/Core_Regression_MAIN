package com.homer.po;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class ApplianceOverlay extends PageBase<ApplianceOverlay> {

	static final By verifyAddToCartModal = By.xpath("//*[contains(text(),'Added to Cart')]");
	static final By applianceATCProductDetails = By.cssSelector(".text-secondary.m-bottom-large");
	static final By applianceZipTextBox = By.xpath("//div[@id='checkAvailableZip']/input");
	static final By applianceCheckAvailabilityBtn = By.id("checkAvailableBtn_MCC");
	static final By applianceEarlistAvlTxt = By.xpath("//div[@id='zipChecker']/div[contains(.,'Earliest Available')]");
	static final By applianceSelectPartsBtn = By.id("selectParts");
	static final By applianceEditCartBtn = By
			.xpath("//*[@id='selectParts']/preceding-sibling::a[contains(.,'Edit Cart')]");
	static final By applianceContinueShoppingBtn = By.xpath("//a[contains(.,'Continue Shopping')]");
	static final By applianceSelectPartsnav = By.cssSelector(".parts-services-tabs.flex");
	static final By applianceGoToCart = By.xpath("//a[contains(.,'Go To Cart')]");
	static final By appliancePnSNext = By.xpath("//div[@id='next']/a[contains(.,'Next')]");
	static final By applianceInstallNoRadio = By.id("noInstall");
	static final By appliancePnSTabs = By.name("tabs");
	static final By appliancePnSGoToCart = By.id("goToCartBtnMCC");
	static final By applianceSubtotalAmount = By.id("updatedSubtotal");
	static final By zipcodeAppl = By.xpath("//div[@id='checkAvailableZip']/input");
	static final By checkAvailBtn = By.xpath("//a[contains(text(),'Check Availability')]");
	static final By protPlanIcons = By.xpath("//ul[@id='hdpp_info_cart_list']");
	static final By moreInfoLink = By.id("hdpp_info_cart_more_info");
	static final By termsAndCondLink = By.xpath("//a[contains(text(),'Terms & Conditions')]");
	static final By applianceATCProductDetailsMyList = By.id("applATCHeader");
	static final By applianceZipTextBoxMyList = By.name("new-zip-code");
	static final By applianceCheckAvailabilityBtnMyList = By.xpath("//span[contains(text(),'CHECK AVAILABILITY')]");
	static final By applianceEarlistAvlTxtMyList = By.xpath("//div[contains(text(),'EARLIEST AVAILABLE:')]");
	static final By applianceSelectPartsBtnMyList = By.id("atcSelectPartsBtn");
	static final By applianceEditCartBtnMyList = By.xpath("//a[contains(text(),'EDIT CART')]");
	static final By applianceSelectPartsnavMyList = By.id("appl-ps-header");
	static final By appliancePnSTabsMyList = By.cssSelector("div.appl-tab");
	static final By appliancePnSGoToCartMyList = By.xpath("//a[contains(text(),'Go To Cart')]");
	static final By protPlanIconsMyList = By.id("hdppInfoWrapper");
	protected static final By freeDeliveryMsg = By.cssSelector("div.delivery-details.b");
	protected static final By noFreeDeliveryMsg = By.cssSelector("div.delivery-details.b > span");
	static final By unitPriceAppliance = By.xpath("//span[@class='xlarge current-unit-price']");
	static final By strikeThroPrice = By.xpath("//span[@class='strike-through']");
	static final By applianceErrGoToCart = By.xpath("//div[@id='applATCBtnsDDErr']/a[@id='goToCartBtn']");
	static final By saveChangesBtn = By.id("savePNSMCC");
	static final By protPlan = By.xpath("//ul[@id='warrantyList']/li/a/span");
	static final By protPlanPrice = By.xpath("//ul[@id='warrantyList']/li/a/div[2]");
	static final By avalilabilityMsg = By.id("checkAvailableMessage");
	static final By applianceATCButton = By.id("addToCart");
	static final By twoStepInstalMsg = By.id("twoStepInstallMsgMCC");
	static final By applnceQtyInOverlay = By.xpath("//p[@id='mccAtcCartTotal']");
	static final By appHookNO = By.xpath("//*[@id='installHookUpCntr']//a[2]");
	

	public ApplianceOverlay(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Component to verify appliance overlay and entering zipcode ,checking
	 * earliest available ,verify edit cart and select parts
	 * 
	 * @since Aug 21, 2015
	 * @author yxg8356
	 * @throws Exception
	 */
	public ApplianceOverlay enterZipCodeCheckAvailability() throws Exception {

		commonData.isAppliance = true;

		// verify product in overly
		if (wh.isElementPresent(applianceATCProductDetails, 2)) {
			try {

				String strProdDetails = wh.getText(applianceATCProductDetails);

				report.addReportStep("Product details should be displayed in overlay",
						"Product details is displayed in overlay  <b>" + strProdDetails + "</b>", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Product details should be displayed in overlay",
						"Product details is not  displayed in overlay", StepResult.FAIL);
			}

			// enter zipcode
			if (wh.isElementPresent(applianceZipTextBox, 2)) {

				String strZipCode = dataTable.getData("ZipCode");
				if (commonData.Zipcd!=null) {
					strZipCode = commonData.Zipcd;
				}
				try {

					wh.clearElement(applianceZipTextBox);
					wh.sendKeys(applianceZipTextBox, strZipCode);

					report.addReportStep("Zipcode should be enter in the text field",
							"<b>" + strZipCode + "</b> zipcode is entered in text field", StepResult.PASS);

					// click on check availability
					if (wh.isElementPresent(applianceCheckAvailabilityBtn, 10)) {

						wh.jsClick(applianceCheckAvailabilityBtn);
						
						wh.waitForLoaderImage();
						
						report.addReportStep("CHECK AVAILABILITY botton should be clicked",
								"<b>CHECK AVAILABILITY </b>button is clicked", StepResult.PASS);
					} else {
						report.addReportStep("CHECK AVAILABILITY botton should be clicked",
								"<b>CHECK AVAILABILITY </b>button is not clicked", StepResult.FAIL);
						rc.terminateTestCase("Appliance zipcode overlay");
					}
				} catch (Exception e) {
					report.addReportStep("Zipcode should be enter in the text field",
							"Zipcode is not entered in the text field", StepResult.FAIL);
					rc.terminateTestCase("Appliance zipcode overlay");
				}

			}

			else if (wh.isElementPresent(verifyAddToCartModal, 3)) {

				report.addReportStep("Zipcode should be availble in overlay", "Zipcode overlay already available",
						StepResult.PASS);
			} else {
				report.addReportStep("Zipcode should be availble in overlay",
						"unable to find enter zipcode field in overlay", StepResult.FAIL);
				rc.terminateTestCase("Appliance ATC overlay");
			}

			// For Backordered < 90 days appliance
			if(wh.isElementPresent(avalilabilityMsg,5)){
				
				if(wh.getText(avalilabilityMsg).contains("BACKORDER")){
					
					wh.clickElement(applianceATCButton);
					
					String strBackordered = wh.getText(avalilabilityMsg).trim();
					
					report.addReportStep("Backordered MSG should be displayed", "<b>" + strBackordered + "</b> is displayed",
							StepResult.PASS);
				}
			}
			
			// earliest date

			if (wh.isElementPresent(applianceEarlistAvlTxt, 10)) {

				String strEarlist = wh.getText(applianceEarlistAvlTxt);

				report.addReportStep("Earliest Available should be displayed", "<b>" + strEarlist + "</b> is displayed",
						StepResult.PASS);

			}

			else {
				report.addReportStep("Earliest Available should be displayed", "Earliest Available is not displayed",
						StepResult.WARNING);
				//rc.terminateTestCase("Appliance Select Parts and Services");
			}

			// verify Select parts and edit cart
			if (wh.isElementPresent(applianceSelectPartsBtn, 2) && wh.isElementPresent(applianceEditCartBtn, 2)
					&& !wh.isElementPresent(applianceContinueShoppingBtn, 2)) {

						report.addReportStep(
						"select parts and Edit cart buttons should be displayed.Continue Shopping button shouldnot be displayed ",
						"select parts and Edit cart buttons are displayed.Continue Shopping button is not  displayed ",
						StepResult.PASS);

			} else {

				if (checkoutConfig.depotDirectDown) {
					if (wh.isElementPresent(applianceErrGoToCart, 2)) {
						report.addReportStep(
								"Depot Direct service is currently down. Go To Cart button should be displayed",
								"Depot Direct service is currently down. Go To Cart button is displayed",
								StepResult.PASS);
					} else {
						report.addReportStep(
								"Depot Direct service is currently down. Go To Cart button should be displayed",
								"Depot Direct service is currently down. Go To Cart button is displayed",
								StepResult.FAIL);
						rc.terminateTestCase("Appliance Select Parts and Services");
					}
				} else {
					report.addReportStep(
							"select parts and Edit cart buttons should be displayed.Continue Shopping button shouldnot be displayed ",
							"select parts and Edit cart buttons are not displayed.Continue Shopping button is  displayed ",
							StepResult.FAIL);
					rc.terminateTestCase("Appliance Select Parts and Services");
				}

			}
		} else {
			report.addReportStep("Overly should be displayed", "unable to find Appliance overly", StepResult.FAIL);
			rc.terminateTestCase("Appliance ATC overlay");
		}

		return this;
	}

	/**
	 * 
	 * Description : verify parts and service with appliance in cart page
	 * 
	 * @since Aug 21,2015
	 * @author yxg8356
	 * @throws Exception
	 */
	public ShoppingCartPage selectPartsAndServices(boolean install) throws Exception {

		int i = 0;

		if (wh.isElementPresent(applianceSelectPartsBtn, 10)) {		
			wh.waitForPageLoaded();
			wh.jsClick(applianceSelectPartsBtn);
			report.addReportStep("Verify select part and services button",
					"Select parts and services button is displayed", StepResult.PASS);
		} else {
			if (checkoutConfig.depotDirectDown) {
				wh.jsClick(applianceErrGoToCart);
				report.addReportStep("Click Go to Cart button", "Go To cart button clicked", StepResult.PASS);
				return new ShoppingCartPage(ic);
			} else {
				report.addReportStep("Verify select part and services button",
						"Select parts and services button is displayed", StepResult.FAIL);
			}
		}

		if (wh.isElementPresent(applianceSelectPartsnav, 8)) {

			String strBreadCrumb = wh.getText(applianceSelectPartsnav);

			report.addReportStep("Verify that the <b>Select Parts and services </b> is displayed",
					"The Select Parts and services is displayed as <b>" + strBreadCrumb + "</b>", StepResult.PASS);

			try {

				List<WebElement> lstPNStabs = driver.findElements(appliancePnSTabs);

				if (!install) {
					if (wh.isElementPresent(applianceInstallNoRadio)) {
						wh.clickElement(applianceInstallNoRadio);
					}
				}

				for (i = 0; i < lstPNStabs.size(); i++) {

					if (i == (lstPNStabs.size() - 1)) {
						try {

							if (wh.isElementPresent(appliancePnSGoToCart, 6)) {

								if (wh.isElementPresent(applianceSubtotalAmount, 15)) {
									String applianceSubtotalAmt = wh.getText(applianceSubtotalAmount);
									String aSubtotal = applianceSubtotalAmt.replaceAll("[$,]", "");
									double aSubtotalAmt = Double.parseDouble(aSubtotal);
									commonData.applianceSubTotal = aSubtotalAmt + commonData.applianceSubTotal;
								} else {
									report.addReportStep("Save Appliance Subtotal",
											"Appliance subtotal is not displayed", StepResult.FAIL);
								}

								wh.jsClick(appliancePnSGoToCart);
								wh.waitUntilDisappear(appliancePnSGoToCart);

								report.addReportStep(
										"Click the <b>Go to CART</b> button in the parts n services overlay",
										"Button clicked", StepResult.PASS);
							}

							break;
						} catch (Exception e) {

							report.addReportStep("Click the <b>Go to CART</b> button in the parts n services overlay",
									"Button not clicked", StepResult.FAIL);
							rc.terminateTestCase("Cart page");
							break;
						}
					}

					try {

						wh.jsClick(appliancePnSNext);

						report.addReportStep(
								"Click the <b>NEXT</b> button in the " + lstPNStabs.get(i).getText() + " tab",
								"Next Button is clicked", StepResult.PASS);
					} catch (Exception e) {
						report.addReportStep("Click the <b>NEXT</b> button in the parts n services overlay",
								"Next Button is not clicked", StepResult.FAIL);

						rc.terminateTestCase("Appliance parts and services overlay");
					}

				}

			} catch (Exception e) {
				report.addReportStep("Verify that Select Parts and services tabs are displayed",
						"Unable to find the Select Parts and  services tabs section", StepResult.FAIL);
				rc.terminateTestCase("Appliance parts and services overlay");
			}

		}

		else {
			report.addReportStep("Verify that 'SELECT PARTS' button is available in the ATC overlay",
					"Unable to click the 'SELECT PARTS' button", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");

		}

		return new ShoppingCartPage(ic);
	}

	/**
	 * Method to click on check availability button in an overlay
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ApplianceOverlay checkAvailabilityApplOverlay() throws Exception {

		String strJumpStore = dataTable.getData("ChangeZipCode");

		if (wh.isElementPresent(zipcodeAppl)) {

			wh.sendKeys(zipcodeAppl, strJumpStore);

			report.addReportStep("Enter zipcode in check availability overlay in cart",
					"Zipcode is entered in check availability overlay in cart", StepResult.PASS);

		} else {
			report.addReportStep("Enter zipcode in check availability overlay in cart",
					"Zipcode is not entered in check availability overlay in cart", StepResult.FAIL);
		}

		if (wh.isElementPresent(checkAvailBtn)) {

			wh.clickElement(checkAvailBtn);
			
			Thread.sleep(commonData.littleWait);
			report.addReportStep("Click Check Availability button in overlay",
					"Check Availability button is clicked in overlay", StepResult.PASS);

		} else {
			report.addReportStep("Click Check Availability button in overlay",
					"Check Availability button is not clicked in overlay", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * part and service protection plan
	 * 
	 * @param install
	 * @return Shopiing cart page
	 * @throws Exception
	 */
	public ShoppingCartPage partsAndServicesProtectionPlan(boolean install) throws Exception {

		int i = 0;

		if (wh.isElementPresent(applianceSelectPartsBtn, 5)) {
			wh.clickElement(applianceSelectPartsBtn);
			report.addReportStep("Verify select part and services button",
					"Select parts and services button is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify select part and services button",
					"Select parts and services button is displayed", StepResult.FAIL);
		}

		if (wh.isElementPresent(applianceSelectPartsnav, 8)) {

			String strBreadCrumb = wh.getText(applianceSelectPartsnav);

			report.addReportStep("Verify that the <b>Select Parts and services </b> is displayed",
					"The Select Parts and services is displayed as <b>" + strBreadCrumb + "</b>", StepResult.PASS);

			try {

				List<WebElement> lstPNStabs = driver.findElements(appliancePnSTabs);

				if (!install) {
					if (wh.isElementPresent(applianceInstallNoRadio)) {
						wh.clickElement(applianceInstallNoRadio);
					}
				}

				for (i = 0; i < lstPNStabs.size(); i++) {

					if (i == (lstPNStabs.size() - 1)) {
						try {

							if (wh.isElementPresent(appliancePnSGoToCart, 6)
									&& (wh.isElementPresent(protPlanIcons, 6))) {
								String protPlanTxt = driver.findElement(protPlanIcons).getText();
								String feesIcon = driver.findElement(By.cssSelector("li#hdpp_li_no-fees"))
										.getCssValue("background");
								String laborIcon = driver.findElement(By.cssSelector("li#hdpp_li_parts-labor"))
										.getCssValue("background");
								String homeIcon = driver.findElement(By.cssSelector("li#hdpp_li_in-home"))
										.getCssValue("background");
								String supportIcon = driver.findElement(By.cssSelector("li#hdpp_li_24-7"))
										.getCssValue("background");
								String moreInfo = driver.findElement(By.id("hdpp_info_cart_more_info")).getText();
								String termsText = driver
										.findElement(By.xpath("//a[contains(text(),'Terms & Conditions')]")).getText();
								if (protPlanTxt.contains("No deductibles, no additional fees")
										&& protPlanTxt.contains("Parts and labor costs included")
										&& protPlanTxt.contains("In-home service by authorized technicians")
										&& protPlanTxt.contains("24/7 support")) {
									report.addReportStep(
											"Protection plan new text should be displayed in the parts n services overlay",
											"Protection plan new text is displayed", StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan new text should be displayed in the parts n services overlay",
											"Protection plan new text is not displayed", StepResult.FAIL);
								}
								if (feesIcon.contains("hdpp_no-fees_icon.png")
										&& laborIcon.contains("hdpp_parts-labor_icon.png")
										&& homeIcon.contains("hdpp_in-home_icon.png")
										&& supportIcon.contains("hdpp_24-7_icon.png")) {
									report.addReportStep(
											"Protection plan new icons should be displayed in the parts n services overlay",
											"Protection plan new icons is displayed", StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan new icons should be displayed in the parts n services overlay",
											"Protection plan new icons is not displayed", StepResult.FAIL);
								}
								if (moreInfo.contains("Click here for more information")
										&& termsText.contains("Terms & Conditions")) {
									report.addReportStep(
											"Protection plan Get More Info and Terms & Condition link should be displayed in the parts n services overlay",
											"Protection plan Get More Info and Terms & Condition link is displayed",
											StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan Get More Info and Terms & Condition link should be displayed in the parts n services overlay",
											"Protection plan Get More Info and Terms & Condition link is not displayed",
											StepResult.FAIL);
								}
							}

							break;
						} catch (Exception e) {

							report.addReportStep(
									"Protection plan new text should be displayed in the parts n services overlay",
									"Protection plan new text is not displayed", StepResult.FAIL);
							rc.terminateTestCase("Cart page");
							break;
						}
					}

					try {

						wh.clickElement(appliancePnSNext);

						report.addReportStep(
								"Click the <b>NEXT</b> button in the " + lstPNStabs.get(i).getText() + " tab",
								"Next Button is clicked", StepResult.PASS);
					} catch (Exception e) {
						report.addReportStep("Click the <b>NEXT</b> button in the parts n services overlay",
								"Next Button is not clicked", StepResult.FAIL);

						rc.terminateTestCase("Appliance parts and services overlay");
					}

				}

			} catch (Exception e) {
				report.addReportStep("Verify that Select Parts and services tabs are displayed",
						"Unable to find the Select Parts and  services tabs section", StepResult.FAIL);
				rc.terminateTestCase("Appliance parts and services overlay");
			}

		}

		else {
			report.addReportStep("Verify that 'SELECT PARTS' button is available in the ATC overlay",
					"Unable to click the 'SELECT PARTS' button", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");

		}

		return new ShoppingCartPage(ic);
	}

	public ShoppingCartPage clickEditCart() throws Exception {
		
		

		if (wh.isElementPresent(applianceEditCartBtn, 5)) {
			wh.clickElement(applianceEditCartBtn);
			report.addReportStep("Verify edit cart button is clicked in P&S overlay",
					"Edit cart button is clicked in P&S overlay", StepResult.PASS);
		} else {
			report.addReportStep("Verify edit cart button is clicked in P&S overlay",
					"Edit cart button is not clicked in P&S overlay", StepResult.FAIL);
		}
		return new ShoppingCartPage(ic);
	}

	/**
	 * Method to navigate and verify parts and protection in cart page
	 * 
	 * @return ShoppingCartpage
	 * @throws Exception
	 */
	public ShoppingCartPage partsAndServicesProtectionPlanCartPage() throws Exception {
		int i = 0;
		if (wh.isElementPresent(applianceSelectPartsnav, 8)) {

			String strBreadCrumb = wh.getText(applianceSelectPartsnav);

			report.addReportStep("Verify that the <b>Select Parts and services </b> is displayed",
					"The Select Parts and services is displayed as <b>" + strBreadCrumb + "</b>", StepResult.PASS);

			try {

				List<WebElement> lstPNStabs = driver.findElements(appliancePnSTabs);

				for (i = 0; i < lstPNStabs.size(); i++) {

					if (i == (lstPNStabs.size() - 1)) {
						try {

							if (wh.isElementPresent(appliancePnSGoToCart, 6)
									&& (wh.isElementPresent(protPlanIcons, 6))) {
								String protPlanTxt = driver.findElement(protPlanIcons).getText();
								String feesIcon = driver.findElement(By.cssSelector("li#hdpp_li_no-fees"))
										.getCssValue("background");
								String laborIcon = driver.findElement(By.cssSelector("li#hdpp_li_parts-labor"))
										.getCssValue("background");
								String homeIcon = driver.findElement(By.cssSelector("li#hdpp_li_in-home"))
										.getCssValue("background");
								String supportIcon = driver.findElement(By.cssSelector("li#hdpp_li_24-7"))
										.getCssValue("background");
								String moreInfo = driver.findElement(By.id("hdpp_info_cart_more_info")).getText();
								String termsText = driver
										.findElement(By.xpath("//a[contains(text(),'Terms & Conditions')]")).getText();
								if (protPlanTxt.contains("No deductibles, no additional fees")
										&& protPlanTxt.contains("Parts and labor costs included")
										&& protPlanTxt.contains("In-home service by authorized technicians")
										&& protPlanTxt.contains("24/7 support")) {
									report.addReportStep(
											"Protection plan new text should be displayed in the parts n services overlay",
											"Protection plan new text is displayed", StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan new text should be displayed in the parts n services overlay",
											"Protection plan new text is not displayed", StepResult.FAIL);
								}
								if (feesIcon.contains("hdpp_no-fees_icon.png")
										&& laborIcon.contains("hdpp_parts-labor_icon.png")
										&& homeIcon.contains("hdpp_in-home_icon.png")
										&& supportIcon.contains("hdpp_24-7_icon.png")) {
									report.addReportStep(
											"Protection plan new icons should be displayed in the parts n services overlay",
											"Protection plan new icons is displayed", StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan new icons should be displayed in the parts n services overlay",
											"Protection plan new icons is not displayed", StepResult.FAIL);
								}
								if (moreInfo.contains("Click here for more information")
										&& termsText.contains("Terms & Conditions")) {
									report.addReportStep(
											"Protection plan Get More Info and Terms & Condition link should be displayed in the parts n services overlay",
											"Protection plan Get More Info and Terms & Condition link is displayed",
											StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan Get More Info and Terms & Condition link should be displayed in the parts n services overlay",
											"Protection plan Get More Info and Terms & Condition link is not displayed",
											StepResult.FAIL);
								}
							}

							break;
						} catch (Exception e) {

							report.addReportStep(
									"Protection plan new text should be displayed in the parts n services overlay",
									"Protection plan new text is not displayed", StepResult.FAIL);
							rc.terminateTestCase("Cart page");
							break;
						}
					}

					try {

						wh.clickElement(appliancePnSNext);

						report.addReportStep(
								"Click the <b>NEXT</b> button in the " + lstPNStabs.get(i).getText() + " tab",
								"Next Button is clicked", StepResult.PASS);
					} catch (Exception e) {
						report.addReportStep("Click the <b>NEXT</b> button in the parts n services overlay",
								"Next Button is not clicked", StepResult.FAIL);

						rc.terminateTestCase("Appliance parts and services overlay");
					}

				}

			} catch (Exception e) {
				report.addReportStep("Verify that Select Parts and services tabs are displayed",
						"Unable to find the Select Parts and  services tabs section", StepResult.FAIL);
				rc.terminateTestCase("Appliance parts and services overlay");
			}

		}

		else {
			report.addReportStep("Verify that 'SELECT PARTS' button is available in the ATC overlay",
					"Unable to click the 'SELECT PARTS' button", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");

		}

		return new ShoppingCartPage(ic);
	}

	/**
	 * Method to click more info link
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ApplianceOverlay clickMoreInfoLink() throws Exception {

		if (wh.isElementPresent(moreInfoLink, 5)) {
			wh.clickElement(moreInfoLink);
			report.addReportStep("Verify more information link is clicked in Protection Plan tab(P&S overlay)",
					"More information link is clicked in Protection Plan tab(P&S overlay)", StepResult.PASS);
		} else {
			report.addReportStep("Verify more information link is clicked in Protection Plan tab(P&S overlay)",
					"More information link is not clicked in Protection Plan tab(P&S overlay)", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to click on terms and conditions link
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ApplianceOverlay clickTermsAndConditionLink() throws Exception {

		String currentWindowHandle = driver.getWindowHandle();

		commonData.newWindow = currentWindowHandle;

		if (wh.isElementPresent(termsAndCondLink, 5)) {
			wh.clickElement(termsAndCondLink);
			report.addReportStep("Verify Terms and conditions link is clicked in Protection Plan tab(P&S overlay)",
					"Terms and conditions link is clicked in Protection Plan tab(P&S overlay)", StepResult.PASS);
		} else {
			report.addReportStep("Verify Terms and conditions link is clicked in Protection Plan tab(P&S overlay)",
					"Terms and conditions link is not clicked in Protection Plan tab(P&S overlay)", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To verify terms and conditions in new tab
	 * 
	 * @return
	 * @throws Exception
	 */
	public ApplianceOverlay verifyTermsAndCondInNewTab() throws Exception {

		try {

			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "/t");

			report.addReportStep("Verify terms and conditions pdf opened in new tab ",
					"Terms and conditions pdf opened in new tab", StepResult.PASS);

		}

		catch (Exception ex) {
			report.addReportStep("Verify terms and conditions pdf opened in new tab ",
					"Terms and conditions pdf is not opened properly", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To verify More info in new tab
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ApplianceOverlay verifyMoreInfoInNewTab() throws Exception {

		try {

			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, Keys.PAGE_DOWN);

			report.addReportStep("Verify More information link is opened in new tab ",
					"More information link is opened in new tab", StepResult.PASS);

		}

		catch (Exception ex) {
			report.addReportStep("Verify More information link is opened in new tab ",
					"More information link is not opened in new tab", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to enter zipcode and check availability from my list
	 * 
	 * @return
	 * @throws Exception
	 */
	public ApplianceOverlay enterZipCodeCheckAvailabilityMyList() throws Exception {

		// verify product in overly

		if (wh.isElementPresent(applianceATCProductDetailsMyList, 2)) {
			try {

				String strProdDetails = wh.getText(applianceATCProductDetailsMyList);

				report.addReportStep("Product details should be displayed in overlay",
						"Product details is displayed in overlay  <b>" + strProdDetails + "</b>", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Product details should be displayed in overlay",
						"Product details is not  displayed in overlay", StepResult.FAIL);
			}

			// enter zipcode
			if (wh.isElementPresent(applianceZipTextBoxMyList, 2)) {

				String strZipCode = dataTable.getData("ZipCode");
				try {

					wh.clearElement(applianceZipTextBoxMyList);
					wh.sendKeys(applianceZipTextBoxMyList, strZipCode);

					report.addReportStep("Zipcode should be enter in the text field",
							"<b>" + strZipCode + "</b> zipcode is entered in text field", StepResult.PASS);

					// click on check availability
					if (wh.isElementPresent(applianceCheckAvailabilityBtnMyList, 2)) {

						wh.clickElement(applianceCheckAvailabilityBtnMyList);
						
						Thread.sleep(commonData.littleWait);

						report.addReportStep("CHECK AVAILABILITY botton should be clicked",
								"<b>CHECK AVAILABILITY </b>button is clicked", StepResult.PASS);
					} else {
						report.addReportStep("CHECK AVAILABILITY botton should be clicked",
								"<b>CHECK AVAILABILITY </b>button is not clicked", StepResult.FAIL);
						rc.terminateTestCase("Appliance zipcode overlay");
					}
				} catch (Exception e) {
					report.addReportStep("Zipcode should be enter in the text field",
							"Zipcode is not entered in the text field", StepResult.FAIL);
					rc.terminateTestCase("Appliance zipcode overlay");
				}

			}

			else if (wh.isElementPresent(verifyAddToCartModal, 3)) {

				report.addReportStep("Zipcode should be availble in overlay", "Zipcode overlay already available",
						StepResult.PASS);
			} else {
				report.addReportStep("Zipcode should be availble in overlay",
						"unable to find enter zipcode field in overlay", StepResult.FAIL);
				rc.terminateTestCase("Appliance ATC overlay");
			}

			// earliest date

			/*
			 * if (wh.isElementPresent(applianceEarlistAvlTxtMyList, 15)) {
			 * 
			 * String strEarlist = wh.getText(applianceEarlistAvlTxtMyList);
			 * 
			 * report.addReportStep("Earliest Available should be displayed",
			 * "<b>" + strEarlist + "</b> is displayed", StepResult.PASS);
			 * 
			 * } else { report.addReportStep(
			 * "Earliest Available should be displayed",
			 * "Earliest Available is not displayed", StepResult.FAIL); }
			 */

			// verify Select parts and edit cart
			if (wh.isElementPresent(applianceSelectPartsBtnMyList, 2)
					&& wh.isElementPresent(applianceEditCartBtnMyList, 2)
					&& !wh.isElementPresent(applianceContinueShoppingBtn, 2)) {

				report.addReportStep(
						"select parts and Edit cart buttons should be displayed.Continue Shopping button shouldnot be displayed ",
						"select parts and Edit cart buttons are displayed.Continue Shopping button is not  displayed ",
						StepResult.PASS);

			} else {
				report.addReportStep(
						"select parts and Edit cart buttons should be displayed.Continue Shopping button shouldnot be displayed ",
						"select parts and Edit cart buttons are not displayed.Continue Shopping button is  displayed ",
						StepResult.FAIL);
				rc.terminateTestCase("Appliance Select Parts and Services");
			}
		} else {
			report.addReportStep("Overly should be displayed", "unable to find Appliance overly", StepResult.FAIL);
			rc.terminateTestCase("Appliance ATC overlay");
		}

		return this;
	}

	/**
	 * Method to verify parts and service in protection plan list
	 * 
	 * @param install
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage partsAndServicesProtectionPlanMyList(boolean install) throws Exception {

		int i = 0;

		if (wh.isElementPresent(applianceSelectPartsBtnMyList, 5)) {
			wh.clickElement(applianceSelectPartsBtnMyList);
			report.addReportStep("Verify select part and services button",
					"Select parts and services button is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify select part and services button",
					"Select parts and services button is displayed", StepResult.FAIL);
		}

		if (wh.isElementPresent(applianceSelectPartsnavMyList, 8)) {

			String strBreadCrumb = wh.getText(applianceSelectPartsnavMyList);

			report.addReportStep("Verify that the <b>Select Parts and services </b> is displayed",
					"The Select Parts and services is displayed as <b>" + strBreadCrumb + "</b>", StepResult.PASS);

			try {

				List<WebElement> lstPNStabs = driver.findElements(appliancePnSTabsMyList);

				if (!install) {
					if (wh.isElementPresent(applianceInstallNoRadio)) {
						wh.clickElement(applianceInstallNoRadio);
					}
				}

				for (i = 0; i < lstPNStabs.size(); i++) {

					if (i == (lstPNStabs.size() - 1)) {
						try {

							if (wh.isElementPresent(appliancePnSGoToCartMyList, 6)
									&& (wh.isElementPresent(protPlanIconsMyList, 6))) {
								String protPlanTxt = driver.findElement(protPlanIconsMyList).getText();
								String feesIcon = driver.findElement(By.cssSelector("li.hdpp-li-no-fees"))
										.getCssValue("background");
								String laborIcon = driver.findElement(By.cssSelector("li.hdpp-li-parts-labor"))
										.getCssValue("background");
								String homeIcon = driver.findElement(By.cssSelector("li.hdpp-li-in-home"))
										.getCssValue("background");
								String supportIcon = driver.findElement(By.cssSelector("li.hdpp-li-24-7"))
										.getCssValue("background");
								String moreInfo = driver.findElement(By.cssSelector("a.hdpp-info-more-info")).getText();
								String termsText = driver
										.findElement(By.xpath("//a[contains(text(),'Terms & Conditions')]")).getText();
								if (protPlanTxt.contains("No deductibles, no additional fees")
										&& protPlanTxt.contains("Parts and labor costs included")
										&& protPlanTxt.contains("In-home service by authorized technicians")
										&& protPlanTxt.contains("24/7 support")) {
									report.addReportStep(
											"Protection plan new text should be displayed in the parts n services overlay",
											"Protection plan new text is displayed", StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan new text should be displayed in the parts n services overlay",
											"Protection plan new text is not displayed", StepResult.FAIL);
								}
								if (feesIcon.contains("hdpp_no-fees_icon.png")
										&& laborIcon.contains("hdpp_parts-labor_icon.png")
										&& homeIcon.contains("hdpp_in-home_icon.png")
										&& supportIcon.contains("hdpp_24-7_icon.png")) {
									report.addReportStep(
											"Protection plan new icons should be displayed in the parts n services overlay",
											"Protection plan new icons is displayed", StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan new icons should be displayed in the parts n services overlay",
											"Protection plan new icons is not displayed", StepResult.FAIL);
								}
								if (moreInfo.contains("Click here for more information")
										&& termsText.contains("Terms & Conditions")) {
									report.addReportStep(
											"Protection plan Get More Info and Terms & Condition link should be displayed in the parts n services overlay",
											"Protection plan Get More Info and Terms & Condition link is displayed",
											StepResult.PASS);

								} else {
									report.addReportStep(
											"Protection plan Get More Info and Terms & Condition link should be displayed in the parts n services overlay",
											"Protection plan Get More Info and Terms & Condition link is not displayed",
											StepResult.FAIL);
								}
							}

							break;
						} catch (Exception e) {

							report.addReportStep(
									"Protection plan new text should be displayed in the parts n services overlay",
									"Protection plan new text is not displayed", StepResult.FAIL);
							rc.terminateTestCase("Cart page");
							break;
						}
					}

					try {

						wh.clickElement(appliancePnSNext);

						report.addReportStep(
								"Click the <b>NEXT</b> button in the " + lstPNStabs.get(i).getText() + " tab",
								"Next Button is clicked", StepResult.PASS);
					} catch (Exception e) {
						report.addReportStep("Click the <b>NEXT</b> button in the parts n services overlay",
								"Next Button is not clicked", StepResult.FAIL);

						rc.terminateTestCase("Appliance parts and services overlay");
					}

				}

			} catch (Exception e) {
				report.addReportStep("Verify that Select Parts and services tabs are displayed",
						"Unable to find the Select Parts and  services tabs section", StepResult.FAIL);
				rc.terminateTestCase("Appliance parts and services overlay");
			}

		}

		else {
			report.addReportStep("Verify that 'SELECT PARTS' button is available in the ATC overlay",
					"Unable to click the 'SELECT PARTS' button", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");

		}

		return new ShoppingCartPage(ic);
	}

	/**
	 * Method to verify free deliver message in my list
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ApplianceOverlay verifyFreeDeliveryMessageMyList() throws Exception {

		if (wh.isElementPresent(freeDeliveryMsg, 5)) {

			String msg = wh.getText(freeDeliveryMsg);

			if (msg.equalsIgnoreCase("free delivery")) {
				report.addReportStep("Verify Free Delivery message is displayed for appliance in overlay",
						"Free Delivery message is displayed for appliance in overlay", StepResult.PASS);
			}

			else {
				report.addReportStep("Verify Free Delivery message is displayed for appliance in overlay",
						"Free Delivery message is not displayed properly for appliance in overlay", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify Free Delivery message is displayed for appliance in overlay",
					"Free Delivery message is not displayed for appliance in overlay", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Method to verify $ 396 or more message in my list
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ApplianceOverlay verify$396orMoreMessageMyList() throws Exception {

		if (wh.isElementPresent(freeDeliveryMsg, 5)) {

			String msg = wh.getText(freeDeliveryMsg);

			if (msg.equalsIgnoreCase("free delivery on\nappliance purchases of $396 or more")) {
				report.addReportStep(
						"Verify Free Delivery on Major Appliances $396 or more message is displayed for appliance in overlay",
						"Free Delivery on Major Appliances $396 or more message is displayed for appliance in overlay",
						StepResult.PASS);
			}

			else {
				report.addReportStep(
						"Verify Free Delivery on Major Appliances $396 or more message is displayed for appliance in overlay",
						"Free Delivery on Major Appliances $396 or more message is not displayed properly for appliance in overlay",
						StepResult.FAIL);
			}

		} else {

			report.addReportStep(
					"Verify Free Delivery on Major Appliances $396 or more message is displayed for appliance in overlay",
					"Free Delivery on Major Appliances $396 or more message is not displayed for appliance in overlay",
					StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Method to verify no free delivery message in my list
	 * 
	 * @return
	 * @throws Exception
	 */
	public ApplianceOverlay verifyNoFreeDeliveryMessageMyList() throws Exception {

		if (wh.isElementNotPresent(noFreeDeliveryMsg)) {

			report.addReportStep("Verify Free Delivery message is not displayed for appliance in overlay",
					"Free Delivery is not displayed for appliance in overlay", StepResult.PASS);

		} else {

			report.addReportStep("Verify Free Delivery message is not displayed for appliance in overlay",
					"Free Delivery message is displayed for appliance in overlay", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Component to enter the zip code in overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void enterZipcode() throws Exception {
		wh.waitForPageLoaded();

		// enter zipcode
		if (wh.isElementPresent(applianceZipTextBox, 2)) {

			String strZipCode = dataTable.getData("ZipCode");

			wh.clearElement(applianceZipTextBox);
			wh.sendKeys(applianceZipTextBox, strZipCode);
			Thread.sleep(3000l);

			wh.clickElement(applianceCheckAvailabilityBtn);

			report.addReportStep("Zipcode should be enter in the text field",
					"<b>" + strZipCode + "</b> zipcode is entered in text field", StepResult.PASS);
		} else {
			report.addReportStep("Verify Zipcode is entered in overlay", "Zipcode is entered in text field  in overlay",
					StepResult.FAIL);
		}

	}
	
	/**
	 * Method to click save changes
	 * 
	 * @return
	 * @throws Exception
	 */
	public void clickSaveChangesBtn() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(saveChangesBtn)) {

			wh.clickElement(saveChangesBtn);
			report.addReportStep("Click Save Changes button in Shopping Cart Page in P&S overlay",
					"Clicked Save Changes button in Shopping Cart Page in P&S overlay", StepResult.PASS);
		} else {
			report.addReportStep("Click Save Changes button in Shopping Cart Page in P&S overlay",
					"Save Changes button in not clicked in Shopping Cart Page in P&S overlay", StepResult.FAIL);
		}
		wh.waitForPageLoaded();
		Thread.sleep(commonData.mediumWait);
	}
	
	public void selectProtectionPlan() throws Exception {

		wh.waitForPageLoaded();
		try {

			List<WebElement> lstPNStabs = driver.findElements(appliancePnSTabs);

			for (int i = 0; i < lstPNStabs.size(); i++) {

				if (i == (lstPNStabs.size() - 1)) {
					try {

						if (wh.isElementPresent(protPlan, 6)) {

							wh.clickElement(protPlan);
							report.addReportStep("Click protection plan in Shopping Cart Page in P&S overlay",
									"Clicked protection plan in Shopping Cart Page in P&S overlay", StepResult.PASS);
							if (wh.isElementPresent(protPlanPrice, 6)) {
								String protPrice = wh.getText(protPlanPrice);
								commonData.protPlanPrice=protPrice.substring(1);
							}
							
						}

						break;
					} catch (Exception e) {

						report.addReportStep("Click the <b>Go to CART</b> button in the parts n services overlay",
								"Button not clicked", StepResult.FAIL);
						rc.terminateTestCase("Cart page");
						break;
					}
				}

				try {

					wh.clickElement(appliancePnSNext);

					report.addReportStep("Click the <b>NEXT</b> button in the " + lstPNStabs.get(i).getText() + " tab",
							"Next Button is clicked", StepResult.PASS);
				} catch (Exception e) {
					report.addReportStep("Click the <b>NEXT</b> button in the parts n services overlay",
							"Next Button is not clicked", StepResult.FAIL);

					rc.terminateTestCase("Appliance parts and services overlay");
				}

			}

		} catch (Exception e) {
			report.addReportStep("Verify that Select Parts and services tabs are displayed",
					"Unable to find the Select Parts and  services tabs section", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");
		}

	}
	
	public void verifyTwoStepInstalMsg() throws Exception {

		if (wh.isElementPresent(twoStepInstalMsg)) {
			Thread.sleep(commonData.littleWait);
			String strText = wh.getText(twoStepInstalMsg);
			if (strText.contains(
					"Note: Installation and delivery are handled separately, since a local licensed installer is needed. Your delivery agent will schedule your installation when you receive your product")) {
				report.addReportStep("Verify two step installation msg is displayed in P&S Overlay",
						"Two step installation msg" + strText + "is displayed in P&S Overlay", StepResult.PASS);
			} else {
				report.addReportStep("Verify two step installation msg is displayed in P&S Overlay",
						"Two step installation msg" + strText + " is not displayed properly in P&S Overlay",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify two step installation msg is displayed in P&S Overlay",
					"Two step installation msg is not displayed in P&S Overlay", StepResult.FAIL);
		}

	}
	
	public void clickSelectPartsButton() throws Exception {
		if (wh.isElementPresent(applianceSelectPartsBtn, 5)) {
			wh.clickElement(applianceSelectPartsBtn);
			report.addReportStep("Verify select part and services button",
					"Select parts and services button is displayed", StepResult.PASS);
		} else {
			if (checkoutConfig.depotDirectDown) {
				wh.clickElement(applianceErrGoToCart);
				report.addReportStep("Click Go to Cart button", "Go To cart button clicked", StepResult.PASS);
			} else {
				report.addReportStep("Verify select part and services button",
						"Select parts and services button is displayed", StepResult.FAIL);
			}
		}
	}
	
	public void verifyQty() throws Exception {
        /* Capture* QTY */
        if (wh.isElementPresent(applnceQtyInOverlay, 2)) {
               /*String strqty  = wh.getText(applnceQtyInOverlay).split("\\(")[1].trim();
               String strquan = strqty.split("\\ ")[0].trim();
               System.out.println(strquan);
               int qty = Integer.parseInt(strquan);*/
               commonData.pipQty = 1;

        }
 }

	public ShoppingCartPage verifyContinueShoppingButton() throws Exception {
		int i = 0;
		if (wh.isElementPresent(applianceSelectPartsnav, 8)) {

			String strBreadCrumb = wh.getText(applianceSelectPartsnav);

			report.addReportStep("Verify that the <b>Select Parts and services </b> is displayed",
					"The Select Parts and services is displayed as <b>" + strBreadCrumb + "</b>", StepResult.PASS);

			try {

				List<WebElement> lstPNStabs = driver.findElements(appliancePnSTabs);

				for (i = 0; i < lstPNStabs.size(); i++) {

					if (i == (lstPNStabs.size() - 1)) {
						try {

							if (wh.isElementPresent(appliancePnSGoToCart, 6)) {
								if (wh.isElementPresent(applianceContinueShoppingBtn, 6)) {
									report.addReportStep("Verify Continue Shopping button in P&S overlay",
											"Continus Shopping button is present in P&S overlay", StepResult.PASS);
								} else {
									report.addReportStep("Verify Continue Shopping button in P&S overlay",
											"Continus Shopping button is not present in P&S overlay", StepResult.FAIL);
								}
							}

							break;
						} catch (Exception e) {

							report.addReportStep(
									"Protection plan new text should be displayed in the parts n services overlay",
									"Protection plan new text is not displayed", StepResult.FAIL);
							rc.terminateTestCase("Cart page");
							break;
						}
					}

					try {

						wh.clickElement(appliancePnSNext);

						report.addReportStep(
								"Click the <b>NEXT</b> button in the " + lstPNStabs.get(i).getText() + " tab",
								"Next Button is clicked", StepResult.PASS);
					} catch (Exception e) {
						report.addReportStep("Click the <b>NEXT</b> button in the parts n services overlay",
								"Next Button is not clicked", StepResult.FAIL);

						rc.terminateTestCase("Appliance parts and services overlay");
					}

				}

			} catch (Exception e) {
				report.addReportStep("Verify that Select Parts and services tabs are displayed",
						"Unable to find the Select Parts and  services tabs section", StepResult.FAIL);
				rc.terminateTestCase("Appliance parts and services overlay");
			}

		}

		else {
			report.addReportStep("Verify that 'SELECT PARTS' button is available in the ATC overlay",
					"Unable to click the 'SELECT PARTS' button", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");

		}

		return new ShoppingCartPage(ic);
	}
	
	public void verifyPartsAndServicesOverlay() throws Exception {
		if (wh.isElementPresent(applianceSelectPartsnav, 8)) {

			String strBreadCrumb = wh.getText(applianceSelectPartsnav);

			report.addReportStep("Verify that the <b>Select Parts and services </b> is displayed",
					"The Select Parts and services is displayed as <b>" + strBreadCrumb + "</b>", StepResult.PASS);
		} else {
			report.addReportStep("Verify that 'SELECT PARTS' button is available in the ATC overlay",
					"Unable to click the 'SELECT PARTS' button", StepResult.FAIL);
			rc.terminateTestCase("Appliance parts and services overlay");

		}
	}

}
