package com.homer.po;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class ApplianceDeliveryPage extends PageBase<ApplianceDeliveryPage> {

	static final By applianceDeliveryPageTitle = By
			.xpath("//h3[@class='title m-bottom-small'][text()='Appliance Delivery Address & Calendar']");
	static final By firstNameTxtBox = By.xpath("(//input[@name='firstName'])[1]");
	static final By lastNameTxtBox = By.xpath("(//input[@name='lastName'])[1]");
	static final By addr1TxtBox = By.xpath("(//input[@name='address1'])[1]");
	static final By addr2TxtBox = By.xpath("(//input[@name='address2'])[1]");
	//static final By zipCodeTxtBox = By.xpath("(//input[@name='zipcode'])[1]");
	static final By zipCodeTxtBox = By.xpath("(//input[@class='zipcode-lookup zipcode zipcode-lookup-us-mexico'])[1]");
	static final By phNoTxtBox = By.xpath("(//input[@name='phone'])[1]");
	static final By altPhNo = By.xpath("//input[@id='appliance-alternate-phone']");
	static final By continueBtn = By.xpath("(//a[contains(.,'Continue')])[1]");
	static final By shippingInfo = By.xpath("//a[contains(.,'add new address')]");
	static final By applianceDeliveryText = By
			.xpath("//div[@class='order-summary-pod']/descendant::h4[contains(text(),'Appliance Delivery')]");
	static final By applianceDeliveryCharge = By
			.xpath("//div[@class='order-summary-pod']/descendant::h4[contains(text(),'Appliance Delivery')]/following-sibling::h4");
	static final By SelectDeliverydate = By.xpath("//h4[contains(text(),'Select Delivery Date from Calendar')]");
	static final By CurrentMonth = By.cssSelector("span[class='datepicker-title title normal uppercase']");
	static final By PreviousMonthArrow = By
			.cssSelector("a[class='thdTablet-btn btn-light-grey-flat btn-small left previous-month']");
	static final By CalendarOverlayclose = By.xpath("//*[@id='applianceDatePickerModal']//*[@class='md-close']");
	static final By NextMonthArrow = By
			.xpath("//*[@class='thdTablet-btn btn-light-grey-flat btn-small right next-month']");
	static final By Deliverysection = By
			.xpath("//*[@class='delivery-options']/h3[contains(text(),'Select a Delivery Date')]");
	// static final By noDeliverysection =
	// By.xpath("//*[@class='delivery-options']//h3[contains(text(),'We Will Call by 7 pm the day')]");
	static final By noDeliverysection = By.xpath("//*[@class='flex no-calendar-appliance-delivery']//h3");

	static final By calendaroverlaysection = By.xpath("//*[@id='appliance-delivery-datepicker']");
	static final By AvailableDelivery = By.xpath("(//*[contains(@class,'datepicker-td available')])[1]");
	static final By OverlayMessage = By.xpath("//*[@class='m-bottom-large datepicker-message']//p");
	static final By overlayUpdatebutton = By.xpath("//*[@id='apply-address' and contains(text(),'UPDATE')]");
	static final By ApplianceDeliverydate = By.xpath("//*[@id='applianceCalendarDate']");
	static final By lblApplianceSubtotal = By.xpath("//*[@class='display-row'][1]/h3[2]");
	static final By lblApplianceDelivery = By.xpath("//*[@class='display-row'][2]/h4[2]");
	static final By lblEstdSalesTax = By.xpath("//*[@id='sales-tax']");
	static final By OrderSummarysection = By.xpath("//*[@class='order-summary order-summary-container clear']");
	static final By EditLink = By.xpath("//a[contains(text(),'edit this address')]");
	static final By AddNewAddress = By.xpath("//a[contains(text(),'add new address')]");
	static final By EditAddressOverlay = By.xpath("//*[@id='edit-address-overlay']");
	static final By CancelButton = By.xpath("//div[@id='edit-address-overlay']//a[contains(text(),'CANCEL')]");
	static final By EnterDeliveryAddress = By.xpath("//h4[contains(text(),'Enter a Delivery Address')]/../div");
	static final By AddAddressOverlay = By.id("add-address-overlay-content");
	static final By NewFirstName = By.xpath("//div[@id='add-address-overlay']//input[@name='firstName']");
	static final By NewlastName = By.xpath("//div[@id='add-address-overlay']//input[@name='lastName']");
	static final By NewAddress = By.xpath("//div[@id='add-address-overlay']//input[@name='address1']");
	static final By NewAddressEdit = By.xpath("//div[@id='edit-address-overlay']//input[@name='address1']");
	static final By NewZipCodeEdit = By.xpath("//div[@id='edit-address-overlay']//input[@class='zipcode-lookup zipcode zipcode-lookup-us-mexico']");
	static final By NewPhoneNum = By.xpath("//div[@id='add-address-overlay']//input[@name='phone']");
	static final By SaveButton = By.xpath("//div[@id='add-address-overlay']//a[contains(text(),'SAVE')]");
	static final By EditAddressOverlaySaveBtn = By.xpath("//div[@id='edit-address-overlay']//a[contains(text(),'SAVE')]");
	static final By addAddrOverlay = By.id("add-address-overlay");
	static final By checkoutErrMsg = By.xpath("//span[@class='checkout-error-message']");
	static final By backBtn = By.xpath("//div[@class='tablet-checkout-right-rail']/descendant::a[contains(.,'Back')]");
	static final By checkoutNowBtn = By.id("checkout-btn");
	static final By secureSignInContinueBtn = By.xpath("//a[text()='CONTINUE']");
	static final By splInstrction = By.xpath("//*[@id='specialInstructions']");

	static final By shippingAddr = By.xpath("//h4[contains(text(),'Shipping Address')]/..//fieldset//label");
	static final By shippingAddrFName = By.xpath("//h4[contains(text(),'Shipping Address')]/..//fieldset/div[2]/label");
	static final By shippingAddrLName = By.xpath("//h4[contains(text(),'Shipping Address')]/..//fieldset/div[4]/label");
	static final By applianceAddrPhone = By
			.xpath("//h3[contains(text(),'Appliance Delivery')]/..//label[contains(text(),'Last Name')]/../following-sibling::div[2]");

	static final By firstnameerr = By.xpath("//*[@for='firstName']");
	static final By lastnameerr = By.xpath("//*[@for='lastName']");
	static final By pherr = By.xpath("//*[@for='phone']");
	static final By addr1err = By.xpath("//*[@for='address1']");
	static final By altPhErr = By.xpath("//*[@for='appliance-alternate-phone']");
	static final By changeLink = By.xpath("//span[@class='bold text-primary m-left-small zipcode-change']");

	static final By noDeliveryDate = By.xpath("//h3[contains(text(),'We Will Call by')]");
	static final By editOverlayCitySelect = By.id("edit-address-overlay-content_city_select");
	static final By EditAddressOverlayUpdateBtn = By.xpath("//div[@id='edit-address-overlay']//a[contains(text(),'UPDATE')]");
	static final By ApplianceDeliverySelectedDate = By.xpath("//td[@class='datepicker-td available delivery']");
	static final By applDelDateRR = By.id("app-deliveryDate");
	static final By applEarliestDelDate = By.id("applianceEarliestDate");
	public ApplianceDeliveryPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify Appliance delivery Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ApplianceDeliveryPage verifyApplianceDeliveryPage() throws Exception {

		wh.waitForElementPresent(applianceDeliveryPageTitle, 5);

		if (wh.isElementPresent(applianceDeliveryPageTitle, 2)) {

			report.addReportStep("Verify Appliance Delivery page is displayed", "Shipping page is displayed",
					StepResult.PASS);
		} else {

			report.addReportStep("Verify Appliance Delivery page is displayed", "Shipping page is not displayed",
					StepResult.FAIL);
			rc.terminateTestCase("Appliance delivery page");
		}

		return this;
	}

	/**
	 * Method to enter Delivery details
	 * 
	 * @return
	 * @throws Exception
	 */
	public ApplianceDeliveryPage enterDeliveryAddress() throws Exception {

		if (wh.isElementPresent(firstNameTxtBox, 7)) {
			report.addReportStep("Verify Address field section is displayed", "Address field section was displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Address field section is displayed",
					"Address field section was not displayed", StepResult.FAIL);
			rc.terminateTestCase("Appliance Delivery Address Section");
		}

		boolean blnIsSavedAddress = false;

		try {

			driver.findElement(firstNameTxtBox).sendKeys("Testing");
			wh.clearElement(firstNameTxtBox);
		} catch (Exception e) {
			String strTempSavedAddress = driver.findElement(By.cssSelector(".address-module.m-bottom-normal"))
					.getText();

			if (strTempSavedAddress.toLowerCase().contains(
					dataTable.getCommonData(CommonDataColumn.ShippingFirstName).toLowerCase())) {
				report.addReportStep("Verify that the delivery section is displayed with a saved address",
						"Section is displayed with a saved address", StepResult.PASS);
				blnIsSavedAddress = true;
			} else {
				report.addReportStep("Verify that the delivery section is displayed with a saved address",
						"Section is not displayed with a saved address", StepResult.FAIL);
				rc.terminateTestCase("Appliance Delivery Saved Address");
			}

		}

		if (!blnIsSavedAddress) {

			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr));

			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);

		}

		return this;
	}

	/**
	 * Component to select delivery date section is displayed and choose the
	 * delivery date
	 * 
	 * @throws Exception
	 * 
	 */
	public void selectDeliveryDate() throws Exception {
		/*
		 * if(wh.isElementPresent(SelectDeliverydate, 5)){ List<WebElement>
		 * lstDate = driver.findElements(SelectDeliverydate); List<WebElement>
		 * lsttext = driver.findElements(By
		 * .xpath("//*[@class='radio-set m-bottom-normal']")); for (int i = 0; i
		 * < lstDate.size(); i++) { if (lstDate.get(i).isSelected()) { String
		 * strValue = lsttext.get(i).getText(); report.addReportStep(
		 * "Delivery date is selected for the item", "The Delivery date is: <b>"
		 * + strValue + "<b> is  selected", StepResult.PASS); break; } }
		 * 
		 * } else {
		 * report.addReportStep("Delivery date option for appliance item",
		 * "Delivery date option is not displayed", StepResult.FAIL); }
		 */
		if (wh.isElementPresent(Deliverysection, 5)) {
			report.addReportStep("Delivery Options section is displayed in the Appliance delivery page",
					"Delivery options section is displayed", StepResult.PASS);
			wh.jsClick(SelectDeliverydate);
			wh.jsClick(AvailableDelivery);
			report.addReportStep("Delivery Date is selected", "Delivery Date is selected", StepResult.PASS);
			String Message = driver.findElement(OverlayMessage).getText();
			if (Message.contains("We will call the day")) {
				report.addReportStep("Delivery information is displayed in calendar Overlay", "Delivery information<b>"
						+ Message + "<b>is displayed in calendar Overlay", StepResult.PASS);
			} else {
				report.addReportStep("Delivery information is displayed in calendar Overlay",
						"Delivery information is not displayed in calendar Overlay", StepResult.FAIL);
			}
			String SelectedColour = driver.findElement(ApplianceDeliverydate).getCssValue("color");
			if (SelectedColour.contains("rgba")) {
				report.addReportStep("Verify Selected date should be displayed in Orange Color",
						"Selected date should be displayed in Orange Color", StepResult.PASS);
			} else {
				report.addReportStep("Verify Selected date should be displayed in Orange Color",
						"Selected date is not displayed in Orange Color", StepResult.DONE);
			}
			Thread.sleep(1500);
			if (wh.isElementPresent(ApplianceDeliverySelectedDate, 5)) {
				String DeliveryDateSelected = driver.findElement(ApplianceDeliverySelectedDate).getText();
				commonData.applDelDate = DeliveryDateSelected;
				report.addReportStep("Delivery date is selected",
						"Delivery date selected is <b> " + DeliveryDateSelected + " </b>displayed", StepResult.PASS);
			} else {
				report.addReportStep("Delivery date selected is selected", "Delivery date is not selected",
						StepResult.FAIL);
			}
			wh.jsClick(overlayUpdatebutton);
			Thread.sleep(1500);
			if (wh.isElementPresent(ApplianceDeliverydate, 5)) {
				String DeliveryDateSelected = driver.findElement(ApplianceDeliverydate).getText();
				report.addReportStep("Delivery date selected is displayed in Day Month Date year format",
						"Delivery date selected is displayed <b>" + DeliveryDateSelected
								+ "<b> in Day Month Date year format", StepResult.PASS);
			} else {
				report.addReportStep("Delivery date selected is displayed in Day Month Date year format",
						"Delivery date selected is not displayed in Day Month Date year format", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(noDeliverysection)) {
			String strMsg = wh.getText(noDeliverysection);
			if (strMsg.contains("We Will Call by 7 pm the day")) {
				report.addReportStep("Delivery information is displayed in appliance delivery page",
						"Delivery information<b>" + strMsg + "<b>is displayed in appliance delivery page",
						StepResult.PASS);
			} else {
				report.addReportStep("Delivery information is displayed in appliance delivery page",
						"Delivery information<b>" + strMsg + "<b>is not displayed in appliance delivery page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Delivery Options section is displayed in the Appliance delivery page",
					"Delivery options section is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Methos to verify delivery charge in right rail
	 * 
	 * @throws Exception
	 */
	public void verifyDeliveryChargeInRightRail() throws Exception {

		// Verify Apply Delivery Text
		if (wh.isElementPresent(applianceDeliveryText, 5)) {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is displayed in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is not displayed in right rail", StepResult.FAIL);
		}

		// Verify Appliance Delivery Charge
		String applianceDeliveryChargeAmt = wh.getText(applianceDeliveryCharge);
		double aSubtotalAmt = commonData.applianceSubTotal;

		if (aSubtotalAmt >= 396.00) {

			if (applianceDeliveryChargeAmt.equals("FREE")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is not displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

		else {
			if (!applianceDeliveryChargeAmt.equals("FREE") && applianceDeliveryChargeAmt.contains("$")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

	}

	/**
	 * This component to verify if you click on previous month link then it
	 * should navigate to previous month
	 * 
	 * @throws Exception
	 */
	public void verifyPreviousMnthInDelvryPage() throws Exception {
		if (wh.isElementPresent(noDeliverysection)) {
			report.addReportStep("Verify delivery calendar section", "Delivery calender not displayed maybe Depot Direct part and Services Down",
					StepResult.WARNING);
		} else {
			wh.jsClick(SelectDeliverydate);
			String[] values = { "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER",
					"OCTOBER", "NOVEMBER", "DECEMBER" };
			System.out.println(values.length);
			int intCurrentMonthVal = 0;
			int intCurrentYear = 0;
			String strCurrentMonth = driver.findElement(CurrentMonth).getText();
			System.out.println(strCurrentMonth);
			for (int c = 0; c < values.length; c++) {
				if (strCurrentMonth.contains(values[c])) {
					intCurrentMonthVal = (c + 1);
					System.out.println("intCurrentMonthVal\t" + intCurrentMonthVal);
					intCurrentYear = Integer.parseInt(strCurrentMonth.substring(
							strCurrentMonth.indexOf(values[c]) + values[c].length(), strCurrentMonth.length()).trim());
					System.out.println("Current Year\t" + intCurrentYear);
				}
			}
			if (wh.isElementPresent(PreviousMonthArrow, 10)) {
				driver.findElement(PreviousMonthArrow).click();
				System.out.println("pass1");
				System.out.println(driver.findElement(CurrentMonth).getText());
				String strPreviousMnth = driver.findElement(CurrentMonth).getText();
				int intPreviousMonthVal = 0;
				int intPrevYear = 0;
				for (int p = 0; p < values.length; p++) {
					if (strPreviousMnth.contains(values[p])) {
						intPreviousMonthVal = (p + 1);
						System.out.println("intNextMonthVal\t" + intPreviousMonthVal);
						intPrevYear = Integer.parseInt(strPreviousMnth.substring(
								strPreviousMnth.indexOf(values[p]) + values[p].length(), strPreviousMnth.length())
								.trim());
						System.out.println("intNextYear\t" + intPrevYear);
					}
				}
				if (intPreviousMonthVal < intCurrentMonthVal) {
					report.addReportStep(strCurrentMonth + "should be navigate to previous month", strCurrentMonth
							+ "is navigated to previous month " + strPreviousMnth, StepResult.PASS);
				} else if (intPreviousMonthVal > intCurrentMonthVal && intPrevYear < intCurrentYear) {
					report.addReportStep(strCurrentMonth + "should be navigate to previous month", strCurrentMonth
							+ "is navigated to previous month " + strPreviousMnth, StepResult.PASS);
				} else {
					report.addReportStep("It should be navigated to previous month",
							"It is not navigated to previous month", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Carousel for navigating to previous months",
						"Carousel for navigating to previous months is not displayed", StepResult.DONE);
			}
			driver.findElement(CalendarOverlayclose).click();
			Thread.sleep(1000);
		}
	}

	/***
	 * This component is getting current month and year in Delivery page
	 * 
	 * @throws Exception
	 */
	public void verifyCurrentMonthYearInDelvryPage() throws Exception {
		String strCurrentMonth = "";
		if (wh.isElementPresent(noDeliverysection)) {
			report.addReportStep("verify Delivery Instructions is displayed",
					"Delivery calender not displayed maybe Depot Direct part and Services Down", StepResult.WARNING);
		} else {
			wh.jsClick(SelectDeliverydate);
			Thread.sleep(3000);
			if (wh.isElementPresent(CurrentMonth, 5)) {
				strCurrentMonth = driver.findElement(CurrentMonth).getText();
				System.out.println(strCurrentMonth);
				report.addReportStep("It should display current month and year",
						"It is displayed current month and year" + strCurrentMonth, StepResult.PASS);
				wh.jsClick(CalendarOverlayclose);
				Thread.sleep(1000);
			} else {
				report.addReportStep("It should display current month and year details",
						"current month and year details are not displayed", StepResult.FAIL);
			}
		}

	}

	/**
	 * This component to verify if you click on next month link then it should
	 * navigate to next month
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyNxtMnthInDelvryPage() throws Exception {
		if (wh.isElementPresent(noDeliverysection)) {
			report.addReportStep("Verify delivery calendar section", "Delivery calender not displayed maybe Depot Direct part and Services Down",
					StepResult.WARNING);
		} else {
			wh.jsClick(SelectDeliverydate);
			try {
				driver.findElement(CalendarOverlayclose).isDisplayed();

			} catch (Exception e) {
				wh.jsClick(SelectDeliverydate);
			}
			Thread.sleep(1000);
			String[] values = { "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER",
					"OCTOBER", "NOVEMBER", "DECEMBER" };
			System.out.println(values.length);
			int intCurrentMonthVal = 0;
			int intCurrentYear = 0;
			Thread.sleep(1000);
			String strCurrentMonth = driver.findElement(CurrentMonth).getText();
			System.out.println(strCurrentMonth);
			for (int c = 0; c < values.length; c++) {
				if (strCurrentMonth.contains(values[c])) {
					intCurrentMonthVal = (c + 1);
					System.out.println("intCurrentMonthVal\t" + intCurrentMonthVal);
					intCurrentYear = Integer.parseInt(strCurrentMonth.substring(
							strCurrentMonth.indexOf(values[c]) + values[c].length(), strCurrentMonth.length()).trim());
					System.out.println("Current Year\t" + intCurrentYear);
				}
			}
			wh.jsClick(NextMonthArrow);
			System.out.println(driver.findElement(CurrentMonth).getText());
			String strNextMonth = driver.findElement(CurrentMonth).getText();
			if (wh.isElementPresent(NextMonthArrow, 5)) {
				int intNextMonthVal = 0;
				int intNextYear = 0;
				for (int p = 0; p < values.length; p++) {
					if (strNextMonth.contains(values[p])) {
						intNextMonthVal = (p + 1);
						System.out.println("intNextMonthVal\t" + intNextMonthVal);
						intNextYear = Integer.parseInt(strNextMonth.substring(
								strNextMonth.indexOf(values[p]) + values[p].length(), strNextMonth.length()).trim());
						System.out.println("intNextYear\t" + intNextYear);
					}
				}
				if (intNextMonthVal > intCurrentMonthVal) {
					report.addReportStep(strCurrentMonth + "should be navigate to next month", strCurrentMonth
							+ "is navigated to next month " + strNextMonth, StepResult.PASS);
				} else if (intNextMonthVal < intCurrentMonthVal && intNextYear > intCurrentYear) {
					report.addReportStep(strCurrentMonth + "should be navigate to next month", strCurrentMonth
							+ "is navigated to next month " + strNextMonth, StepResult.PASS);
				} else {
					report.addReportStep("It should be navigate to next month", "It is not navigated to next month "
							+ strNextMonth, StepResult.FAIL);
				}
			}
			wh.jsClick(CalendarOverlayclose);
			Thread.sleep(1000);
		}
	}

	/**
	 * Function to verify the order summary section in Appliance delivery page
	 * 
	 * @throws Exception
	 *
	 */
	public void orderSummarySectionAppliance() throws Exception {
		Thread.sleep(1000);
		if (wh.isElementPresent(OrderSummarysection, 4)) {
			report.addReportStep("Check whether order summary section is displayed",
					"Order summary section is displayed", StepResult.PASS);
			if (wh.isElementPresent(lblApplianceSubtotal, 5)) {
				String subtotal = driver.findElement(lblApplianceSubtotal).getText();
				report.addReportStep("Check Appliance Subtotal is displayed", "Appliance Subtotal'" + subtotal
						+ "' is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Check whether order summary section is displayed",
						"Appliance Subtotal is not displayed", StepResult.FAIL);

			}
			if (wh.isElementPresent(lblApplianceDelivery, 5)) {
				String DeliveryCharge = driver.findElement(lblApplianceDelivery).getText();
				report.addReportStep("Check Appliance Delivery Mode is displayed", "Appliance Delivery Mode "
						+ DeliveryCharge + "is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Check Appliance Delivery Mode is displayed",
						"Appliance Delivery Mode is not displayed", StepResult.FAIL);
			}

			if (wh.isElementPresent(lblEstdSalesTax, 5)) {
				String DeliveryCharge = driver.findElement(lblEstdSalesTax).getText();
				report.addReportStep("Check Estd Sales Tax is displayed", "Estd Sales Tax is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Check Estd Sales Tax is displayed", "Estd Sales Tax is not displayed",
						StepResult.PASS);
			}

		} else {
			report.addReportStep("Check whether order summary section is displayed",
					"Order summary section is  not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify that the zipcode is displayed as a static text in the
	 * appliance delivery page
	 * 
	 * @throws Exception
	 */

	public void verifyStaticZipInDeliveryPage() throws Exception {
		String strApplianceZip = dataTable.getData("ZipCode");
		String strJumpStore = dataTable.getData("ChangeZipCode");
		if(!strJumpStore.isEmpty()){
			strApplianceZip = strJumpStore;
		}
		if (wh.isElementPresent(zipCodeTxtBox, 2)) {
			String strTempZip = wh.getAttribute(zipCodeTxtBox, "value");
			if (strTempZip.contains(strApplianceZip)) {
				report.addReportStep("verify that zip code auto-populated as statis text in appliance delivery page",
						"Zipcode :" + strApplianceZip + " is displayed as a static text", StepResult.PASS);
			} else {
				report.addReportStep("verify that zip code auto-populated as statis text in appliance delivery page",
						"Zipcode :" + strApplianceZip + " is displayed as a static text", StepResult.FAIL);
			}
		}

	}

	/**
	 * Component to verify that add new address and edit address links are
	 * available in delivery address page
	 * 
	 * @throws Exception
	 */
	public void verifyAddEditAddressLinks() throws Exception {
		verifyEditAddressLink();
		verifyAddNewAddressLink();
	}

	/*
	 * Function to check that edit address link is available in delivery address
	 * page
	 * 
	 * @throws InterruptedException
	 */
	public void verifyEditAddressLink() throws Exception {
		if (wh.isElementPresent(EditLink, 5)) {
			report.addReportStep("verify that edit address link is available in delivery addr page",
					"The link is available", StepResult.PASS);
		} else {
			report.addReportStep("verify that edit address link is available in delivery addr page",
					"The link is not available", StepResult.FAIL);
		}
	}

	/**
	 * Function to check that add new address link is available in delivery
	 * address page
	 * 
	 * @throws Exception
	 */
	public void verifyAddNewAddressLink() throws Exception {
		if (wh.isElementPresent(AddNewAddress, 3)) {
			report.addReportStep("verify that add new address link is available in delivery addr page",
					"The link is available", StepResult.PASS);
		} else {
			report.addReportStep("verify that add new address link is available in delivery addr page",
					"The link is not available", StepResult.FAIL);
		}
	}

	/**
	 * function to click on edit this address links in delivery/shipping address
	 * pages
	 * 
	 * @throws InterruptedException
	 */
	public void clickEditAddrLinkInApp() throws InterruptedException {
		try {
			if (wh.isElementPresent(EditLink, 3)) {
				wh.jsClick(EditLink);
				report.addReportStep("Click on edit address link", "The link is clicked", StepResult.PASS);
			} else {
				report.addReportStep("Click on edit address link", "The link is not clicked", StepResult.FAIL);
			}
		} catch (Exception e) {
			report.addReportStep("Click on edit address link", "The link is not clicked", StepResult.FAIL);
		}

	}

	public void enterApplianceAddressInOverlay() throws Exception {
		if (wh.isElementPresent(EditAddressOverlay, 5)) {
			report.addReportStep("Verify Edit Address Overlay is displayed", "Edit Addres Overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Edit Address Overlay is displayed", "Edit Addres Overlay is not displayed",
					StepResult.FAIL);
		}

		if (wh.isElementPresent(firstNameTxtBox, 2)) {
			wh.sendKeys(firstNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingFirstName1));
			wh.sendKeys(lastNameTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingLastName1));
			wh.sendKeys(addr1TxtBox, dataTable.getCommonData(CommonDataColumn.ShippingAddr1));

			wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.ShippingPhNo1));

		}

	}

	/*
	 * component to Click Cancel Button In Edit Address overlay
	 */
	public void clickCancelButton() throws Exception, Exception {
		if (wh.isElementPresent(CancelButton, 3)) {
			wh.jsClick(CancelButton);
			Thread.sleep(3000);
			report.addReportStep("Click the CANCEL button", "CANCEL button is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click the CANCEL button", "CANCEL button is not clicked", StepResult.FAIL);
		}
	}

	/*
	 * Component to verify Static address in Appliance Delivery page
	 */
	public void verifyApplianceStaticAddress() throws Exception {
		String firstName = dataTable.getCommonData(CommonDataColumn.ShippingFirstName);
		String lastName = dataTable.getCommonData(CommonDataColumn.ShippingLastName);
		String sPhonenum = dataTable.getCommonData(CommonDataColumn.ShippingPhNo);
		String strAddress1 = dataTable.getCommonData(CommonDataColumn.ShippingAddr);
		Thread.sleep(1000);
		if (wh.isElementPresent(EnterDeliveryAddress, 5)) {
			String strStaticAddr = "";
			try {
				strStaticAddr = driver.findElement(EnterDeliveryAddress).getText();
			} catch (Exception e) {
				System.out.println("Static text is not displayed");
			}
			if (strStaticAddr.contains(firstName) && strStaticAddr.contains(lastName)
					&& strStaticAddr.contains(strAddress1)) {
				report.addReportStep("verify that the static address displayed is the previously saved address",
						"Previously saved adddress is displayed", StepResult.PASS);
			} else {
				report.addReportStep("verify that the static address displayed is the previously saved address",
						"Previously saved adddress is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify that the static address displayed is the previously saved address",
					"Unable to validate the previously saved address", StepResult.FAIL);
		}
	}

	/*
	 * Component to click Add New address button in appliance Delivery page
	 */
	public void clickAddNewAddrInAppliancePage() throws Exception {
		if (wh.isElementPresent(AddNewAddress, 3)) {
			wh.jsClick(AddNewAddress);
			report.addReportStep("Click on Add New address link", "The link is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on Add New address link", "The link is not clicked", StepResult.FAIL);
		}
	}

	/*
	 * Component to add new Address in appliance Delivery page
	 */
	public void addAddrForApplianceDelivery() throws Exception {
		if (wh.isElementPresent(AddAddressOverlay, 4)) {
			String Header = driver.findElement(AddAddressOverlay).getText();
			if (Header.contains("Address")) {
				report.addReportStep("Add Address field section is displayed", "<b>Add field</b> section is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Add Address field section is displayed",
						"<b>Add field</b> section is not displayed", StepResult.FAIL);
			}
		}
		Thread.sleep(1000);
		if (wh.isElementPresent(AddAddressOverlay, 4)) {

			wh.sendKeys(NewFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName1));
			wh.sendKeys(NewlastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName1));
			wh.sendKeys(NewAddress, dataTable.getCommonData(CommonDataColumn.ShippingAddr1));
			wh.sendKeys(NewPhoneNum, dataTable.getCommonData(CommonDataColumn.ShippingPhNo1));
		} else {
			String strAddress = driver.findElement(By.xpath("//div[@id='savedAddresssection_0']/p")).getText();
			System.out.println(strAddress);
			report.addReportStep("Enter the Address in shipping page", "Address: <b>" + strAddress
					+ "</b> was default selected in Shipping page", StepResult.PASS);
		}
	}

	public void clickSaveButton() throws InterruptedException, Exception {
		if (wh.isElementPresent(SaveButton, 4)) {
			wh.jsClick(SaveButton);
			Thread.sleep(3000);
			report.addReportStep("Click the SAVE button", "SAVE button is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click the CANCEL button", "SAVE button is not clicked", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify add address overlay is displayed in delivery page
	 * AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyAddAddressOverlay() throws Exception {
		if (wh.isElementPresent(addAddrOverlay, 3)) {
			report.addReportStep("Verify Add Address overlay is displayed", "Add Address overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Add Address overlay is displayed", "Add Address overlay is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the Phone field is moved up AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyPhoneFieldMovedUp() throws Exception {
		if (wh.isElementPresent(applianceAddrPhone, 3)) {
			String phone = wh.getText(applianceAddrPhone);
			if (phone.contains("Phone")) {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is moved up and displayed below Last Name field", StepResult.PASS);
			} else {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is not moved up and not displayed below Last Name field", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
					"Shipping address fields are not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify Edit address overlay is displayed in delivery page
	 * AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyEditAddressOverlay() throws Exception {
		if (wh.isElementPresent(EditAddressOverlay, 3)) {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Method to click continue button
	 * 
	 * @return
	 * @throws Exception
	 */
	public void clickContinueBtn() throws Exception {

		wh.clickElement(continueBtn);

		report.addReportStep("Click checkout now button in Checkout Page",
				"Clicked check out now button in Checkout Page", StepResult.PASS);
		Thread.sleep(commonData.smallWait);

	}

	public void enterInvalidPoBoxAddressApplDelPage() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr1TxtBox, 3)) {
			for (i = 0; i < commonData.addrPOBOX.length; i++) {
				String addr = commonData.addrPOBOX[i];
				wh.clearElement(addr1TxtBox);
				wh.sendKeys(addr1TxtBox, addr);
				report.addReportStep("Verify <b>" + addr + "</b> is entered", "<b>" + addr + "</b> is entered",
						StepResult.PASS);
				clickContinueBtn();
				// wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(checkoutErrMsg, 5)) {
					String err = wh.getText(checkoutErrMsg);
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				// wh.clearElement(addr1TxtBox);
				// wh.sendKeys(addr1TxtBox,
				// dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(backBtn);
				Thread.sleep(commonData.mediumWait);
				wh.clickElement(checkoutNowBtn);
				Thread.sleep(commonData.littleWait);
				wh.clickElement(secureSignInContinueBtn);
				Thread.sleep(commonData.littleWait);
				verifyApplianceDeliveryPage();
				enterDeliveryAddress();

			}
		} else

		{
			report.addReportStep("Verify Address is entered with invalid PoBox", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidPoBoxAddress2ApplDelPage() throws Exception {

		int i = 0;

		if (wh.isElementPresent(addr2TxtBox, 3)) {
			for (i = 0; i < commonData.addrPOBOX.length; i++) {
				String addr = commonData.addrPOBOX[i];
				wh.clearElement(addr2TxtBox);
				wh.sendKeys(addr2TxtBox, addr);
				report.addReportStep("Verify <b>" + addr + "</b> is entered", "<b>" + addr + "</b> is entered",
						StepResult.PASS);
				clickContinueBtn();
				// wh.clickElement(addr2TxtBox);
				if (wh.isElementPresent(checkoutErrMsg, 5)) {
					String err = wh.getText(checkoutErrMsg);
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				// wh.clearElement(addr1TxtBox);
				// wh.sendKeys(addr1TxtBox,
				// dataTable.getCommonData(CommonDataColumn.ShippingAddr));
				wh.clickElement(backBtn);
				Thread.sleep(commonData.mediumWait);
				wh.clickElement(checkoutNowBtn);
				Thread.sleep(commonData.littleWait);
				wh.clickElement(secureSignInContinueBtn);
				Thread.sleep(commonData.littleWait);
				verifyApplianceDeliveryPage();
				enterDeliveryAddress();

			}
		} else

		{
			report.addReportStep("Verify Address2 is entered with invalid PoBox", "Address2 text box is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Method to verify all fields in delvery page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ApplianceDeliveryPage verifyAllFieldsInAppDelvPage() throws Exception {
		if (wh.isElementPresent(firstNameTxtBox, 2)) {

			String strFN = wh.getAttribute(firstNameTxtBox, "value");
			String strLN = wh.getAttribute(lastNameTxtBox, "value");
			String stradd1 = wh.getAttribute(addr1TxtBox, "value");
			String strzip = wh.getAttribute(zipCodeTxtBox, "value");
			String strph = wh.getAttribute(phNoTxtBox, "value");
			if (strFN.contains("") && strLN.contains("") && stradd1.contains("") && strzip.contains("")
					&& strph.contains("")) {
				report.addReportStep("Verify all fields in Delivery page",
						"Delivery page is displayed with mandatory fields", StepResult.PASS);
			} else {
				report.addReportStep("Verify all fields in Delivery page",
						"Delivery page is not displayed with mandatory fields", StepResult.FAIL);
			}

			if (wh.isElementPresent(continueBtn, 1) && wh.isElementPresent(backBtn, 1)
					&& wh.isElementPresent(splInstrction, 1)) {
				report.addReportStep("Verify all fields in Delivery page",
						"Delivery page is displayed with mandatory buttons", StepResult.PASS);
			}

		}
		return this;
	}

	/**
	 * Component to clear all input fields in delivery page
	 * 
	 * @throws Exception
	 */
	public void clearAllFields() throws Exception {
		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			wh.clearElement(firstNameTxtBox);
			wh.clearElement(lastNameTxtBox);
			wh.clearElement(addr1TxtBox);
			wh.clearElement(phNoTxtBox);
			report.addReportStep("clear fields", "All fields are cleared", StepResult.PASS);
		} else {
			report.addReportStep("clear fields", "All fields are not cleared", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify the error messages when user does not enter any input
	 * and verify error
	 * 
	 * @throws Exception
	 */
	public void verifyAllFieldsError() throws Exception {
		if (wh.isElementPresent(firstnameerr, 2)) {
			report.addReportStep("verify First name error", "First name error field is displayed", StepResult.PASS);
			String strFN = wh.getText(firstnameerr);
			String strLN = wh.getText(lastnameerr);
			String strPH = wh.getText(pherr);
			String strADDR = wh.getText(addr1err);

			if (strFN.contains("First name is required. Please enter your first name")
					&& strLN.contains("Last name is required. Please enter your last name")
					&& strPH.contains("Phone is required. Please enter your phone number")
					&& strADDR.contains("Address Line 1 required. Please enter your address")) {
				report.addReportStep("verify error message", "Error message is displayed for all the input fields",
						StepResult.PASS);
			} else {
				report.addReportStep("verify error message", "Error message is not displayed for all the input fields",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify First name error", "First name error field is not displayed", StepResult.FAIL);
		}
	}

	public void enterValidSymbolsFirstName(String symbol) throws Exception {

		String fName = "John" + symbol;
		if (wh.isElementPresent(firstNameTxtBox, 3)) {
			wh.clearElement(firstNameTxtBox);
			wh.sendKeys(firstNameTxtBox, fName);
			report.addReportStep("Verify " + fName + " is entered", fName + " is entered", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify " + fName + " is entered", "First name text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterValidSymbolsLastName(String symbol) throws Exception {

		String lName = "John" + symbol;
		if (wh.isElementPresent(lastNameTxtBox, 3)) {
			wh.clearElement(lastNameTxtBox);
			wh.sendKeys(lastNameTxtBox, lName);
			wh.clickElement(phNoTxtBox);
			report.addReportStep("Verify " + lName + " is entered", lName + " is entered", StepResult.PASS);

		} else

		{
			System.out.println("test");
			report.addReportStep("Verify " + lName + " is entered", "Last name text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void enterInvalidALTPhNumbers() throws Exception {
		if (wh.isElementPresent(altPhNo, 3)) {
			int i = 0;
			for (i = 0; i < commonData.invalidPhNo.length; i++) {
				wh.clearElement(altPhNo);
				wh.sendKeys(altPhNo, commonData.invalidPhNo[i]);

				report.addReportStep("Verify " + commonData.invalidPhNo[i] + " is entered", commonData.invalidPhNo[i]
						+ " is entered", StepResult.PASS);
				wh.clickElement(splInstrction);
				if (wh.isElementPresent(altPhErr, 5)) {
					String err = wh.getText(altPhErr);
					if (err.contains("Please enter a valid phone number"))
						report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
								+ " entered", "Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
								+ " entered", "Error message <b>" + err + "</b> is not displayed properly",
								StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
							+ " entered", "Error message is not displayed", StepResult.FAIL);
				}
			}
		} else {
			report.addReportStep("Verify Zipcode is entered with invalid numbers", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}
		// clear field
		wh.clearElement(altPhNo);
	}

	public void verifySplInstructionField() throws Exception {
		if (wh.isElementPresent(splInstrction, 3)) {
			report.addReportStep("verify spl instruction field", "Spl instruction field is displayed", StepResult.PASS);
			String strSpl = wh.getAttribute(splInstrction, "maxlength");
			if (strSpl.contains("99")) {
				report.addReportStep("verify spl instruction field", "Max of " + strSpl
						+ "Chars can be entered in Spl instruction field", StepResult.PASS);
			} else {
				report.addReportStep("verify spl instruction field", "Max of " + strSpl
						+ "Chars cannot be entered in Spl instruction field", StepResult.FAIL);
			}

		} else {
			report.addReportStep("verify spl instruction field", "Spl instruction field is not displayed",
					StepResult.FAIL);
		}
	}
	
	public void clickChangeDeliveryZipCode() throws Exception {

		if (wh.isElementPresent(changeLink, 7)) {
			wh.clickElement(changeLink);
			report.addReportStep("Click change zipcode link", "Change zipcode link clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click change zipcode link", "Change zipcode link not displayed", StepResult.FAIL);
		}

	}
	
	public void editApplianceAddressInEditOverlay() throws Exception {
		if (wh.isElementPresent(EditAddressOverlay, 5)) {
			report.addReportStep("Verify Edit Address Overlay is displayed", "Edit Addres Overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Edit Address Overlay is displayed", "Edit Addres Overlay is not displayed",
					StepResult.FAIL);
		}

		if (wh.isElementPresent(NewAddressEdit, 2)) {
			wh.clearElement(NewAddressEdit);
			wh.sendKeys(NewAddressEdit, dataTable.getCommonData(CommonDataColumn.ShippingAddr1));
			wh.selectValue(editOverlayCitySelect,2);
			wh.clickElement(EditAddressOverlayUpdateBtn);
			Thread.sleep(commonData.smallWait);
			
		}

	}
	
	/*
	 * Component to verify Edited address in Appliance Delivery page
	 */
	public void verifyApplianceEditedAddress() throws Exception {
		String strAddress1 = dataTable.getCommonData(CommonDataColumn.ShippingAddr1);
		Thread.sleep(commonData.littleWait);
		if (wh.isElementPresent(EnterDeliveryAddress, 5)) {
			String strStaticAddr = "";
			try {
				strStaticAddr = driver.findElement(EnterDeliveryAddress).getText();
			} catch (Exception e) {
				System.out.println("Static text is not displayed");
			}
			if (strStaticAddr.contains(strAddress1)) {
				report.addReportStep("verify that Edited address is reflected in appliance delivery page",
						"Edited address is reflected in appliance delivery page", StepResult.PASS);
			} else {
				report.addReportStep("verify that Edited address is reflected in appliance delivery page",
						"Edited address is not reflected in appliance delivery page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify that Edited address is reflected in appliance delivery page",
					"Unable to validate the Edited address", StepResult.FAIL);
		}
	}
	
	public void editApplianceCityInEditOverlay() throws Exception {
		if (wh.isElementPresent(EditAddressOverlay, 5)) {
			report.addReportStep("Verify Edit Address Overlay is displayed", "Edit Addres Overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Edit Address Overlay is displayed", "Edit Addres Overlay is not displayed",
					StepResult.FAIL);
		}

		if (wh.isElementPresent(editOverlayCitySelect, 2)) {
			WebElement element = driver.findElement(editOverlayCitySelect);
			List<WebElement> lists = element.findElements(By.tagName("option"));
			String selectedCity  = lists.get(1).getText();
			commonData.selectedCity = selectedCity;
			Thread.sleep(commonData.smallWait);

		}

	}
	
	/*
	 * Component to verify Edited city in Appliance Delivery page
	 */
	public void verifyApplianceEditedCity() throws Exception {
		String selectedCity = commonData.selectedCity;
		if (wh.isElementPresent(EnterDeliveryAddress, 5)) {
			String strStaticAddr = "";
			try {
				strStaticAddr = driver.findElement(EnterDeliveryAddress).getText();
			} catch (Exception e) {
				System.out.println("Static text is not displayed");
			}
			if (strStaticAddr.contains(selectedCity)) {
				report.addReportStep("verify that Edited City is reflected in appliance delivery page",
						"Edited City is reflected in appliance delivery page", StepResult.PASS);
			} else {
				report.addReportStep("verify that Edited City is reflected in appliance delivery page",
						"Edited City is not reflected in appliance delivery page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify that Edited City is reflected in appliance delivery page",
					"Unable to validate the Edited City", StepResult.FAIL);
		}
	}

	public void verifyNoChangeLinkMultipleItems() throws Exception {

		if (wh.isElementNotPresent(changeLink)) {
			report.addReportStep("Verify change zipcode link", "Change zipcode link is not displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify change zipcode link", "Change zipcode link displayed", StepResult.FAIL);
		}

	}
	
	public void verifyErrMsgStylingAddress() throws Exception {
		wh.clickElement(addr1TxtBox);
		wh.clearElement(addr1TxtBox);
		if (wh.isElementPresent(continueBtn)) {
			wh.jsClick(continueBtn);
			report.addReportStep("Click continue button", "Continue button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(addr1err, 5)) {
			String strCardErr = wh.getCssValue(addr1err, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for address", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for address", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for address", "Err msg is not displayed", StepResult.FAIL);
		}

	}
	
	public void verifyErrMsgStylingInvalidPhone() throws Exception {
		wh.clickElement(phNoTxtBox);
		wh.clearElement(phNoTxtBox);
		wh.sendKeys(phNoTxtBox, dataTable.getCommonData(CommonDataColumn.InvalidPhoneNumber));
		if (wh.isElementPresent(continueBtn)) {
			wh.jsClick(continueBtn);
			report.addReportStep("Click continue button", "Continue button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(pherr, 5)) {
			String strCardErr = wh.getCssValue(pherr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for phone", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for phone", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for phone", "Err msg is not displayed", StepResult.FAIL);
		}

	}
	
	public void verifyErrMsgStylingFirstName() throws Exception {
		wh.clickElement(firstNameTxtBox);
		wh.clearElement(firstNameTxtBox);
		if (wh.isElementPresent(continueBtn)) {
			wh.jsClick(continueBtn);
			report.addReportStep("Click continue button", "Continue button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(firstnameerr, 5)) {
			String strCardErr = wh.getCssValue(firstnameerr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for phone", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for phone", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for phone", "Err msg is not displayed", StepResult.FAIL);
		}

	}
	
	public void verifySelectedApplDeliveryDate() throws Exception {
		if (wh.isElementPresent(applDelDateRR, 5)) {
			String deliveryDate = wh.getText(applDelDateRR);
			if ((!commonData.applDelDate.isEmpty()) && (deliveryDate.contains(commonData.applDelDate))) {
				report.addReportStep("Verify appliance delivery date is displayed",
						"Appliance delivery date <b> " + deliveryDate + " </b>is displayed correctly in right rail",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery date is displayed",
						"Appliance delivery date <b> " + deliveryDate + " </b>is not displayed correctly in right rail",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify appliance delivery date is displayed",
					"Appliance delivery date is not displayed", StepResult.FAIL);
		}

	}
	
	public void selectDeliveryRadioAndClickClose() throws Exception {
		String deliveryDate = null;
		if (wh.isElementPresent(applEarliestDelDate, 5)) {
			deliveryDate = wh.getText(applEarliestDelDate);
		}
		if (wh.isElementPresent(Deliverysection, 5)) {
			report.addReportStep("Delivery Options section is displayed in the Appliance delivery page",
					"Delivery options section is displayed", StepResult.PASS);
			wh.jsClick(SelectDeliverydate);
			wh.jsClick(CalendarOverlayclose);
			report.addReportStep("Verify Calendar overlay is closed in the Appliance delivery page",
					"Calendar overlay is closed", StepResult.PASS);
			if (wh.isElementPresent(applEarliestDelDate, 5)) {
				String delDate = wh.getText(applEarliestDelDate);
				if (delDate.contains(deliveryDate)) {
					report.addReportStep("Verify appliance delivery date is displayed",
							"Appliance delivery date <b> " + deliveryDate + " </b>is displayed correctly",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify appliance delivery date is displayed",
							"Appliance delivery date <b> " + deliveryDate + " </b>is not displayed correctly",
							StepResult.FAIL);
				}

			} else {
				report.addReportStep("Delivery Options section is displayed in the Appliance delivery page",
						"Delivery options section is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Delivery Options section is displayed in the Appliance delivery page",
					"Delivery options section is not displayed", StepResult.FAIL);
		}

	}

}
