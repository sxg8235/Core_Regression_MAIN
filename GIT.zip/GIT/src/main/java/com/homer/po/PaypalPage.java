package com.homer.po;

import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class PaypalPage extends PageBase<PaypalPage> {

	static final By txtPaypalLogin = By.id("login_email");
	static final By txtPaypalLoginTab = By.xpath("//*[@id='email']");
	static final By paypalHeader = By.xpath("//div[@id='miniCart' or @id='subhead']/h3");
	static final By paypalTitleTxt = By.xpath("//div[@id='secureCheckout' or @class='logo user']/span");
	static final By txtPaypalPassword = By.id("login_password");
	static final By txtPaypalPasswordTab = By.xpath("//*[@id='password']");
	static final By btnPaypalLogin = By.xpath("//*[@id='submitLogin' or @id='login']");
	static final By txtPaypalPhone = By.id("contact_tel");
	static final By btnPayNow = By.xpath("//*[@id='continue_abovefold' or @id='continue']");
	By appliancedeliveryTxt = By.xpath("//a[@class='autoTooltip'][contains(text(),'Appliance Delivery')]");
	By applianceDeliveryCharge = By
			.xpath("//a[@class='autoTooltip'][contains(text(),'Appliance Delivery')]/ancestor::span/following-sibling::span[@class='amount']");
	static final By lnkCancelReturn = By.name("cancel_return");
	static final By applianceDeliveryCharge1 = By
			.xpath("//a[@class='autoTooltip'][contains(text(),'Appliance Delivery')]/ancestor::span/parent::li/following-sibling::li/span");
	static final By orderSummary = By.xpath("//h3[contains(text(),'Your order summary')]");
	static final By changeAddrBtn = By.id("changeAddressButton");
	static final By AddShippingAddrLnk = By.id("addShipAddress");
	static final By shipAddrName = By.id("shipping_addressee_name");
	static final By shipAddrAddr1 = By.id("shipping_address1");
	static final By shipAddrAddr2 = By.id("shipping_address2");
	static final By shipCity = By.id("shipping_city");
	static final By shipZip = By.id("shipping_zip");
	static final By saveAddress = By.id("continueBabySlider");
	static final By updateBtn = By.cssSelector("a[class='btn btn-gray edit-address-button md-submit']");

	static final By changeAddr = By.xpath("//div[@id='shipping']//a[@class='drop']");
	static final By changeShipAddr = By.xpath("//*[contains(text(),'Change shipping address to:')]");
	static final By addAddress = By.xpath("//*[@id='add_address']");
	static final By payPalFrame = By.xpath("//*[@id='frame']");
	static final By quickmodel = By.cssSelector("#fancybox-content .miniQvCntr");
	static final By custattr = By.xpath(".//*[@class='custom-attr-cntr']");
	
	//Tablet PayPal
	static final By Tabletphone = By.xpath("//input[@id='phone']");
		
	public PaypalPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Function to verify Paypal page
	 * @return 
	 * 
	 * @throws Exception
	 * 
	 * @FunctionName verifyPayPal
	 * @InputParameters None
	 * @Author SXI8382
	 * @DateCreated Feb 2, 2015
	 */
	public PaypalPage verifyPayPalPgDisplayed() throws Exception {

		Thread.sleep(1000);
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

			return this;
		}
		String strTitle = driver.getTitle();
		if (wh.isElementPresent(txtPaypalLogin, 15)) {

			if (strTitle.matches("Certificate Error: Navigation Blocked")) {
				driver.navigate().to("javascript:document.getElementById('overridelink').click()");
				report.addReportStep("Click on <b>Continue Paypal</b>", "<b>Continue Paypal </b>button is Clicked",
						StepResult.DONE);
			}

			verifyPayPalPgHeadr();

			if (rc.isProdEnvironment()) {
				report.addReportStep("Paypal is not validated in Production", "Paypal steps skipped",
						StepResult.WARNING);
				rc.terminateTestCase("Paypal Checkout in Production");
			}
		}
		else if (strTitle.contains("Mobile")) {
			report.addReportStep("Paypal Page validation", "Tablet paypal page is displayed",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Click on <b>Continue Paypal</b> and move to paypal page",
					"Paypal Page is not displayed", StepResult.FAIL);
		}
		return null;
	}

	/**
	 * 
	 * Description : verify paypal page header
	 * 
	 * @since May 24, 2013
	 * @author sxd8901
	 * @throws Exception
	 */

	public void verifyPayPalPgHeadr() throws Exception {

		String str = "";
		String strimg = "";
		if (wh.isElementPresent(paypalHeader, 7)) {

			str = wh.getText(paypalHeader);

			try {
				strimg = wh.getAttribute(paypalTitleTxt, "title");
			} catch (Exception e) {
				report.addReportStep("Verify whether <b>PayPal Login</b> Page should be displayed",
						"<b>PayPal Login</b> Title is not displayed", StepResult.FAIL);
			}

			if (str.trim().equals("Your order summary") || str.trim().equals("Login") && strimg.trim().equals("PayPal"))
				report.addReportStep("Verify whether <b>PayPal Login</b> Page should be displayed",
						"<b>PayPal login</b> page is displayed", StepResult.PASS);
			else {
				report.addReportStep("Verify whether <b>PayPal Login</b> Page should be displayed",
						"<b>PayPal Login</b> page is not displayed", StepResult.FAIL);
				rc.terminateTestCase("Paypal Login");
			}

		} else {
			report.addReportStep("Verify whether <b>PayPal Login</b> Page should be displayed",
					"<b>PayPal Login</b> page is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Paypal Login");
		}

	}

	/**
	 * 
	 * Description : Paypal login
	 * 
	 * @since May 24, 2013
	 * @author sxd8901
	 * @throws Exception
	 */

	public void payPalLogin() throws Exception {
		String strTitle = driver.getTitle();
		String strUserName = dataTable.getCommonData(CommonDataColumn.paypalUserId);

		String strPassword = dataTable.getCommonData(CommonDataColumn.paypalUserPassword);
		String internationalUserId = dataTable.getData("International_PaypalUserId");
		String internationalPwd = dataTable.getData("International_PaypalPwd");

		if (!internationalUserId.isEmpty() && !internationalPwd.isEmpty()) {
			strUserName = internationalUserId;
			strPassword = internationalPwd;
		}
			
		if(wh.isElementPresent(txtPaypalLogin,2)) {
		
		// 1. Enter the UserName and Password for Paypal page
		wh.sendKeys(txtPaypalLogin, strUserName);
			if (commonData.desktopUserAgent) {
				wh.sendKeys(txtPaypalPassword, strPassword);
			} else {
				wh.sendKeys(txtPaypalPasswordTab, strPassword);
			}
		wh.clickElement(btnPaypalLogin);
		Thread.sleep(5000);
		report.addReportStep("Enter Paypal signin credentials ", "User signed in as <b>" + strUserName
				+ "</b> in Paypal section", StepResult.PASS);
		}
		
		else if (strTitle.contains("Mobile")) {
			//Enter Username
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(txtPaypalLoginTab));
			actions.click();
			actions.sendKeys(strUserName);
			actions.build().perform();
			//Enter password
			Actions actions1 = new Actions(driver);
			actions1.moveToElement(driver.findElement(By
					.xpath("//*[@id='password']")));
			actions1.click();
			actions1.sendKeys(strPassword);
			actions1.build().perform();
			//wh.sendKeys(txtPaypalLoginTab, strUserName);
			//wh.sendKeys(txtPaypalPasswordTab, strPassword);
			wh.clickElement(btnPaypalLogin);
			Thread.sleep(5000);
			report.addReportStep("Enter Paypal signin credentials ", "User signed in as <b>" + strUserName
					+ "</b> in Paypal section", StepResult.PASS);
		} else {
			report.addReportStep("Enter Paypal signin credentials ", "PayPal login page is not displayed", StepResult.FAIL);
		}
	

	}

	/**
	 * To enter phone no in review ur information page of paypal site
	 * 
	 * 
	 * @since Jul 31, 2013
	 * @author axr8235
	 * @throws Exception
	 */
	public void enterPaypalContactPhoneno() throws Exception {

		if (!commonData.desktopUserAgent) {

			if (wh.isElementPresent(By.xpath("(//a[@class='drop'])[3]"), 2)) {
				wh.jsClick(By.xpath("//*[@id='options']/div[1]/a/span"));
			} else {
				report.addReportStep("Enter Paypal Contact Phone no", "Paypal Contact Phone no is not entered",
						StepResult.FAIL);
			}
			
			//Enter Username
			
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(By.xpath("//input[@id='phone']")));
			actions.sendKeys(Keys.BACK_SPACE);
			//wh.clearElement(Tabletphone);
			actions.click();
			actions.sendKeys("7183383198");
			actions.build().perform();
			//wh.sendKeys(By.id("phone"), "7183383198");
		}

		else {
			if (wh.isElementPresent(txtPaypalPhone, 2)) {
				wh.sendKeys(txtPaypalPhone, "7183383198");
			}
		}
	}

	/**
	 * 
	 * Description : click PayNow button in paypal page
	 * 
	 * @since May 24, 2013
	 * @author sxd8901, modified PXM8043 2-Aug-2013
	 * @throws Exception
	 */
	public void clickPayNowPaypal() throws Exception {
		String strTitle = driver.getTitle();

		if (strTitle.contains("Mobile")
				|| strTitle.contains("PayPal")) {
			Thread.sleep(commonData.littleWait);
			if (wh.isElementPresent(btnPayNow, 2)) {
				wh.clickElement(btnPayNow);
				Thread.sleep(commonData.smallWait);
				
			}else {
				report.addReportStep("Click on <b>Pay Now</b> button in the paypal page", "Could not find the button",
						StepResult.FAIL);
			}
		}

		else if (wh.isElementPresent(btnPayNow, 30)) {

			enterPaypalContactPhoneno();

			wh.clickElement(btnPayNow);

			report.addReportStep("Click on <b>Pay Now</b> button in the paypal page",
					"Clicked on the button and proceeding to <b>Home Depot Order Confirmation Page</b>",
					StepResult.PASS);
		} else {
			report.addReportStep("Click on <b>Pay Now</b> button in the paypal page", "Could not find the button",
					StepResult.FAIL);
			rc.terminateTestCase("paypal page");
		}
	}

	/**
	 * Verify delivery charge in paypal screen
	 */
	public void verifyDeliveryChargeInPaypalRightRail() throws Exception {
		String strTitle = driver.getTitle();
		if (strTitle.contains("Mobile")) { 
			wh.jsClick(By.xpath("//*[@class='drop']"));
			appliancedeliveryTxt = By.xpath("//th[contains(text(),'Appliance Delivery')]");
			applianceDeliveryCharge = By.xpath("//*[contains(text(),'Appliance Delivery')]/..//td");
		
		}
		
		else if (commonData.desktopUserAgent) {
			//wh.jsClick(By.xpath("//*[@id='cart']/h2/a/span"));
			appliancedeliveryTxt = By.xpath("//li[@class='dark']//a[contains(text(),'Appliance Delivery')]");
			applianceDeliveryCharge = By.xpath("//li[@class='dark']//a[contains(text(),'Appliance Delivery')]/./../../..//span[2]");
		}

		// Verify Apply Delivery Text
		if (wh.isElementPresent(appliancedeliveryTxt, 5)) {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is displayed in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is not displayed in right rail", StepResult.FAIL);
		}

		// Verify Appliance Delivery Charge

		String applianceDeliveryChargeAmt;

		if (wh.isElementPresent(applianceDeliveryCharge)) {
			applianceDeliveryChargeAmt = wh.getText(applianceDeliveryCharge);
		} else if (wh.isElementPresent(applianceDeliveryCharge1)) {
			applianceDeliveryChargeAmt = wh.getText(applianceDeliveryCharge1);
		} else {
			applianceDeliveryChargeAmt = "$0.00";
		}

		double aSubtotalAmt = commonData.applianceSubTotal;

		if (aSubtotalAmt > 396.00) {

			if (applianceDeliveryChargeAmt.equals("FREE") || applianceDeliveryChargeAmt.contains("$0.00")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is not displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

		else {
			if (!applianceDeliveryChargeAmt.equals("FREE") && applianceDeliveryChargeAmt.contains("$59.00") ||  applianceDeliveryChargeAmt.contains("59.00")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

	}

	/**
	 * Click cancel and return link
	 * 
	 * @throws
	 * @author YXG8356
	 * @since Aug 27,2015
	 */

	public PaymentPage clickCancelAndReturn() throws Exception {

		if (wh.isElementPresent(lnkCancelReturn, 10)) {
			wh.clickElement(lnkCancelReturn);
		} else {
			report.addReportStep("Verify <b>'Click cancel and return'</b> link is displayed",
					" <b>Click cancel and return</b> button is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Paypal checkout page");
		}

		return new PaymentPage(ic);

	}

	/**
	 * verify unit price order summary
	 * 
	 * @throws Exception
	 */
	public void verifyUnitPriceOrderSummary() throws Exception {

		if (wh.isElementPresent(orderSummary, 7)) {

			for (String sku : commonData.skuList) {

				By unitPrice = By.xpath("//*[contains(text(),'" + sku + "')]/../li/span[2]");

				for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {

					String itemPrice = wh.getText(unitPrice);
					String finalPrice;
					if (itemPrice.contains(",")) {
						finalPrice = itemPrice.replaceAll(",", "");
					} else {
						finalPrice = itemPrice;
					}

					if (entry.getKey().contains(sku)) {
						if (finalPrice.contains(entry.getValue())) {
							report.addReportStep(
									"Verify whether unit price in order summary is equivalent to Cassandra DB",
									"Unit price inorder summary " + finalPrice
											+ " is equivalent to Cassandra DB price " + entry.getValue(),
									StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether unit price in order summary is equivalent to Cassandra DB",
									"Unit price in order summary " + finalPrice
											+ " is not equivalent to Cassandra DB price " + entry.getValue(),
									StepResult.FAIL);

						}
					} else {
						report.addReportStep(
								"Verify whether unit price in order summary is equivalent to Cassandra DB",
								"Product description mismatch", StepResult.FAIL);
					}
					System.out.println(entry.getKey() + " - " + entry.getValue());

				}
			}

		} else {
			report.addReportStep("Verify whether unit price in order summary is equivalent to Cassandra DB",
					"Unit price in order summary is not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * To click on Change address link in pay pal page
	 * 
	 * @throws Exception
	 */

	public void clickChangeAddrPpal() throws Exception {
		String strTitle = driver.getTitle();
		if (wh.isElementPresent(changeAddrBtn, 2)) {

			int intCounter = 0;
			boolean bklnLinkClicked = false;

			while ((!bklnLinkClicked) && intCounter <= 2) {
				wh.clickElement(changeAddrBtn);

				++intCounter;
				if (wh.isElementPresent(AddShippingAddrLnk, 2)) {
					bklnLinkClicked = true;
				}
			}

			if (bklnLinkClicked) {
				report.addReportStep("Click the change Address link", "The Link is clicked", StepResult.PASS);
			}

			else {
				report.addReportStep("Click the change Address link", "The Link is not clicked", StepResult.FAIL);
			}

			Thread.sleep(2000);

		} else if (strTitle.contains("Mobile") 
				|| strTitle.contains("PayPal") ) { 
			wh.jsClick(changeAddr);
			Thread.sleep(1000);
			if(wh.isElementPresent(changeShipAddr)) {
				report.addReportStep("Click the change Address link", "change address Link is clicked", StepResult.PASS);
			} else {
				report.addReportStep("Click the change Address link", "change address Link is not clicked", StepResult.FAIL);
			}
		}
		
		else {
			report.addReportStep("verify and click on the change link in paypal page",
					"Unable to find the change link", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * To click on add address link in pay pal page
	 * 
	 * @throws Exception
	 */

	public void clickAddNewAddrPayPal() throws Exception {
		String strTitle = driver.getTitle();
		if (wh.isElementPresent(AddShippingAddrLnk, 2)) {

			int intCounter = 0;
			boolean blnIsLinkDisplayed = false;

			while ((!blnIsLinkDisplayed) && intCounter <= 2) {
				wh.clickElement(AddShippingAddrLnk);

				++intCounter;
				if (wh.isElementPresent(shipAddrName, 2)) {
					blnIsLinkDisplayed = true;
				}

			}

			if (blnIsLinkDisplayed) {
				report.addReportStep("click the add new address link", "The Link is clicked", StepResult.PASS);
			} else {
				report.addReportStep("click the add new address link", "The Link is not clicked", StepResult.FAIL);
			}
		} else if (strTitle.contains("Mobile")
				|| strTitle.contains("PayPal")) {
			wh.jsClick(addAddress);
			Thread.sleep(5000);
		}

		else {
			report.addReportStep("click the add new address link", "The Link is not clicked", StepResult.FAIL);
		}
	}

	/**
	 * To add new address to the paypal user in pay pal page
	 * 
	 * @throws Exception
	 */

	public void addNewAddrPPal() throws Exception {
		if (wh.isElementPresent(shipAddrName, 2)) {
			//Enter shipping address name
			Actions actions = new Actions(driver);
			actions.moveToElement(driver.findElement(shipAddrName));
			actions.click();
			actions.sendKeys("John Pal");
			actions.build().perform();
			//wh.sendKeys(shipAddrName, "John Pal");
			
			//Enter shipping address1
			Actions actions1 = new Actions(driver);
			actions1.moveToElement(driver.findElement(shipAddrAddr1));
			actions1.click();
			actions1.sendKeys("London");
			actions1.build().perform();
			//wh.sendKeys(shipAddrAddr1, "London");
			
			//Enter shipping address2
			Actions actions2 = new Actions(driver);
			actions2.moveToElement(driver.findElement(shipAddrAddr2));
			actions2.click();
			actions2.sendKeys("London");
			actions2.build().perform();
			//wh.sendKeys(shipAddrAddr2, "London");
			
			//Enter shipping city
			Actions actions3 = new Actions(driver);
			actions3.moveToElement(driver.findElement(shipCity));
			actions3.click();
			actions3.sendKeys("Kahului");
			actions3.build().perform();
			//wh.sendKeys(shipCity, "Kahului");

			try {
				Select selectDropState = new Select(driver.findElement(By.id("shipping_state")));

				selectDropState.selectByVisibleText("HI");

				report.addReportStep("select the state from the drop down", "HI is selected", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("select the state from the drop down", "Unable to select the state details",
						StepResult.FAIL);
			}
			//Enter shipping zipcode
			Actions actions4 = new Actions(driver);
			actions4.moveToElement(driver.findElement(shipZip));
			actions4.click();
			actions4.sendKeys("96732");
			actions4.build().perform();
			//wh.sendKeys(shipZip, "96732");

		} else

		{
			report.addReportStep("verify that addres fields are displayed in paypal page",
					"Unable to find the Address field details", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * To click on save address button in pay pal page
	 * 
	 * @throws Exception
	 */

	public void clickSavePPal() throws Exception {
		if (wh.isElementPresent(saveAddress, 2)) {
			wh.clickElement(saveAddress);
			Thread.sleep(1000);
		} else if (wh.isElementPresent(addAddress, 2)) {
			wh.clickElement(addAddress);
			Thread.sleep(1000);
		}
		else {
			report.addReportStep("click the save button", "Click failure", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * To click on edit this address link
	 * 
	 * @throws Exception
	 */

	public void clickEditThisAddress() throws Exception {
		JavascriptExecutor js = null;
		if (driver instanceof JavascriptExecutor) {
			js = (JavascriptExecutor) driver;
		}
		js.executeScript("arguments[0].click();", driver.findElement(By.linkText("edit this address")));
		report.addReportStep("Click on 'Edit Address' link", "Edit link clicked", StepResult.DONE);
	}

	/**
	 * To click on update button after editing the address
	 * 
	 * @throws Exception
	 */
	public void clickUpdateBtn() throws Exception {
		if (wh.isElementPresent(updateBtn, 2)) {

			try {
				wh.clickElement(updateBtn);
				report.addReportStep("click the save/update address button", "Save/update button clicked",
						StepResult.PASS);

			} catch (Exception e) {
				report.addReportStep("click the save/Update address button", "Unable to find the button",
						StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}

		} else {
			report.addReportStep("click the save/Update address button", "Unable to find the button", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}
	
	/**
	 * Component to verify custom product details in Papal express page
	 * 
	 * @throws InterruptedException
	 */
	public void verifyCustomBlindProductsNotPresentInPPalExp()
			throws InterruptedException {
		try {
			
			if(wh.isElementPresent(By
					.xpath("//div[@class='custom-attr-div']/div"), 5))
			{
				report.addReportStep(
						"Verify Custom Attributes should not be displayed in the Paypal Express page",
						"Custom Attributes are displayed in the Paypal Express page",
						StepResult.FAIL);
			}
			else {
				report.addReportStep(
						"Verify Custom Attributes should not be displayed in the Paypal Express page",
						"Custom Attributes are not displayed in the Paypal Express page",
						StepResult.PASS);
			}
		} catch (Exception e) {
			report.addReportStep(
					"Verify Custom Attributes should not be displayed in the Paypal Express page",
					"Custom Attributes are displayed in the Paypal Express page",
					StepResult.FAIL);
		}

		try {
			if(wh.isElementPresent(By.xpath("//div[@class='blinds-sku-img']"), 5))
			{
				report.addReportStep(
						"Verify Custom Image should not be displayed in the Paypal Express page",
						"Custom Image is displayed in the Paypal Express page",
						StepResult.FAIL);
			}
			else {
				report.addReportStep(
						"Verify Custom Image should not be displayed in the Paypal Express page",
						"Custom Image is not displayed in the Paypal Express page",
						StepResult.PASS);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			report.addReportStep(
					"Verify Custom Attributes should not be displayed in the Paypal Express page",
					"Custom Image is displayed in the Paypal Express page",
					StepResult.FAIL);
		}
	}
	/**
	 * Component to verify that the details of STH item added to cart is
	 * displayed in STH POD
	 * 
	 * 
	 * @since Sep 18, 2014
	 * @author PXM8043
	 * @throws Exception 
	 */
	public void verifySTHPODItemDetails() throws Exception {
		verifyDisplayedItemInPOD(
				"Ship to Home",
				By.xpath("//*[contains(@class,'fulFillmentPods')]//*[contains(text(),'Ship to Home')]/ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='rightRailitemTitle']"));
	}
	
	
	/**
	 * Component to verify that the details of STS item added to cart is
	 * displayed in STS POD
	 * 
	 * 
	 * @since Sep 18, 2014
	 * @author PXM8043
	 * @throws Exception 
	 */
	public void verifySTSPODItemDetails() throws Exception {
		verifyDisplayedItemInPOD(
				"Ship to Store",
				By.xpath("//*[contains(@class,'fulFillmentPods')]//*[contains(text(),'Ship To	Store')]/ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='rightRailitemTitle']"));
	}

	/**
	 * Component to verify that the details of item added to cart is displayed
	 * in rightrail POD
	 * 
	 * 
	 * @since Sep 18, 2014
	 * @author PXM8043
	 * @throws Exception 
	 */
	public void verifyDisplayedItemInPOD(String strPODname, By strLocator)
			throws Exception {
		if(wh.isElementPresent(strLocator)) {
			report.addReportStep("Verify that " + strPODname
					+ " POD is displayed with the Item title",
					"POD is displayed with the item title", StepResult.PASS);

			WebElement webPOD = driver.findElement(strLocator);

			if (wh.isElementPresent(
					webPOD,
					By.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalIteamChargesAmt']"),
					1)) {
				String strTempCharge = webPOD
						.findElement(
								By.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalIteamChargesAmt']"))
						.getText();

				report.addReportStep(
						"Verify that Price is displayed for the product", ""
								+ strTempCharge + " is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify that Price is displayed for the product",
						"Unable to find the price", StepResult.FAIL);
			}

			if (wh.isElementPresent(
					webPOD,
					By.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalItemsQtyNum']"),
					1)) {
				String strTempQty = webPOD
						.findElement(
								By.xpath("./ancestor::*[contains(@class,'fulFillmentPods')]//*[@class='totalItemsQtyNum']"))
						.getText();
				report.addReportStep(
						"Verify that Quantity is displayed for the product", ""
								+ strTempQty + " is displayed", StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify that Quantity is displayed for the product",
						"Unable to find the Quantity", StepResult.FAIL);
			}

			try {
				driver.findElement(strLocator).click();
				report.addReportStep(
						"Click the item description displayed in the "
								+ strPODname + " POD", "Description clicked",
						StepResult.PASS);

				if (wh.isElementPresent(quickmodel, 4)) {
					report.addReportStep(
							"Verify that Item quick view- modal  is displayed",
							"The modal is displayed", StepResult.PASS);

					WebElement webQvModal = driver.findElement(By
							.cssSelector("#fancybox-content .miniQvCntr"));

					if (wh.isElementPresent(webQvModal,
							By.xpath(".//*[@class='rightRailprodTitle']"), 2)) {
						String strProdTitle = webQvModal.findElement(
								By.xpath(".//*[@class='rightRailprodTitle']"))
								.getText();
						report.addReportStep(
								"Verify that product title is displayed in the QV modal",
								"Product title is displayed as " + strProdTitle
										+ "", StepResult.PASS);
					} else {
						report.addReportStep(
								"Verify that product title is displayed in the QV modal",
								"Product title is not displayed", StepResult.FAIL);
					}

					if (wh.isElementPresent(webQvModal,
							By.xpath(".//*[@class='custom-attr-cntr']"), 2)) {
						String strProdAttribute = webQvModal.findElement(
								By.xpath(".//*[@class='custom-attr-cntr']"))
								.getText();
						report.addReportStep(
								"Verify that product Attributes are displayed in the QV modal",
								"Product Attributes are displayed as "
										+ strProdAttribute + "", StepResult.PASS);
					} else {
						report.addReportStep(
								"Verify that product Attributes are displayed in the QV modal",
								"Product Attributes are not displayed",
								StepResult.FAIL);
					}

				} else {
					report.addReportStep(
							"Verify that Item quick view- modal  is displayed",
							"The modal is not displayed", StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep(
						"Click the item description displayed in the "
								+ strPODname + "POD",
						"Description not clicked", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that " + strPODname
					+ " POD is displayed", "Unable to find the item title",
					StepResult.FAIL);
		}

	}
	
	
	//////*************Instant Rebate ***************////////////
    
    public void addNewAddrPPalIR() throws Exception {
           //String strJumpStore = 
 	   String PayPalZip = dataTable.getData("PayPalZip");
           String PayPalCity = dataTable.getData("PayPalCity");
           String PayPalState = dataTable.getData("PayPalState");
           if (wh.isElementPresent(shipAddrName, 2)) {
               wh.sendKeys(shipAddrName, "john Thomas");
                  wh.sendKeys(shipAddrAddr1, "London");
                  wh.sendKeys(shipAddrAddr2, "London");
                  wh.sendKeys(shipCity, PayPalCity);

                  try {
                        Select selectDropState = new Select(driver.findElement(By.id("shipping_state")));

                        selectDropState.selectByVisibleText(PayPalState);

                        report.addReportStep("select the state from the drop down", "State selected", StepResult.PASS);
                  } catch (Exception e) {
                        report.addReportStep("select the state from the drop down", "Unable to select the state details",
                                      StepResult.FAIL);
                  }
               wh.sendKeys(shipZip, PayPalZip);

           } else

           {
                  report.addReportStep("verify that addres fields are displayed in paypal page",
                               "Unable to find the Address field details", StepResult.FAIL);
                  commonData.blnGracefulExit = true;
           }

    }
//////*************End of Instant Rebate ***************////////////


	
	
}
