package com.homer.po;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.*;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;

public class GiftCardPage extends PageBase<GiftCardPage> {

	static final By headerTitle = By.xpath("//h1[@class='page-title']");
	static final By shopGCSection = By.xpath("(//*[@class='row transparentBorder'])[1]");
	static final By checkBalGc = By.xpath("//*[contains(text(),'Check Gift Card Balance')]");
	// Enter gift card
	static final By GCnumber = By.xpath("//*[@name='giftCardNumber']");
	static final By GCpin = By.xpath("//*[@name='pinNumber']");
	static final By captchaverif = By.xpath("//*[@name='captchaVerification']");
	static final By checkBalGo = By.xpath("//*[@class='gc-check-balance']");
	static final By GcChangeVerfImg = By.xpath("//*[@id='giftCardChangeCaptcha']");
	// Error
	static final By GCError = By.xpath("//*[@id='gift-card-errors']");

	public GiftCardPage(InstanceContainer ih) {
		super(ih);
	}

	/**
	 * Component to verify gift card page
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifyGCPage() throws Exception {

		if (wh.isElementPresent(headerTitle)) {
			String strgift = wh.getText(headerTitle);
			report.addReportStep("Verify the gift card page", "Page title " + strgift + " is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify the gift card page", "Gift card page is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify shop gift card and balance check section in gift card
	 * page
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifySections() throws Exception {

		if (wh.isElementPresent(shopGCSection) && wh.isElementPresent(checkBalGc)) {

			report.addReportStep("Verify the gift card page sction",
					"shop GC scetion and Balance check link is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify the gift card page sction",
					"shop GC scetion and Balance check link is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to click check gift card balance link
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void clickCheckBalanceLink() throws Exception {

		if (wh.isElementPresent(checkBalGc)) {
			//wh.clickElement(checkBalGc);
			wh.jsClick(checkBalGc);
			Thread.sleep(1000);
			report.addReportStep("Verify the check GC balance", "GC Balance link is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Verify the check GC balance", "GC Balance link is not clicked", StepResult.FAIL);
		}

	}

	/**
	 * Component to enter gift card and check balance
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void enterGiftCardAndCheckBalance() throws Exception {

		String GcNumber = dataTable.getData("GiftCardNumber");
		String GcPin = dataTable.getData("GiftCardPin");
		String GcCaptcha = dataTable.getData("GiftCardCaptcha");
		if (wh.isElementPresent(GCnumber)) {
			// 1.Gift Card Number
			wh.sendKeys(GCnumber, GcNumber);
			report.addReportStep("Gift Card Number", "Gift Card " + GcNumber + " is entered", StepResult.DONE);
			// 2.PIN Number
			wh.sendKeys(GCpin, GcPin);
			report.addReportStep("Gift Card Pin", "Gift Card pin " + GcPin + " is entered", StepResult.DONE);
			// 4.Verification Codefields
			wh.sendKeys(captchaverif, GcCaptcha);
			report.addReportStep("Gift Card captcha", "Gift Card captcha " + GcCaptcha + " is entered", StepResult.DONE);
			// 5.Change It link
			if (wh.isElementPresent(GcChangeVerfImg)) {

				report.addReportStep("Captcha Change link", "Captcha Change link", StepResult.PASS);
			} else {
				report.addReportStep("Captcha Change link", "Change Change link is not displayed", StepResult.FAIL);
			}

			// 6.APPLY CARD
			if (wh.isElementPresent(checkBalGo)) {
				wh.jsClick(checkBalGo);
				Thread.sleep(10000);
				report.addReportStep("Verify check balance button is displayed",
						"Check balance button is displayed and clicked", StepResult.PASS);
			} else {
				report.addReportStep("Verify Check balance button is displayed",
						"Check balance button is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify gift card overlay", "Gift Card section is not displayed", StepResult.FAIL);

		}

	}

	/**
	 * Component to verify gift card error
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifyGCError() throws Exception {

		if (wh.isElementPresent(GCError)) {
			String strgift = wh.getText(GCError);
			if (strgift.contains("Please visit any Home Depot store and ask a cashier to check the balance for you.")) {
				report.addReportStep("Verify the gift card error", "Gift card error  " +  strgift + " is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify the gift card error", "Gift card error is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify the gift card error", "Gift card error is not displayed", StepResult.FAIL);
		}

	}

}
