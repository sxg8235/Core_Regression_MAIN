package com.homer.po;

import org.openqa.selenium.By;

import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class Blinds_61889 extends PageBase<Blinds_61889>{

	public static final By cartIcon= By.xpath("//*[@id='Cart']");
	public static final By flyout= By.id("headerFlyoutMenu");
	public static final By blindsAndDecor= By.xpath("//*[@title='Blinds & Decor']");
	public static final By blindsShades= By.xpath("//*[contains(text(),'Blinds & Shades')]");
	public static final By pageTitle= By.xpath("//*[@class='page-title']");
	
	public Blinds_61889(InstanceContainer ic) {
		super(ic);
		// TODO Auto-generated constructor stub
	}


 
public void clickMiniCart() throws Exception{
	if(wh.isElementPresent(cartIcon)){
		wh.clickElement(cartIcon);
		report.addReportStep("Verify mini cart icon and click on it", "Mini cart icon is displayed and clicked successfully", StepResult.PASS);
	}else
		report.addReportStep("Verify mini cart icon and click on it", "Mini cart icon is NOT displayed", StepResult.FAIL);
}

public void clickPSonMenuBar() throws Exception{
	if(wh.isElementPresent(flyout)){
		wh.clickElement(flyout);
		report.addReportStep("Verify Product and services menu bar and click on it", "Product and services menu bar is displayed and clicked successfully", StepResult.PASS);
	}else
		report.addReportStep("Verify Product and services menu bar and click on it", "Product and services menu bar is NOT displayed", StepResult.FAIL);
}
	




public void clickBandD() throws Exception {
	// TODO Auto-generated method stub
	
	if(wh.isElementPresent(blindsAndDecor)){
		wh.clickElement(blindsAndDecor);
		report.addReportStep("Verify Blinds and Decor in sub menu and click on it", "Blinds and Decor is displayed and clicked successfully", StepResult.PASS);
	}else
		report.addReportStep("Verify Blinds and Decor in sub menu and click on it", "Blinds and Decor is NOT displayed", StepResult.FAIL);
}




public void clickBandSsubMenu() throws Exception {
	// TODO Auto-generated method stub

	if(wh.isElementPresent(blindsShades)){
		wh.clickElement(blindsShades);
		report.addReportStep("Verify Blinds and shades in sub menu and click on it", "Blinds and shades is displayed and clicked successfully", StepResult.PASS);
	}else
		report.addReportStep("Verify Blinds and shades in sub menu and click on it", "Blinds and shades is NOT displayed", StepResult.FAIL);
}




public void verfyBlindsPLP() throws Exception {
	// TODO Auto-generated method stub
	Thread.sleep(3000);
	if(wh.getText(pageTitle).contains("Blinds & Window Treatments")){
		report.addReportStep("Verify page title as Blinds & Windows Treatments", "Page title is displayed as Blinds & Windows Treatments", StepResult.PASS);
	}else
		report.addReportStep("Verify page title as Blinds & Windows Treatments", "Page title is NOT displayed as Blinds & Windows Treatments", StepResult.FAIL);
}










}