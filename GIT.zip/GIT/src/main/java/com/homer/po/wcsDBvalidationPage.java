package com.homer.po;
//STEP 1. Import required packages
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.support.ui.WebDriverWait;




//import org.apache.commons.lang.text.StrTokenizer;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;

public class wcsDBvalidationPage extends PageBase<wcsDBvalidationPage> {

	/*private ConvenienceFunctions cf = new ConvenienceFunctions(driver, report);
	private ConvenienceFunctions2 cf2 = new ConvenienceFunctions2(driver,
			report);

	private Asserts asserts = new Asserts();
	private ReusableComponent rc;*/

	WebDriverWait wait = new WebDriverWait(driver, 30);

	final int SHIP_RADIO_BUTTON_SELECTED = 1;
	final int PICK_UP_RADIO_BUTTON_SELECTED = 2;
	final int SHIP_LABEL_PRESENT = 3;
	final int PICK_UP_LABEL_PRESENT = 4;
	final int PICK_UP_AND_SHIP_LABELS_PRESENT = 5;
	final int SELECT_SHIP = 11;
	final int SELECT_PICK_UP = 12;
	final int PICK_UP_IN_STORE_ONLY = 1;
	final int ADD_TO_CART_ONLY = 2;
	final int BOTH_PICK_UP_IN_STORE_ADD_TO_CART = 3;
	public static int setItemNumber;
	private CharSequence replacement;
	String db_url;
	String db_username;
	String db_password;
	String xrefcardnumber;
	String auth_id;
	String auth_status;
	String status;
	String strSku;
	String Quant;
	String tax;
	String paymthd;

	/*public wcsDBvalidationPage(ScriptHelper scriptHelper) {
		super(scriptHelper);
		rc = new ReusableComponent(scriptHelper);

	}*/
	
	public wcsDBvalidationPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * COmponent to perform the order validation in DB
	 * 
	 * 
	 * @since Jan 11, 2013
	 * @author PXM8043
	 * @throws InterruptedException
	 */
	public void wcsDBValidation() throws InterruptedException {

		Thread.sleep(1000);
		
		String strOrderId =   commonData.strOrderId;
		//String strOrderId = "W668439038";
		System.out.println(strOrderId);
		strOrderId = strOrderId.substring(1, strOrderId.length());
		String strQueryString = "";

		// Verifying the OSSTATUS
		try {
			strQueryString = "select osstatus from ordstat where orders_id ='"
					+ strOrderId + "'";
			;
			List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
			boolean blnisPresent = false;
			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {

					/* biOfferID = (Long) result.get(0).get("OFFER_ID"); */
					String strOsStatus = (String) result.get(i).get("OSSTATUS");
					System.out.println("Query result:  "
							+ result.get(i).get("OSSTATUS"));

					try {
						if (strOsStatus.contains("1200")) {
							blnisPresent = true;
							break;
						}
					} catch (Exception e) {
						System.out.println("");
					}

				}
				if (blnisPresent) {
					System.out.println("DB validation successful and the displayed value is '1200'");
					report.addReportStep(
							"Verify that OSSTATUS in DB is displayed as '1200'",
							"DB validation is successful and the displayed value is <b>'1200'</b>",
							StepResult.DONE);
				} else {
					report.addReportStep(
							"Verify that OSSTATUS in DB is displayed as '1200'",
							"DB validation is not successful", StepResult.WARNING);
				}

			} else {
				System.out.println(strQueryString
						+ " did not return any result");
			}
		} catch (Exception e) {
			System.out.println();
			System.out.println("Database operation failed. Could not perform "
					+ strQueryString);
		}

		// valdiate Line item status

		try {
			strQueryString = "select oistatus from ordistat where orders_id='"
					+ strOrderId + "'";
			List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
			boolean isPresent = false;
			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {

					/* biOfferID = (Long) result.get(0).get("OFFER_ID"); */
					String strOsStatus = "" + result.get(i).get("OISTATUS");

					System.out.println("Query result:  "
							+ result.get(i).get("OISTATUS"));
					try {
						int index = strOsStatus.indexOf("0");

						if (strOsStatus.contains("0") && index == 0) {
							isPresent = true;
							break;
						}
					} catch (Exception e) {
						System.out.println("");
					}
				}

				if (isPresent) {
					System.out.println("DB validation is successful and the displayed value is '0'");
					report.addReportStep(
							"Verify that line item STATUS in DB is displayed as '0'",
							"DB validation is successful and the displayed value is <b>'0'</b>",
							StepResult.DONE);
				} else {
					report.addReportStep(
							"Verify that line item STATUS in DB is displayed as '0'",
							"DB validation is not successful", StepResult.WARNING);
				}

			} else {
				System.out.println(strQueryString
						+ " did not return any result");
			}
		} catch (Exception e) {
			System.out.println();
			System.out.println("Database operation failed. Could not perform "
					+ strQueryString);
		}

		// valdiate address info in DB

		/*try {
			String firstName = dataTable.getData("FirstName");
			String lastName = dataTable.getData("LastName");

			String strAddress1 = dataTable.getData("Address1");
			String Email = dataTable.getData("EmailRegistration");
			boolean blnAddressDetails = false;

			strQueryString = "select * from address where member_id in (select member_id from orders where orders_id ='"
					+ strOrderId + "')";
			List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
			boolean blnIsPresent = false;
			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {

					 biOfferID = (Long) result.get(0).get("OFFER_ID"); 
					String fname = (String) result.get(i).get("FIRSTNAME");
					String lname = (String) result.get(i).get("LASTNAME");
					String Address = (String) result.get(i).get("ADDRESS1");
					System.out.println("Query result:  " + fname + " " + lname
							+ " " + Address + "");

					try {
						if (fname.contains(firstName)
								&& lname.contains(lastName)
								&& Address.contains(strAddress1)) {
							blnAddressDetails = true;
							break;
						}
					} catch (Exception e) {
						System.out.println("");
					}

				}

			} else {
				System.out.println(strQueryString
						+ " did not return any result");

			}

			if (blnAddressDetails) {
				
				System.out.println("DB validation successful for the Address details <br>"
						+ firstName + " " + lastName + " "
						+ strAddress1 + "");

				report.addReportStep("Validate the address details in DB",
						"DB validation successful for the Address details <br>"
								+ firstName + " " + lastName + " "
								+ strAddress1 + "", Status.DONE);

			} else {
				report.addReportStep("Validate the address details in DB",
						"DB validation is not successful", Status.WARNING);
			}
		} catch (Exception e) {
			System.out.println();
			System.out.println("Database operation failed. Could not perform "
					+ strQueryString);
		}
*/
		// validate SKU and Quantity details in DB
		try {

			String strSkuNumber = dataTable.getData("SKUNumber");
			String strQuantity = dataTable.getData("Quantity");
			strQueryString = "Select * from orderitems where orders_id ='"
					+ strOrderId + "'";
			List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
			boolean isPresent = false;

			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {

					/* biOfferID = (Long) result.get(0).get("OFFER_ID"); */
					 strSku = "" + result.get(i).get("CATENTRY_ID");
					 Quant = "" + result.get(i).get("QUANTITY");
					 tax = "" + result.get(i).get("TAXAMOUNT");
					// System.out.println("Query result:  " +
					// result.get(0).get("oistatus"));

					try {
						if (strSku.equals(strSkuNumber)
								&& Quant.contains(strQuantity)) {
							isPresent = true;
							break;
						}
					} catch (Exception e) {
						System.out.println("");
					}

				}
				if (isPresent) {
					System.out.println("DB validation is successful.'SKU','Quantity' and 'Tax' fields have been validated");
					
					report.addReportStep("Verify the 'SKU','Quantity' and 'Tax' details in DB",
							"DB validation is successful.SKU <b>("+strSkuNumber+")</b>,Quantity <b>(" +strQuantity+ ")</b> and Tax<b>(" +tax+ ")</b> fields have been validated", StepResult.DONE);
				} else {
					report.addReportStep("Verify the SKU and Quantity details in DB",
							"DB validation is not successful", StepResult.WARNING);
				}
			} else {
				System.out.println(strQueryString
						+ " did not return any result");
			}
		} catch (Exception e) {
			System.out.println();
			System.out.println("Database operation failed. Could not perform "
					+ strQueryString);
		}

		
		// valdiate VoltageWebFeature & VoltageTabletFeature 			
		try {

			strQueryString = "select * from HD_CD_GRP_CD where CD_NM in ('BeehiveServicesFeature','VoltageWebFeature','VoltageTabletFeature') and cd_env_val='live'";
			List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
			boolean isPresent_1 = false;
			boolean isPresent_2 = false;
			boolean isPresent_3 = false;
			String Value_1 = null;
			String Value_2 = null;
			String Value_3 = null;

			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {

					String name = "" + result.get(i).get("CD_NM");
					String value = "" + result.get(i).get("INT_VAL");

					try {
						if (name.trim().equals("BeehiveServicesFeature"))
								 {
							 Value_1 = value;
							isPresent_1 = true;
							//break;
						}
						
					} catch (Exception e) {
						System.out.println("");
					}
					
					try {
						if (name.trim().equals("VoltageTabletFeature"))
								 {
							 Value_2 = value;
							isPresent_2 = true;
							//break;
						}
						
					} catch (Exception e) {
						System.out.println("");
					}
					
					try {
						if (name.trim().equals("VoltageWebFeature"))
						 {
					 Value_3 = value;
					isPresent_3 = true;
					//break;
				}
						
					} catch (Exception e) {
						System.out.println("");
					}
					
					
				}
				if (isPresent_1 && isPresent_2 && isPresent_3) {
					
					System.out.println("DB validation is successful.'BeehiveServicesFeature','VoltageWebFeature' & 'VoltageTabletFeature' fields value have been validated ");
					
					report.addReportStep("Verify 'BeehiveServicesFeature','VoltageWebFeature' & 'VoltageTabletFeature' details in DB",
							"DB validation is successful.'BeehiveServicesFeature'<b>("+Value_1+")</b>,'VoltageWebFeature'<b>("+Value_2+")</b> & 'VoltageTabletFeature'<b>("+Value_3+")</b> have been validated ", StepResult.DONE);
				} else {
					report.addReportStep("Verify 'BeehiveServicesFeature','VoltageWebFeature' & 'VoltageTabletFeature' details in DB",
							"DB validation is not successful",
							StepResult.WARNING);
				}
			} else {
				System.out.println(strQueryString
						+ " did not return any result");
			}
		} catch (Exception e) {
			System.out.println();
			System.out
					.println("Database operation failed. Could not perform "
							+ strQueryString);
		}


	// validate ORDPAYINFO details in DB
		
		//if (properties.getProperty("RunConfiguration").toLowerCase()
				//.contains("beehive")) {
			try {

				String strCardNumber = dataTable.getData("CardNumber");
				//String strCardNumber = "5442983333333336";
				strCardNumber=strCardNumber.substring(12);
				System.out.println(strCardNumber);
				strQueryString = "Select * from ordpayinfo where orders_id ='"
						+ strOrderId + "'";
				List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
				boolean isPresent_1 = false;
				boolean isPresent_2 = false;

				if (result.size() > 0) {
					for (int i = 0; i < result.size(); i++) {

						/* biOfferID = (Long) result.get(0).get("OFFER_ID"); */
						String name = "" + result.get(i).get("NAME");
						String value = "" + result.get(i).get("VALUE");
						// System.out.println("Query result:  " +
						// result.get(0).get("oistatus"));

						try {
							if (name.trim().equals("isXREF")
									&& value.trim().contains("true")) {
								isPresent_1 = true;
								//break;
							}
							
						} catch (Exception e) {
							System.out.println("");
						}
						
						try {
							if (name.trim().equals("cardNumber")
									&& value.trim().substring(12).contains(strCardNumber)) {
								isPresent_2 = true;
								xrefcardnumber=value;
								commonData.strxrefnbr=xrefcardnumber;
								//break;
							}
							
						} catch (Exception e) {
							System.out.println("");
						}
						
						
					}
					if (isPresent_1 && isPresent_2) {
						
						System.out.println("DB validation is successful.'isXREF' field & last four digits of XREF cardNumber("+xrefcardnumber+") have been validated ");
						
						report.addReportStep("Verify the XRef card details in DB",
								"DB validation is successful.'isXREF' field & last four digits of XREF cardNumber<b>("+xrefcardnumber+")</b> have been validated ", StepResult.DONE);
					} else {
						report.addReportStep("Verify the XRef card details in DB",
								"DB validation is not successful",
								StepResult.WARNING);
					}
				} else {
					System.out.println(strQueryString
							+ " did not return any result");
				}
			} catch (Exception e) {
				System.out.println();
				System.out
						.println("Database operation failed. Could not perform "
								+ strQueryString);
			}

			// validate PAY_AUTH_ID and REV_AUTH_STATUS details in DB
			try {
				strQueryString = "Select * from HD_ORDER_TRANSMIT where orders_id ='"
						+ strOrderId + "'";
				List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
				boolean isPresent = false;

				if (result.size() > 0) {
					for (int i = 0; i < result.size(); i++) {
						
						String fulfil = "" + result.get(i).get("FULFIL_OMS");

						if (fulfil.equals("COM")||fulfil.equals("DD")) {
						 status = "" + result.get(i).get("STATUS");
						 auth_id = "" + result.get(i).get("PAY_AUTH_ID");
					
						commonData.strpayauthId=auth_id;
						 auth_status = "" + result.get(i).get("REV_AUTH_STATUS");
						// System.out.println("Query result:  " +
						// result.get(0).get("oistatus"));

						System.out.println("DB validation is successful.STATUS ("+ status + ") ,PAY_AUTH_ID ("+ auth_id + ") and REV_AUTH_STATUS(" + auth_status + ") fields have been validated");
						
						report.addReportStep("Verify the STATUS , PAY_AUTH_ID and REV_AUTH_STATUS details in DB",
								"DB validation is successful.STATUS <b>("+ status + ")</b> ,PAY_AUTH_ID <b>("+ auth_id + ")</b> and REV_AUTH_STATUS <b>(" + auth_status + ")</b> fields have been validated", StepResult.DONE);
					} 
					
					else {
						report.addReportStep("Verify the PAY_AUTH_ID and REV_AUTH_STATUS details in DB",
								"DB validation is not successful", StepResult.WARNING);
					}
					}
				} else {
					System.out.println(strQueryString
							+ " did not return any result");
				}
			} catch (Exception e) {
				System.out.println();
				System.out.println("Database operation failed. Could not perform "
						+ strQueryString);
			}		
			
			// validate PAYMETHOD details in DB
						try {
							strQueryString = "Select * from ORDPAYMTHD where orders_id ='"
									+ strOrderId + "'";
							List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
							boolean isPresent = false;

							if (result.size() > 0) {
								for (int i = 0; i < result.size(); i++) {

									 paymthd = "" + result.get(i).get("PAYMETHOD");

									System.out.println("DB validation is successful.PAYMETHOD ("+ paymthd + ") field has been validated");
									
									report.addReportStep("Verify the PAYMETHOD details in DB",
											"DB validation is successful.PAYMETHOD <b>("+ paymthd + ")</b> field has been validated", StepResult.DONE);
								} 
							}
								
								else {
									report.addReportStep("Verify the PAYMETHOD details in DB",
											"DB validation is not successful", StepResult.WARNING);
								}
						} catch (Exception e) {
							System.out.println();
							System.out.println("Database operation failed. Could not perform "
									+ strQueryString);
						}		
						
			
		}

		//}

		
	/**
	 * Function to connect to IBM DB2 database.
	 * 
	 * @param sqlQuery
	 *            Your SQL query string like
	 *            "select ATTRNAME from ACATTR where ACATTR_ID = 10002"
	 * @return Returns an ArrayList with values
	 */
	public ArrayList<HashMap<String, Object>> connectDB2DatabaseGetRowSet(
			String sqlQuery) {
		ArrayList<HashMap<String, Object>> list = null;
		try {
			//STEP 2: Load the DB2(R) Universal JDBC Driver with DriverManager
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			
		    //STEP 3: Open a connection
		    System.out.println("Connecting to database...");
		    
		  //STEP 4: Get the credentials and URL 
			db_connection_url();
			db_connection_username();
			db_connection_password();
			
			Connection con = DriverManager.getConnection(db_url, db_username,
					db_password);
			if (!con.isClosed()) {
				System.out.println("Successfully connected to DB2 server");
			}
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sqlQuery);
			report.addReportStep("Execute the query <b>" + sqlQuery
					+ "</b> in DB", "Mentioned query has been executed", StepResult.DONE);

			
			//STEP 5: Extract data from result set
			ResultSetMetaData md = rs.getMetaData();
			int columns = md.getColumnCount();
			list = new ArrayList<HashMap<String, Object>>(50);
			while (rs.next()) {
				HashMap<String, Object> row = new HashMap<String, Object>(
						columns);
				for (int i = 1; i <= columns; ++i) {
					row.put(md.getColumnName(i), rs.getObject(i));
				}
				list.add(row);
			}

			rs.close();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return list;
	}

	
	public String db_connection_url() {
		//String envirnmnt = properties.getProperty("Environment");
		String envirnmnt = HelperClass.baseModel.runEnvironment;
		db_url = null;

		if (envirnmnt.equalsIgnoreCase("qa71")) {

			db_url = "jdbc:db2://cpaiqagb.homedepot.com:50121/dq1012sa";
		}

		else if (envirnmnt.equalsIgnoreCase("qa72")) {

			db_url = "jdbc:db2://cpaiqaab.homedepot.com:50120/dq2012sa";
		}

		else if (envirnmnt.equalsIgnoreCase("qa73")) {

			db_url = "jdbc:db2://cpaiqaeb.homedepot.com:50123/dq3012sa";
			
		} else if (envirnmnt.equalsIgnoreCase("qa74")) {

			db_url = "jdbc:db2://cpaiqaub.homedepot.com:50120/DQ4012SA";
		}

		else if (envirnmnt.equalsIgnoreCase("st71")) {

			db_url = "jdbc:db2://cpaist5b.homedepot.com:50121/ds1012sa";
		}

		else if (envirnmnt.equalsIgnoreCase("st72")) {

			db_url = "jdbc:db2://cpaist2b.homedepot.com:50120/ds2012sa";
		}

		else if (envirnmnt.equalsIgnoreCase("st73")) {

			db_url = "jdbc:db2://cpaist8b.homedepot.com:50123/ds3012sa";
		}

		else if (envirnmnt.equalsIgnoreCase("ps71")) {

			db_url = "jdbc:db2://pqasa090.homedepot.com:50120/DQA012SA";
		}

		return db_url;

	}

	public String db_connection_username() {
		db_username = "tauser03";
		return db_username;

	}

	public String db_connection_password() {
		//String envirnmnt = properties.getProperty("Environment");
		String envirnmnt = HelperClass.baseModel.runEnvironment;
		if (envirnmnt.equalsIgnoreCase("ps71")) {

			db_password = "webster5";
		}

		else {

			db_password = "webster6";
		}

		return db_password;
	}

	/**
	 * COmponent to perform the sys out validation for beehive
	 * 
	 * @since Oct 06, 2015
	 * @author RXP8655
	 * @throws InterruptedException
	 * @throws SQLException 
	 */
	public void sysOutValidation() throws InterruptedException, SQLException {

		Thread.sleep(1000);
		//String strOrderId = scriptHelper.commonData.orderNumber;
		String strOrderId = "W152175048";
		System.out.println(strOrderId);
		strOrderId = strOrderId.substring(1, strOrderId.length());
		String strQueryString = "";

		String DBURL = "cpaiqauh.homedepot.com";
		String DBUsername = "tauser02";
		String DBPassword = "1nd0n3s1a";

		Connection con = DriverManager.getConnection(DBURL, DBUsername,
				DBPassword);
		if (!con.isClosed()) {
			System.out.println("Successfully connected to MySQL server");
		}
		
		// Verifying the OSSTATUS
		/*try {
			// strQueryString =
			// "select osstatus from ordstat where orders_id ='"+ strOrderId +
			// "'";;
			List<HashMap<String, Object>> result = connectDB2DatabaseGetRowSet(strQueryString);
			boolean blnisPresent = false;
			if (result.size() > 0) {
				for (int i = 0; i < result.size(); i++) {

					 biOfferID = (Long) result.get(0).get("OFFER_ID"); 
					String strOsStatus = (String) result.get(i).get("OSSTATUS");
					System.out.println("Query result:  "
							+ result.get(i).get("OSSTATUS"));

					try {
						if (strOsStatus.contains("1200")) {
							blnisPresent = true;
							break;
						}
					} catch (Exception e) {
						System.out.println("");
					}

				}
				if (blnisPresent) {
					report.addReportStep(
							"Verify that OSSTATUS in DB is displayed as '1200'",
							"DB validation successful and the displayed value is '1200'",
							Status.PASS);
				} else {
					report.addReportStep(
							"Verify that OSSTATUS in DB is displayed as '1200'",
							"DB validation is not successful", Status.WARNING);
				}

			} else {
				System.out.println(strQueryString
						+ " did not return any result");
			}
		} catch (Exception e) {
			System.out.println();
			System.out.println("Database operation failed. Could not perform "
					+ strQueryString);
		}*/

	}

}
