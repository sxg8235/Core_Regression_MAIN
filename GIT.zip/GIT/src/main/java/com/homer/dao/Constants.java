package com.homer.dao;

public class Constants {
	
	public static String ProdUrl = "http://www.homedepot.com";
	
}
