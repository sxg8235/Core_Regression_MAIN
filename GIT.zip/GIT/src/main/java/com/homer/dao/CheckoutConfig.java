package com.homer.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class CheckoutConfig {
	
	public boolean readPriceFromCassandra;
	public boolean depotDirectDown;
	public boolean readFromPricingAPI;

	public CheckoutConfig() {
	       Properties prop = new Properties();
	       try {
	              prop = loadPropertyfile("CheckoutConfig.properties");
	              
	              readPriceFromCassandra = Boolean.parseBoolean(prop.getProperty("readPriceFromCassandra"));     
	              readFromPricingAPI = Boolean.parseBoolean(prop.getProperty("readFromPricingAPI")); 
	              depotDirectDown = Boolean.parseBoolean(prop.getProperty("DepotDirectDown"));  
	      	       
	       } catch (Exception e) {
	       System.out.println("Unable to read config file " + e.getMessage());
	       }
	}

	public Properties loadPropertyfile(String fileName)  {
	       Properties prop = new Properties();
	       FileInputStream in;
	       try {
	              in = new FileInputStream(fileName);
	              prop.load(in);       
	       } catch (FileNotFoundException e) {
	    	   System.out.println("Config File not found" + e.getMessage());
	       } 
	       catch (IOException e) {
	    	   System.out.println("Config read File error " + e.getMessage());
	       }
	       return prop;
	}


		
}
