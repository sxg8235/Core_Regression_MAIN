package com.homer.dao;

public class CommonDataColumn {

	public static final String EnvironmentUrl = "EnvironmentUrl";
	public static final String RegUserEmail = "RegUserEmail";
	public static final String RegUserPwd = "RegUserPwd";
	public static final String GuestEmail = "GuestEmail";	
	public static final String ShippingFirstName = "ShippingFirstName";
	public static final String ShippingLastName ="ShippingLastName";
	public static final String ShippingAddr = "ShippingAddr";
	public static final String ShippingZipCode = "ShippingZipCode";
	public static final String ShippingPhNo = "ShippingPhNo";
	public static final String WrongPwd = "WrongPwd";
	
	public static final String NameOnCard = "NameOnCard";
	public static final String CardType = "CardType";
	public static final String CardNumber = "CardNumber";
	public static final String ExpirationMonth = "ExpirationMonth";
	public static final String ExpirationYear = "ExpirationYear";
	public static final String BillingPh1 = "BillingPh1";
	public static final String BillingPh2 = "BillingPh2";
	public static final String BillingPh3 = "BillingPh3";
	public static final String CardSecurityID = "CardSecurityID";
	public static final String BuyerName = "BuyerName";
	public static final String InvalidTaxExempt = "InvalidTaxExemptId";
	public static final String TaxExempt1 = "TaxExmptId";
	public static final String fourDigitInvalidTaxExmptId = "4DigitInvalidTaxExmptId";
	
	public static final String paypalUserId = "PaypalUserId";
	public static final String paypalUserPassword = "PaypalUserPassword";
	public static final String diffZipCode = "DiffZipCode";
	public static final String ShippingZipCodeRestricted = "ShippingZipCodeRestricted";
	public static final String VISA_card = "VISA_card";
	public static final String MASTER_card = "MASTER_card";
	public static final String AMEX_card = "AMEX_card";
	public static final String DISCOVER_card = "DISCOVER_card";
	public static final String HDCONSUMER_card = "HDCONSUMER_card";
	public static final String HDCOMMERCIAL_card = "HDCOMMERCIAL_card";
	public static final String GSA_card = "GSA_card";
	public static final String CVV_Amex = "CVV_Amex";
	public static final String POJobCode = "POJobCode";
	public static final String SaveExpirationMonth = "SaveExpirationMonth";
	public static final String TaxExempt = "TaxExempt";
	public static final String ShippingFirstName1 = "ShippingFirstName1";
	public static final String ShippingLastName1 = "ShippingLastName1";
	public static final String ShippingAddr1 = "ShippingAddr1";
	public static final String ShippingPhNo1 = "ShippingPhNo1";
	public static final String zipcode = "zipcode";
	public static final String newZipcode = "zipcode_new";
	public static final String InvalidPhoneNumber = "InvalidPhoneNumber";
	public static final String CSRuser = "CSRuser";
	public static final String CSRpassword = "CSRpassword";
	public static final String FPOZipcode = "FPOZipcode";
	public static final String APOZipcode = "APOZipcode";
	public static final String DPOZipcode = "DPOZipcode";
	public static final String TEST_card = "TEST_card";
	public static final String PROXY_card = "PROXY_card";
	public static final String HDCOMMERCIAL_POMandat = "HDCOMMERCIAL_POMandat";
	public static final String GIFT_card = "GIFT_card";
	public static final String STORECREDIT_card = "STORECREDIT_card";
	public static final String GIFT_card_PIN ="GIFT_card_PIN";
	public static final String STORECREDIT_card_PIN ="STORECREDIT_card_PIN";
	public static final String InvalidCard ="InvalidCard";
	public static final String InvalidNum = "InvalidNum";
	public static final String InvalidCvv = "InvalidCvv";
	public static final String RegUserEmailRestrictedZip = "RegUserEmailRestrictedZip";
	public static final String RegUserPwdRestrictedZip = "RegUserPwdRestrictedZip";
	public static final String BillingFirstName1 = "BillingFirstName1";
	public static final String BillingLastName1 = "BillingLastName1";
	public static final String BillingAddr1 = "BillingAddr1";
	public static final String BillingZipCode1 = "BillingZipCode1";
	public static final String InvaildPO = "InvaildPO";
	public static final String THDMailUserName = "THDMailUserName";
	public static final String THDMailPwd = "THDMailPwd";
	
}
