package com.homer.dao;

public class RunManagerColumns {

	public static String Browser ="Browser";
	public static String BrowserVersion ="Browser Version";
	public static String Platform = "Platform";
}
