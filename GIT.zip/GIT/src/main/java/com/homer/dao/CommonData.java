package com.homer.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CommonData {

	public static String TotalTax;
	public String keyword;
	public String sku;
	public String strEmail;
	public String strEmailGuest;
	public String strPassword;
	public String url;
	public String newWindow;
	public double applianceSubTotal;
	public boolean desktopUserAgent;
	public String pipModelNumber;
	public int pipQty;
	public String pipPrice;
	public String serviceLevelToSelect;
	public String adultText;
	public String cassandraURL = "";// "172.20.240.40";
	public String cassandraUserId = "catalogread";
	public String cassandraPwd = "c@t@l0gr3@d!";
	public String cassandraRefAppIPandPort = "172.20.240.43:8082";
	public String prodDescription;
	public HashMap<String, String> unitPrice = new HashMap<String, String>();
	public HashMap<String, String> itemTotal = new HashMap<String, String>();
	public HashMap<String, String> itemDescPrice = new HashMap<String, String>();
	public HashMap<String, String> calcUnitPrice = new HashMap<String, String>();
	public String unitPriceDB;
	public String modelNo;
	public int littleWait = 1500;
	public int tinyWait = 3000;
	public int smallWait = 5000;
	public int mediumWait = 7500;
	public int LongWait = 10000;
	public String subTotal;
	public List<String> skuList = new ArrayList<String>();
	public String total;
	public Double unitSubTotal = 0.0;
	public String alternateStore;
	public String bodfsAddress;

	public Double dblSubTotalCart = 0.0;
	public Double dblPickInStoreTotalcart = 0.0;
	public Double dblExpDelChargesCart = 0.0;
	public Double dblSalesTax = 0.0;
	public Double dblEstimatedSubTotalCart = 0.0;
	public Double dblEstShippingChargesCart = 0.0;
	public String Zipcode;
	public String orderNumber;
	public String bodfsZipCodeCart = null;
	public String strDeliveryPrice = null;
	public String strikeThroPriceDB = "";
	public String specialBuyPrice = "";
	public String estDeliveryBODFS = "";
	public boolean isAppliance = false;
	public String plccPrice;
	public String protPlanPrice;
	public String Zipcd;
	public double doubleQualifierDiscount;

	public boolean priceRead = false;

	// **********For HDPP**********************
	public double doubATCSubtotal;
	public String pcpPrice;
	public String prodQuantity;
	public String prodQuantityFulfilment;
	public String prodQuantitybopis;
	public int pcpQuantity;
	public String editCartCount;
	public String increasepipqty;
	public String plpPrice;
	public String strOrderId;
	public boolean isMerAdded;
	public boolean isApplianceAdded;
	public String cardNum;
	public boolean blnGracefulExit;
	public boolean strIsShipAddrSaved;

	public String ShippingCity;
	public String shortShipState;
	public String strStoreselect;
	public ArrayList<String> lstStoreNames = new ArrayList<String>();
	public String NewZipcode;
	public List<String> lstProductNames = new ArrayList<String>();
	// public int lstProductNames;
	public ArrayList<String> strSelectDate = new ArrayList<String>();
	public ArrayList<String> strSelectTime = new ArrayList<String>();
	public String EarliestArrivalDate;
	public Object arrItemNames;
	public String typeAheadZipCd;
	public String typeAheadCity;
	public String typeAheadState;
	public String overlaySelectedDate;
	public String overlaySelectedTime;
	public String selectedStore;
	public String applDelDate;

	

	// Form Validations
	public String[] symbolName = { "~", "`", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "+", "=", "[", "]",
			"{", "}", "\"", ";", ":", "?", ">", "<" };
	public String[] addrStartingSymb = { ".", ",", "-", "`", "~", "#" };
	public String[] addrSymbols = { "!", "@", "$", "%", "^", "&", "*", "(", ")", "+", "=", "[", "]", "{", "}", "�",
			"\"", ";", ":", "/", "?", ">", "<" };
	public String[] addrPOBOX = { "Pobox", "PoBox", "poBox", "POBOX", "P.O. box", "P.O.Box", "p.o.box", "P.o. box",
			"P.o Box", "p.O. box", "P.O Box", "P.O. BOX", "PO box", "Po Box", "PO BOX", "Po box","POST OFFICE BOX","Post office box","post office box","posted box","Post Of Box","Pobox","Post box"};

	public String[] zipcdSymbols = { "!", "#", "$", "%", "&", "*", "(", ")", "+", "'", "\"", ".", "," };
	public String[] phSymbols = { ".", "," };
	public String[] symbolNameInMiddle = { "'", "\"", "`", "~", "|", "\\" };
	public String[] addrSymbolInMiddle = { "'", "\"", "|", "\\" };
	public String zipcdSymbol = "!#$%&";
	public String[] zeroZipCd = { "00000", "00001" };

	//Invalid ph numbers
	public String[] invalidPhNo = { "12345", "74125896", "258741589" };
	
	//Invalid credit card number
	public String[] invalidCCNo = { "37323538788100", "3732353878810000", "438775111111", "54429833333"};
	
	//Invalid Tax value
	public String[] invalidTax = { "12345", "1258" };
	
	public String strPO;
	public ArrayList<String> liststoresCart = new ArrayList<String>();
	public String strTaxNum;
	public String pipSave;
	public String strCartColor;
	public String strshipvalue;
	public String QuantityTotal;
	public int qtyTotal;
	public String strWidthWhole;
	public String strHeightWhole;
	public String strMount;
	public String miniCartSampleCount;
	public static final String fourDigitInvalidTaxExmptId = "4DigitInvalidTaxExmptId";

	// **********Instant Rebate**********************//
	public String longdesc_PIP;
	public String shortdesc_PIP;
	public String longdesc;
	public String shortdesc;
	public String changedstore;
	public String multistore;
	public String changedstoreprice;
	public String localizestore;
	public int storeId;
	public ArrayList<String> PriceList = new ArrayList<String>();
	public ArrayList<String> PriceList1 = new ArrayList<String>();
	public ArrayList<String> IRList = new ArrayList<String>();
	public ArrayList<String> IRList1 = new ArrayList<String>();
	public ArrayList<String> BOPISSKUList = new ArrayList<String>();
	public ArrayList<String> STHSKUList = new ArrayList<String>();
	public ArrayList<String> StoreList = new ArrayList<String>();
	public ArrayList<String> IRzipcodeList = new ArrayList<String>();
	public ArrayList<String> Proddesc = new ArrayList<String>();
	public String changedstoreprice1;
	public String InstantRebateEligMsg1_CC="Good news! An instant rebate is available in your area, which has decreased this item's price.";
	public String InstantRebateIneligMsg1_CC = "We're sorry. The instant rebate for this item is not available in your area, which has increased this item's price.";
	public String InstantRebateEligMsg2_CC="Good news! Instant rebates are available in your area, which has decreased these items' prices.";
	public String InstantRebateIneligMsg2_CC = "We're sorry. The instant rebates for these items are not available in your area, which has increased these items' prices.";
	public String InstantRebateEligMsg3_CC="Good news! An instant rebate with a greater discount is available in your area.";
	public String InstantRebateEligMsg4_CC = "An instant rebate is still available in your area, but at a lower discount.";
	public String InstantRebateEligMsg_ATC = "Good news! An instant rebate is available in your area.";
	public String InstantRebateIneligMsg_ATC = "The instant rebate is not available in your area.";
	public boolean mixedcart = false;
	public String guestUserNameAndShipAddressStored;
	
	public String storeNO;
	public String storeNAME;
	public String strRoom;
	public String strtotal;
	public String promovalue;
	public double doubMerchandiseSubTotalCart;
	public double doubSubtTotalCart;
	public double doubShipChargesCart;
	public double doubEstimatedTaxCart;
	public double doubEstimatedTotalCart;
	public double doubPickupTotalCart;
	public double doubApplianceDeliveryCart;
	public double doubApplianceSubtotalCart;
	public double doubtotalCart;
	public double doubYouSavedCart;
	public double finalDiscountTotalcart;
	public String strpayauthId;
	public String strxrefnbr;
	public int totalItems;
	public String cartStoreName;
	public String strPrice;
	public String cartStatecity;
	public String strEstimatedSalesTaxValue;
	public String taxAmount;
	public String strFromPrice;
	public String strShipExp;
	public String strshipprice;
	public String strTotalWithPromo;
	public String strTotalWithoutPromo;
	public String selectedCity;
	public ArrayList<String> strDateAndTime;
	public ArrayList<String> strDateAndTime2;
	public String strEstTotal;
	public boolean shipmuladdcheck = false;
	public ArrayList<String> StoreList1 = new ArrayList<String>();
	
	// **********End of Instant Rebate data**********//

	public enum PLPProdSearchType {
		productID, modelno, profield;
	}

	public enum ProductType {

		OnlineOnlyShipHome, BOSS, BOPIS, BODFS, Blinds, BSS, Shared, STH, Appliance, BODFSOnly;
	}

	public enum ShippingType {

		ShipToHome, PickUpInStore, ShipToStore;
	}

}
