package com.homer.dao;
import java.util.List;

public class CurrentRun {

	public static List<String> lstCommonDynamicData;
}
