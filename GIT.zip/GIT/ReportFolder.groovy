import jenkins.model.*;
import hudson.model.*;
def folderName = "TestRun_2016-05-18_10-58-19-AM";
def pa = new ParametersAction([
new StringParameterValue("FOLDERNAME_QA_JOB", folderName)
])
Thread.currentThread().executable.addAction(pa);