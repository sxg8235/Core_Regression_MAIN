package com.homer.dao;

public class DataColumn {
	
	public static final String SubIteration = "SubIteration";
	public static String TaxExemptNum = "TaxExemptNum";
	public static String Keyword = "Keyword";
	public static String SKU = "SKU";
	public static String FlyoutCat = "FlyoutCat";
	public static String FlyoutSubCat = "FlyoutSubCat";
	public static String FlyoutAlt = "FlyoutAlt";	
	public static String CityStateZipCode = "CityStateZipCode";
	public static String UserType = "UserType";
	public static String Order = "Order";
	public static String Credit = "Credit";
	public static String Gift = "Gift";
	public static String Status = "Status";
	public static String LocalizeStore = "LocalizeStore";
	public static String PromoCode = "PromoCode";
	public static String ChangeZipCode="ChangeZipCode";
	public static String PersistedZipCode="PersistedZipCode";
	public static String ZipCode1="ZipCode1";
	public static String storeID = "storeID";
	public static String multistoreID = "multistoreID";
	public static String ShippingCharge = "ShippingCharge";
	public static String ShipMethod = "ShipMethod";
	public static String Quantity = "Quantity";
	public static String CardSecurityId = "CardSecurityId";
	public static String NewStore = "NewStore";
	public static String Regusername = "Regusername";
	public static String Regpwd = "Regpwd";
	public static final String ZipCode = "ZipCode";
	
	
	//HDPP related
	public static String HDPP = "HDPP";
	public static  String HDPPADDED = "HDPPADDED" ;
	public static String SKUPATH="SKUPATH";
	public static String SKUPATH1="SKUPATH1";
	public static String PlanPath="PlanPath";
	public static String PlanPath1="PlanPath1";
	public static String ProductID="ProductID";
	public static String PlanID="PlanID";
	public static String HDPP_PRICE = "HDPP_PRICE";
	public static String PLAN_ID="PLAN_ID";
	public static String PLAN_TXT_CART="PLAN_TXT_CART";
	public static String Guidance_Txt="Guidance_Txt";

	//One Page Checkout
		public static String Firstname = "Firstname";
		public static String Lastname ="LastName";
		
		//Instant Rebates
	
		public static String PayPalCity  = "PayPalCity";
		public static String PayPalState  = "PayPalState";
		public static String PayPalZip  = "PayPalZip";
	
}
