package com.homer.po;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.homer.dao.CheckoutConfig;
import com.homer.dao.CommonData;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.DataTable;
import com.homer.reports.Report;
import com.homer.resuablecomponents.ReusableComponents;
import com.homer.resuablecomponents.WebDriverHelper;

public class PageBase<CHILD extends PageBase<CHILD>> {

	protected InstanceContainer ic;
	protected WebDriver driver;
	protected WebDriverHelper wh;
	protected DataTable dataTable;
	protected ReusableComponents rc;
	protected Report report;
	protected CommonData commonData;

	protected boolean expectedResult;
	protected boolean isListViewSelected;

	protected static By pageTitle = By.className("page-title");
	protected static By searchTxtBox = By.xpath("//*[@id='headerSearch']");
	protected static By searchBtn = By.xpath("//*[@id='headerSearchButton']");

	protected static By verifyPLPPage = By.id("hd_plp");
	protected static By breadCrumbDiv = By.id("breadcrumb");

	protected static final By signInLink = By.xpath("//*[@id='authSignIn']//*[text()='Sign in']");
	protected static final By verifySignInPage = By.id("userLogin");
	protected static final By emailTxtBox = By.id("email_id");
	protected static final By passwordTxtBox = By.id("password");
	protected static final By signInBtn = By.id("signIn");
	protected static final By verifySignedInUser = By.cssSelector("#headerMyAccountTitle");
	protected static final By lnkSignOut = By.xpath(".//a[contains(text(),'Sign Out')]");
	protected static final By lnkSignIn = By.xpath("//span[contains(text(),'Sign in')]");
	protected static final By lnkMyAccount = By.id("headerMyAccount");

	protected static final By lnkStoreFinder = By.id("headerStoreFinder");
	protected static final By localStoreName = By.className("headerStore__name");
	protected static final By lnkYourAccount = By.xpath("//a[contains(.,'Your Account')]");
	protected static final By localStoreNameChangeStoreOverlay = By
			.xpath("//*[@id='sfYourStore']//span[@class='sfStoreName']");
	protected static final By closeBtnChangeStoreOverlay_tab = By
			.xpath("//span[contains(@class,'thdTablet-glyph-black-close')]");
	protected static final By changeStoreOverlay_tab = By.xpath("//*[contains(@class,'overlay-close-fancybox')]");
	protected static final By changeStoreLink_Tab = By
			.xpath("//a[@class='text-primary bold js-storefinder-change-store']");

	CheckoutConfig checkoutConfig = new CheckoutConfig();

	public PageBase(InstanceContainer ic) {

		this.ic = ic;
		this.driver = ic.driver;
		this.wh = ic.wh;
		this.rc = ic.rc;
		this.dataTable = ic.dataTable;
		this.report = ic.report;
		this.commonData = ic.commonData;
	}

	/**
	 * Method to search keyword
	 * 
	 * @return
	 * @throws Exception
	 */
	public PLPPage searchKeyword(String keyword) throws Exception {

		wh.sendKeys(searchTxtBox, keyword);
		// wh.clickElement(searchBtn);
		driver.findElement(searchTxtBox).sendKeys(Keys.ENTER);
		// addMCCparamter();

		expectedResult = (wh.isElementPresent(verifyPLPPage, 7) && wh.getText(breadCrumbDiv).contains(keyword)) ? true
				: false;

		if (expectedResult) {

			report.addReportStep("Search for keyword '" + keyword + "'",
					"Search PLP page for '" + keyword + "' is displayed", StepResult.PASS);

		} else {

			report.addReportStep("Search for keyword '" + keyword + "'",
					"Search PLP page for '" + keyword + "' is not displayed", StepResult.PASS);
		}

		return new PLPPage(ic);
	}

	/**
	 * Method to enter SKU
	 * 
	 * @param sku
	 * @return
	 * @throws Exception
	 */
	public PIPPage searchSkuNo(String sku) throws Exception {

		commonData.sku = sku;
		commonData.skuList.add(sku);
		
		if(!sku.equals("")){
			wh.sendKeys(searchTxtBox, sku);
		}
		else{
			report.addReportStep("Verify Data", "Data is Empty", StepResult.FAIL_TESTDATA);
			rc.terminateTestCase();
		}
		
		driver.findElement(searchTxtBox).sendKeys(Keys.ENTER);
		//wh.clickElement(searchBtn);

		wh.waitForPageLoaded();

		addMCCparamter();
		//Thread.sleep(commonData.littleWait);
		PIPPage pipPage = new PIPPage(ic);
		pipPage.getProdDescription();

		report.addReportStep("Type '" + sku + "' in search text box and click on search button",
				"Typed '" + sku + "' in search text box and clicked on search button", StepResult.PASS);

		String url = driver.getCurrentUrl();
		//wh.waitForPageLoaded();
		commonData.url = url;

		return new PIPPage(ic);
	}

	/**
	 * Method to sign In User
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public CHILD signInUser(String email, String password) throws Exception {

		wh.clickElement(lnkSignIn);
		wh.clickElement(signInLink);

		if (wh.isElementPresentAfterWait(verifySignInPage)) {

			report.addReportStep("Click on 'Sign in' link present on the top right side of the page",
					"Sign In page displayed successfully", StepResult.PASS);

			wh.sendKeys(emailTxtBox, email);
			wh.sendKeys(passwordTxtBox, password);
			wh.clickElement(signInBtn);
			
			wh.waitForPageLoaded();
			Thread.sleep(3000);

			if (wh.getText(verifySignedInUser).contains("Hello")) {

				report.addReportStep("Enter valid email address and Password and click on the 'Sign in' button.",
						"User name displayed on top right corner after successful login", StepResult.PASS);
			} else {

				report.addReportStep("Enter valid email address and Password and click on the 'Sign in' button.",
						"User did not get signed in successfully", StepResult.FAIL);
				rc.terminateTestCase("User Not Logged in ");
			}

		} else {
			report.addReportStep("Click on Sign In link", "Sign In page did not get displayed", StepResult.FAIL);
		}

		Thread.sleep(commonData.mediumWait);

		return (CHILD) this;

	}

	/*
	 * To verify sign in user
	 */
	@SuppressWarnings("unchecked")
	public CHILD verifySignInUser() throws Exception {

		if (wh.isElementPresentAfterWait(verifySignedInUser)) {

			report.addReportStep("Enter valid email address and Password and click on the 'Sign in' button.",
					"User is logged in and the user name is displayed on top right corner", StepResult.PASS);
		} else {

			String stepDesc = "";

			stepDesc = "User did not get signed in successfully";

			report.addReportStep("Enter valid email address and Password and click on the 'Sign in' button.", stepDesc,
					StepResult.FAIL);
			rc.terminateTestCase("Signed in User");
		}
		return (CHILD) this;
	}

	/**
	 * Component to sign out
	 * 
	 * @throws Exception
	 * 
	 * @FunctionName signOut
	 * @InputParameters None
	 * @Author Cognizant
	 * @DateCreated Jun 22, 2012, modified PXM8043 26-Jul-2013
	 */
	@SuppressWarnings("unchecked")
	public CHILD signOut() throws Exception {

		wh.waitForPageLoaded();
		String url = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);

		if (wh.isElementPresent(lnkMyAccount, 7)) {

			try {

				wh.clickElement(lnkMyAccount);
				String strSignout = wh.getAttribute(lnkSignOut, "href");
				wh.clickElement(lnkSignOut);
				driver.get(strSignout);
				wh.waitForPageLoaded();

				if (wh.isElementPresent(lnkSignIn)) {
					report.addReportStep("Click <b>SignOut </b>in header of the paeg.HD Home Page should appear",
							"<b>HD Home Page is displayed</b>", StepResult.PASS);
					if(rc.isProdEnvironment()){
						driver.get("http://www.homedepot.com");
					}
					else{
						driver.get(url);
					}
					
					wh.waitForPageLoaded();
				} else {
					report.addReportStep("Click <b>SignOut </b>in header of the paeg.HD Home Page should appear",
							"<b>HD Home Page is not displayed</b>", StepResult.WARNING);
				}
			} catch (Exception e) {
				report.addReportStep("Click <b>SignOut </b>in header of the paeg.HD Home Page should appear",
						"Unable to find the SignOut link", StepResult.FAIL);
				rc.terminateTestCase("User signout");
			}

		} else {
			report.addReportStep("Click <b>SignOut </b>in header of the paeg.HD Home Page should appear",
					"Unable to find the SignOut link", StepResult.FAIL);
			rc.terminateTestCase("User signout");
		}

		return (CHILD) this;

	}

	/*
	 * Method to sign in with invalid credentials
	 * 
	 */
	@SuppressWarnings("unchecked")
	public CHILD signInInvalidCredentials(String email, String password) throws Exception {

		wh.clickElement(lnkSignIn);
		wh.clickElement(signInLink);

		if (wh.isElementPresentAfterWait(verifySignInPage)) {

			report.addReportStep("Click on 'Sign in' link present on the top right side of the page",
					"Sign In page displayed successfully", StepResult.PASS);

			wh.sendKeys(emailTxtBox, email);
			wh.sendKeys(passwordTxtBox, password);
			wh.clickElement(signInBtn);

		} else {
			report.addReportStep("Click on Sign In link", "Sign In page did not get displayed", StepResult.FAIL);
		}

		return (CHILD) this;
	}

	/**
	 * Search keyword by specific SKU number
	 * 
	 * @return PLPPage
	 * @author YXG8356
	 * @throws Expception
	 * 
	 */
	public String SearchKeywordBySKU(String sku) throws Exception {

		PIPPage pipPage = new PIPPage(ic);
		pipPage.searchSkuNo(sku);

		String[] prodDetails = pipPage.getModelIdAndKeyword();
		if (prodDetails.length != 0) {

			// Search Keyword
			searchKeyword(prodDetails[0]);
		} else {
			report.addReportStep("Search for the Keyword", "No product details fetched", StepResult.FAIL);
			rc.terminateTestCase("PLP Page");
		}

		// Return Model ID
		return prodDetails[1];
		// return new PLPPage(ic);
	}

	/**
	 * Method to get Current local store
	 * 
	 * @return currentLocalStore
	 * @throws Exception
	 */
	public String getCurrentLocalStore() throws Exception {

		String localStrName = driver.manage().getCookieNamed("THD-LOC-STORE").getValue();

		/*
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("window.scrollBy(0,-550)", "");
		  wh.clickElement(lnkStoreFinder); wh.waitForPageLoaded();
		  
		  String localStrName = wh.getText(localStoreName);
		  
		  String[] arrStore = localStrName.split("#");
		  wh.clickElement(lnkStoreFinder); return arrStore[1];
		 */
		return localStrName;

	}

	/**
	 * To navigate MCC cart page
	 * 
	 * @throws Exception
	 */
	public void navigateMCCCart() throws Exception {

		if(rc.isProdEnvironment()){
			driver.get("http://www.homedepot.com/MCCCheckout/Cart/ViewCart.do");
		}
		else{
			driver.get(dataTable.getCommonData(CommonDataColumn.EnvironmentUrl) + "/MCCCheckout/Cart/ViewCart.do");
		}
	}

	/**
	 * Add MCC param
	 */
	public void addMCCparamter() {

		/*if (commonData.desktopUserAgent) {

			wh.waitForPageLoaded();
			wh.waitForPageLoaded();

			String currentURL = driver.getCurrentUrl();

			if (!currentURL.contains("mcc=true") && !currentURL.contains("MCCCheckout")) {

				if (currentURL.contains("?")) {
					driver.get(currentURL + "&mcc=true");
				} else {
					driver.get(currentURL + "?mcc=true");
				}

				wh.waitForPageLoaded();

			}
		}
*/
	}

}
