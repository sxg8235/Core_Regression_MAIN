package com.homer.po;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.taskdefs.Sleep;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;

public class PIPPage extends PageBase<PIPPage> {

	static final By verifyPIPPage = By.xpath("//div[@id='hd-pip' or @id='hd-bica']");
	static final By internetNo = By.id("product_internet_number");
	static final By addTocartBtn = By.cssSelector(".addToCart_btn.dynamic_btn.c");
	static final By verifyAddToCartModal = By
			.xpath("//*[contains(text(),'Added in Cart') or contains(text(),'Added to Cart')]");
	static final By checkOutNowBtn = By.id("editCartBtn");
	static final By applianceATCOverlay = By.xpath("//span[contains(text(),'Check Availability')]");
	static final By shipToStoreRadio = By.xpath("//*[contains(text(),'Ship to Store')]/div[@class='radio-custom']");
	static final By pickupInStoreRadio = By
			.xpath("//*[contains(text(),'Pick Up In Store')]/div[@class='radio-custom']");
	static final By bopisInStockText = By.cssSelector("div.c.itemInStock");
	static final By lnkChangeStoreBopis = By.id("bbChangeLocationBopis");
	static final By lnkChangeStoreBoss = By.id("bbChangeLocationBoss");
	static final By verifySmartOverlay = By.id("smartOverlay");
	static final By zipCodeTxt = By.id("bbDeliveryZipcode");
	static final By checkAvailBtn = By.xpath("//*[contains(@class,'dynamic_btn b c')]");
	static final By sthRadio = By.xpath("//label[@for='bboxShipToMeRadio']//div[contains(@class,'radio-custom')]");
	static final By bopisRadio = By.xpath("//label[@for='bboxPickUpInStoreRadio']/input[@type='radio']");
	static final By pipModelNumber = By.xpath("//*[@class='product_details modelNo']");
	static final By pipPrice = By.xpath("//*[contains(@class,'product_containerprice')]//*[@id='ajaxPrice']");
	static final By pipQty = By.id("buybox_quantity_field");
	static final By addToList = By.id("AddToList");
	static final By addToListPopUp = By.xpath("//a[contains(text(),'Create List')]");
	static final By addToListPopUpTab = By.id("createNewList");
	static final By shipToHomeTxt = By.id("bboxShipToMe");
	static final By PickUpInStoreText = By.id("bboxPickUpStoreText");
	static final By ShipToStoreText = By.id("bboxShipToStoreText");
	static final By expressDeliveryFromStoreTxt = By.id("bboxDelivery");
	static final By activeRadioBtn = By.xpath("//div[@class='radio-custom radio-custom-active']");
	static final By ChangePickUpInStore = By.id("bbChangeLocationBopis");
	static By certonaPIP = By.cssSelector("div.certona1main.grid");
	static By certonaAddToCartBtn = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]");
	static final By sbotdTitle = By.cssSelector("h1.page-title");
	static By sbotdAddToCartBtn = By.xpath("//a[@id='addToCartButton']/span[contains(text(),'Add to Cart')]");
	static final By prodTitle = By.xpath("//h1[@class='product_title']");
	static final By modelNo = By.cssSelector("h2.product_details.modelNo");
	static final By prodTitleBlinds = By.xpath("//h1[@class='bdc-product-name']");
	static final By STSLink = By.id("bbChangeLocationBoss");
	static final By ApplianceError = By.id("checkAvailableError");
	static final By appZipcode = By.xpath("//input[@id='zipCodeTxt']");
	static final By appCheckAvail = By.xpath("//*[@name='checkAvailability']");
	static final By changeZiperr = By.xpath("(//*//*[@class='product_Appl_BuyBox']//div[@class='error-msg c'])[3]");
	static final By TabletSmartOverlay = By.className("md-content");
	// Price related
	static final By skuPrice = By.cssSelector("div[class*='product_containerprice c'] span#ajaxPrice");
	static final By pricingDiv = By.cssSelector("div[class*='product_containerprice c']//div[@class='pricingReg']");
	static final By mapMsg = By.id("mapMessage");
	static final By wasPrice = By
			.xpath("//div[@class='pricingStrikeThru' and contains(text(),'Was')]//span[@id='ajaxPriceStrikeThru']");
	static final By applnATCPrice = By.cssSelector("div#applATCOverlayCol2 div[class='appl-price b item_price']");
	static final By specialBuyPrice = By.xpath(
			"//div[@class='pricingStrikeThru' and contains(text(),'Special Buy')]//span[@id='ajaxPriceStrikeThru']");
	static final By mapOriginalPrice = By.id("mapOriginalPrice");
	static final By mapMessage = By.id("mapMessage");

	static final By estDelPrice = By.xpath("//span[@class='estDeliveryPrice']");
	static final By shipToStoreTxt = By.id("bboxShipToStoreText");
	static final By certonaAddToCartLink = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]/..");

	static final By unitPriceSTH = By.xpath("//div[@class='offerprice']/*/*[@class='xlarge']");
	static final By strikeThroPrice = By.xpath("//span[@class='strike-through']");
	static final By pipqtyTxtBox = By.xpath("//*[@id='buybox_quantity_field']");
	static final By smartSearchInput = By.id("smrtSearchInput");
	static final By smartSearchBtn = By.xpath("//span[contains(text(),'SEARCH')]");
	static final By restrictedStateMsg = By.className("excludedShipStates");
	static final By zeroStockErrMsg = By
			.xpath("//div[contains(text(),'Sorry, this item is not in stock for delivery in this ZIP code')]");
	static By certonaAddToCartLinkAppl = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add to cart')]/..");
	static final By addPlanPIP = By.xpath("//div[@class='buy-box-hdpp__optin checkbox-custom']");
	static final By removePlanPIP = By
			.xpath("//div[@class='buy-box-hdpp__optin checkbox-custom checkbox-custom-active']");
	static final By saveTxt = By.xpath("//*[@id='savingsText']//p");
	static final By orderSample = By.xpath("//div[@class='bdc-product-choice-actions']/a");
	static final By sampleOverlay = By.xpath("//div[@id='cboxLoadedContent']");
	static final By continueShoppingSamples = By.xpath("//a[contains(text(),'Continue Shopping')]");

	static final By ETA = By.xpath("//div[@class='bbShipToMeMsg']");
	static final By FreeTextmessageforSTH = By.xpath("(//*[contains(@class,'bboxfreeShip')])[1]");
	static final By FreeTextmessageforBopis = By.xpath("(//*[contains(@class,'bboxfreeShip')])[2]");
	static final By pipPaypalBtn = By.id("pipPaypalCheckoutBtn");
	static final By Buybox = By.id("buyBox");
	static final By delUnavailErr = By.id("deliveryError1");
	static final By ShipOptionlink = By.xpath("//*[@id='shipping_options_link']");
	static final By OutOfstockMsg = By.xpath("//*[@class='productSoldLabel']");
	static final By AddToMyList = By.id("AddToList");

	// Recently viewed section
	static final By RVSection = By.xpath("//*[@class='RV_container_rr']");
	static final By RVrightarrow = By.xpath("//*[@class='RV_container_rr']//a[@class='slide-right']");
	static final By RVleftarrow = By.xpath("//*[@class='RV_container_rr']//a[@class='slide-left']");
	static final By RVviewmore = By.xpath("(//*[@class='RV_container_rr']//div[@class='show-more-btn-container'])[1]");
	static final By noProd = By.xpath("//*[@class='noProductsMsg']");
	static final By RVsimilarsection = By.xpath("//*[@class='RV_container_rr rv2ShowMore rv2-container']");
	static final By RVsimilarclose = By.className("closeRVButton");
	static final By RvsimilarAddtocart = By
			.xpath("//*[@class='RV_container_rr rv2ShowMore rv2-container']//a//span[@class='plus']");
	static final By RVseconditem = By
			.xpath("(//*[@class='RV_container_rr']//div[@class='item_description_wrapper'])[2]");

	// IRG Section
	static final By IRGSection = By.xpath("//*[@class='row IRGsectionWrapper  in alpha omega']");
	static final By IRGSectionText = By
			.xpath("//*[@class='row IRGsectionWrapper  in alpha omega']/..//a[@class='header_bar on']");
	static final By IRGminus = By.xpath("//*[@class='plus_minus_icon']");
	static final By IRGmultiAdd = By.xpath("//*[@class='multiATC_btn dynamic_btn orange_btn c']");
	static final By IRGrightarrow = By.xpath("//*[@class='row IRGsectionWrapper  in alpha omega']//a[@class='next']");
	static final By IRGleftarrow = By.xpath("//*[@class='row IRGsectionWrapper  in alpha omega']//a[@class='prev']");
	static final By IRGprimarysku = By.xpath("(//*[@class='checkbox oneLine'])[1]");
	static final By IRGSku1select = By.xpath("(//*[@class='spad dynamic']//div[@class='control-group'])[1]");
	static final By IRGmultiATC = By.id("multiATCOverlay");
	static final By IRGmultiATCText = By.xpath("//*[@id='multiATCOverlay']//p");
	static final By IRGmultiATCCheckout = By.id("CartOverlayCheckoutId1");
	static final By IRGAddtocartgrey = By.xpath("//*[@class='multiATC_btn dynamic_btn orange_btn c disable']");
	// change store overlay
	static final By clarificationMsg = By.xpath("//span[@class='small']");
	static final By tabletClarificationMsg = By.xpath("//*[@class='bopis-inventory module-normal text-muted xsmall ']");
	static final By storeDistnce = By.xpath("(//*[@class='storeInfo-Col storeInfo-ColMiles'])[1]");
	static final By tabletStoreDistance = By.xpath("//*[@class='distance']/..");
	static final By storeAddr = By.xpath("(//*[@class='storeInfo-Col last-Col'])[1]");
	static final By totalItems = By.id("smrtOvTotalItems");
	static final By tabletTotalItems = By.id("bopis-atc-total");
	static final By skuInfo = By.id("skuInformation");
	static final By tabletSkuInfo = By.id("bopis-title");
	static final By overlayClose = By.id("fancybox-close");
	static final By tabletOverlayClose = By.className("md-close");
	static final By prodType = By.xpath("(//div[@class='b storeInfo-ColHead'])[1]");
	static final By tabletProdType = By.xpath("//*[@class='bold small']");
	static final By prodStock = By.xpath("(.//div[@class='smrtOvNumInStock b'])[1]");
	static final By tabletProdStock = By.xpath("(//*[@class='bold text-muted bopis-instock-section'])[1]");
	static final By headerText = By.xpath("//*[@class='control-label large checkStores']");
	static final By tabletHeaderText = By.xpath("//*[@class='bold text-muted m-right-small']");
	boolean wasPriceDisplay;
	boolean specialBuyPriceDisplay;
	boolean effRTLPriceDisplay;
	boolean noWASPrice;
	boolean noSpecialBuyPrice;

	public PIPPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify PIP page
	 * 
	 * @throws Exception
	 */
	public PIPPage verifyPIPPage() throws Exception {

		if (wh.isElementPresent(verifyPIPPage, 2)) {

			report.addReportStep("Verify PIP page is displayed", "PIP page is displayed", StepResult.PASS);

		} else {

			report.addReportStep("Verify PIP page is displayed", "PIP page is not displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to verify PIP for SKU
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyPIPForSKU() throws Exception {

		String sku = commonData.sku;

		if (wh.getText(internetNo).contains(sku)) {

			report.addReportStep("Verify PIP page is displayed for SKU - " + sku,
					"PIP page for SKU '" + sku + "'is displayed", StepResult.PASS);
		} else {

			report.addReportStep("Verify PIP page is displayed for SKU - " + sku,
					"PIP page for SKU '" + sku + "'is not displayed", StepResult.PASS);
		}

		return this;
	}

	/**
	 * Method to click add to cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickAddToCart() throws Exception {

		if (wh.isElementPresent(addTocartBtn, 20)) {

			addMCCparamter();

			wh.clickElement(addTocartBtn);

		} else {

			report.addReportStep("On PIP page, add to cart button should display",
					"'Add to Cart' button was not displayed.", StepResult.FAIL);

			rc.terminateTestCase("PIP Add To Cart not displayed");
		}

		if (!wh.isElementPresent(verifyAddToCartModal, 10)) {

			report.addReportStep("Click on 'Add to Cart' button", "User is not navigated to checkout pop up.",
					StepResult.FAIL);

			rc.terminateTestCase("Add To Cart");
		}

		wh.clickElement(checkOutNowBtn);

		report.addReportStep("Click on check out now button", "Clicked on checkout now button", StepResult.PASS);

		return new ShoppingCartPage(ic);
	}

	/**
	 * Method to click add to cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay clickAddToCartButton() throws Exception {

		if (wh.isElementPresent(addTocartBtn, 20)) {

			addMCCparamter();

			wh.waitForPageLoaded();

			wh.clickElement(addTocartBtn);

		} else {

			report.addReportStep("On PIP page, add to cart button should display",
					"'Add to Cart' button was not displayed.", StepResult.FAIL);

			rc.terminateTestCase("PIP Add To Cart");
		}

		if (wh.isElementPresent(verifyAddToCartModal, 10) || wh.isElementPresent(applianceATCOverlay, 5)) {

			report.addReportStep("Click on 'Add to Cart' button",
					"Appliance check availability overlay or Added to Cart overlay is displayed", StepResult.PASS);

		} else {
			rc.terminateTestCase("Appliance Overlay or Add to Cart");
		}
		return new ATCOverlay(ic);
	}

	/**
	 * To click ShipToStore Radio button in PIP page
	 * 
	 * 
	 * @since May 29, 2013
	 * @author autotest
	 * @throws Exception
	 */
	public PIPPage clickShipToStoreRadio() throws Exception {

		if (wh.isElementPresent(shipToStoreRadio, 15)) {
			wh.clickElement(shipToStoreRadio);

			report.addReportStep("Click <b>ShipToStore</b> Radio button in the PIP Page",
					"<b>ShipToStore</b> Radio button is clicked ", StepResult.DONE);
		}

		else if (wh.isElementPresent(shipToStoreTxt)) {
			report.addReportStep("Click <b>ShipToStore</b> Radio button in the PIP Page",
					"<b>ShipToStore</b> Only Item dispayed in PIP page ", StepResult.DONE);
		}

		else {
			report.addReportStep("Click <b>ShipToStore</b> Radio button in the PIP Page",
					"<b>ShipToStore</b> Radio button not displayed ", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	/**
	 * To click Pick Up In Store Radio button in PIP page
	 * 
	 * 
	 * @since May 29, 2013
	 * @author autotest
	 * @throws Exception
	 */
	public PIPPage clickPickupInStoreRadio() throws Exception {

		if (wh.isElementPresent(By.id("bboxPickUpStore"), 15)) {

			if (wh.isElementPresent(pickupInStoreRadio)) {
				wh.clickElement(pickupInStoreRadio);
				report.addReportStep("Click <b>Pick Up In Store</b> Radio button in the PIP Page",
						"<b>Pick Up In Store</b> Radio button is clicked ", StepResult.DONE);
			} else {
				report.addReportStep("Verify <b>Pick Up In Store</b> in the PIP Page",
						"<b>Pick Up In Store</b> Only Item ", StepResult.DONE);
			}

			// verify the bopis inventory available
			if (wh.isElementNotPresent(bopisInStockText)) {
				report.addReportStep("Click <b>Pick Up In Store</b> Radio button in the PIP Page",
						"No Inventory available for bopis item", StepResult.FAIL);
				rc.terminateTestCase("PIP Page");
			}
		}

		else {
			report.addReportStep("Click <b>Pick Up In Store</b> Radio button in the PIP Page",
					"<b>Pick Up In Store</b> Option not available", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	/**
	 * 
	 */

	public boolean verifyExpectedFulfilment(String fulfilmentMethod) throws Exception {
		boolean expectedFM = false;

		if (fulfilmentMethod.equalsIgnoreCase("bopis")) {
			if (wh.isElementPresent(By.id("bboxPickUpStore"), 3)) {
				expectedFM = true;
			}
		} else if (fulfilmentMethod.equalsIgnoreCase("boss")) {
			if (wh.isElementPresent(shipToStoreRadio, 3)) {
				expectedFM = true;
			}
		} else if (fulfilmentMethod.equalsIgnoreCase("sth")) {

			if (wh.isElementPresent(shipToHomeTxt, 5)) {
				expectedFM = true;
			}

		}
		return expectedFM;
	}

	/**
	 * Method to click change pickup store and add to cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage changePicupStoreAddToCart() throws Exception {

		boolean changeStore = false;

		// Check change store link
		if (wh.isElementPresent(lnkChangeStoreBopis, 5)) {
			wh.clickElement(lnkChangeStoreBopis);

			// Verify Smart overlay
			if (wh.isElementPresent(verifySmartOverlay, 5)) {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS or BOPIS",
						"Change Pickup Store overlay is present", StepResult.PASS);

				String storeId = dataTable.getData(DataColumn.storeID);

				if (!storeId.equals("")) {

					// Enter Store id and click search
					wh.sendKeys(smartSearchInput, storeId);
					wh.clickElement(smartSearchBtn);
					wh.waitForPageLoaded();

					WebElement wElm = driver.findElement(By.id("localizedStore"));

					if (wElm.findElement(By.cssSelector(".smrtOvNumInStock.b")).getText().contains("IN STOCK")) {
						wElm.findElement(By.cssSelector(".input-mini.smrtQtyInp")).sendKeys("1");
						String alternateStore = wElm.findElement(By.cssSelector(".b.storeInfo-ColName")).getText();
						String[] arrStore = alternateStore.split("#");
						commonData.alternateStore = arrStore[1];
						changeStore = true;
					}

					else {
						report.addReportStep("Verify near by stores are displayed", "No instock in Near by stores",
								StepResult.FAIL);
						rc.terminateTestCase("Change PickUp Store overlay");
					}
				}

				else if (wh.isElementPresent(By.className("otherStores"), 5)) {

					List<WebElement> lstStore = driver.findElements(By.cssSelector(".otherStore-Row"));

					if (lstStore.size() > 1) {

						for (int i = 1; i < lstStore.size(); i++) {
							if (lstStore.get(i).findElement(By.cssSelector(".smrtOvNumInStock.b")).getText()
									.contains("IN STOCK")) {
								lstStore.get(i).findElement(By.cssSelector(".input-mini.smrtQtyInp")).sendKeys("1");
								String alternateStore = lstStore.get(i)
										.findElement(By.cssSelector(".b.storeInfo-ColName")).getText();
								String[] arrStore = alternateStore.split("#");
								commonData.alternateStore = arrStore[1];
								changeStore = true;
								break;
							}

							else {
								report.addReportStep("Verify near by stores are displayed",
										"No instock in Near by stores", StepResult.FAIL);
								rc.terminateTestCase("Change PickUp Store overlay");
							}
						}

					}

				}

				else {
					report.addReportStep("Verify near by stores are displayed", "No Near by stores", StepResult.FAIL);
					rc.terminateTestCase("Change PickUp Store overlay");
				}

				if (changeStore) {
					wh.clickElement(By.xpath("//button[contains(.,'ADD TO CART')]"));

					if (!wh.isElementPresent(verifyAddToCartModal, 10)) {

						report.addReportStep("Click on 'Add to Cart' button",
								"User is not navigated to checkout pop up.", StepResult.FAIL);

						rc.terminateTestCase("Add To Cart");
					}

					wh.clickElement(checkOutNowBtn);

					report.addReportStep("Click on check out now button", "Clicked on checkout now button",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify Changed Store", "Store not changed", StepResult.FAIL);
					rc.terminateTestCase("Change Store");
				}

			} else {
				report.addReportStep("Verify the change PickUpstore overlay for BOPIS",
						"Change Pickup Store overlay is not present", StepResult.FAIL);
				rc.terminateTestCase("Change PickUp Store overlay");
			}

		} else {
			report.addReportStep("Verify the change PickUpstore for BOPIS", "Change Pickup Store link is not present",
					StepResult.FAIL);
			rc.terminateTestCase("Change PickUp Store link");
		}

		return new ShoppingCartPage(ic);

	}

	/**
	 * Method to open new tab in browser
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage openNewTabAndLaunch() throws Exception {

		try {

			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
			ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
			driver.switchTo().window(tabs.get(1));

			driver.get(commonData.url);

			report.addReportStep("Open new tab and launch URL", "New tab opened and URL launched", StepResult.PASS);
		}

		catch (Exception ex) {
			report.addReportStep("Open new tab and launch URL", "New tab is not opened and URL not launched",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to click Shedule deliver radio button in tablet
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage clickTabletScheduleDeliveryRadioButton() throws Exception {
		if (wh.isElementPresent(By.xpath("//b[contains(.,'Express Delivery from Store')]"), 2)) {
			wh.clickElement(By.xpath("//b[contains(.,'Express Delivery from Store')]"));

			report.addReportStep("<b>Verify Schedule Delivery</b>Radio button should be selected.",
					"<b>Schedule Delivery</b> Radio button is selected", StepResult.PASS);

		} else if (wh.isElementPresent(By.xpath("//div[contains(.,'Express Delivery from Store')]"), 2)) {
			report.addReportStep("Verify<b> BODFS only</b>item is displayed", "<b>BODFS only</b> item is displayed",
					StepResult.PASS);
		}

		else {
			report.addReportStep("<b>Verify Schedule Delivery</b>Radio button should be selected.",
					"<b>Schedule Delivery</b> Radio button is not selected", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Method to Method to capture model#, item price, qty on pip page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public PIPPage CapturePipPageInfo() throws Exception {

		/* Capture Model Number */
		if (wh.isElementPresent(pipModelNumber)) {
			String[] aSplit = wh.getText(pipModelNumber).split("#");
			commonData.pipModelNumber = aSplit[1].trim();
		}

		/* Capture* Price */
		if (wh.isElementPresent(pipPrice)) {
			// commonData.pipPrice=wh.getText(pipPrice).trim();
			commonData.pipPrice = (wh.getText(pipPrice).replaceAll("\\$", "")).replaceAll(",", "").trim();
			commonData.pcpPrice = (wh.getText(pipPrice).replaceAll("\\$", "")).replaceAll(",", "").trim();

		}

		/* Capture* QTY */
		if (wh.isElementPresent(pipqtyTxtBox)) {
			commonData.pipQty = Integer.parseInt(wh.getAttribute(pipqtyTxtBox, "value").trim());
		}

		/* Capture* QTY */
		if (wh.isElementPresent(pipQty)) {
			commonData.pipQty = Integer.parseInt(wh.getAttribute(pipQty, "value").trim());
			commonData.pcpQuantity = Integer.parseInt(wh.getAttribute(pipQty, "value").trim());
		}

		/* Capture* Save price */
		if (wh.isElementPresent(saveTxt)) {
			String strsave = wh.getText(saveTxt).split(" ")[1];
			String strSavePrc = strsave.split(" ")[0];
			commonData.pipSave = strSavePrc;

		}

		return this;
	}

	/**
	 * Method to capture store info on pip page
	 * 
	 * @throws Exception
	 * @author RXP8655
	 */
	public PIPPage CaptureStoreInfo() throws Exception {

		/* Capture store info Number */
		String strStoreName = driver.findElement(By.xpath("//*[@class='buyBox-groupings']//p")).getText();
		// .split("#")[1].trim();
		commonData.strStoreselect = strStoreName;
		commonData.lstStoreNames.add(strStoreName.toUpperCase());
		System.out.println(commonData.strStoreselect);
		System.out.println(commonData.lstStoreNames);
		return this;
	}

	/**
	 * Method enter zip code in tablet for BODFS item
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage enterZipCodeTabletBODFSItem() throws Exception {
		String strZipCode = dataTable.getData("ZipCode");
		if (commonData.Zipcd != null) {
			strZipCode = commonData.Zipcd;
		}
		if (wh.isElementPresent(By.id("bbDeliveryZipcode"), 2)) {
			report.addReportStep("<b>Verify Check Availability </b>zipcode field Should be displayed in PIP page.",
					"<b>Check Availability </b>zipcode field is displayed ", StepResult.DONE);

			wh.sendKeys(zipCodeTxt, strZipCode);

			wh.clickElement(checkAvailBtn);

			report.addReportStep("<b>Verify <b>BODFS Zipcode </b>should be entered in PIP page.",
					"<b>Check <b>BODFS Zipcode </b>is entered", StepResult.PASS);
		} else {
			report.addReportStep("<b>Verify <b>BODFS Zipcode </b>should be entered in PIP page.",
					"<b>Check <b>BODFS Zipcode </b>is not entered", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify no radio button for STH in pip page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyNoRadioButtonSTHPIP() throws Exception {

		if (wh.isElementNotPresent(sthRadio)) {

			report.addReportStep("Verify that no Radio button is displayed in PIP Page for online only item",
					"Radio button is not displayed in PIP Page for online only item", StepResult.DONE);
		}

		else {
			report.addReportStep("Verify that no Radio button is displayed in PIP Page for online only item",
					"Radio button is displayed in PIP Page for online only item", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	/**
	 * Method to verify No Radio Button in BOPIS PIP
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyNoRadioButtonBOPISPIP() throws Exception {

		if (wh.isElementNotPresent(bopisRadio)) {

			report.addReportStep("Verify that no Radio button is displayed in PIP Page for bopis only item",
					"Radio button is not displayed in PIP Page for bopis only item", StepResult.DONE);
		}

		else {
			report.addReportStep("Verify that no Radio button is displayed in PIP Page for bopis only item",
					"Radio button is displayed in PIP Page for bopis only item", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	/**
	 * Method to click add to list button
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyListOverlay clickAddToListButton() throws Exception {

		if (wh.isElementPresent(addToList, 20)) {

			wh.clickElement(addToList);

		} else {

			report.addReportStep("On PIP page, Add to List button should display",
					"'Add to List' button was not displayed.", StepResult.FAIL);

			rc.terminateTestCase("PIP Add To List");
		}

		if (wh.isElementPresent(addToListPopUp, 5) || wh.isElementPresent(applianceATCOverlay, 5)) {

			report.addReportStep("Click on 'Add to List' button",
					"Add to List button is clicked and add to list pop up/Signin popup displayed", StepResult.PASS);
		} else if (wh.isElementPresent(addToListPopUpTab, 5) || wh.isElementPresent(applianceATCOverlay, 5)) {

			report.addReportStep("Click on 'Add to List' button",
					"Add to List button is clicked and add to list pop up/Signin popup displayed", StepResult.PASS);
		} else {
			rc.terminateTestCase("Add to list overlay");
		}
		return new MyListOverlay(ic);
	}

	/**
	 * Description-To click ShipToHome Radio button in PIP page
	 * 
	 * 
	 * @since OCT 26, 2015
	 * @author rsm8521
	 * @throws Exception
	 */
	public PIPPage clickShipToHomeRadioButton() throws Exception {
		if (wh.isElementPresent(sthRadio, 5)) {

			// String strSTHBtnDefault=wh.getText(activeRadioBtn);
			String strClass = wh.getAttribute(sthRadio, "class");

			if (strClass.contains("custom-active")) {
				report.addReportStep("<b>Verify Ship to Home</b>Radio button should be selected.",
						"<b>Ship to Home</b> Radio button is selected", StepResult.PASS);
			} else {
				wh.clickElement(sthRadio);
				report.addReportStep("<b>Verify Ship to Home</b> Radio button should be selected.",
						"<b>Ship to Home</b> Radio button is selected", StepResult.PASS);
			}

		} else if (wh.isElementPresent(shipToHomeTxt, 5)) {
			report.addReportStep("Verify<b> STH only</b> item is displayed", "<b>STH only</b> item is displayed",
					StepResult.PASS);
		}

		else {
			report.addReportStep("<b>Verify Ship to Home</b> Radio button should be selected.",
					"<b>Ship to Home</b> Radio button is not selected", StepResult.FAIL);
			rc.terminateTestCase("Ship to Home");
		}

		return this;

	}

	/**
	 * Function To validate the pip page for bodfs and sth item
	 * 
	 * @since Jan 8, 2013
	 * @author sxd8901 modified by raj8328 on Nov 12,2013
	 * @throws InterruptedException
	 */

	public void verifyPIPpageforBODFS_STHItem() throws Exception {

		if (wh.isElementPresent(expressDeliveryFromStoreTxt, 7) && wh.isElementPresent(shipToHomeTxt, 7)) {

			report.addReportStep("Verify <b>Ship to Home</b>, <b>Schedule Delivery</b> button is displayed in PIP page",
					"<b>Ship to Home</b>, <b>Schedule Delivery</b>button is displayed in PIP page", StepResult.PASS);

		} else {

			report.addReportStep("Verify <b>Ship to Home</b>, <b>Schedule Delivery</b> button is displayed in PIP page",
					"<b>Ship to Home</b>, <b>Schedule Delivery</b>button is not displayed in PIP page",
					StepResult.FAIL);

		}

	}

	/**
	 * Method to verify certona section in PIP
	 * 
	 * @return this
	 * @throws Exception
	 */
	public PIPPage verifyCertonaSectionPIP() throws Exception {
		Thread.sleep(5000);
		if (wh.isElementPresent(certonaPIP, 4)) {
			report.addReportStep("Verify <b>Certona</b> section is displayed", "<b>Certona</b> section is displayed",
					StepResult.PASS);

			String sku = null;
			if (wh.isElementPresent(certonaAddToCartLink)) {
				String href = wh.getAttribute(certonaAddToCartLink, "href");
				String[] href1 = href.split("catEntryId=");

				sku = href1[1].substring(0, 9);

			} else if (wh.isElementPresent(certonaAddToCartLinkAppl)) {
				sku = wh.getAttribute(certonaAddToCartLinkAppl, "data-prodid");
			}

			if (!sku.equals(null)) {
				commonData.sku = sku;
				commonData.skuList.clear();
				commonData.skuList.add(sku);
			}

		} else {
			report.addReportStep("Verify <b>Certona</b> section is displayed",
					"<b>Certona</b> section is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Certona Section");
		}
		return this;

	}

	/**
	 * Method to click Add to cart first item from certona section in PIP
	 * 
	 * @return this
	 * @throws Exception
	 */
	public PIPPage clickAddtoCartCertonaPIP() throws Exception {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,2250)", "");
		Thread.sleep(8000);
		if (wh.isElementPresent(certonaAddToCartBtn, 0)) {

			addMCCparamter();

			wh.clickElement(certonaAddToCartBtn);

			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is clicked in certona section", StepResult.PASS);

		} else {
			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is not clicked in certona section", StepResult.FAIL);
		}
		Thread.sleep(8000);
		return this;

	}

	/**
	 * Method to verify Special buy of the day page
	 * 
	 * @throws Exception
	 */
	public PIPPage verifySbotdPage() throws Exception {

		String url = driver.getCurrentUrl();
		driver.get(url + "&mcc=true");

		if (wh.isElementPresent(sbotdTitle, 2)) {

			String title = wh.getText(sbotdTitle);

			if (title.contains("Special Buy of the Day")) {

				report.addReportStep("Verify Special Buy of The Day page is displayed",
						"Special Buy of The Day page is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify Special Buy of The Day page is displayed",
						"Special Buy of The Day page is not displayed properly", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify Special Buy of The Day page is displayed",
					"Special Buy of The Day page is not displayed properly", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to click Add to cart first item from certona section in PIP
	 * 
	 * @return this
	 * @throws Exception
	 */
	public PIPPage clickAddtoCartSBOTD() throws Exception {
		Thread.sleep(commonData.littleWait);
		if (wh.isElementPresent(sbotdAddToCartBtn, 15)) {

			addMCCparamter();
			wh.clickElement(sbotdAddToCartBtn);

			report.addReportStep("Click Add to cart button in SBOTD section",
					"Add to cart button is clicked in SBOTD section", StepResult.PASS);

		} else {
			report.addReportStep("Click Add to cart button in SBOTD section",
					"Add to cart button is not clicked in SBOTD section", StepResult.FAIL);
		}
		Thread.sleep(commonData.littleWait);
		return this;

	}

	/**
	 * Get product description
	 * 
	 * @throws Exception
	 */
	public void getProdDescription() throws Exception {

		if (wh.isElementPresent(prodTitle)) {
			String productTitle = driver.findElement(prodTitle).getText().substring(0, 9);
			commonData.prodDescription = productTitle.trim();
			report.addReportStep("Verify whether the product description is retrived from cart page",
					"Product description is taken from cart page", StepResult.PASS);

		} else if (wh.isElementPresent(prodTitleBlinds)) {
			String productTitle = driver.findElement(prodTitleBlinds).getText().substring(0, 9);
			commonData.prodDescription = productTitle.trim();
			report.addReportStep("Verify whether the product description is retrived from cart page",
					"Product description is taken from cart page", StepResult.PASS);

		} else {
			report.addReportStep("Verify whether the product description is retrived from cart page",
					"Product description is not taken from cart page", StepResult.WARNING);
		}

	}

	/**
	 * Get Unit Price value Db
	 * 
	 * @throws Exception
	 */
	public void getUnitPriceValueDB() throws Exception {
		String unitPrice = "";

		commonData.unitPrice.put(commonData.prodDescription, unitPrice);

	}

	/**
	 * Method to get the model numbers and Keyword to assist PLP search
	 * 
	 * @return HashMap<String,String>
	 * @throws Exception
	 */
	public String[] getModelIdAndKeyword() throws Exception {
		String keyWord = "";
		// Get Model No
		String modelNumber = wh.getText(modelNo);

		if (!modelNumber.isEmpty()) {
			String[] arrModelNo = modelNumber.split("#");
			modelNumber = arrModelNo[1].trim();
			System.out.println(modelNumber);
		}

		try {
			// Get the Keyword for PLP search
			String productTitle = driver.findElement(prodTitle).getText();
			String[] arrProductDesc = StringUtils.split(productTitle);
			keyWord = arrProductDesc[0] + " " + arrProductDesc[1];

			if (keyWord.length() < 10) {
				keyWord = arrProductDesc[0] + " " + arrProductDesc[1] + " " + arrProductDesc[2];
				// keyWord = keyWord.substring(0, 12);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		System.out.println(keyWord);

		return new String[] { keyWord, modelNumber };
	}

	/**
	 * Method to verify Price or 'See final price in cart' message is displayed
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyPriceSection() throws Exception {
		String skuNumber = dataTable.getData("SKUNumber");
		verifyPriceDisplayed(skuNumber);

		if (!noWASPrice) {

			verifyWASPriceDisplayed(skuNumber);
		}

		return this;
	}

	/**
	 * Method to verify price is displayed or 'See final price in cart' message
	 * is displayed
	 * 
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyPriceDisplayed(String skuNumber) throws Exception {

		double price = rc.getPrice(skuPrice);
		String strPrice = new Double(price).toString();

		String cassandraPrice = "";
		String prodDescr = commonData.prodDescription;

		for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {
			if (prodDescr.contains(entry.getKey())) {
				cassandraPrice = entry.getValue();
				break;
			}
		}

		if (strPrice.equals(cassandraPrice) && !wh.getText(mapMsg).contains("Add to Cart to See Price")) {

			report.addReportStep(
					"Product price should be displayed and message 'See final price in cart' should not be displayed",
					"Product price is displayed and message 'See final price in cart' is not displayed",
					StepResult.PASS);
		}

		else if (wh.getText(mapMsg).contains("Add to Cart to See Price")) {

			report.addReportStep(
					"Product price should not be displayed and message 'See final price in cart' should be displayed",
					"Product price is not displayed and message 'See final price in cart' is displayed",
					StepResult.PASS);
		}

		else {

			report.addReportStep(
					"Product price should be displayed and message 'See final price in cart' should not be displayed",
					"Product price is not displayed as expected", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * replace
	 * 
	 * Method to verify was price is displayed or 'See final price in cart'
	 * message is displayed
	 * 
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyWASPriceDisplayed(String skuNumber) throws Exception {

		if (wh.isElementPresent(wasPrice)) {

			double price = rc.getPrice(wasPrice);

			if (Double.valueOf(price).equals(ic.wasPrice)
					&& !wh.getText(pricingDiv).contains("Add to Cart to See Price")) {

				report.addReportStep(
						"Product Was price should be displayed and message 'See final price in cart' should not be displayed",
						"Product Was price is displayed and message 'See final price in cart' is not displayed",
						StepResult.PASS);
			} else {

				report.addReportStep(
						"Product Was price should be displayed and message 'See final price in cart' should not be displayed",
						"Product Was price is not displayed as expected", StepResult.FAIL);
			}

		}

		else if (wh.isElementPresent(mapOriginalPrice) && wh.isElementPresent(mapMessage)) {

			String wasPrice = wh.getText(mapOriginalPrice).split("\\/")[0].replace("$", "").replace(",", "");

			if (Double.valueOf(wasPrice).equals(ic.wasPrice)
					&& wh.getText(mapMessage).contains("Add to Cart to See Price")) {

				report.addReportStep(
						"Product Was price should be displayed and message 'Add to Cart to see Price' should be displayed",
						"Product Was price is displayed and message 'SAdd to Cart to see Price' is displayed",
						StepResult.PASS);
			} else {

				report.addReportStep(
						"Product Was price should be displayed and message 'Add to Cart to see Price'  should  be displayed",
						"Product Was price and 'Add to Cart to See Price' message is not displayed as expected",
						StepResult.FAIL);
			}

		}

		else {

			if (wh.getText(mapMsg).contains("Add to Cart to See Price")) {

				report.addReportStep(
						"Product Was price should not be displayed and message 'See final price in cart' should be displayed",
						"Product Was price is not displayed and message 'See final price in cart' is displayed",
						StepResult.PASS);

			} else {

				report.addReportStep(
						"Product Was price should not be displayed and message 'See final price in cart' should be displayed",
						"Product Was price is not displayed as expected", StepResult.FAIL);
			}
		}

		return this;
	}

	/**
	 * To Add blinds to cart
	 * 
	 * @throws Exception
	 */

	public ShoppingCartPage addBlindsItemThroURL() throws InterruptedException {

		wh.ignorePopup(driver);

		String strCurrentEnvironment = HelperClass.baseModel.runEnvironment;
		String strSkuToSearch = dataTable.getData("SKU");
		// String strQuantity = dataTable.getData("Quantity");
		String strEnvirType = "";

		if (strCurrentEnvironment.contains("prod")) {
			strCurrentEnvironment = "homedepot.com";
		}

		else {
			strCurrentEnvironment = "hd-" + strCurrentEnvironment + ".homedepotdev.com";
		}
		if (strCurrentEnvironment.toLowerCase().contains("st")) {
			strEnvirType = "dev";
		} else {
			strEnvirType = "qa";
		}

		String strJumpURL;
		if (strCurrentEnvironment.contains("homedepot.com")) {
			strJumpURL = "https://blinds.homedepot.com/p/p/" + strSkuToSearch;

		} else {
			strJumpURL = "https://" + strEnvirType + "-blinds." + strCurrentEnvironment + "/p/p/" + strSkuToSearch + "";

		}

		try {
			driver.get(strJumpURL);
			report.addReportStep("Launch the link " + strJumpURL + "", "Link launch is triggered", StepResult.PASS);

			if (wh.isElementPresent(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big"), 15)) {
				/*
				 * String strConfigUrl = driver .findElement( By.xpath(
				 * "//*[@class='btn-shop-now' and contains(text(),'Shop Now')]"
				 * )) .getAttribute("href");
				 */

				try {
					// driver.get(strConfigUrl);
					report.addReportStep("Open the Blinds product information page", "The link is launched",
							StepResult.PASS);

					Thread.sleep(10000);
					boolean blnIsButtonFound = false;

					try {
						JavascriptExecutor js = null;
						if (driver instanceof JavascriptExecutor) {
							js = (JavascriptExecutor) driver;
						}

						try {
							new WebDriverWait(driver, 30).until(ExpectedConditions
									.elementToBeClickable(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big")));

							js.executeScript("arguments[0].click();",
									driver.findElement(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big")));
							report.addReportStep("CLick the 'Customize and Buy'button in the Product information page",
									"Button clicked", StepResult.PASS);
							blnIsButtonFound = true;
						} catch (Exception e) {
							js.executeScript("arguments[0].click();",
									driver.findElement(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big")));
							report.addReportStep("CLick the 'Customize and Buy'button in the Product information page",
									"Button clicked", StepResult.PASS);
							blnIsButtonFound = true;
						}

					} catch (Exception e) {
						blnIsButtonFound = false;
					}

					wh.ignorePopup(driver);

					if (blnIsButtonFound) {

						if (wh.isElementPresent(By.className("bdc-room-selector-item-image"), 15)) {
							try {
								driver.findElement(By.className("bdc-room-selector-item-image")).click();
								report.addReportStep("Click the first occuring room option", "Option selected",
										StepResult.PASS);

								if (wh.isElementPresent(
										By.xpath(
												"//section[@class='bdc-prdcfg-option bdc-prdcfg-option-mount']//div[@class='bdc-prdcfg-choice']"),
										7)) {
									try {
										driver.findElement(By
												.xpath("//section[@class='bdc-prdcfg-option bdc-prdcfg-option-mount']//div[@class='bdc-prdcfg-choice']"))
												.click();
										report.addReportStep("Click the first available mount option",
												"First available option selected", StepResult.PASS);

										if (wh.isElementPresent(
												By.xpath(
														"//section[@class='bdc-prdcfg-option bdc-prdcfg-option-with-color-swatches']//div[@class='bdc-choiceswatch']"),
												2)) {
											try {
												driver.findElement(By
														.xpath("//section[@class='bdc-prdcfg-option bdc-prdcfg-option-with-color-swatches']//div[@class='bdc-choiceswatch']"))
														.click();
												report.addReportStep("Click the first available Color option",
														"First available option selected", StepResult.PASS);

												// selectDefaultOoptions();

												Thread.sleep(5000);

												if (wh.isElementPresent(
														By.xpath("//button[contains(text(),'ORDER MY BLINDS')]"), 8)) {
													try {

														clickOrderMyBlindsButton();

														report.addReportStep("Click 'Order My blinds' button",
																"Button  clicked", StepResult.PASS);

													} catch (Exception e) {
														report.addReportStep("Click 'Order My blinds' button",
																"Button not clicked", StepResult.FAIL);
													}
												} else {
													report.addReportStep("Click 'Order My blinds' button",
															"Button not Found", StepResult.FAIL);
												}

											} catch (Exception e) {
												report.addReportStep("Click the first available Color option",
														"Failed to click", StepResult.FAIL);
											}
										} else {
											report.addReportStep("Click the first available Color option",
													"Unable to find the Color option", StepResult.FAIL);
										}

									} catch (Exception e) {
										report.addReportStep("Click the first available mount option",
												"Failed to click", StepResult.FAIL);
									}
								} else {
									report.addReportStep("Click the first available mount option",
											"Unable to find the Mount option", StepResult.FAIL);
								}

							} catch (Exception e) {
								report.addReportStep("Click the first occuring room option", "Option Not clicked",
										StepResult.FAIL);
							}
						} else {
							report.addReportStep("Click the first occuring room option", "Option Not found",
									StepResult.FAIL);
						}

					} else {
						report.addReportStep("Click the Buy Button from Blinds PIP page", "Unable to find the button",
								StepResult.FAIL);
					}

				} catch (Exception e) {
					report.addReportStep("Open the Blinds product information page", "The link is not launched",
							StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify that Buy now button is displayed in product search page",
						"Unable to find the button", StepResult.FAIL);
			}

		} catch (Exception e) {
			report.addReportStep("Launch the link " + strJumpURL + "", "Unable to launch the link", StepResult.FAIL);
		}

		Thread.sleep(commonData.smallWait);

		driver.get("http://" + strCurrentEnvironment + "/MCCCheckout/Cart/ViewCart.do");
		Thread.sleep(commonData.mediumWait);

		return new ShoppingCartPage(ic);

	}

	/**
	 * Component to click the order my blinds button in configurator page
	 * 
	 * @throws Exception
	 * 
	 * 
	 * 
	 */
	public boolean clickOrderMyBlindsButton() throws Exception {
		if (wh.isElementPresent(By.xpath("//button[contains(text(),'ORDER MY BLINDS')]"), 3)) {
			try {

				/*
				 * JavascriptExecutor js = null; if (driver instanceof
				 * JavascriptExecutor) { js = (JavascriptExecutor) driver; }
				 */
				wh.jsClick(By.xpath("//button[contains(text(),'ORDER MY BLINDS')]"));
				// js.executeScript("arguments[0].click();",
				// driver.findElement(By.xpath("//button[contains(text(),'ORDER
				// MY BLINDS')]")));

				/*
				 * driver.findElement(By.cssSelector(
				 * "button.btn-thd-action.wide" )) .click();
				 */

				Thread.sleep(commonData.LongWait);
				// return true;

				try {
					driver.switchTo().alert().accept();

					report.addReportStep(
							"Verify that there is no alert displayed after 'order my blinds' button is clicked",
							"Alert is displayed. Quiting the Test case", StepResult.FAIL);
					return false;
				} catch (Exception e) {
					report.addReportStep("Click 'Order My blinds' button", "'Order My blinds' buttonButton  clicked",
							StepResult.PASS);
					return true;
				}

			} catch (Exception e) {
				report.addReportStep("Click 'Order My blinds' button", "Button not clicked", StepResult.FAIL);
				return false;
			}

		} else {
			report.addReportStep("Click 'Order My blinds' button", "Button not Found", StepResult.FAIL);
			return false;
		}

	}

	/**
	 * Component to verify Bodfs only item in pip page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage verifyPIPpageforBODFSOnlyItem() throws Exception {
		if (wh.isElementPresent(By.xpath("//b[contains(.,'Express Delivery from Store')]"), 2)) {

			report.addReportStep("Verify<b> BODFS only</b>item is displayed", "Bodfs only item is not displayed",
					StepResult.FAIL);

		} else if (wh.isElementPresent(By.xpath("//div[contains(.,'Express Delivery from Store')]"), 2)) {
			report.addReportStep("Verify<b> BODFS only</b>item is displayed", "<b>BODFS only</b> item is displayed",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify<b> BODFS only</b>item is displayed", "Bodfs only item is not displayed",
					StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Method to get express del charge for BODFS item
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage getExpressDeliveryCharge() throws Exception {
		if (wh.isElementPresent(estDelPrice, 5)) {

			String estimatedDel = wh.getText(estDelPrice);
			String finalEstDel = estimatedDel.replace("As Low as $", "").trim();
			String finalEstDeli = finalEstDel.replace("per Order", "").trim();
			commonData.estDeliveryBODFS = finalEstDeli;
			report.addReportStep("<b>Verify <b>BODFS Zipcode </b>should be entered in PIP page.",
					"<b>Check <b>BODFS Zipcode </b>is entered", StepResult.PASS);
		} else {
			report.addReportStep("<b>Verify <b>BODFS Zipcode </b>should be entered in PIP page.",
					"<b>Check <b>BODFS Zipcode </b>is not entered", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Verify BOPIS Zero in stock
	 * 
	 * @throws Exception
	 */
	public void verifyBopisZeroInStockMsgPIP() throws Exception {

		if (wh.isElementPresent(By.xpath("//div[@class='c zeroInStock']"), 2)) {

			String inStockMsg = driver.findElement(By.xpath("//div[@class='c zeroInStock']")).getText();
			if (inStockMsg.contains("0 In stock at:")) {
				report.addReportStep("Verify that zero instock message is dispalyed in PIP page",
						"<b>" + inStockMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that zero instock message is dispalyed in PIP page",
						"Bopis message is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that zero instock message is dispalyed in PIP page",
					"Zero Instock message is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Method to click change pickup store and add to cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay changeShipToStorePIP() throws Exception {

		// Check change store link
		if (wh.isElementPresent(lnkChangeStoreBoss, 5)) {
			wh.clickElement(lnkChangeStoreBoss);

			// Verify Smart overlay
			if (wh.isElementPresent(verifySmartOverlay, 5)) {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS",
						"Change Ship to Store overlay is present", StepResult.PASS);

				if (wh.isElementPresent(By.className("otherStores"), 5)) {

					List<WebElement> lstStore = driver
							.findElements(By.cssSelector(".otherStore-Row.otherStore-OddRow"));

					if (lstStore.size() > 1) {

						// for(int i=1;i<lstStore.size();i++){
						// if(lstStore.get(i).findElement(By.cssSelector(".smrtOvNumInStock.b")).getText().contains("IN
						// STOCK")){
						lstStore.get(0).findElement(By.cssSelector(".input-mini.smrtQtyInp")).sendKeys("1");
						String alternateStore = lstStore.get(0).findElement(By.cssSelector(".b.storeInfo-ColName"))
								.getText();
						String[] arrStore = alternateStore.split("#");
						commonData.alternateStore = arrStore[1];
						// break;
						// }
						// }

						wh.clickElement(By.xpath("//button[contains(.,'ADD TO CART')]"));

						if (!wh.isElementPresent(verifyAddToCartModal, 10)) {

							report.addReportStep("Click on 'Add to Cart' button",
									"User is not navigated to checkout pop up.", StepResult.FAIL);

							rc.terminateTestCase("Add To Cart");
						}

					}

					else {
						report.addReportStep("Verify near by stores are displayed", "No instock in Near by stores",
								StepResult.FAIL);
						rc.terminateTestCase("Change PickUp Store overlay");
					}

				} else {
					report.addReportStep("Verify near by stores are displayed", "No Near by stores", StepResult.FAIL);
					rc.terminateTestCase("Change PickUp Store overlay");
				}

			}

			else if (wh.isElementPresent(TabletSmartOverlay, 5)) {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS",
						"Change Ship to Store overlay is present", StepResult.PASS);

				if (wh.isElementPresent(By.id("localizedStore"), 5)) {

					List<WebElement> lstStore = driver.findElements(By.xpath(
							"//*[@class='flex align-items-center module-normal border-bottom sborder border-default']"));

					if (lstStore.size() > 1) {

						// for(int i=1;i<lstStore.size();i++){
						// if(lstStore.get(i).findElement(By.cssSelector(".smrtOvNumInStock.b")).getText().contains("IN
						// STOCK")){
						lstStore.get(0)
								.findElement(By
										.xpath("//*[@class='quantity bopis-input bopis-qty sborder border-all border-secondary']"))
								.sendKeys("1");
						String alternateStore = lstStore.get(0)
								.findElement(By.xpath("//*[@class='storeInfo-Col last-Col']")).getText();
						String[] arrStore = alternateStore.split("#");
						commonData.alternateStore = arrStore[1];
						// break;
						// }
						// }
						wh.clickElement(By.xpath("//*[contains(text(),' ADD TO CART')]"));

						if (!wh.isElementPresent(verifyAddToCartModal, 10)) {

							report.addReportStep("Click on 'Add to Cart' button",
									"User is not navigated to checkout pop up.", StepResult.FAIL);

							rc.terminateTestCase("Add To Cart");
						}

					}

					else {
						report.addReportStep("Verify near by stores are displayed", "No instock in Near by stores",
								StepResult.FAIL);
						rc.terminateTestCase("Change PickUp Store overlay");
					}

				} else {
					report.addReportStep("Verify near by stores are displayed", "No Near by stores", StepResult.FAIL);
					rc.terminateTestCase("Change PickUp Store overlay");
				}

			} else {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS",
						"Change Ship to Store overlay is not present", StepResult.FAIL);
				rc.terminateTestCase("Change PickUp Store overlay");
			}

		} else {
			report.addReportStep("Verify the change PickUpstore for BOSS", "Change Ship to Store link is not present",
					StepResult.FAIL);
			rc.terminateTestCase("Change Ship to Store link");
		}

		return new ATCOverlay(ic);

	}

	/**
	 * increaseItemQtypipPage
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage increaseItemQtypipPage() throws Exception {

		if (wh.isElementPresent(pipqtyTxtBox, 7)) {

			String strQTY = wh.getAttribute(pipqtyTxtBox, "value");
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY + 1).toString();

			commonData.increasepipqty = strNewQty;

			wh.sendKeys(pipqtyTxtBox, strNewQty);
			Thread.sleep(2000l);
			driver.findElement(pipqtyTxtBox).sendKeys(Keys.TAB);
			Thread.sleep(2000l);

			if (wh.getAttribute(pipqtyTxtBox, "value").equals(strNewQty)) {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + strNewQty + "</b> displayed in shopping cart page",
						StepResult.PASS);
				wh.clickElement(pipqtyTxtBox);
				driver.findElement(pipqtyTxtBox).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + strNewQty + "</b> is not displayed in shopping cart page",
						StepResult.FAIL);
			}

		}

		return this;
	}

	/**
	 * clickAddToCartbtn
	 * 
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay clickAddToCartbtn() throws Exception {

		if (wh.isElementPresent(addTocartBtn, 20)) {

			addMCCparamter();
			wh.clickElement(addTocartBtn);
			Thread.sleep(4000);
			report.addReportStep("Verify add to cart button is clicked", "Add to cart button is clicked",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify add to cart button is clicked", "Add to cart button is not clicked",
					StepResult.FAIL);

		}
		return new ATCOverlay(ic);
	}

	/**
	 * increaseItemQtypipPage
	 * 
	 * @return
	 * @throws Exception
	 */
	public PIPPage enterQuantityInPIP() throws Exception {

		String strQTY = dataTable.getData(DataColumn.Quantity);

		if (strQTY.equals("")) {
			return this;
		}

		if (wh.isElementPresent(pipqtyTxtBox, 7)) {

			wh.sendKeys(pipqtyTxtBox, strQTY);

			driver.findElement(pipqtyTxtBox).sendKeys(Keys.TAB);

			if (wh.getAttribute(pipqtyTxtBox, "value").equals(strQTY)) {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + strQTY + "</b> displayed in shopping cart page",
						StepResult.PASS);
				wh.clickElement(pipqtyTxtBox);
				driver.findElement(pipqtyTxtBox).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + strQTY + "</b> is not displayed in shopping cart page",
						StepResult.FAIL);
			}

		}

		return this;
	}

	/**
	 * To click Pick Up In Store Radio button in PIP page
	 * 
	 * 
	 * @since May 29, 2013
	 * @author autotest
	 * @throws Exception
	 */
	public PIPPage clickPickupInStoreRadio_NoInvCheck() throws Exception {

		if (wh.isElementPresent(By.id("bboxPickUpStore"), 15)) {

			if (wh.isElementPresent(pickupInStoreRadio)) {
				wh.clickElement(pickupInStoreRadio);
				report.addReportStep("Click <b>Pick Up In Store</b> Radio button in the PIP Page",
						"<b>Pick Up In Store</b> Radio button is clicked ", StepResult.DONE);
			} else {
				report.addReportStep("Verify <b>Pick Up In Store</b> in the PIP Page",
						"<b>Pick Up In Store</b> Only Item ", StepResult.DONE);
			}

		}

		else {
			report.addReportStep("Click <b>Pick Up In Store</b> Radio button in the PIP Page",
					"<b>Pick Up In Store</b> Option not available", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	public PIPPage addPlanPIP() throws Exception {

		if (wh.isElementPresent(addPlanPIP, 5)) {
			wh.clickElement(addPlanPIP);

			report.addReportStep("Click Add Plan in the PIP Page", "Add Plan is clicked ", StepResult.PASS);
		}

		else {
			report.addReportStep("Click Add Plan in the PIP Page", "Add Plan is  not clicked ", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	public PIPPage removePlanPIP() throws Exception {

		if (wh.isElementPresent(removePlanPIP, 5)) {
			wh.clickElement(removePlanPIP);

			report.addReportStep("Remove Plan in the PIP Page", "Remove plan  is clicked ", StepResult.PASS);
		}

		else {
			report.addReportStep("Remove Plan in the PIP Page", "Remove Plan is  not clicked ", StepResult.FAIL);
			rc.terminateTestCase("PIP Page");
		}

		return new PIPPage(ic);
	}

	/**
	 * To verify the restricted msg in pip
	 * 
	 * @throws Exception
	 */
	public void verifyRestrictedStateMsgPIP() throws Exception {
		if (wh.isElementPresent(restrictedStateMsg, 2)) {
			String strMsg = driver.findElement(By.className("excludedShipStates")).getText();
			report.addReportStep("Verify the SKU having restricted shipping message in PIP Page",
					"Restricted shipping message: <b>" + strMsg + "</b> is displayed for the SKU in PIP Page",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify the SKU having restricted shipping message in PIP Page",
					"Restricted shipping message is not displayed for the SKU in PIP Page", StepResult.FAIL);
		}

	}

	/**
	 * To verify the zero in stock msg in pip
	 * 
	 * @throws Exception
	 */
	public void verifyZeroInStockBODFSPIP() throws Exception {
		if (wh.isElementPresent(zeroStockErrMsg, 2)) {
			String strMsg = wh.getText(zeroStockErrMsg);
			if (strMsg.contains("Sorry, this item is not in stock for delivery in this ZIP code")) {
				report.addReportStep("Verify zero in stock error msg for BODFS in PIP Page",
						"Zero in stock err msg: <b>" + strMsg + "</b> is displayed for the BODFS in PIP Page",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify zero in stock error msg for BODFS in PIP Page",
						"Zero in stock err msg: <b>" + strMsg + "</b> is not displayed for the BODFS in PIP Page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify zero in stock error msg for BODFS in PIP Page",
					"Zero in stock err msg is not displayed for the BODFS in PIP Page", StepResult.FAIL);
		}

	}

	/**
	 * Instant Rebate Component to change the pick up store based on the input
	 * in the storeID column in Instant Rebate Data sheet.
	 * 
	 * @author u93wcs
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay changePickupStoreAddToCart() throws Exception {
		boolean changeStore = false;

		// Check change store link
		if (wh.isElementPresent(lnkChangeStoreBopis, 5)) {
			wh.clickElement(lnkChangeStoreBopis);

			// Verify Smart overlay
			if (wh.isElementPresent(verifySmartOverlay, 5)) {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS or BOPIS",
						"Change Pickup Store overlay is present", StepResult.PASS);

				String storeId = dataTable.getData(DataColumn.storeID);
				if (!storeId.equals("")) {
					// Enter Store id and click search
					wh.sendKeys(smartSearchInput, storeId);
					wh.clickElement(smartSearchBtn);
					wh.waitForPageLoaded();
					Thread.sleep(commonData.smallWait);
					driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
							.sendKeys("1");
					changeStore = true;
					if (changeStore) {
						wh.clickElement(By.xpath("//button[contains(.,'ADD TO CART')]"));

						if (wh.isElementPresent(verifyAddToCartModal, 10)) {

							report.addReportStep("Click on 'Add to Cart' button",
									"User is  navigated to checkout pop up.", StepResult.PASS);
						} else {
							report.addReportStep("Click on 'Add to Cart' button",
									"User is not navigated to checkout pop up.", StepResult.FAIL);
							rc.terminateTestCase("Add To Cart");
						}
					}
				}
			} else if (wh.isElementPresent(TabletSmartOverlay, 5)) {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS or BOPIS",
						"Change Pickup Store overlay is present", StepResult.PASS);

				String storeId = dataTable.getData(DataColumn.storeID);
				if (!storeId.equals("")) {
					// Enter Store id and click search
					wh.sendKeys(smartSearchInput, storeId);
					wh.clickElement(smartSearchBtn);
					wh.waitForPageLoaded();
					Thread.sleep(commonData.smallWait);
					driver.findElement(By
							.xpath("(//input[contains(@class,'quantity bopis-input bopis-qty sborder border-all border-secondary')])[1]"))
							.sendKeys("1");
					changeStore = true;
					if (changeStore) {
						wh.clickElement(By.xpath("//*[@class='btn btn-primary bold btn-bopis']"));

						if (wh.isElementPresent(verifyAddToCartModal, 10)) {

							report.addReportStep("Click on 'Add to Cart' button",
									"User is  navigated to checkout pop up.", StepResult.PASS);
						} else {
							report.addReportStep("Click on 'Add to Cart' button",
									"User is not navigated to checkout pop up.", StepResult.FAIL);
							rc.terminateTestCase("Add To Cart");
						}
					}
				}
			}
		}
		return new ATCOverlay(ic);
	}

	public void addSampleFromBlinds() throws Exception {

		if (wh.isElementPresent(orderSample)) {
			wh.clickElement(orderSample);
			if (wh.isElementPresent(sampleOverlay)) {
				report.addReportStep("Verify order sample is added from blinds", "Order sample is added",
						StepResult.PASS);
			} else {

				report.addReportStep("Verify order sample is added from blinds", "Order sample is not added",
						StepResult.FAIL);

			}
		} else {
			report.addReportStep("Verify order sample is added from blinds", "Order sample not present",
					StepResult.FAIL);
		}

	}

	public void clickContinueShoppingForSamples() throws Exception {

		if (wh.isElementPresent(continueShoppingSamples)) {
			wh.clickElement(continueShoppingSamples);
			report.addReportStep("Click continue shopping in samples overlay", "Continue shopping link clicked",
					StepResult.PASS);

		} else {
			report.addReportStep("Click continue shopping in samples overlay", "Continue shopping link is not clicked",
					StepResult.FAIL);
		}

	}

	/**
	 * Instant Rebate Component to change the ship to store based on the input
	 * in the storeID column in Instant Rebate Data sheet.
	 * 
	 * @author vxr8162
	 * @return
	 * @throws Exception
	 */

	public ATCOverlay changeShipToStoreAddToCart() throws Exception {

		boolean changeStore = false;

		// Check change store link
		if (wh.isElementPresent(lnkChangeStoreBoss, 5)) {
			wh.clickElement(lnkChangeStoreBoss);

			// Verify Smart overlay
			if (wh.isElementPresent(verifySmartOverlay, 5)) {
				report.addReportStep("Verify the change PickUpstore overlay for BOSS or BOPIS",
						"Change Pickup Store overlay is present", StepResult.PASS);

				String storeId = dataTable.getData(DataColumn.storeID);

				if (!storeId.equals("")) {

					// Enter Store id and click search
					wh.sendKeys(smartSearchInput, storeId);
					wh.clickElement(smartSearchBtn);
					wh.waitForPageLoaded();
					Thread.sleep(commonData.smallWait);
					driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
							.sendKeys("1");

					changeStore = true;
					if (changeStore) {
						wh.clickElement(By.xpath("//button[contains(.,'ADD TO CART')]"));

						if (wh.isElementPresent(verifyAddToCartModal, 10)) {

							report.addReportStep("Click on 'Add to Cart' button",
									"User is  navigated to checkout pop up.", StepResult.PASS);

						}

						else

						{
							report.addReportStep("Click on 'Add to Cart' button",
									"User is not navigated to checkout pop up.", StepResult.FAIL);
							rc.terminateTestCase("Add To Cart");

						}

					}

				}
			}

		}
		return new ATCOverlay(ic);

	}

	public void addSampleFromBlinds1() throws Exception {

		if (wh.isElementPresent(orderSample)) {
			wh.clickElement(orderSample);
			if (wh.isElementPresent(sampleOverlay)) {
				report.addReportStep("Verify order sample is added from blinds", "Order sample is added",
						StepResult.PASS);
			} else {

				report.addReportStep("Verify order sample is added from blinds", "Order sample is not added",
						StepResult.FAIL);

			}
		} else {
			report.addReportStep("Verify order sample is added from blinds", "Order sample not present",
					StepResult.FAIL);
		}

	}

	public void clickContinueShoppingForSamples1() throws Exception {

		if (wh.isElementPresent(continueShoppingSamples)) {
			wh.clickElement(continueShoppingSamples);
			report.addReportStep("Click continue shopping in samples overlay", "Continue shopping link clicked",
					StepResult.PASS);

		} else {
			report.addReportStep("Click continue shopping in samples overlay", "Continue shopping link is not clicked",
					StepResult.FAIL);
		}

	}

	/**
	 * Function To validate the pip page for Bopis and sth item
	 * 
	 * @throws InterruptedException
	 */

	public void verifyPIPpageforBOPIS_STHItem() throws Exception {

		if (wh.isElementPresent(PickUpInStoreText, 7) && wh.isElementPresent(shipToHomeTxt, 7)) {

			report.addReportStep("Verify <b>Ship to Home</b>, <b>Pick Up in Store</b> button is displayed in PIP page",
					"<b>Ship to Home</b>, <b>Pick Up in Store</b>button is displayed in PIP page", StepResult.PASS);

		} else {
			report.addReportStep("Verify <b>Ship to Home</b>, <b>Pick Up in Store</b> button is displayed in PIP page",
					"<b>Ship to Home</b>, <b>Pick Up in Store</b>button is not displayed in PIP page", StepResult.FAIL);

		}

	}

	/**
	 * Component to verify Estimated arrival date for STH in PIP
	 * 
	 * @throws Exception
	 */

	public void verifyETAMsgForSTHInPIP() throws Exception {

		if (wh.isElementPresent(ETA, 5)) {
			String strETASTH = driver.findElement(ETA).getText();
			System.out.println("STH ETA" + strETASTH);
			report.addReportStep("Estimated Arrival date should be displayed",
					"<b>" + strETASTH + "</b> date is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Estimated Arrival date should be displayed",
					"Estimated Arrival date is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify Free text message for Ship to home and pick up in
	 * store labels in PIP
	 * 
	 * @throws Exception
	 */
	public void verifyFreeTextMsgForSharedBOPIS() throws Exception {
		if ((wh.isElementPresent(FreeTextmessageforSTH, 2)) && (wh.isElementPresent(FreeTextmessageforBopis, 2))) {
			report.addReportStep("Free text should be displayed for Ship to Home and Pick Up In Store labels ",
					"Free text is  displayed for Ship to Home and Pick Up In Store labels ", StepResult.PASS);
		} else {
			report.addReportStep("Free text should be displayed for Ship to Home and Pick Up In Store labels ",
					"Free text is not  displayed for Ship to Home and Pick Up In Store labels ", StepResult.FAIL);
		}
	}

	/**
	 * Component to click paypal in PIP page
	 * 
	 * @since Mar 08,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickPaypalButton() throws Exception {

		if (wh.isElementPresent(pipPaypalBtn)) {
			wh.clickElement(pipPaypalBtn);
			report.addReportStep("Verify paypal button is clicked in PIP", "Paypal button is clicked from PIP",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify paypal button is clicked in PIP", "Paypal button is not clicked from PIP",
					StepResult.FAIL);
		}

	}

	/**
	 * Function To validate the pip page for Boos and sth item
	 * 
	 * @throws InterruptedException
	 */

	public void verifyPIPpageforBOSS_STHItem() throws Exception {

		if (wh.isElementPresent(ShipToStoreText, 7) && wh.isElementPresent(shipToHomeTxt, 7)) {

			report.addReportStep("Verify <b>Ship to Home</b>, <b>Ship To Store</b> button is displayed in PIP page",
					"<b>Ship to Home</b>, <b>Ship To Store</b>button is displayed in PIP page", StepResult.PASS);

		} else {
			report.addReportStep("Verify <b>Ship to Home</b>, <b>Ship To Store</b> button is displayed in PIP page",
					"<b>Ship to Home</b>, <b>Ship To Store</b>button is not displayed in PIP page", StepResult.FAIL);

		}
	}

	/**
	 * Component to verify Ship to another store link in PIP
	 * 
	 * @throws Exception
	 */
	public void clickShipToAnotherStoreLink() throws Exception {
		if (wh.isElementPresent(STSLink, 5)) {
			wh.jsClick(STSLink);
			report.addReportStep("Ship to Store link should be displayed",
					"<b>Ship to Store link  </b>is clicked in PIP", StepResult.PASS);
		} else {
			report.addReportStep("Ship to Store link should be displayed", "Ship to Store link is not clicked in PIP",
					StepResult.PASS);
		}
	}

	/**
	 * Component to verify by default STH selected
	 * 
	 * @throws Exception
	 */
	public void verifyDefaultSTHBtnSelected() throws Exception {
		if (wh.isElementPresent(Buybox, 4)) {
			boolean blnIsSTHFound = false;
			try {

				/*
				 * blnIsSTHFound = driver .findElement( By.xpath(
				 * "//input[contains(@id,'shipHome') and @value='shipHome']"))
				 * .isSelected();
				 */
				blnIsSTHFound = driver.findElement(sthRadio).isSelected();
				System.out.println(blnIsSTHFound);
				if (blnIsSTHFound) {
					report.addReportStep("Verify that STH radio button is selected for a product",
							"STH option is selected", StepResult.PASS);
				}
			} catch (Exception e) {
				blnIsSTHFound = false;
			}

		} else {
			report.addReportStep("Buy box should be displayed", "Buy box is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * /** Description : Click on the Change link below pick up in store radio
	 * button Author: modified PXM8043
	 * 
	 * @throws Exception
	 */

	public void clickChangePickUpInStoreInPIP() throws Exception {
		if (wh.isElementPresent(ChangePickUpInStore, 5)) {
			try {

				wh.jsClick(ChangePickUpInStore);
				System.out.println("clicked");

				Thread.sleep(2000);
				report.addReportStep("Verify <b> Change Pick Up In Store </b> link is clicked in the PIP page",
						"<b>Change Pick Up In Store </b> link is clicked", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Verify <b> Change Pick Up In Store </b> link is clicked in the PIP page",
						"<b>Change Pick Up In Store </b> link is not clicked", StepResult.FAIL);

				commonData.blnGracefulExit = true;
			}

		} else {
			report.addReportStep("Verify <b> Change Pick Up In Store </b> link is clicked in the PIP page",
					"<b>Change Pick Up In Store </b> link is not clicked", StepResult.FAIL);
		}
	}

	/**
	 * verifying Error Message 'You can not order more than two of the same
	 * appliance!!!! if we add more than 2 LA items
	 * 
	 */
	public void verifyErrorMoreTwoAppliance() throws InterruptedException {
		String strZipCode = null;
		Thread.sleep(2000);
		String strErr = driver.findElement(ApplianceError).getText();
		String StrError = driver
				.findElement(By
						.xpath("//*[contains(text(),'Sorry, but only two of the same appliance may be purchased per order.')]"))
				.getText();
		System.out.println(strErr);
		if (strErr.contains("Sorry, but only two of the same appliance may be purchased per order.")
				|| StrError.contains("Sorry, but only two of the same appliance may be purchased per order.")) {
			report.addReportStep(
					"Error Message 'You can not order more than two of the same appliance!!!!' should be displayed",
					"<b>Error Message 'You can not order more than two of the same appliance!!!!'is displayed</b>",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"Error Message 'You can not order more than two of the same appliance!!!!' should be displayed",
					"Error Message 'You can not order more than two of the same appliance!!!!'is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to zipcode for appliacne item and verify error message
	 * 
	 * @throws Exception
	 */
	public void changeZipcodeAndVerifyErr() throws Exception {
		if (wh.isElementPresent(appZipcode, 5)) {
			String strZipCode = dataTable.getData("LocalizeStore");
			wh.clearElement(appZipcode);
			wh.sendKeys(appZipcode, strZipCode);
			wh.jsClick(appCheckAvail);
			Thread.sleep(1000);
			String strErr = wh.getText(changeZiperr);
			if (strErr.contains("All major appliances must be delivered to the same address.")) {
				report.addReportStep("Appliance zipcode error",
						"<b>Appliance zipcode error </b>" + strErr + " is displayed in PIP", StepResult.PASS);
			} else {
				report.addReportStep("Appliance zipcode error",
						"<b>Appliance zipcode error </b> is not displayed in PIP", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Appliance zipcode", "Appliance zipcode field is not displayed in PIP",
					StepResult.FAIL);
		}
	}

	public void verifyDeliveryUnavailableForBODFS() throws Exception {

		if (wh.isElementPresent(delUnavailErr)) {
			String errMsg = driver.findElement(delUnavailErr).getText().trim();
			if (errMsg.contains("Sorry, this item is not available for delivery in this ZIP code")) {
				report.addReportStep("Verify delivery unavailable error message is displayed",
						"Error message<b>" + errMsg + "</b>is  displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify delivery unavailable error message is displayed",
						"Error message<b>" + errMsg + "</b>is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify delivery unavailable error message is displayed",
					"Delivery unavailable error message is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify shipping option link for STH in PIP
	 * 
	 * @throws Exception
	 */
	public void verifyShippingOptLink() throws Exception {
		if (wh.isElementPresent(ETA, 3)) {
			String strShipLink = driver.findElement(ShipOptionlink).getText();
			System.out.println("STH Ship" + strShipLink);
			report.addReportStep("Shipping option link should be displayed",
					"<b>" + strShipLink + "</b> link is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Shipping option link should be displayed", "shipping option link is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to Verify the QTY box field for Out of Stock Items
	 * 
	 * @throws Throwable
	 * 
	 */
	public boolean verifyQtyboxFieldPresent() throws Throwable {
		boolean qtyField = wh.isElementPresent(pipqtyTxtBox, 4);
		if (!qtyField) {
			report.addReportStep("Qty Field ", "<b>QtyField is not displayed for Out of Stock Items</b>",
					StepResult.FAIL);
			return true;
		} else {
			report.addReportStep("Qty Field ", "QtyField is displayed for Out of Stock Items", StepResult.PASS);
			return false;
		}
	}

	/*
	 * Component to verify Out of stock message is displayed
	 */

	public void verifyOutOfStock() throws Exception {
		if (wh.isElementPresent(OutOfstockMsg, 4)) {
			report.addReportStep("Verify Out of Stock online message is displayed",
					"Out of stock online message is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify Out of Stock online message is displayed",
					"Out of stock online message is not displayed", StepResult.FAIL);
		}
	}

	/*
	 * Component to verify Add to My List is displayed
	 */

	public void verifyAddToMyList() throws Exception {
		if (wh.isElementPresent(AddToMyList, 4)) {
			report.addReportStep("Verify Add To My List is displayed", "Add To My List is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify Add To My List is displayed", "Add To My List is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify Recently viewed section in PIP page
	 * 
	 * @throws Exception
	 */
	public void verifyRVSection() throws Exception {
		boolean blnsize = false;
		if (wh.isElementPresent(RVSection, 3)) {
			// img, prod and rating section
			List<WebElement> lstimg = driver
					.findElements(By.xpath("//*[@class='RV_container_rr']//div[@class='product-image']"));
			List<WebElement> lstprod = driver
					.findElements(By.xpath("//*[@class='RV_container_rr']//div[@class='item_description_wrapper']"));
			List<WebElement> lstrating = driver
					.findElements(By.xpath("//*[@class='RV_container_rr']//div[@class='item_rating_wrapper']"));
			if (lstimg.size() == lstprod.size()) {
				blnsize = true;
			} else {
				report.addReportStep("Verify Recenty viewed section", "Size of Img and prod is not equal in RV section",
						StepResult.FAIL);
			}
			if (blnsize) {
				if (lstprod.size() == lstrating.size()) {
					report.addReportStep("Verify Recenty viewed section",
							"<b>" + lstprod.size() + "</b> Size of Img, prod and rating is equal in RV section",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify Recenty viewed section",
							"Size of Prod and Rating is not equal in RV section", StepResult.FAIL);
				}
			}
			// CTA link
			if (wh.isElementPresent(RVrightarrow) && wh.isElementPresent(RVleftarrow)) {
				report.addReportStep("Verify Recenty viewed section", "Right and left arrow is displayed in RV section",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Recenty viewed section",
						"Right and left arrow is not displayed in RV section", StepResult.FAIL);
			}
			// View more link
			List<WebElement> lstviewmore = driver
					.findElements(By.xpath("//*[@class='RV_container_rr']//div[@class='show-more-btn-container']"));
			report.addReportStep("verify view more link in RV section",
					"<b>" + lstviewmore.size() + "</b> view more link is displayed", StepResult.PASS);
			if (wh.isElementPresent(RVsimilarclose)) {
				wh.clickElement(RVsimilarclose);
			}
			int i = 1;
			for (WebElement ele1 : lstviewmore) {

				wh.clickElement(ele1);
				if (wh.isElementPresent(noProd)) {
					boolean strnoprod = wh.getText(noProd)
							.contains("We're sorry. We don't have suggestions for similar items.");
					report.addReportStep("verify similar item section in RV section",
							"We don't have suggestions for similar items.is displayed", StepResult.PASS);
				} else {
					if (wh.isElementPresent(RVsimilarsection)) {
						List<WebElement> lstsimilaritem = driver.findElements(By
								.xpath("//*[@class='RV_container_rr rv2ShowMore rv2-container']//div[@class='spad']"));
						List<WebElement> lstsimilaraddtocart = driver.findElements(By.xpath(
								"//*[@class='RV_container_rr rv2ShowMore rv2-container']//a//span[@class='plus']"));
						if (lstsimilaritem.size() == lstsimilaraddtocart.size()
								&& wh.isElementPresent(RVsimilarclose)) {

							report.addReportStep("verify similar item section under RV section",
									"<b>" + lstsimilaritem.size() + "</b> item is displayed with close button",
									StepResult.PASS);
						} else {
							report.addReportStep("verify similar item section under RV section",
									"similar items is not displayed with close button", StepResult.FAIL);
						}
					}
				}
				i++;
				if (i == 3)
					break;
			}

		} else {
			report.addReportStep("Verify Recenty viewed section", "Recenty viewed section is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to click prod description and navigate to PIP page from RV
	 * sction
	 * 
	 * @throws Exception
	 */
	public void clickProdInRVSection() throws Exception {
		if (wh.isElementPresent(RVSection, 3)) {
			String strprod = wh.getText(RVseconditem);
			wh.clickElement(RVseconditem);
			Thread.sleep(100);
			verifyPIPPage();
			getProdDescription();
			if (strprod.contains(commonData.prodDescription)) {
				report.addReportStep("Product description in RV section",
						"<b>" + strprod + "</b>  is clicked and moved to PIP Page", StepResult.PASS);
			} else {
				report.addReportStep("Product description in RV section", "Prod description is not clicked",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Shipping option link should be displayed", "shipping option link is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify IRG section in PIP page
	 * 
	 * @throws Exception
	 */
	public void verifyIRGSection() throws Exception {
		boolean blnsize = false;
		if (wh.isElementPresent(IRGSection, 3)) {
			// Heading
			String strheader = wh.getText(IRGSectionText);
			if (strheader.contains("COORDINATING ITEMS") || strheader.contains("ACCESSORIES")
					|| strheader.contains("COLLECTION")) {
				report.addReportStep("Verify IRG section", "<b>" + strheader + "</b> IRG section is displayed",
						StepResult.PASS);
			}
			// Expand and collapse
			if (wh.isElementPresent(IRGminus)) {
				wh.clickElement(IRGminus);
				if (wh.isElementNotPresent(IRGmultiAdd)) {
					report.addReportStep("Verify expand and collapse section",
							"<b>" + strheader + "</b> IRG section is collapsed", StepResult.PASS);
				}
				wh.clickElement(IRGminus);
				if (wh.isElementPresent(IRGmultiAdd)) {
					report.addReportStep("Verify expand and collapse section",
							"<b>" + strheader + "</b> IRG section is expanded", StepResult.PASS);
				}
			}
			// img, prod and rating section
			List<WebElement> lstprod = driver.findElements(
					By.xpath("//*[@class='row IRGsectionWrapper  in alpha omega']//*[@class='spad dynamic']"));
			List<WebElement> lstimg = driver.findElements(
					By.xpath("//*[@class='row IRGsectionWrapper  in alpha omega']//*[@class='product-image']"));
			List<WebElement> lstpricing = driver
					.findElements(By.xpath("//div[@class='sliderContainer']//div[@class='irgPricing']"));
			List<WebElement> lstreviews = driver
					.findElements(By.xpath("//div[@class='sliderContainer']//*[@class='productReviews b']"));

			if (lstprod.size() == lstimg.size() && lstimg.size() == lstpricing.size()
					&& lstpricing.size() == lstreviews.size() && lstreviews.size() == lstprod.size()) {
				report.addReportStep("verify prod in IRG section",
						"<b>" + lstprod.size() + "products is displayed in IRG section with img,pricing and Reviews",
						StepResult.PASS);
			} else {
				report.addReportStep("verify prod in IRG section", "Products are not displayed properly in IRG",
						StepResult.FAIL);
			}
			// CTA link
			if (wh.isElementPresent(IRGrightarrow)) {
				report.addReportStep("Verify IRG section", "Right arrow is displayed in IRG section", StepResult.PASS);
			} else {
				report.addReportStep("Verify Recenty viewed section", "Right arrow is not displayed in IRG section",
						StepResult.FAIL);
			}
			wh.clickElement(IRGrightarrow);
			if (wh.isElementPresent(IRGleftarrow)) {
				report.addReportStep("Verify IRG section", "Left arrow is displayed in IRG section", StepResult.PASS);
				wh.clickElement(IRGleftarrow);
			}

			// Add to cart button greyed out
			String strorange = wh.getCssValue(IRGmultiAdd, "color");
			System.out.println(strorange);
			if (strorange.contains("rgba")) {
				report.addReportStep("verify Add to cart in orange color",
						"<b>" + strorange + "</b> Add to cart is in orange color", StepResult.PASS);
			} else {
				report.addReportStep("verify Add to cart in orange color", "Add to cart is not in orange color",
						StepResult.FAIL);
			}
			wh.clickElement(IRGprimarysku);
			boolean grey = wh.isElementPresent(IRGAddtocartgrey);
			if (grey)
				report.addReportStep("verify Add to cart greyed out", "Add to cart is greyed out", StepResult.PASS);
			wh.clickElement(IRGprimarysku);
			// Add multiple item to cart
			wh.clickElement(IRGSku1select);
			wh.clickElement(IRGmultiAdd);
			if (wh.isElementPresent(IRGmultiATC)) {
				String strtext = wh.getText(IRGmultiATCText);
				report.addReportStep("Verify IRG multi ATC overlay",
						"<b>" + strtext + "</b> is displayed in ATC overlay", StepResult.PASS);
			} else {
				report.addReportStep("Verify IRG multi ATC overlay", "Item is not added to cart", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Recenty viewed section", "Recenty viewed section is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to click checkout in IRG multi ATC overlay
	 * 
	 * @since Mar 08,2016
	 * @author RXP8655
	 * @throws Exception
	 */
	public void clickCheckoutInMultiATC() throws Exception {

		if (wh.isElementPresent(IRGmultiATCCheckout)) {
			wh.clickElement(IRGmultiATCCheckout);
			report.addReportStep("Verify checkout button", "checkout button is clicked from IRG multi ATC overlay",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify checkout button", "checkout button is not clicked from IRG multi ATC overlay",
					StepResult.FAIL);
		}

	}

	/**
	 * Method to verify delivery price retained in cart and pip page
	 * 
	 * @throws Exception
	 */
	public PIPPage verifyPriceRetained() throws Exception {
		if (wh.isElementPresent(estDelPrice, 5)) {

			String estimatedDel = wh.getText(estDelPrice);
			String finalEstDel = estimatedDel.replace("As Low as $", "").trim();
			String finalEstDeli = finalEstDel.replace("per Order", "").trim();
			commonData.estDeliveryBODFS = finalEstDeli;
			report.addReportStep("<b>Verify <b>BODFS Zipcode </b>should be entered in PIP page.",
					"<b>Check <b>BODFS Zipcode </b>is entered", StepResult.PASS);
			if (commonData.strDeliveryPrice.contains(commonData.estDeliveryBODFS)) {
				report.addReportStep("verify delivery price retained",
						"<b>" + finalEstDeli + "</b> Delivery price is retained", StepResult.PASS);
			} else {
				report.addReportStep("verify delivery price retained", "Delivery price differs in cart and pip page",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("<b>Verify <b>BODFS Zipcode </b>should be entered in PIP page.",
					"<b>Check <b>BODFS Zipcode </b>is not entered", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Component to verify the the default information displayed for a localized
	 * user on the BOPIS overlay page
	 * 
	 * 
	 * @since Jan 4, 2013
	 * @author BXB8917
	 * @throws Exception
	 */
	public void verifyClarificationMsginBOPISoverlay() throws Exception {
		boolean tablet = HelperClass.baseModel.tabletMode;

		if (!tablet) {
			if (wh.isElementPresent(clarificationMsg)) {

				String strmsg = wh.getText(clarificationMsg);
				System.out.println(clarificationMsg);
				if (strmsg.contains("We do our best to update store pricing and inventory amounts as they change.")) {
					report.addReportStep(
							"User verifies the <b>Localized user </b>to see <b>Legal clarification message and timestamp </b>in the BOPIS Overlay page",
							"Clarification message and timestamp is displayed <b>" + strmsg
									+ " </b>in the BOPIS Overlay page",
							StepResult.PASS);
				} else {
					report.addReportStep(
							"User verifies the <b>Localized user </b>to see <b>Legal clarification message and timestamp </b>in the BOPIS Overlay page",
							"Clarification message and timestamp is not displayed <b>" + strmsg
									+ " </b>in the BOPIS Overlay page",
							StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify BOPIS overlay", "Bopis overlay is not displayed", StepResult.FAIL);
			}
		}
		// Tablet
		if (tablet) {
			if (wh.isElementPresent(tabletClarificationMsg)) {

				String strmsg = wh.getText(tabletClarificationMsg);
				System.out.println(tabletClarificationMsg);
				if (strmsg.contains("We do our best to update store pricing and inventory amounts as they change.")) {
					report.addReportStep(
							"User verifies the <b>Localized user </b>to see <b>Legal clarification message and timestamp </b>in the BOPIS Overlay page",
							"Clarification message and timestamp is displayed <b>" + strmsg
									+ " </b>in the BOPIS Overlay page",
							StepResult.PASS);
				} else {
					report.addReportStep(
							"User verifies the <b>Localized user </b>to see <b>Legal clarification message and timestamp </b>in the BOPIS Overlay page",
							"Clarification message and timestamp is not displayed <b>" + strmsg
									+ " </b>in the BOPIS Overlay page",
							StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify BOPIS overlay", "Bopis overlay is not displayed", StepResult.FAIL);
			}
		}

		driver.switchTo().defaultContent();
	}

	/**
	 * Component to verify the list of content present in the Check store
	 * Overlay
	 * 
	 * @throws Exception
	 */
	public void verifyBopisOverlayContents() throws Exception {

		driver.switchTo().defaultContent();
		boolean tablet = HelperClass.baseModel.tabletMode;

		if (!tablet) {
			if (wh.isElementPresent(verifySmartOverlay)) {

				try {
					if (wh.isElementPresent(smartSearchInput)) {
						report.addReportStep("Verify Zipcode field is displayed in overlay  ",
								"<b>Zipcode field</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Zipcode field is displayed in overlay ",
								"<b>Zipcode field</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Search field is displayed in overlay ",
							"<b>Zipcode field</b> is not displayed in overlay", StepResult.FAIL);
				}

				try {
					if (wh.isElementPresent(smartSearchBtn)) {
						report.addReportStep("Verify Search button is displayed in overlay  ",
								"<b>Search button</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Search button is displayed in overlay ",
								"<b>Search button</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Search button is displayed in overlay ",
							"Search button is not displayed in overlay", StepResult.FAIL);
				}

				String strDist = wh.getText(storeDistnce);
				System.out.println(strDist);
				try {
					if (wh.isElementPresent(storeDistnce)) {
						report.addReportStep(
								"Verify Store distance away from current zipcode  is displayed in overlay  ",
								"<b>Store distance: " + strDist + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep(
								"Verify Store distance away from current zipcode  is displayed in overlay  ",
								"<b>Store distance: " + strDist + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Store distance away from current zipcode  is displayed in overlay  ",
							"Unable to find the Store distance in overlay", StepResult.FAIL);
				}

				String strAddr = wh.getText(storeAddr);
				System.out.println(strAddr);
				try {
					if (wh.isElementPresent(storeAddr)) {
						report.addReportStep("Verify Store Address is displayed in overlay  ",
								"<b>Store Address: " + strAddr + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Store Address is displayed in overlay  ",
								"<b>Store Address: " + strAddr + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Store Address is displayed in overlay  ",
							"Store Address is not displayed in overlay", StepResult.FAIL);
				}

				String strTot = wh.getText(totalItems);
				System.out.println(strTot);
				try {
					if (wh.isElementPresent(totalItems)) {
						report.addReportStep("Verify Quantity is displayed in overlay  ",
								"<b>Quantity:" + strTot + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Quantity is displayed in overlay  ",
								"<b>Quantity: " + strTot + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify Quantity is displayed in overlay  ", "Unable to find Quantity in overlay",
							StepResult.FAIL);
				}

				String strSkuInfo = wh.getText(skuInfo);
				System.out.println(strSkuInfo);
				try {
					if (wh.isElementPresent(skuInfo)) {
						report.addReportStep("Verify Sku Information is displayed in overlay  ",
								"<b>Sku Information: " + strSkuInfo + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Sku Information is displayed in overlay  ",
								"<b>Sku Information: " + strSkuInfo + "</b> is not displayed in overlay",
								StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify Sku Information is displayed in overlay  ",
							"Unable to find Sku Information in overlay", StepResult.FAIL);
				}

				try {
					if (wh.isElementPresent(overlayClose)) {
						report.addReportStep("Verify Close Button  is displayed in overlay  ",
								"Close Button is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Close Button is displayed in overlay  ",
								"Close Button is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep("Verify Close Button is displayed in overlay  ",
							"Unable to find close Button is not displayed in overlay", StepResult.FAIL);
				}

				String strProdtype = wh.getText(prodType);
				System.out.println(strProdtype);
				try {
					if (wh.isElementPresent(prodType)) {
						report.addReportStep("Verify Product Type is displayed in overlay  ",
								"<b>Product Type: " + strProdtype + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Product Type is displayed in overlay  ",
								"<b>Product Type: " + strProdtype + "</b> is not displayed in overlay",
								StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify Sku Information is displayed in overlay  ",
							"Unable to find Product Type in overlay", StepResult.FAIL);
				}

				String strInstock = wh.getText(prodStock);
				System.out.println(strInstock);
				try {
					if (wh.isElementPresent(prodStock)) {
						report.addReportStep("Verify InStock message is displayed in overlay  ",
								"<b>Store has : " + strInstock + "</b> message is displayed in overlay",
								StepResult.PASS);

					} else {
						report.addReportStep("Verify Product Type is displayed in overlay  ",
								"<b>Store has : " + strInstock + "</b> message is not displayed in overlay",
								StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep("Verify Product Type is displayed in overlay  ",
							"Unable to find the Instock message  in overlay", StepResult.FAIL);
				}

				String strStrMsg = wh.getText(headerText);
				System.out.println(strStrMsg);
				try {
					if (wh.isElementPresent(headerText)) {
						report.addReportStep("Verify LocalStoreMsg message  is displayed in overlay  ",
								"<b>LocalStoreMsg: " + strStrMsg + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify LocalStoreMsg message is displayed in overlay  ",
								"<b>LocalStoreMsg: " + strStrMsg + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify  LocalStoreMsg message is displayed in overlay  ",
							"Unable to  LocalStoreMsg message in overlay", StepResult.FAIL);
				}
			}

			else {
				report.addReportStep(

						"Verify that the BOPIS overlay is displayed", "The overlay is not displayed", StepResult.FAIL);

			}
		}

		// Tablet mode

		if (tablet) {
			if (wh.isElementPresent(TabletSmartOverlay)) {

				try {
					if (wh.isElementPresent(smartSearchInput)) {
						report.addReportStep("Verify Zipcode field is displayed in overlay  ",
								"<b>Zipcode field</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Zipcode field is displayed in overlay ",
								"<b>Zipcode field</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Search field is displayed in overlay ",
							"<b>Zipcode field</b> is not displayed in overlay", StepResult.FAIL);
				}

				try {
					if (wh.isElementPresent(smartSearchBtn)) {
						report.addReportStep("Verify Search button is displayed in overlay  ",
								"<b>Search button</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Search button is displayed in overlay ",
								"<b>Search button</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Search button is displayed in overlay ",
							"Search button is not displayed in overlay", StepResult.FAIL);
				}

				String strDist = wh.getText(tabletStoreDistance);
				System.out.println(strDist);
				try {
					if (wh.isElementPresent(tabletStoreDistance)) {
						report.addReportStep(
								"Verify Store distance away from current zipcode  is displayed in overlay  ",
								"<b>Store distance: " + strDist + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep(
								"Verify Store distance away from current zipcode  is displayed in overlay  ",
								"<b>Store distance: " + strDist + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Store distance away from current zipcode  is displayed in overlay  ",
							"Unable to find the Store distance in overlay", StepResult.FAIL);
				}

				String strAddr = wh.getText(storeAddr);
				System.out.println(strAddr);
				try {
					if (wh.isElementPresent(storeAddr)) {
						report.addReportStep("Verify Store Address is displayed in overlay  ",
								"<b>Store Address: " + strAddr + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Store Address is displayed in overlay  ",
								"<b>Store Address: " + strAddr + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					report.addReportStep("Verify Store Address is displayed in overlay  ",
							"Store Address is not displayed in overlay", StepResult.FAIL);
				}

				String strTot = wh.getText(tabletTotalItems);
				System.out.println(strTot);
				try {
					if (wh.isElementPresent(tabletTotalItems)) {
						report.addReportStep("Verify Quantity is displayed in overlay  ",
								"<b>Quantity:" + strTot + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Quantity is displayed in overlay  ",
								"<b>Quantity: " + strTot + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify Quantity is displayed in overlay  ", "Unable to find Quantity in overlay",
							StepResult.FAIL);
				}

				String strSkuInfo = wh.getText(tabletSkuInfo);
				System.out.println(strSkuInfo);
				try {
					if (wh.isElementPresent(tabletSkuInfo)) {
						report.addReportStep("Verify Sku Information is displayed in overlay  ",
								"<b>Sku Information: " + strSkuInfo + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Sku Information is displayed in overlay  ",
								"<b>Sku Information: " + strSkuInfo + "</b> is not displayed in overlay",
								StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify Sku Information is displayed in overlay  ",
							"Unable to find Sku Information in overlay", StepResult.FAIL);
				}

				try {
					if (wh.isElementPresent(tabletOverlayClose)) {
						report.addReportStep("Verify Close Button  is displayed in overlay  ",
								"Close Button is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Close Button is displayed in overlay  ",
								"Close Button is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep("Verify Close Button is displayed in overlay  ",
							"Unable to find close Button is not displayed in overlay", StepResult.FAIL);
				}

				String strProdtype = wh.getText(tabletProdType);
				System.out.println(strProdtype);
				try {
					if (wh.isElementPresent(tabletProdType)) {
						report.addReportStep("Verify Product Type is displayed in overlay  ",
								"<b>Product Type: " + strProdtype + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify Product Type is displayed in overlay  ",
								"<b>Product Type: " + strProdtype + "</b> is not displayed in overlay",
								StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify Sku Information is displayed in overlay  ",
							"Unable to find Product Type in overlay", StepResult.FAIL);
				}

				String strInstock = wh.getText(tabletProdStock);
				System.out.println(strInstock);
				try {
					if (wh.isElementPresent(tabletProdStock)) {
						report.addReportStep("Verify InStock message is displayed in overlay  ",
								"<b>Store has : " + strInstock + "</b> message is displayed in overlay",
								StepResult.PASS);

					} else {
						report.addReportStep("Verify Product Type is displayed in overlay  ",
								"<b>Store has : " + strInstock + "</b> message is not displayed in overlay",
								StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep("Verify Product Type is displayed in overlay  ",
							"Unable to find the Instock message  in overlay", StepResult.FAIL);
				}

				String strStrMsg = wh.getText(tabletHeaderText);
				System.out.println(strStrMsg);
				try {
					if (wh.isElementPresent(tabletHeaderText)) {
						report.addReportStep("Verify LocalStoreMsg message  is displayed in overlay  ",
								"<b>LocalStoreMsg: " + strStrMsg + "</b> is displayed in overlay", StepResult.PASS);

					} else {
						report.addReportStep("Verify LocalStoreMsg message is displayed in overlay  ",
								"<b>LocalStoreMsg: " + strStrMsg + "</b> is not displayed in overlay", StepResult.FAIL);
					}
				} catch (Exception e) {

					report.addReportStep(

							"Verify  LocalStoreMsg message is displayed in overlay  ",
							"Unable to  LocalStoreMsg message in overlay", StepResult.FAIL);
				}
			}

			else {
				report.addReportStep(

						"Verify that the BOPIS overlay is displayed", "The overlay is not displayed", StepResult.FAIL);

			}
		}

	}

	/**
	 * To Add blinds to cart
	 *
	 * @throws Exception
	 */

	public void addBlinds() throws InterruptedException {

		wh.ignorePopup(driver);

		String strCurrentEnvironment = HelperClass.baseModel.runEnvironment;
		String strSkuToSearch = dataTable.getData("SKU");
		commonData.sku = strSkuToSearch;
		commonData.skuList.add(strSkuToSearch);
		String strEnvirType = "";

		if (strCurrentEnvironment.contains("prod")) {
			strCurrentEnvironment = "homedepot.com";
		} else {
			strCurrentEnvironment = "hd-" + strCurrentEnvironment + ".homedepotdev.com";
		}
		if (strCurrentEnvironment.toLowerCase().contains("st")) {
			strEnvirType = "dev";
		} else {
			strEnvirType = "qa";
		}
		String strJumpURL;
		if (strCurrentEnvironment.contains("homedepot.com")) {
			strJumpURL = "https://blinds.homedepot.com/p/p/" + strSkuToSearch;

		} else {
			strJumpURL = "https://" + strEnvirType + "-blinds." + strCurrentEnvironment + "/p/p/" + strSkuToSearch + "";

		}

		try {
			driver.get(strJumpURL);
			report.addReportStep("Launch the link " + strJumpURL + "", "Link launch is triggered", StepResult.PASS);

			if (wh.isElementPresent(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big"), 15)) {

				try {
					report.addReportStep("Open the Blinds product information page", "The link is launched",
							StepResult.PASS);

					Thread.sleep(10000);
					boolean blnIsButtonFound = false;

					try {
						JavascriptExecutor js = null;
						if (driver instanceof JavascriptExecutor) {
							js = (JavascriptExecutor) driver;
						}

						try {
							new WebDriverWait(driver, 30).until(ExpectedConditions
									.elementToBeClickable(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big")));

							js.executeScript("arguments[0].click();",
									driver.findElement(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big")));
							report.addReportStep("CLick the 'Customize and Buy'button in the Product information page",
									"Button clicked", StepResult.PASS);
							blnIsButtonFound = true;
						} catch (Exception e) {
							js.executeScript("arguments[0].click();",
									driver.findElement(By.cssSelector("a.bdc-btn.bdc-btn-submit.bdc-btn-big")));
							report.addReportStep("CLick the 'Customize and Buy'button in the Product information page",
									"Button clicked", StepResult.PASS);
							blnIsButtonFound = true;
						}

					} catch (Exception e) {
						blnIsButtonFound = false;
					}

				} catch (Exception e) {

				}
			}

		} catch (Exception e) {

		}
	}
	
	public void addblindssamples() throws Exception{
		if(wh.isElementPresent(By.xpath("//*[@class='bdc-product-choice-actions']"))){
			report.addReportStep("Verify Blinds Samples",
					"Blind samples are dispalyed in PIP page", StepResult.PASS);
			wh.clickElement(By.xpath("//*[@class='bdc-product-choice-actions']"));
			Thread.sleep(1000);
			wh.clickElement(By.xpath("//*[@id='cboxLoadedContent']//*[@class='bdc-btn bdc-btn-submit bdc-product-samples-header-content-request-samples']"));
		}else{
			report.addReportStep("Verify Blinds Samples",
					"Blind samples are not dispalyed in PIP page", StepResult.FAIL);
		}
	}
	
	
	public void verifyblindsaddedtocart() throws Exception{
		if(wh.isElementPresent(By.cssSelector("div .bdc-cart-items-list"))){
			report.addReportStep("Verify Blinds Samples added to cart",
					"Blind samples are added to cart successfully", StepResult.PASS);
		}else{
			report.addReportStep("Verify Blinds Samples added to cart",
					"Blind samples are not added to cart.", StepResult.FAIL);
		}
	}
	
	public void clickhomepageicon() throws Exception{
		if(wh.isElementPresent(By.cssSelector("div .headerLogo"))){
			report.addReportStep("Verify THD icon",
					"THD icon is displayed in header section", StepResult.PASS);
			wh.clickElement(By.cssSelector("div .headerLogo"));
			Thread.sleep(1000);
			String stritemcount = driver.findElement(By.cssSelector("div .headerCart__itemCount")).getText();
			if(stritemcount.contains("1")){
				report.addReportStep("Verify Minicart Value",
						stritemcount +" No of product displayed in Minicart", StepResult.PASS);
			}else{
				report.addReportStep("Verify Minicart Value",
						stritemcount +" No of product are not matching with selected item count", StepResult.FAIL);
			}
			wh.clickElement(By.id("headerCart"));
			Thread.sleep(1000);
		}else{
			report.addReportStep("Verify THD icon",
					"THD icon is not displayed in header section", StepResult.FAIL);
		}
	}
	
	public void verifyproductincart() throws Exception{
		if(wh.isElementPresent(By.cssSelector("div .tpl-content.overflowHidden"))){
			report.addReportStep("Verify Product in Cart",
					"Product is added to cart", StepResult.PASS);
		}else{
			report.addReportStep("Verify Product in Cart",
					"Cart is empty", StepResult.FAIL);
		}
	}
	
	
}
