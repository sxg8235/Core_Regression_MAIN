package com.homer.po;
import java.util.Date;
import java.util.List;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.homer.dao.DataColumn;
import com.homer.dao.CommonData.PLPProdSearchType;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class PLPPage extends PageBase<PLPPage> {
	
	static final By verifyPLPPage = By.id("hd_plp");	
	static By firstItemDescSearchPLP = By.cssSelector("a[class='item_description position_tracking_btn']");
	static By addToCartPLP = By.xpath("//span[contains(text(),'Add To Cart')]");
	static By certonaPLP = By.cssSelector("div.certona1main.grid");
	static By certonaAddToCartBtn = By.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]");
	static By certonaAddToCartBtnAppl = By.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add to cart')]");
	static By certonaAddToCartLink = By.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]/..");
	static By certonaAddToCartLinkAppl = By.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add to cart')]/..");
	static By certonaUnitPrice = By.xpath("//div[@class='certona1main grid']/div[1]//span[contains(@class,'xlarge item_price')]");
	public static final By prodPrice = By.cssSelector("span[class='xlarge item_price']");
	public static final By prodMinPrice = By.cssSelector("span[class='xlarge item_price']:nth-of-type(1)");
	static final By prodMaxPrice = By.cssSelector("span[class='xlarge item_price']:nth-of-type(2)");
	
	static final By wasPrice = By.xpath(".//div[@class='item_pricing_wrapper']//span[contains(text(),'Was')]//following-sibling::span[@class='normal item_stike_price']");
	static final By specialBuyPODPrice = By.xpath(".//div[@class='promo-price-container']//span[@class='normal' and contains(text(),'Special Buy')]//following-sibling::span");
	static final By pricingDiv = By.xpath(".//div[@class='item_pricing_wrapper']");
	static final By mapOriginalPrice = By.xpath("//span[@class='xlarge item_price item_stike_price']/span");
	static final By mapMessage = By.xpath("//a[@class='js-tooltip map_message']");
	static String skuPLPProd = "//input[@name='product' and @value='##value##']//ancestor::div[contains(@class,'product pod plp-grid')]";
	static String skuPLPProdTab = "//a[contains(@href,'##value##')]//ancestor::div[contains(@class,'product pod plp-grid')]";
	static String modelNoPLPProd ="//p[@class='model_container']/span[contains(text(),'##value##')]//ancestor::div[contains(@class,'product pod plp-grid')]";	
	static String pofieldPLPProd = "//a[@class='item_description' and contains(text(),'##value##')]//ancestor::div[contains(@class,'product pod plp-grid')]";
	
	static By plpPODs = By.cssSelector("div#products div[class^='product pod plp-grid']");
	static By nextBtn = By.cssSelector("a.icon-next");
	public static By compareChkBox = By.name("product");
	static By compareChkBtn = By.cssSelector("a[class='comparenow btn btn-small Compare_btn']");
	
	static String newFirstChkBox = "//input[@name='product' and value='##sku##']";
	static final By verifyProdTitleQV = By.xpath("//h1[@class='product_title']");
		
	static By plpProdImage = By.cssSelector("div.product-image img");
	static By plpProdLink = By.className("item_description");
	static By plpAddToCart = By.className("plus");
	static By plpProdPrice = By.xpath("//span[@class='xlarge item_price' and contains(text(),'$')]");
	static final By loadingIcon = By.cssSelector("div.containerLoading.loader-image");
	
	static final By strikeThroPrice = By.xpath("//span[@class='strike-through']");
	static final By unitPriceSTH  = By.xpath("//div[@class='offerprice']");

	static final By txtBopis = By.xpath("//a[contains(text(),'Pick Up in Store')]");
	static final By bopisFilter = By.xpath("//a[@data-refinementvalue='Pick Up In Store Today']");
	
	boolean wasPriceDisplay;
	boolean specialBuyPriceDisplay;
	boolean effRTLPriceDisplay;
	boolean noWASPrice;
	boolean noSpecialBuyPrice;
	WebElement plpPOD = null;
	
	public PLPPage(InstanceContainer ic) {
		 super(ic);
		 
		 this.ic = ic;
			this.report = ic.report;
			this.driver = ic.driver;
			this.wh = ic.wh;
			
			this.wasPriceDisplay = ic.wasPriceDisplay;
			this.effRTLPriceDisplay = ic.effRTLPriceDisplay;
			//this.effRTLPriceDisplay = ic.EffRTLPrice;
			this.noWASPrice = ic.noWASPrice;
			this.specialBuyPriceDisplay = ic.specialBuyPriceDisplay;
			
			rc = ic.rc;
	} 
	
	/**
	 * Method to verify PLP Page
	 * @return
	 * @throws Exception
	 */
	public PLPPage verifyPLPPage() throws Exception {

		expectedResult = wh.isElementPresent(verifyPLPPage, 3);
		
		//rc.scenarioWrite(expectedResult, "PLP page is not displayed");
		
		if(expectedResult) {
			
			report.addReportStep("Verify PLP page is displayed" , 
					"PLP page is displayed", 
					StepResult.PASS);
		} else {
			
			report.addReportStep("Verify PLP page is displayed" , 
					"PLP page is not displayed", 
					StepResult.FAIL);
		}
		
		Thread.sleep(3000);
		
		return this;
	}
	 
	
	/**
	 * Method to click first PLP POD
	 * @return
	 * @throws Exception
	 */
	public PIPPage clickFirstPLPPOD() throws Exception {
		
		wh.clickElement(firstItemDescSearchPLP);
		
		report.addReportStep("Click on first PLP product",
				"Clicked first PLP product", 
				StepResult.DONE);
		
		return new PIPPage(ic);
	}
	
	/**
	 * Method to click add to cart button in PLP
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage clickAddToCartPLP() throws Exception {
		if (wh.isElementPresent(addToCartPLP, 0)) {
			
			addMCCparamter();

			wh.jsClick(addToCartPLP);
			report.addReportStep("Verify <b>Add to Cart</b> button is clicked" , 
					"<b>Add to Cart</b> button is clicked", 
					StepResult.PASS);


		} else {
			report.addReportStep(
					"verify <b>Add to Cart</b> button is clicked",
					"<b>Add to Cart</b> button is not clicked", StepResult.FAIL);
		}
		
		Thread.sleep(commonData.littleWait);
		return new ShoppingCartPage(ic);

	}
	
	/**
	 * Method to verify certona section in PLP
	 * 
	 * @return this
	 * @throws Exception
	 */
	public PLPPage verifyCertonaSectionPLP() throws Exception {
		Thread.sleep(5000);
		if (wh.isElementPresent(certonaPLP, 4)) {
			report.addReportStep("Verify <b>Certona</b> section is displayed" , 
					"<b>Certona</b> section is displayed", 
					StepResult.PASS);
			Thread.sleep(commonData.littleWait);
			
			String sku = null;
			if(wh.isElementPresent(certonaAddToCartLink)){
				String href = wh.getAttribute(certonaAddToCartLink, "href");
				String[] href1 = href.split("catEntryId=");
			
				sku = href1[1].substring(0,9);
			
			}
			else if(wh.isElementPresent(certonaAddToCartLinkAppl)){
				sku = wh.getAttribute(certonaAddToCartLinkAppl, "data-prodid");
			}
			
			if (!sku.equals(null)){
				commonData.sku = sku;
				commonData.skuList.add(sku);
			}

		} else {
			report.addReportStep(
					"Verify <b>Certona</b> section is displayed",
					"<b>Certona</b> section is not displayed", StepResult.FAIL_ENV);
			rc.terminateTestCase("Certona Section");
		}
		return this;

	}
	
	/**
	 * Method to click Add to cart first item from certona section in PLP
	 * 
	 * @return this
	 * @throws Exception
	 */
	public PLPPage clickAddtoCartCertonaPLP() throws Exception {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,3250)", "");
		Thread.sleep(8000);
		if (wh.isElementPresent(certonaAddToCartBtn, 0)) {
			
			addMCCparamter();
					
			wh.clickElement(certonaAddToCartBtn);
			
			Thread.sleep(commonData.littleWait);
			
			report.addReportStep("Click Add to cart button in certona section" , 
					"Add to cart button is clicked in certona section", 
					StepResult.PASS);

		} 
		
		else if(wh.isElementPresent(certonaAddToCartBtnAppl)){
			addMCCparamter();
			wh.clickElement(certonaAddToCartBtnAppl);
			
			report.addReportStep("Click Add to cart button in certona section" , 
					"Add to cart button is clicked in certona section", 
					StepResult.PASS);
		}
		else {
			report.addReportStep(
					"Click Add to cart button in certona section",
					"Add to cart button is not clicked in certona section", StepResult.FAIL);
			rc.terminateTestCase();
		}
		return this;

	}
	

	/**
	 * Method to verify Price or 'See final price in cart' message is displayed
	 * @return
	 * @throws ExceptionBOS
	 */
	public PLPPage verifyPriceSection() throws Exception {
		String skuNumber = dataTable.getData("SKUNumber");
		verifyPriceDisplayed(skuNumber);
		
		//if(!noWASPrice)
		if(wh.isElementPresent(plpPOD,wasPrice)){
		
			verifyWASPriceDisplayed(skuNumber);
		}		
		
		return this;
	}
	
	/**
	 * Method to verify price is displayed or 'See final price in cart' message is displayed
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PLPPage verifyPriceDisplayed(String skuNumber) throws Exception {
		
		if(plpPOD==null) {
			
			getPlpProdPOD(PLPProdSearchType.productID, skuNumber);
		}		
			
		double price = rc.getPrice(plpPOD, prodPrice);
		String strPrice = new Double(price).toString();
		
		String cassandraPrice="";
		String prodDescr = commonData.prodDescription;
		
		for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {
			if (prodDescr.contains(entry.getKey())) {
					cassandraPrice = entry.getValue();
					break;
			}
		}
		
		if(strPrice.equals(cassandraPrice)
				&& !wh.getText(plpPOD, pricingDiv).contains("Add to Cart to See Price")) {
			
			report.addReportStep("Product price should be equal to cassandra price",
					"Product price <b>"+price+"</b> is equal to cassandra price", 
					StepResult.PASS);
		} 
		
		else if(wh.getText(plpPOD, pricingDiv).contains("Add to Cart to See Price")) {
			
			//&&   !wh.getText(plpPOD,pricingDiv).contains("$")
			
			report.addReportStep("Product original price should not be displayed and message 'See final price in cart' should be displayed",
					"Product price is not displayed and message 'See final price in cart' is displayed", 
					StepResult.PASS);
			
		} 
		else {
			
			report.addReportStep("Product price should be displayed and message 'See final price in cart' should not be displayed",
					"Product price is not displayed as expected", 
					StepResult.FAIL);
		}			
	
		return this;
	}
	
	
	/**
	 * Method to verify was price is displayed or 'See final price in cart' message is displayed
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PLPPage verifyWASPriceDisplayed(String skuNumber) throws Exception {
		
		if(plpPOD==null) {
			
			getPlpProdPOD(PLPProdSearchType.productID, skuNumber);
		}
		
		
		if(wh.isElementPresent(plpPOD,wasPrice)) {
			
			double wasPriceDisplayed = rc.getPrice(plpPOD, wasPrice);
			
			if(Double.valueOf(wasPriceDisplayed).equals(ic.wasPrice)
					&& !wh.getText(plpPOD, pricingDiv).contains("Add to Cart to See Price")) {
				
				report.addReportStep("Product Was price should be displayed and message 'See final price in cart' should not be displayed",
						"Product Was price is displayed and message 'See final price in cart' is not displayed", 
						StepResult.PASS);
				
			} else {
				
				report.addReportStep("Product Was price should be displayed and message 'See final price in cart' should not be displayed",
						"Product price is not displayed as expected", 
						StepResult.FAIL);
			}			
			
		} 
		
		
		
		else if (wh.isElementPresent(plpPOD, mapOriginalPrice) && wh.isElementPresent(plpPOD, mapMessage)) {
			
			String wasPrice = wh.getText(plpPOD, mapOriginalPrice).split("\\/")[0].replace("$", "").replace(",", "");
			
			
			if(Double.valueOf(wasPrice).equals(ic.wasPrice)
					&& wh.getText(plpPOD, mapMessage).contains("Add to Cart to See Price")) {
				
				report.addReportStep("Product Was price should be displayed and message 'Add to Cart to see Price' should be displayed",
						"Product Was price is displayed and message 'Add to Cart to see Price' is displayed", 
						StepResult.PASS);
			} else {
				
				report.addReportStep("Product Was price should be displayed and message 'Add to Cart to see Price'  should  be displayed",
						"Product Was price and 'Add to Cart to See Price' message is not displayed as expected", 
						StepResult.FAIL);
			}			
			
		} 
		
		else {
			
			if(wh.getText(plpPOD, pricingDiv).contains("Add to Cart to See Price")
					&& !wh.getText(plpPOD,pricingDiv).contains("$")
					&& !wh.isElementPresent(plpPOD, wasPrice) ) {
				
				report.addReportStep("Product Was price should not be displayed and message 'See final price in cart' should be displayed",
						"Product Was price is not displayed and message 'See final price in cart' is displayed", 
						StepResult.PASS);
				
			} else {
				
				report.addReportStep("Product Was price should not be displayed and message 'See final price in cart' should be displayed",
						"'See final price in cart' (Pricing details) is not displayed as expected", 
						StepResult.FAIL);
			}			
			
		}
		
		return this;
	}
	
	/**
	 * Method to click next button
	 * @throws Exception
	 */
	public void clickNextButton() throws Exception {

		String sku = wh.getAttribute(compareChkBox,"value");
		
		wh.clickElement(nextBtn);

		String firstProdXPATH = newFirstChkBox.replaceFirst("##sku##",
				sku);

		Date start = new Date();
		Date end = new Date();

		while (!wh.isElementNotPresent(By.xpath(firstProdXPATH))
				&& wh.isElementPresent(compareChkBox, 1)) {

			Thread.sleep(800);
			
			if (end.getTime() - start.getTime() >= 1 * 800) {
				break;
			}

			end = new Date();
		}
	}
	/**
	 * Method to get PLP POD for given search type and value
	 * @param plpSearchType
	 * @param value
	 * @return
	 * @throws Exception
	 */
	
	public WebElement getPlpProdPOD(PLPProdSearchType plpSearchType,
			String value) throws Exception {

		WebElement plpDiv = null;

		String plpXPATH = "";
		if (commonData.desktopUserAgent) {
			switch (plpSearchType) {

			case productID:
				plpXPATH = skuPLPProd.replaceFirst("##value##", value);
				break;

			case modelno:
				plpXPATH = modelNoPLPProd.replaceFirst("##value##", value);
				break;
			case profield:
				plpXPATH = pofieldPLPProd.replaceFirst("##value##", value);
				break;
			}
		} else {

			switch (plpSearchType) {

			case productID:
				plpXPATH = skuPLPProdTab.replaceFirst("##value##", value);
				break;

			case modelno:
				plpXPATH = modelNoPLPProd.replaceFirst("##value##", value);
				break;
			case profield:
				plpXPATH = pofieldPLPProd.replaceFirst("##value##", value);
				break;
			}

	
}

		boolean lastPage = false;

		int pageNum = 1;

		boolean isLastPage = false;
		do {

			if (wh.isElementPresent(By.xpath(plpXPATH), 2)) {

				plpDiv = driver.findElement(By.xpath(plpXPATH));
				break;
			}

			if (wh.isElementPresent(nextBtn, 1)) {

				pageNum++;
				System.out.println("Page no is : " + pageNum);

				clickNextButton();
				
				if (!wh.isElementPresent(nextBtn, 1)) {
					isLastPage = true;
				}
				
				
			} else {

				lastPage = true;
				isLastPage = false;
			}

		} while (wh.isElementPresent(nextBtn, 1) || !lastPage || isLastPage);

		if (plpDiv == null) {

			String reportMsg = "";

			switch (plpSearchType) {

			case productID:
				reportMsg = "Product ID - " + value;
				break;

			case modelno:
				reportMsg = "Model No - " + value;
				break;
				
			case profield:
				reportMsg = "PO field - " + value;
				break;
			}

			report.addReportStep("Search for product with " + reportMsg
					+ " in PLP page", "Product is not present in PLP page",
					StepResult.FAIL);
		}

		plpPOD = plpDiv;
		
		return plpDiv;
	}
	
	/**
	 * Method to click Product by SKU number
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PIPPage clickBySkuNumber() throws Exception {
		
		String skuNumber = dataTable.getData("SKU");
		if(plpPOD == null) 
		{
			wh.waitForElementPresent(verifyPLPPage,5);
			plpPOD = getPlpProdPOD(PLPProdSearchType.productID, skuNumber);			
		}
			
		wh.clickElement(plpPOD, plpProdLink);	
		return new PIPPage(ic);
	}
	
	/**
	 * Method to select Compare
	 * 
	 * @param plpPOD
	 * @return
	 */
	public PLPPage selectCompare(WebElement plpPOD) {
		
		wh.clickElement(plpPOD, compareChkBox);
		
		return this;
	}	
	
	/**
	 * Method to Compare products
	 * 
	 * @return
	 * @throws Exception
	 */
	public PCPPage compareProducts() throws Exception {
		
		wh.waitForPageLoaded();
		
		String skuNumber = dataTable.getData(DataColumn.SKU);
		selectCompare(getPlpProdPOD(PLPProdSearchType.productID, skuNumber));
		
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("scroll(0, 250)");
		
		selectCompare(getPLPPodToCompare(skuNumber));
		
		wh.clickElement(compareChkBtn);
		Thread.sleep(2000l);

		String currentURL = driver.getCurrentUrl();
		if (currentURL.contains("?")){
			driver.get(currentURL+"&mcc=true");
		}
		else{
			driver.get(currentURL+"?mcc=true");
		}
		
		wh.waitForPageLoaded();
		
		report.addReportStep("Select Products to Compare", "Two products are selected to compate", StepResult.DONE);
		
		return new PCPPage(ic);
	}
	
	/**
	 * Method to get the PLP Pod compare
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	private WebElement getPLPPodToCompare(String skuNumber) throws Exception {
	
		WebElement plpPOD = null;
		
		List<WebElement> lstPLPPOD = wh.getElements(plpPODs);
		
		String sku;
		
		for (WebElement pod : lstPLPPOD) {
			
			sku = wh.getAttribute(pod, compareChkBox,"value");
			
			if(!skuNumber.equalsIgnoreCase(sku)) {
				
				plpPOD = pod;
				break;
			}
		}
	
		return plpPOD;
	}
	
	/**
	 * Method to click add to cart button for selected product
	 * 
	 * @return Overlays
	 * @throws Exception
	 */
	public ATCOverlay clickAddToCartForSKU() throws Exception{
		
		String skuNumber = dataTable.getData(DataColumn.SKU);
		
		try{
			
			
			addMCCparamter();
			
			if(plpPOD == null) 
			{
				wh.waitForElementPresent(verifyPLPPage,5);
				plpPOD = getPlpProdPOD(PLPProdSearchType.productID, skuNumber);			
			}

			wh.clickElement(By.xpath("//input[@name='product' and @value="+commonData.sku+"]//ancestor::div[contains(@class,'product pod plp-grid')]//span[contains(text(),'Add To Cart')]"));
			//wh.clickElement(plpPOD, addToCartPLP);	

			
			report.addReportStep("Click on Add to Cart for the Selected Product", "Add to Cart button is clicked", StepResult.PASS);
			
		}
		catch(Exception ex){
			ex.printStackTrace();
			report.addReportStep("Click on Add to Cart for the Selected Product", "Add to Cart button not clicked", StepResult.FAIL);
		}
		
		return new ATCOverlay(ic);
		
	}
	
	/**
	 * Get product price from certona
	 * 
	 * @throws Exception
	 */
	public void getProdUnitPricePLPCertona() throws Exception {

		if (wh.isElementPresent(certonaUnitPrice, 7)) {
			String unitPrice = driver.findElement(certonaUnitPrice).getText();
			commonData.unitPriceDB = unitPrice.substring(1).trim();
			report.addReportStep(
					"Verify whether the product price is retrived from certona",
					"Product price is taken from cart page", StepResult.PASS);

		} else {
			report.addReportStep(
					"Verify whether the product price is retrived from certona",
					"Product price is not taken from certona", StepResult.FAIL);
		}

	}
	
	/**
	 * Description : verify bopis filter is not displayed in PLP page
	 * @author RXP8655
	 */
	public void verifyPickUpStorePositionNotDisplayed() {

		if (wh.isElementNotPresent(txtBopis)) {

			report.addReportStep(
					"<b>System shouldn't display the 'Bopis Filter' </b>in the left rail <b> below 'More ways to shop' </b>section",
					"<b>'Bopis Filter' is not displayed </b>in the left rail <b>below 'More ways to shop' </b>section",
					StepResult.PASS);
		} else {

			report.addReportStep(
					"<b>System shouldn't display the 'Bopis Filter' </b>in the left rail <b> below 'More ways to shop' </b>section",
					"<b>'Bopis Filter' is displayed </b>in the left rail <b>below 'More ways to shop' </b>section",
					StepResult.FAIL);
		}
	}
	
	/**
	 * 
	 * Description : verify bopis filter is displayed in PLP page
	 * @author RXP8655
	 * @throws Exception 
	 */
	public void verifyPickUpStorePositionDisplayInPLPPg()
			throws Exception {

		if (wh.isElementPresent(bopisFilter)) {
			report.addReportStep(
					"User Verifies that <b>BOPIS filter should be displayed </b>as link under <b>'More Ways to Shop' section </b>with both BOPIS eligible SKU displayed.",
					"<b>'Bopis Filter' is displayed </b>in the left rail below <b>'More ways to shop' </b>section",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"User Verifies that <b>BOPIS filter should be displayed </b>as link under <b>'More Ways to Shop' section </b>with both BOPIS eligible SKU displayed.",
					"<b>'Bopis Filter' is not displayed </b>in the left rail below <b>'More ways to shop' </b>section",
					StepResult.FAIL);
		}

	}

}
