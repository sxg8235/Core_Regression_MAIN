package com.homer.po;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;


public class DBConnection extends PageBase<DataBase> {
	
	
	public DBConnection(InstanceContainer ic) {
		super(ic);
	}

	public ArrayList<HashMap<String, Object>> connectDB2DatabaseGetRowSet(String sqlQuery) {
		ArrayList<HashMap<String, Object>> list = null;
		try {
			Properties prop = new Properties();
			// Load the DB2(R) Universal JDBC Driver with DriverManager
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			prop.load(new FileInputStream("config.properties"));
			Class.forName("com.ibm.db2.jcc.DB2Driver");
			String strURL = (String) prop.get("URL");
			String strUsername = (String) prop.get("Username");
			String strPassword = (String) prop.get("Password");
			Connection con = DriverManager.getConnection(strURL, strUsername, strPassword);
			if (!con.isClosed())
				System.out.println("Successfully connected to MySQL server");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sqlQuery);

			ResultSetMetaData md = rs.getMetaData();
			int columns = md.getColumnCount();
			list = new ArrayList<HashMap<String, Object>>(50);
			while (rs.next()) {
				HashMap<String, Object> row = new HashMap<String, Object>(columns);
				for (int i = 1; i <= columns; ++i) {
					row.put(md.getColumnName(i), rs.getObject(i));
				}
				list.add(row);
			}

			rs.close();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * Verify HDPP Feature switch ON or OFF from DB
	 * 
	 * @throws Exception
	 */
	public DBConnection verifyHDPPFeatureSwitchOFFInDB() throws Exception {

		String env = HelperClass.baseModel.runEnvironment;

		try {

			String switchValue;
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;

			int dbLivePort = 50120;

			Properties prop = new Properties();
			// Load the DB2(R) Universal JDBC Driver with DriverManager
			
			prop.load(new FileInputStream("config.properties"));
			String strUsername = (String) prop.get("Username");
			String strPassword = (String) prop.get("Password");
			String dbLiveSever = (String) prop.get(env + "dbLiveSever");
			String dbLiveSeverName = (String) prop.get(env + "dbLiveSeverName");

			Class.forName("COM.ibm.db2os390.sqlj.jdbc.DB2SQLJDriver");
			// Class.forName("COM.ibm.db2os390.sqlj.jdbc.DB2SQLJDriver");

			String connectDBLive = "jdbc:db2://" + dbLiveSeverName +":" + dbLivePort + "/"
					+ dbLiveSever;

			conn = DriverManager.getConnection(connectDBLive,strUsername,strPassword);

			stmt = conn.createStatement();
			String hdppSwitch = "select * from HD_CD_GRP_CD where CD_NM = 'HDPPFeatureSwitch' and CD_ENV_VAL = 'live'";

			rs = stmt.executeQuery(hdppSwitch);

			while (rs.next()) {
				switchValue = rs.getString("INT_VAL");
				if (switchValue.contains("0")) {
					report.addReportStep("Verify the HDPPFeatureSwitch is OFF in DB", "HDPPFeatureSwitch is OFF in DB",
							StepResult.PASS);

				} else {
					report.addReportStep("Verify the HDPPFeatureSwitch is OFF in DB", "HDPPFeatureSwitch is ON in DB",
							StepResult.WARNING);
					rc.terminateTestCase("HDPPFeatureSwitch is ON in DB");
				}
			}

			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();

		}

		return this;

	}
	
	/**
	 * Verify Checkout from ATC overlay Feature switch ON or OFF from DB
	 * 
	 * @throws Exception
	 */
	
			
	public DBConnection verifyMCCAtcModalCoNowFeatureSwitchOnInDB() throws Exception {
	
		String env = HelperClass.baseModel.runEnvironment;
		
		try {
	
			String switchValue;
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
	
			int dbLivePort = 50120;
	
			Properties prop = new Properties();
			// Load the DB2(R) Universal JDBC Driver with DriverManager
			
			prop.load(new FileInputStream("config.properties"));
			String strUsername = (String) prop.get("Username");
			String strPassword = (String) prop.get("Password");
			String dbLiveSever = (String) prop.get(env + "dbLiveSever");
			String dbLiveSeverName = (String) prop.get(env + "dbLiveSeverName");
	
			Class.forName("COM.ibm.db2os390.sqlj.jdbc.DB2SQLJDriver");
			// Class.forName("COM.ibm.db2os390.sqlj.jdbc.DB2SQLJDriver");
	
			String connectDBLive = "jdbc:db2://" + dbLiveSeverName +":" + dbLivePort + "/"
					+ dbLiveSever;
	
			conn = DriverManager.getConnection(connectDBLive,strUsername,strPassword);
	
			stmt = conn.createStatement();
			String CoNowFromATCFeatureSwitch = "select * from HD_CD_GRP_CD where CD_NM = 'MCCAtcModalCoNowFeatureSwitch' and CD_ENV_VAL = 'live'";
	
			rs = stmt.executeQuery(CoNowFromATCFeatureSwitch);
	
			while (rs.next()) {
				switchValue = rs.getString("INT_VAL");
				if (switchValue.contains("1")) {
					report.addReportStep("Verify the CoNowFromATCFeatureSwitch is ON in DB", "CoNowFromATCFeatureSwitch is ON in DB",
							StepResult.PASS);
	
				} else {
					report.addReportStep("Verify the CoNowFromATCFeatureSwitch is ON in DB", "CoNowFromATCFeatureSwitch is OFF in DB",
							StepResult.WARNING);
					rc.terminateTestCase("MCCAtcModalCoNowFeatureSwitch is OFF in DB");
				}
			}
	
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
	
		}
	
		return this;
	}
	
	/**
	 * Verify EnableStoreCreditSwitch switch ON or OFF from DB MLTC2797 and MLTC2798
	 * 
	 * @throws Exception
	 */
	
			
	public DBConnection verifyEnableStoreCreditSwitchIsOffInDB() throws Exception {
	
		String env = HelperClass.baseModel.runEnvironment;
		
		try {
	
			String switchValue;
			Connection conn = null;
			Statement stmt = null;
			ResultSet rs = null;
	
			int dbLivePort = 50120;
	
			Properties prop = new Properties();
			// Load the DB2(R) Universal JDBC Driver with DriverManager
			
			prop.load(new FileInputStream("config.properties"));
			String strUsername = (String) prop.get("Username");
			String strPassword = (String) prop.get("Password");
			String dbLiveSever = (String) prop.get(env + "dbLiveSever");
			String dbLiveSeverName = (String) prop.get(env + "dbLiveSeverName");
	
			Class.forName("COM.ibm.db2os390.sqlj.jdbc.DB2SQLJDriver");
			// Class.forName("COM.ibm.db2os390.sqlj.jdbc.DB2SQLJDriver");
	
			String connectDBLive = "jdbc:db2://" + dbLiveSeverName +":" + dbLivePort + "/"
					+ dbLiveSever;
	
			conn = DriverManager.getConnection(connectDBLive,strUsername,strPassword);
	
			stmt = conn.createStatement();
			String CoNowFromATCFeatureSwitch = "select * from HD_CD_GRP_CD where CD_NM = 'EnableStoreCredit' and CD_ENV_VAL = 'live'";
	
			rs = stmt.executeQuery(CoNowFromATCFeatureSwitch);
	
			while (rs.next()) {
				switchValue = rs.getString("INT_VAL");
				if (switchValue.contains("0")) {
					report.addReportStep("Verify the EnableStoreCredit is OFF in DB", "EnableStoreCredit is OFF in DB",
							StepResult.PASS);
	
				} else {
					report.addReportStep("Verify the EnableStoreCredit is OFF in DB", "EnableStoreCredit is ON in DB",
							StepResult.WARNING);
					rc.terminateTestCase("MCCAtcModalCoNowFeatureSwitch is OFF in DB");
				}
			}
	
			conn.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
	
		}
	
		return this;
	}
	
}
