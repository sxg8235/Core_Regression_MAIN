package com.homer.po;

import java.text.DecimalFormat;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;

public class EmailPage extends PageBase<EmailPage> {
	
	public boolean isProdEnv = false;
	

	static final By verifyOrderConfEmailPage = By.xpath("//td[contains(text(),'. We have received your order')]");
	static final By mailUserName = By.id("username");
	static final By mailPwd = By.id("password");
	static final By signInBtn = By.xpath("//*[@type='submit' and @value='Sign in']");
	static final By searchBtn = By.id("imgS");
	//static final By searchBtn = By.cssSelector(".sImg");
	static final By searchTxtBox = By.id("txtS");
	static final By damageEmailSubj = By.xpath("//*[@id='divSubject' and contains(text(),'Order Issue')]");
	static final By ThankYouEmailSubj = By.xpath("//*[@id='divSubject' and contains(text(),'Thank you for your pickup order')]");
	
	
	public EmailPage(InstanceContainer ic) {
		super(ic);
	}
	
	
	/**
	 * To verify order confirmation email
	 * 
	 * @return ThankYouPage
	 * @throws Exception
	 */
	public EmailPage verifyOrderConfEmail() throws Exception {

		if (wh.isElementPresent(verifyOrderConfEmailPage)) {
			String emailText = wh.getText(verifyOrderConfEmailPage);
			if (emailText.contains("We have received your order")) {
				report.addReportStep(
						"Verify order confirmation email is received",
						"Order confirmation email is received", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify order confirmation email is received",
						"Order confirmation email is not received",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify order confirmation email is received",
					"Order confirmation email is not displayed properly",
					StepResult.FAIL);

		}

		return this;
	}
	
	
	/**
	 * To verify order confirmation email
	 * 
	 * @return ThankYouPage
	 * @throws Exception
	 */
	public EmailPage navigateToOrderConfimationEmailPg(String skuType)
			throws Exception {
		String strCurrentEnvironment = HelperClass.baseModel.runEnvironment;
		strCurrentEnvironment = "hd-" + strCurrentEnvironment
				+ ".homedepotdev.com";
		String strJumpStore = dataTable.getData("LocalizeStore");

		if (skuType.equalsIgnoreCase("sth") || skuType.equalsIgnoreCase("boss")) {
			driver.get("http://"
					+ strCurrentEnvironment
					+ "/webapp/wcs/stores/servlet/hdus/Messages/MerchandiseEmailOrderConfirmation.jsp?orderId="
					+ commonData.orderNumber);
			report.addReportStep(
					"Verify order confirmation email page is displayed",
					"Order confirmation email page is displayed",
					StepResult.PASS);
		} else if (skuType.equalsIgnoreCase("bopis")) {
			if (commonData.alternateStore != null) {
				strJumpStore = commonData.alternateStore;
			}
			driver.get("http://"
					+ strCurrentEnvironment
					+ "/webapp/wcs/stores/servlet/hdus/Messages/BopisEmailOrderConfirmation.jsp?orderId="
					+ commonData.orderNumber + "&storeNumber=" + strJumpStore);
			report.addReportStep(
					"Verify order confirmation email page is displayed",
					"Order confirmation email page is displayed",
					StepResult.PASS);

		} else if (skuType.equalsIgnoreCase("appliance")) {
			driver.get("http://"
					+ strCurrentEnvironment
					+ "/webapp/wcs/stores/servlet/hdus/Messages/AOLApplianceOrderNotify.jsp?orderId="
					+ commonData.orderNumber);
			report.addReportStep(
					"Verify order confirmation email page is displayed",
					"Order confirmation email page is displayed",
					StepResult.PASS);

		} else if (skuType.equalsIgnoreCase("bodfs")) {
			driver.get("http://"
					+ strCurrentEnvironment
					+ "/webapp/wcs/stores/servlet/hdus/Messages/BODFSEmailOrderConfirmation.jsp?orderId="
					+ commonData.orderNumber);
			report.addReportStep(
					"Verify order confirmation email page is displayed",
					"Order confirmation email page is displayed",
					StepResult.PASS);

		} else {
			report.addReportStep(
					"Verify order confirmation email page is displayed",
					"Order confirmation email page is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Verify Unit Price Email Page
	 * 
	 * @throws Exception
	 */
	public EmailPage verifyUnitPriceEmailPods() throws Exception {
		
		String disc = "";
		
		for (String sku : commonData.skuList) {
			
			By unitPriceCart = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../../td[4]");
			
			By promoDiscount = By
					.xpath("//td[contains(text(),'Promotional Discount')]/../td[2]");
			
			if(wh.isElementPresent(promoDiscount)){
				disc = wh.getText(promoDiscount).replaceAll(",", "").replace("$", "");
				System.out.println("Disocunt "+disc);
			}
			
			By prodDesc = By.xpath("//a[contains(@href,'" + sku + "')]/../../td[3]");
			
			if (wh.isElementPresent(unitPriceCart, 7)) {
				String unitPrice = wh.getText(unitPriceCart);
				String prodDescr = wh.getText(prodDesc);
				String finalPrice;
				if (unitPrice.contains(",")) {
					finalPrice = unitPrice.replaceAll(",", "");
				} else {
					finalPrice = unitPrice;
				}
				
				if(!disc.equals("")){
					commonData.subTotal= finalPrice;
					finalPrice = finalPrice.substring(1);
					finalPrice = Double.toString(Double.parseDouble(new DecimalFormat("##.##").format(Double.parseDouble(finalPrice)+Double.parseDouble(disc))));
				}
				
				for (Entry<String, String> entry : commonData.unitPrice
						.entrySet()) {
					
					if (prodDescr.contains(entry.getKey())) {
						if (finalPrice.contains(entry.getValue())) {
							report.addReportStep(
									"Verify whether unit price in Thank You page is equivalent to Expected Price",
									"Unit price in cart page "
											+ unitPrice
											+ " is equivalent to Expected Price"
											+ entry.getValue(), StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether unit price in Thank You page is equivalent to Expected Price",
									"Unit price in cart page "
											+ unitPrice
											+ " is not equivalent to Expected Price"
											+ entry.getValue(),
									StepResult.FAIL);
						}
					}
					System.out.println(entry.getKey() + " - "
							+ entry.getValue());
				}

			} else {
				report.addReportStep(
						"Verify whether unit price in Thank You page is equivalent to Expected Price",
						"Unit price is not displayed", StepResult.FAIL);
			}
		}
		return this;
	}
	
	/**
	 * Verify Unit Price Email Page
	 * 
	 * @throws Exception
	 */
	public EmailPage verifyUnitPriceBOPISEmailPods() throws Exception {
		String disc = "";
		
		for (String sku : commonData.skuList) {
			
			By unitPriceCart = By.xpath("//span[contains(text(),'" + sku + "')]/../../../../../../../td[2]");
			
			By promoDiscount = By
					.xpath("//td[contains(text(),'Promotional Discount')]/../td[2]");
			
			if(wh.isElementPresent(promoDiscount)){
				disc = wh.getText(promoDiscount).replaceAll(",", "").replace("$", "");
				disc=disc.substring(1);
				System.out.println("Disocunt "+disc);
			}
			
			
			//By prodDesc = By.xpath("//span[contains(text(),'" + sku + "')]/../../p[1]");
			
			if (wh.isElementPresent(unitPriceCart, 7)) {
				String unitPrice = wh.getText(unitPriceCart);
				//String prodDescr = wh.getText(prodDesc);
				String finalPrice;
				if (unitPrice.contains(",")) {
					finalPrice = unitPrice.replaceAll(",", "");
				} else {
					finalPrice = unitPrice;
				}
				
				/*if(!disc.equals("")){
					commonData.subTotal= Double.toString(Double.parseDouble(commonData.subTotal)-Double.parseDouble(disc));
					finalPrice = finalPrice.substring(1);
					finalPrice = Double.toString(Double.parseDouble(new DecimalFormat("##.##").format(Double.parseDouble(finalPrice)+Double.parseDouble(disc))));
				}*/
				
				for (Entry<String, String> entry : commonData.unitPrice
						.entrySet()) {
					
					if (sku.contains(entry.getKey())) {
						if ((finalPrice).contains(entry.getValue())) {
							report.addReportStep(
									"Verify whether unit price in Email page is equivalent to Expected Price",
									"Unit price in Email page "
											+ finalPrice
											+ " is equivalent to Expected Price"
											+ entry.getValue(), StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether unit price in Email page is equivalent to Expected Price",
									"Unit price in Email page "
											+ finalPrice
											+ " is not equivalent to Expected Price"
											+ entry.getValue(),
									StepResult.FAIL);
						}
					}
					System.out.println(entry.getKey() + " - "
							+ entry.getValue());
				}

			} else {
				report.addReportStep(
						"Verify whether unit price in Thank You page is equivalent to Expected Price",
						"Unit price is not displayed", StepResult.FAIL);
			}
		}
		return this;
	}
	
	/**
	 * Verify Subtotal Order Confirmation Email Page
	 * 
	 * @throws Exception
	 */
	public EmailPage verifySubtotalEmailPods() throws Exception {

		By subtotEmailPod = By
				.xpath("//td[contains(text(),'Subtotal')]/../td[2]");

		if (wh.isElementPresent(subtotEmailPod, 7)) {
			String unitPrice = wh.getText(subtotEmailPod);
			String finalPrice;
			if (unitPrice.contains(",")) {
				finalPrice = unitPrice.replaceAll(",", "");
			} else {
				finalPrice = unitPrice;
			}
			if (finalPrice.contains(commonData.subTotal)) {
				report.addReportStep(
						"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
						"Subtotal in order confirmation email page "
								+ finalPrice
								+ " is equivalent to thankyou page"
								+ commonData.subTotal, StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
						"Subtotal in order confirmation email page is not equivalent to thankyou page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
					"Subtotal is not displayed", StepResult.FAIL);
		}
		return this;
	}
	
	/**
	 * Verify Subtotal Order Confirmation Email Page
	 * 
	 * @throws Exception
	 */
	public EmailPage verifySubtotalBOPISEmailPods() throws Exception {

		By subtotEmailPod = By.xpath("//td[contains(text(),'Merchandise Subtotal')]/../td[2]");
		By subtotApplEmailPod = By.xpath("//td[contains(text(),'Appliance Subtotal')]/../td[2]");

		if (wh.isElementPresent(subtotEmailPod, 7)) {
			String unitPrice = wh.getText(subtotEmailPod);
			String finalPrice;
			if (unitPrice.contains(",")) {
				finalPrice = unitPrice.replaceAll(",", "");
			} else {
				finalPrice = unitPrice;
			}
			if (finalPrice.contains(commonData.subTotal)) {
				report.addReportStep(
						"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
						"Subtotal in order confirmation email page "
								+ finalPrice
								+ " is equivalent to thankyou page"
								+ commonData.subTotal, StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
						"Subtotal in order confirmation email page is not equivalent to thankyou page",
						StepResult.FAIL);
			}

		} else if (wh.isElementPresent(subtotApplEmailPod, 7)) {
			String unitPrice = wh.getText(subtotApplEmailPod);
			String finalPrice;
			if (unitPrice.contains(",")) {
				finalPrice = unitPrice.replaceAll(",", "");
			} else {
				finalPrice = unitPrice;
			}
			if (finalPrice.contains(commonData.subTotal)) {
				report.addReportStep(
						"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
						"Subtotal in order confirmation email page "
								+ finalPrice
								+ " is equivalent to thankyou page"
								+ commonData.subTotal, StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
						"Subtotal in order confirmation email page is not equivalent to thankyou page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify whether subtotal in order confirmation email page is equivalent to thankyou page",
					"Subtotal is not displayed", StepResult.FAIL);
		}
		return this;
	}
	
	/**
	 * To Login THD webmail
	 * 
	 * @throws Exception
	 */
	public void loginThdEmail() throws Exception {
		String userName = dataTable.getCommonData(CommonDataColumn.THDMailUserName);
		String pwd = dataTable.getCommonData(CommonDataColumn.THDMailPwd);
		String strWebMailLink = dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);
		try {
			driver.get(strWebMailLink);
			driver.manage().window().maximize();
			if (wh.isElementPresent(mailUserName, 10) && wh.isElementPresent(mailUserName, 10)) {
				wh.clearElement(mailUserName);
				wh.sendKeys(mailUserName, userName);

				wh.sendKeys(mailPwd, pwd);
				if (wh.isElementPresent(signInBtn, 3)) {
					wh.clickElement(signInBtn);
					wh.ignorePopup(driver);
					driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
					report.addReportStep("Click on Sign In Button", "Sign In Successfull", StepResult.PASS);
				}
			} else {
				report.addReportStep("Click on the SignIn Button", "SignIn button not enabled", StepResult.FAIL);
			}
		} catch (Exception e) {
			report.addReportStep("Login to THD mail", "Unable to login", StepResult.FAIL);
		}

	}
	
	/**
	 * To search order in mail box
	 * 
	 * @throws Exception
	 */
	public void searchEmailForOrder(String arg1) throws Exception {
		String order = dataTable.getData("OrderNumber");
		if (wh.isElementPresent(searchTxtBox, 10) && wh.isElementPresent(searchBtn, 10)) {
			wh.clearElement(searchTxtBox);
			wh.clickElement(searchTxtBox);
			report.addReportStep("Verify Search box and Search button", "Search box and Search button is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Search box and Search button", "Search box and Search button is not displayed",
					StepResult.FAIL);
		}
		if (arg1.toLowerCase().contains("damage")) {
			wh.sendKeys(searchTxtBox, "Order Issue for " + order);
			wh.clickElement(searchBtn);
			Thread.sleep(commonData.tinyWait);
			report.addReportStep("Enter order number and click search",
					"Order number entered and search button clicked", StepResult.PASS);
		} else if (arg1.toLowerCase().contains("thankyou")) {
			wh.sendKeys(searchTxtBox, "Thank you for your pickup order && "+order);
			wh.clickElement(searchBtn);
			Thread.sleep(commonData.tinyWait);
			report.addReportStep("Enter order number and click search",
					"Order number entered and search button clicked", StepResult.PASS);
		}

		else {
			report.addReportStep("Enter order number and click search",
					"Search text box and search button is not displayed", StepResult.FAIL);
		}
	}
	
	/**
	 * To verify email subject
	 * 
	 * @throws Exception
	 */
	public void verifyEmailReceived(String arg1) throws Exception {
		String order = dataTable.getData("OrderNumber");

		if (arg1.toLowerCase().contains("damage")) {
			if (wh.isElementPresent(damageEmailSubj, 10)) {
				report.addReportStep("Verify Damage receive email for the order " + order,
						"Damage receive email for the order <b>" + order + "</b> is received", StepResult.PASS);
				wh.clickElement(damageEmailSubj);
			} else {
				report.addReportStep("Verify Damage receive email for the order " + order,
						"Damage receive email for the order <b>" + order + "</b> is not received", StepResult.FAIL);
			}
		} else if (arg1.toLowerCase().contains("thankyou")) {
			if (wh.isElementPresent(ThankYouEmailSubj, 10)) {
				report.addReportStep("Verify Thank you email for the order " + order,
						"Thank you email for the order <b>" + order + "</b> is received", StepResult.PASS);
				wh.clickElement(ThankYouEmailSubj);
			} else {
				report.addReportStep("Verify Thank you email for the order " + order,
						"Thank you email for the order <b>" + order + "</b> is not received", StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify email recieved", "Email not received", StepResult.FAIL);
		}
	}

}
