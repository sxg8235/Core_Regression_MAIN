package com.homer.po;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.openqa.selenium.*;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;

public class CsrPage extends PageBase<CsrPage> {

	static final By GMOrderSearch=By.xpath("//h1[contains(text(),'GM Order Search')]");
	static final By Login=By.name("logonId");
	static final By Password=By.name("logonPassword");
	static final By SignInButton=By.className("sign-in-button");
	static final By BopisRefId=By.id("bopis_ref_id");
	static final By SearchOrder=By.xpath("//input[contains(@value,'SEARCH ORDERS')]");
	static final By CsrHeader=By.className("csrHeader");

	public CsrPage(InstanceContainer ic) {
		super(ic);
	}



	/**
	 * 
	 * Description : login to CSR Bopis Login Page
	 * @throws Exception 
	 * 
	 */

	public void csrBopisLogin() throws Exception {

		String strSiteName =dataTable.getCommonData(CommonDataColumn.EnvironmentUrl);
		String strUserName=dataTable.getCommonData(CommonDataColumn.CSRuser);
		String strPassword=dataTable.getCommonData(CommonDataColumn.CSRpassword);

		String strCSRLink = "/webapp/wcs/stores/servlet/CSRBopisOrderLogin?catalogId=10053&storeId=10051&langId=-1";
		if (strSiteName.toLowerCase().contains("http://")) {
			strSiteName = strSiteName.substring(
					strSiteName.indexOf("http://") + 7, strSiteName.length())
					+ strCSRLink;
			driver.get("https://secure." + strSiteName);

			if(wh.isElementPresent(GMOrderSearch, 5))
			{
				report.addReportStep(
						"Verify the CSR login page is launched successfully",
						"CSR login page is launched successfully", StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify the CSR login page is launched successfully",
						"CSR login page is not launched successfully",
						StepResult.FAIL);
			}

			if((wh.isElementPresent(Login, 2)) && (wh.isElementPresent(Password, 2)))
			{
				driver.findElement(Login).sendKeys(strUserName);
				report.addReportStep(
						"Enter the login credentials in the username field ",
						"" + strUserName + " entered", StepResult.PASS);
				driver.findElement(By.name("logonPassword")).sendKeys(
						strPassword);
				report.addReportStep(
						"Enter the login credentials in the password field ",
						"" + strPassword + " entered", StepResult.PASS);
				if(wh.isElementPresent(SignInButton, 7))
				{
					driver.findElement(SignInButton).click();
					report.addReportStep(
							"Click the signIn button in the Csr homepage",
							"Button clicked successfully", StepResult.PASS);
				} else {
					report.addReportStep(
							"Click the signIn button in the Csr homepage",
							"Unable to find the button", StepResult.FAIL);
					commonData.blnGracefulExit = true;
				}

			} else {
				report.addReportStep(
						"Verify that the Sign In fields are displayed in the CSR homepage",
						"Unable to find the Sign In fields", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}

		} else {
			System.out
			.println("Site Url is not in proper format ex: http://site.com");
			commonData.blnGracefulExit = true;
		}

	}


	/**
	 * 
	 * Description : Search Order Details in CSR page
	 * 
	 * @since May 24, 2013
	 * @author PXM8946
	 */

	public void searchOrderDetailsInCSRPage() {

		try { 
			if(wh.isElementPresent(BopisRefId, 3))
			{
				String strOrderno = commonData.orderNumber;
				// String strOrderno="W137240174";
				driver.findElement(BopisRefId).click();
				driver.findElement(BopisRefId).sendKeys(strOrderno);
				Thread.sleep(1000);
				driver.findElement(SearchOrder).click();
				try {
					String strTitle = driver.findElement(CsrHeader).getText();
					if (strTitle.contains("Search Results")) {
						report.addReportStep(
								"Enter the order# and click on the search button",
								"Successfully traversed to the next page: 'search results'",
								StepResult.PASS);
					} else {
						report.addReportStep(
								"Enter the order# and click on the search button",
								"search results page is not displayed",
								StepResult.FAIL);
					}
				} catch (Exception e) {
					report.addReportStep(
							"Enter the order# and click on the search button",
							"unable to find the page header", StepResult.FAIL);
				}
			}
			else {
				report.addReportStep(
						"Enter the order # and click on search button",
						"Unable to perform the search ", StepResult.FAIL);
			}
		} catch (Exception e) {
			report.addReportStep(
					"Enter the order # and click on search button",
					"Unable to perform the search ", StepResult.FAIL);
		}

	}


	/**
	 * Component to click on the order# in search results page
	 * 
	 * @throws InterruptedException
	 */
	public void clickOrderNumLinkInCSRPage() throws InterruptedException {
		try {
			if(wh.isElementPresent(By.cssSelector("a.srBlue"), 5))
			{
				try {
					String strOrder = driver.findElement(
							By.cssSelector("a.srBlue")).getText();
					System.out.println(strOrder);
					String oldTab = driver.getWindowHandle();
					// driver.findElement(By.linkText("Twitter Advertising Blog")).click();
					driver.findElement(By.cssSelector("a.srBlue")).click();
					ArrayList<String> newTab = new ArrayList<String>(
							driver.getWindowHandles());
					newTab.remove(oldTab);
					// change focus to new tab
					driver.switchTo().window(newTab.get(0));
					String strOrdStatus = driver.findElement(
							By.xpath("//p[@class='csrHeader']")).getText();
					System.out.println(strOrdStatus);
					String strTitle = driver.getTitle();
					System.out.println(strTitle);
					report.addReportStep(
							"click on the order# in search results page",
							"Clicked on Order No:<b>"
									+ strOrder
									+ "</b> link and  Successfully traversed to the 'order status page'",
									StepResult.PASS);
					if (strTitle.contains("Detailed Order Status")) {
						report.addReportStep(
								"click on the order# in search results page",
								"Successfully traversed to the 'order status page'",
								StepResult.PASS);
					} else {
						report.addReportStep(
								"click on the order# in search results page",
								"failed to traverse to 'order status page'",
								StepResult.FAIL);
					}
				} catch (Exception e) {
					report.addReportStep(
							"click on the order# in search results page",
							"failed to traverse to 'order status page'",
							StepResult.FAIL);
				}
			} else {
				report.addReportStep(
						"click on the order# in search results page",
						"unable to find the order#", StepResult.FAIL);
			}
		} catch (Exception e) {
			report.addReportStep("click on the order# in search results page",
					"unable to find the order#", StepResult.FAIL);
		}
	}
	
	/**
	 * 
	 * Description : Order Status for BOPIS in CSR search page
	 * 
	 * @since May 24, 2013
	 * @author PXM8946
	 */

	public boolean orderStatusForBopisInCSRSearchPage() {

		String strPage = driver.getTitle();
		System.out.println(strPage);
		String strOrderStatus = driver
				.findElement(
						By.xpath("//div[@id='innerCSRContainer']/table[2]/tbody/tr[2]/td[3]"))
				.getText();
		System.out.println(strOrderStatus);
		if (strPage.contains("Detailed Order Status")) {
			report.addReportStep(
					"Verify the status in <b>Search Results</b> page", "<b>"
							+ strOrderStatus
							+ "</b> status is displayed in <b>" + strPage
							+ "</b> page", StepResult.PASS);
			return true;
		} else {
			report.addReportStep(
					"Verify the status in <b>Search Results</b> page",
					"Status is not displayed in <b>" + strPage + "</b> page",
					StepResult.FAIL);
			return false;
		}

	}
	
	

}
