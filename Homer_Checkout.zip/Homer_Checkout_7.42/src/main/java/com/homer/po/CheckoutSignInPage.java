package com.homer.po;

import org.openqa.selenium.By;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class CheckoutSignInPage extends PageBase<CheckoutSignInPage> {

	static final By verifySignInPage = By.id("secureLogin");
	static final By verifyPersistentSignInPage = By.id("persistLogin");
	static final By guestEmailTxtBox = By.id("guestEmail");
	static final By regEmailTxtBox = By.id("email");
	static final By regPwdTxtBox = By.id("password");
	static final By signIn = By.id("signInNow");
	static final By continueBtn = By.xpath("//a[text()='CONTINUE']");
	static final By editCartBtn = By.xpath("//a[contains(text(),'EDIT CART')]");
	static final By sessionExpireMsg = By
			.xpath("//h3[contains(text(),'Session expired. Please sign in again to continue.')]");
	static final By checkoutBtn = By.xpath("//a[contains(text(),'CONTINUE CHECKOUT')]");
	static final By backBtn = By.xpath("//a[contains(text(),'Back')]");
	static final By backBtn2 = By.xpath("(//a[contains(text(),'Back')])[1]");

	static final By editCartCnt = By.xpath("//span[@class='afterCnt text-primary bold']");
	static final By viewCart = By.id("LoginViewCart");
	// editCartCnt

	static final By guestChkout = By.xpath("//h3[contains(text(),'Guest Checkout')]");
	static final By guestEmail = By.xpath("//label[contains(text(),' Email Address:')]");
	static final By regChkout = By.xpath("//h3[contains(text(),'I'm a Returning User')]");
	static final By regEmail = By.xpath("(//label[contains(text(),' Email Address:')])[2]");
	static final By backGuest = By.xpath("(//a[contains(text(),'BACK TO CART')])[1]");
	static final By backReg = By.xpath("(//a[contains(text(),'BACK TO CART')])[2]");
	static final By guestChkoutSec = By.id("guest");
	static final By regChkoutSec = By.id("checkOutLogonForm");
	static final By emailErrMsg = By.xpath("//span[contains(text(),'Enter a valid email address')]");
	static final By pwdErrMsg = By.xpath("//span[contains(text(),'Passwords must be 8-16 characters')]");
	static final By persitentGuest = By.id("persistentGuestLogonForm");
	static final By persistentReg = By.id("persistentLogonForm");
	static final By persitentGuestOverlay = By
			.xpath("//div[@class='md-content']/h3[contains(text(),'You chose to check out as a guest')]");
	static final By persitentGuestCheckout = By
			.cssSelector("input.persist-guest-btn.btn.btn-orange.continue.left.pointer");
	static final By persitentGuestCancel = By
			.cssSelector("input.btn.btn-flat-lightGray.m-right-small.md-close.left.pointer");

	// Cart merge overlay
	static final By cartMergeOverlay = By.xpath("//*[@id='merge-cart']");
	
	//GuestuserOption - MLTC-2718
	static final By guestOptionOverlay = By.xpath("//div[@class='p-all-normal']");
	static final By proceedCheckoutButton = By.xpath("//input[@value='PROCEED TO CHECKOUT']");
	static final By cancelButton = By.xpath("//input[@value='CANCEL']");

	public CheckoutSignInPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify secure page
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage verifySecurePage() throws Exception {

		if (wh.isElementPresent(verifySignInPage, 15)) {

			report.addReportStep("Verify Checkout Sign In Page", "Checkout Sign In Page is displayed", StepResult.PASS);
		} else {

			report.addReportStep("Verify Checkout Sign In Page", "Checkout Sign In Page is not displayed",
					StepResult.FAIL);
			rc.terminateTestCase("Secure Signin Page");
		}

		return this;
	}

	/**
	 * Method to sign in as guest
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage guestSignInAndContinue() throws Exception {

		String strTimeStmp = "Run_" + rc.getCurrentFormattedTime().replace(" ", "_").replace(":", "-");
		String strEmail = strTimeStmp + "@homedepot.com";
		commonData.strEmailGuest = strEmail;

		if (wh.isElementPresent(guestEmailTxtBox, 5)) {

			wh.sendKeys(guestEmailTxtBox, strEmail);

			Thread.sleep(commonData.littleWait);

			wh.clickElement(continueBtn);

			wh.waitForPageLoaded();

			report.addReportStep("Select guest user, enter email and click on continue",
					"Selected guest user, enter email and clicked on continue", StepResult.PASS);
		} else {
			report.addReportStep("Select guest user, enter email and click on continue",
					"Not Selected guest user, enter email and clicked on continue", StepResult.FAIL);
			rc.terminateTestCase("Checkout Sign in page");
		}

		return new ShippingPage(ic);
	}
	
	/**
	 * Method to sign in as guest
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShippingPage guestSignInWithExistingMailIdAndContinue(String strEmail) throws Exception {

		commonData.strEmailGuest = strEmail;

		if (wh.isElementPresent(guestEmailTxtBox, 5)) {

			wh.sendKeys(guestEmailTxtBox, strEmail);

			Thread.sleep(commonData.littleWait);

			wh.clickElement(continueBtn);

			wh.waitForPageLoaded();

			report.addReportStep("Select guest user, enter email and click on continue",
					"Selected guest user, enter email and clicked on continue", StepResult.PASS);
		} else {
			report.addReportStep("Select guest user, enter email and click on continue",
					"Not Selected guest user, enter email and clicked on continue", StepResult.FAIL);
			rc.terminateTestCase("Checkout Sign in page");
		}

		return new ShippingPage(ic);
	}

	/**
	 * Method to sign in as Reg
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage registerUserSignIn() throws Exception {

		if (wh.isElementPresent(regEmailTxtBox, 5)) {

			wh.sendKeys(regEmailTxtBox, commonData.strEmail);

			wh.sendKeys(regPwdTxtBox, commonData.strPassword);

			wh.clickElement(signIn);
			
			wh.waitForPageLoaded();
			Thread.sleep(commonData.LongWait);

			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Selected register user, entered email password and clicked on continue", StepResult.PASS);
		} else {
			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Not Selected register user, not entered email password and clicked on continue", StepResult.FAIL);
			rc.terminateTestCase("Checkout Sign in page");
		}

		return this;
	}

	/**
	 * Method to click cart merge overlay edit button
	 *
	 * @throws Exception
	 */
	public void cartMergeOverlayEditCartBtn() throws Exception {

		if (wh.isElementPresent(editCartBtn, 5)) {
			commonData.editCartCount = wh.getText(editCartCnt);
			wh.clickElement(editCartBtn);
			Thread.sleep(commonData.LongWait);
			report.addReportStep("Verify EDIT CART button is clicked", "<b>EDIT CART</b> button is clicked",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify EDIT CART button is clicked", "<b>EDIT CART</b> button is not clicked",
					StepResult.FAIL);
		}

	}

	/**
	 * Method to verify session expired error message
	 *
	 * @throws Exception
	 */
	public void verifySessionExpiredErrMsg() throws Exception {

		if (wh.isElementPresent(sessionExpireMsg, 2)) {
			String errMsg = driver.findElement(sessionExpireMsg).getText();
			if (errMsg.contains("Session expired. Please sign in again to continue")) {
				report.addReportStep("Verify sesion expired error message displayed after idle time",
						"Error message<b>" + errMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify sesion expired error message displayed after idle time",
						"Error message<b>" + errMsg + "</b> is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify sesion expired error message displayed after idle time",
					"Error message is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Method to enter password for the persistant user
	 * 
	 * @throws Exception
	 */
	public void enterPwdForPersistentUser() throws Exception {

		String strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);
		By signInBtn = By.xpath("//input[@class='btn btn-orange left continue pointer']");

		if (wh.isElementPresent(regPwdTxtBox)) {

			wh.sendKeys(regPwdTxtBox, strPassword);
			wh.clickElement(signInBtn);

			report.addReportStep("Enter password for persistent user in secure signin page",
					"Password entered for persistent user in secure signin page", StepResult.PASS);
		} else {

			report.addReportStep("Enter password for persistent user in secure signin page",
					"Password is not entered for persistent user in secure signin page", StepResult.FAIL);

		}

	}

	/**
	 * Method to click cart merge overly checkout button
	 *
	 * @throws Exception
	 */
	public void cartMergeOverlayCheckoutBtn() throws Exception {

		if (wh.isElementPresent(checkoutBtn, 2)) {
			wh.clickElement(checkoutBtn);

			report.addReportStep("Verify CONTINUE CHECKOUT button is clicked",
					"<b>CONTINUE CHECKOUT</b> button is clicked", StepResult.PASS);

		} else {
			report.addReportStep("Verify CONTINUE CHECKOUT button is clicked",
					"<b>CONTINUE CHECKOUT</b> button is not clicked", StepResult.FAIL);
		}

	}

	/**
	 * Method to click back button
	 *
	 * @throws Exception
	 */
	public void clickBackButton() throws Exception {

		if (wh.isElementPresent(backBtn, 2)) {
			wh.clickElement(backBtn);

			report.addReportStep("Verify BACK button is clicked", "<b>BACK</b> button is clicked", StepResult.PASS);

		} else {
			report.addReportStep("Verify BACK button is clicked", "<b>BACK</b> button is not clicked", StepResult.FAIL);
		}

	}

	public void verifyGuestCheckoutSection() throws Exception {

		if (wh.isElementPresent(guestChkoutSec, 2)) {
			String guestTxt = wh.getText(guestChkout);
			if (guestTxt.contains("Guest Checkout")) {
				report.addReportStep("Verify Guest Checkout text is displayed", guestTxt + "text is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Guest Checkout text is displayed", guestTxt + "text is not displayed",
						StepResult.FAIL);
			}
			String guestEmailTxt = wh.getText(guestEmail);
			if (guestEmailTxt.contains(" Email Address:")) {
				report.addReportStep("Verify Email Address text is displayed", guestEmailTxt + "text is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Email Address text is displayed", guestEmailTxt + "text is not displayed",
						StepResult.FAIL);
			}

			String backGuestTxt = wh.getText(backGuest);
			if (backGuestTxt.contains("BACK TO CART")) {
				report.addReportStep("Verify Back to cart text is displayed", backGuestTxt + "text is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Email Address text is displayed", backGuestTxt + "text is not displayed",
						StepResult.FAIL);
			}

			if (wh.isElementPresent(continueBtn, 2)) {

				report.addReportStep("Verify Continue button is displayed", "<b>CONTINUE</b> button is displayed",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify Continue button is displayed", "<b>CONTINUE</b> button is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Guest Checkout section is displayed",
					"Guest Checkout section is not displayed", StepResult.FAIL);
		}

	}

	public void verifyRegCheckoutSection() throws Exception {

		if (wh.isElementPresent(regChkoutSec, 2)) {

			String regTxt = wh.getText(regChkout);
			if (regTxt.contains("I'm a Returning User")) {
				report.addReportStep("Verify Reg Checkout text is displayed", regTxt + "text is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Reg Checkout text is displayed", regTxt + "text is not displayed",
						StepResult.FAIL);
			}
			String regEmailTxt = wh.getText(regEmail);
			if (regEmailTxt.contains("I'm a Returning User")) {
				report.addReportStep("Verify Email Address text is displayed", regEmailTxt + "text is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Email Address text is displayed", regEmailTxt + "text is not displayed",
						StepResult.FAIL);
			}

			String backRegTxt = wh.getText(backReg);
			if (backRegTxt.contains("BACK TO CART")) {
				report.addReportStep("Verify Back to cart text is displayed", backRegTxt + "text is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Email Address text is displayed", backRegTxt + "text is not displayed",
						StepResult.FAIL);
			}
			if (wh.isElementPresent(signIn, 2)) {

				report.addReportStep("Verify SignIn button is displayed", "<b>SIGNIN</b> button is displayed",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify SignIn button is displayed", "<b>SIGNIN</b> button is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Register Checkout section is displayed",
					"Register Checkout section is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Method to verify View Cart link
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage verifyViewCartLink() throws Exception {

		if (wh.isElementPresent(viewCart, 15)) {

			report.addReportStep("Verify View Cart link in secure checkout page",
					"View Cart link is displayed in secure checkout page", StepResult.PASS);
			wh.clickElement(viewCart);
			report.addReportStep("Click View Cart link in secure checkout page",
					"View Cart link is clicked in secure checkout page", StepResult.PASS);

		} else {

			report.addReportStep("Verify View Cart link in secure checkout page",
					"View Cart link is not displayed in secure checkout page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to verify cart merge overlay and click continue
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyCartMergeOverlay() throws Exception {
		if (wh.isElementPresent(cartMergeOverlay)) {
			String strItemadded = wh.getText(By.xpath("//*[@id='merge-cart']//h4[2]"));
			System.out.println(strItemadded);
			if (strItemadded.contains("We have merged your items")) {
				report.addReportStep("Item added to your account", "Item added info" + strItemadded + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Item added to your account", "Item added info is not  displayed",
						StepResult.FAIL);
			}
			// To click continue
			wh.jsClick(checkoutBtn);
			Thread.sleep(1000);
			report.addReportStep("verify merge cart overlay", "Merge cart overlay is displayed", StepResult.PASS);
		} else {
			report.addReportStep("verify merge cart overlay", "Merge cart overlay is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Method to verify back button is not available
	 *
	 * @throws Exception
	 */
	public void verifyBackButtonNotAvailable() throws Exception {

		if (wh.isElementNotPresent(backBtn) && wh.isElementNotPresent(backBtn2)) {

			report.addReportStep("Verify BACK TO CART buttons are not available in Secure sign in page",
					"<b>BACK TO CART</b> buttons are not available in Secure sign in page", StepResult.PASS);

		} else {
			report.addReportStep("Verify BACK TO CART buttons are not available in Secure sign in page",
					"<b>BACK TO CART</b> buttons are available in Secure sign in page", StepResult.FAIL);
		}

	}

	/**
	 * Method to verify persistent sign in page
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage verifyPersistentSignInPage() throws Exception {

		if (wh.isElementPresent(verifyPersistentSignInPage, 15)) {

			report.addReportStep("Verify Persistent Sign In Page", "Persistent Sign In Page is displayed",
					StepResult.PASS);
		} else {

			report.addReportStep("Verify Persistent Sign In Page", "Persistent Sign In Page is not displayed",
					StepResult.FAIL);
			rc.terminateTestCase("Persistent Signin Page");
		}

		return this;
	}

	/**
	 * Method to verify session expired error message not displayed
	 *
	 * @throws Exception
	 */
	public void verifySessionExpiredErrMsgNotPresent() throws Exception {

		if (wh.isElementNotPresent(sessionExpireMsg)) {

			report.addReportStep("Verify sesion expired error message displayed after idle time",
					"Session expired error message is not displayed", StepResult.PASS);

		} else {
			report.addReportStep("Verify sesion expired error message displayed after idle time",
					"Session expired error message is displayed", StepResult.FAIL);
		}

	}

	/**
	 * Method to verify view cart link qty
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage verifyViewCartLinkQty() throws Exception {

		if (wh.isElementPresent(viewCart, 15)) {
			report.addReportStep("Verify View cart link is present in secure checkout page",
					"View cart link is present in secure checkout page", StepResult.PASS);
			String viewCartQty = wh.getText(viewCart);
			if (commonData.qtyTotal > 999) {
				if (viewCartQty.contains("999+")) {
					report.addReportStep(
							"Verify the Qty is displayed as 999+ in view cart link when qty in cart exceeds 999",
							"Qty is displayed as 999+ in view cart link", StepResult.PASS);
				} else {
					report.addReportStep(
							"Verify the Qty is displayed as 999+ in view cart link when qty in cart exceeds 999",
							"Qty is not displayed as 999+ in view cart link", StepResult.FAIL);
				}

			} else {
				if (viewCartQty.contains(commonData.QuantityTotal)) {
					report.addReportStep("Verify the Qty displayed in view cart link is same as cart page total qty",
							"Qty " + commonData.qtyTotal
									+ " displayed in view cart link is same as cart page total qty",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify the Qty displayed in view cart link is same as cart page total qty",
							"Qty " + viewCartQty + " displayed in view cart link is not same as cart page total qty",
							StepResult.FAIL);
				}
			}
		} else {

			report.addReportStep("Verify View cart link is present in secure checkout page",
					"View cart link is not present in secure checkout page", StepResult.FAIL);
			rc.terminateTestCase("View cart link");
		}

		return this;
	}

	public void enterEmptyPwdForRegUser() throws Exception {

		if (wh.isElementPresent(regEmailTxtBox, 5)) {

			wh.sendKeys(regEmailTxtBox, commonData.strEmail);

			wh.clickElement(signIn);

			wh.waitForPageLoaded();
			if (wh.isElementPresent(pwdErrMsg, 7)) {
				String errMsg = driver.findElement(pwdErrMsg).getText();
				if (errMsg.contains("Passwords must be 8-16 characters in length and are case sensitive")) {
					report.addReportStep("Enter reg email and leave pwd blank and click signin",
							"Err Msg <b>" + errMsg + " </b>is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Enter reg email and leave pwd blank and click signin",
							"Err Msg <b>" + errMsg + " </b>is not displayed properly", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Enter reg email and leave pwd blank and click signin", "Err Msg is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Enter reg email and leave pwd blank and click signin",
					"Email address field is not displayed", StepResult.FAIL);
		}

	}

	public void enterWrongPwdForRegUser() throws Exception {

		if (wh.isElementPresent(regEmailTxtBox, 5)) {

			wh.sendKeys(regEmailTxtBox, commonData.strEmail);

			wh.sendKeys(regPwdTxtBox, dataTable.getData("NewRegPwd"));

			wh.clickElement(signIn);

			wh.waitForPageLoaded();
			if (wh.isElementPresent(pwdErrMsg, 7)) {
				String errMsg = driver.findElement(pwdErrMsg).getText();
				if (errMsg.contains("Passwords must be 8-16 characters in length and are case sensitive")) {
					report.addReportStep("Enter reg email and enter wrong pwd and click signin",
							"Err Msg <b>" + errMsg + " </b>is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Enter reg email and enter wrong pwd and click signin",
							"Err Msg <b>" + errMsg + " </b>is not displayed properly", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Enter reg email and enter wrong pwd and click signin", "Err Msg is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Enter reg email and enter wrong pwd and click signin",
					"Email address field is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify persistent guest section
	 * 
	 * @since Mar 14,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyPersistentGuestSection() throws Exception {

		if (wh.isElementPresent(persitentGuest, 5)) {
			report.addReportStep("Verify persistent guest login section", "persistent guest login section is displayed",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify persistent guest login section",
					"persistent guest login section is not displayed ", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify persistent email id pre populated
	 * 
	 * @since Mar 14,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyPersistentEmailPopulated() throws Exception {

		if (wh.isElementPresent(persitentGuest, 5)) {
			String emailId = driver.findElement(guestEmailTxtBox).getAttribute("value");
			System.out.println("==============================> " + emailId);
			if (emailId.equalsIgnoreCase(commonData.strEmail)) {
				report.addReportStep("Verify persistent email id in guest login section",
						"Persistent Email Id<b> " + emailId + " </b>is pre populated in guest login section",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify persistent email id in guest login section",
						"Persistent Email Id<b> " + emailId + " </b> is not pre populated in guest login section",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify persistent email id in guest login section",
					"persistent guest login section is not displayed ", StepResult.FAIL);
		}
		if (wh.isElementPresent(persistentReg, 5)) {
			String emailId = driver.findElement(regEmailTxtBox).getAttribute("value");
			System.out.println("===============================> " + emailId);
			if (emailId.equalsIgnoreCase(commonData.strEmail)) {
				report.addReportStep("Verify persistent email id in registered login section",
						"Persistent Email Id<b> " + emailId + " </b> is pre populated in registered login section",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify persistent email id in registered login section",
						"Persistent Email Id<b> " + emailId + " </b> is not pre populated in registered login section",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify persistent email id in registered login section",
					"persistent registered login section is not displayed ", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify persistent guest overlay
	 * 
	 * @since Mar 14,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyPersistentGuestOverLay() throws Exception {

		if (wh.isElementPresent(persitentGuestOverlay, 5)) {
			report.addReportStep("Verify Persistent guest overlay", "Persistent guest overlay is displayed",
					StepResult.PASS);
			if (wh.isElementPresent(persitentGuestCheckout)) {
				String strBtn = driver.findElement(persitentGuestCheckout).getAttribute("value");
				if (strBtn.contains("PROCEED TO CHECKOUT")) {
					report.addReportStep("Verify Proceed to checkout button",
							"<b> " + strBtn + " </b>is displayed in Persistent guest overlay", StepResult.PASS);
				} else {
					report.addReportStep("Verify Proceed to checkout button",
							"<b> " + strBtn + " </b>is not displayed in Persistent guest overlay", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify Proceed to checkout button",
						"Proceed to checkout button is not displayed ", StepResult.FAIL);
			}
			if (wh.isElementPresent(persitentGuestCancel)) {
				String strBtn = driver.findElement(persitentGuestCancel).getAttribute("value");
				if (strBtn.contains("CANCEL")) {
					report.addReportStep("Verify Cancel button",
							"<b> " + strBtn + " </b>is displayed in Persistent guest overlay", StepResult.PASS);
				} else {
					report.addReportStep("Verify Cancel button",
							"<b> " + strBtn + " </b>is not displayed in Persistent guest overlay", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify Cancel button", "Cancel button is not displayed ", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Persistent guest overlay", "Persistent guest overlay is not displayed ",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to click proceed to checkout button
	 * 
	 * @since Mar 14,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickProceedCheckoutInOverlay() throws Exception {

		if (wh.isElementPresent(persitentGuestCheckout, 5)) {
			wh.clickElement(persitentGuestCheckout);
			report.addReportStep("Verify proceed to checkout button", "Proceed to checkout button is clicked",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify proceed to checkout button", "Proceed to checkout button is not clicked ",
					StepResult.FAIL);
		}

	}

	/*** MLTC-2718 ***/

	public CheckoutSignInPage verifyProceedGuestCheckout() throws Exception {

		if (wh.isElementPresent(guestOptionOverlay)) {

			report.addReportStep("Verify Persisted Guest Option ovelay getting displayed",
					"Persisted Guest Option ovelay getting displayed ", StepResult.PASS);
			wh.clickElement(proceedCheckoutButton);

			report.addReportStep("Click Proceed Checkout Button in the Guest Option ovelay",
					"Proceed Checkout Button is clicked ", StepResult.PASS);
		} else {
			report.addReportStep("Verify Persisted Guest Option ovelay getting displayed",
					"Persisted Guest Option ovelay is not getting displayed ", StepResult.FAIL);
		}

		return this;
	}
	
	/**
	 * Component to click continue button in persistent guest section
	 * 
	 * @since Mar 15,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickContinueButton() throws Exception {
		if (wh.isElementPresent(continueBtn, 2)) {
			wh.clickElement(continueBtn);
			report.addReportStep("Verify Continue button is clicked", "<b>CONTINUE</b> button is clicked",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify Continue button is clicked", "<b>CONTINUE</b> button is not clicked",
					StepResult.FAIL);
		}
	}
	
	/**
	 * Method to sign in as Existing User
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage existingUserSignIn() throws Exception {

		if (wh.isElementPresent(regEmailTxtBox, 5)) {
			wh.sendKeys(regEmailTxtBox, "");
			wh.sendKeys(regEmailTxtBox, dataTable.getCommonData(CommonDataColumn.RegUserEmail));
			wh.sendKeys(regPwdTxtBox, "");
			wh.sendKeys(regPwdTxtBox, dataTable.getCommonData(CommonDataColumn.RegUserPwd));

			wh.clickElement(signIn);

			wh.waitForPageLoaded();
			Thread.sleep(commonData.LongWait);

			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Selected register user, entered email password and clicked on continue", StepResult.PASS);
		} else {
			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Not Selected register user, not entered email password and clicked on continue", StepResult.FAIL);
			rc.terminateTestCase("Checkout Sign in page");
		}

		return this;
	}
	
	/**MLTC-3017 and 3019 - Clear Guest user cookies from Thank you page
	 * Method to verify guest user email ID is not pre-populated in Checkout sign in page
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage verifySecurePageGuest() throws Exception {
		
		String strEmail = ".com";
		if (wh.isElementPresent(verifySignInPage, 15)){
			
			String GuestEmailId = driver.findElement(guestEmailTxtBox).getAttribute("value");
			System.out.println("Value of guest email Id is " + GuestEmailId);
			if (GuestEmailId.contains(strEmail)) {
				
				report.addReportStep("Verify check out sign in page does not prepopulate guest email id",
						"Guest Email Id<b> " + GuestEmailId + " </b>is pre populated in guest login section",
						StepResult.FAIL);
			} else {
				report.addReportStep("Verify check out sign in page does not prepopulate guest email id",
						"Guest Email Id<b> " + GuestEmailId + " </b> is not pre populated in guest login section",
						StepResult.PASS);
			}
			
		} else {

			report.addReportStep("Verify Checkout Sign In Page", "Checkout Sign In Page is not displayed",
					StepResult.FAIL);
			rc.terminateTestCase("Secure Signin Page");
		}

		return this;
	}

}
