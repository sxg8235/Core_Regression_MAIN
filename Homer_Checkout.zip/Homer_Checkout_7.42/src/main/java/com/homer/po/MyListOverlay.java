package com.homer.po;

import org.openqa.selenium.By;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class MyListOverlay extends PageBase<MyListOverlay>{


	static final By regEmail = By.id("email_id");
	static final By regEmailTab = By.id("logonId");
	static final By regPwd = By.id("password");
	static final By regPwdTab = By.id("logonPassword");
	static final By regSignInBtn = By.id("signIn");
	static final By regSignInBtnTab = By.xpath("//input[@type='submit']");
	static final By listName = By.id("add_new_list_cart");
	static final By listNamePIP = By.id("add_new_list");
	static final By listNamePIPTab = By.id("listName");
	static final By submitBtn = By.xpath("//a[contains(text(),'Submit')]");
	static final By createListBtn = By.xpath("//a[contains(text(),'Create List')]");
	static final By createListBtnTab=By.id("createNewList");
	static final By viewListBtn = By.xpath("//span[contains(text(),'VIEW LIST')]");
	static final By listAdded = By.xpath("//div[contains(@id,'item_copied_')]/a/span");
	static final By listAddedPIP = By.xpath("//div[contains(text(),'New list created')]");
	static final By myListPg = By.xpath("//h1[contains(text(),'My Lists')]");

	static final By accountLinkHdr = By.xpath("//a[contains(text(),'Your Account')]");
	static final By clickMyList = By.xpath("//a[contains(text(),'My Lists')]");
	static final By clickListName = By.xpath("//a[contains(text(),'ListOne')]");

	public MyListOverlay(InstanceContainer ic) {
		super(ic);
	}
	
	
	
	/**
	 * Method to sign in as Reg 
	 * @return
	 * @throws Exception
	 */
	public MyListOverlay regUserSignInAddToList() throws Exception {
		
		if (wh.isElementPresent(regEmail,5)){

			wh.sendKeys(regEmail, commonData.strEmail);
			
			wh.sendKeys(regPwd, commonData.strPassword);

			wh.clickElement(regSignInBtn);
			
			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Selected register user, entered email password and clicked on continue", 
					StepResult.PASS);
		}
		else if(wh.isElementPresent(regEmailTab,5)){
			wh.sendKeys(regEmailTab, commonData.strEmail);
			
			wh.sendKeys(regPwdTab, commonData.strPassword);

			wh.clickElement(regSignInBtnTab);
			
			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Selected register user, entered email password and clicked on continue", 
					StepResult.PASS);
		}
		else{
			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Not Selected register user, not entered email password and clicked on continue", 
					StepResult.FAIL);
			rc.terminateTestCase("Add to list Sign in overlay");
		}
		
			
		
		return this;
	}
	
	/**
	 * Method to Add prod to list from cart 
	 * @return
	 * @throws Exception
	 */
	public MyListOverlay addProdToListCart() throws Exception {
		
		if (wh.isElementPresent(listName,5)){

			wh.sendKeys(listName, "ListOne");
			
			wh.clickElement(submitBtn);
			
			report.addReportStep("Verify Add to list overlay is displayed and able to click submit button",
					"Add to list overlay is displayed and able to click submit button", 
					StepResult.PASS);
			
			if (wh.isElementPresent(listAdded,5)){
				
				report.addReportStep("Verify Product is added to the given list",
						"Product is added to the given list", 
						StepResult.PASS);
			}
			else{
				report.addReportStep("Verify Product is added to the given list",
						"Product is not added to the given list", 
						StepResult.FAIL);
			}
			
		}
		
		else if(wh.isElementPresent(listNamePIPTab,5)){

			wh.sendKeys(listNamePIPTab, "ListOne");
			
			wh.clickElement(createListBtnTab);
			
			report.addReportStep("Verify Add to list overlay is displayed and able to click submit button",
					"Add to list overlay is displayed and able to click submit button", 
					StepResult.PASS);
			
			if (wh.isElementPresent(listAdded,5)){
				
				report.addReportStep("Verify Product is added to the given list",
						"Product is added to the given list", 
						StepResult.PASS);
			}
			else{
				report.addReportStep("Verify Product is added to the given list",
						"Product is not added to the given list", 
						StepResult.FAIL);
			}
			
		}
		else{
			report.addReportStep("Verify Add to list overlay is displayed and able to click submit button",
					"Add to list overlay is not displayed and unable to click submit button", 
					StepResult.FAIL);
			rc.terminateTestCase("Add to list overlay");
		}
		
			
		
		return this;
	}
	

    /**
     * Method to add prod list
     * @return
     * @throws Exception
     */
	public MyListOverlay addProdToListPIP() throws Exception {

		if (wh.isElementPresent(listNamePIP, 5)) {

			wh.sendKeys(listNamePIP, "ListOne");

			wh.clickElement(createListBtn);

			report.addReportStep(
					"Verify Add to list overlay is displayed and able to click create list button",
					"Add to list overlay is displayed and able to click create list button",
					StepResult.PASS);

			if (wh.isElementPresent(listAddedPIP, 5)) {

				wh.clickElement(viewListBtn);

				report.addReportStep(
						"Verify Product is added to the given list",
						"Product is added to the given list", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Product is added to the given list",
						"Product is not added to the given list",
						StepResult.FAIL);
			}

			if (wh.isElementPresent(myListPg, 5)) {

				

				report.addReportStep("Verify My list page is displayed",
						"My list page is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify My list page is displayed",
						"My list page is not displayed", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(listNamePIPTab, 5)) {

			wh.sendKeys(listNamePIPTab, "ListOne");

			wh.clickElement(createListBtnTab);

			report.addReportStep(
					"Verify Add to list overlay is displayed and able to click create list button",
					"Add to list overlay is displayed and able to click create list button",
					StepResult.PASS);
			if (wh.isElementPresent(accountLinkHdr, 5)) {
				wh.clickElement(accountLinkHdr);
				report.addReportStep("Verify Your Account link is clicked",
						"Your Account link is clicked", StepResult.PASS);
				
				wh.clickElement(clickMyList);
				wh.clickElement(clickListName);

			} else {
				report.addReportStep("Verify My list page is displayed",
						"My list page is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify Add to list overlay is displayed and able to click submit button",
					"Add to list overlay is not displayed and unable to click submit button",
					StepResult.FAIL);
			rc.terminateTestCase("Add to list overlay");
		}

		

		return this;
	}
    
 	
}
