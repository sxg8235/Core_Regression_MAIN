package com.homer.po;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.homer.dao.CommonData;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class ThankYouPage extends PageBase<ThankYouPage> {

	public boolean isProdEnv = false;

	static final By verifyOrderPage = By.xpath("//*[contains(text(),'Thank You For Your Order')]");
	static final By orderNumber = By.xpath("(//*[contains(text(),'Order Summary')])[1]/following-sibling::h3");
	static final By applianceDeliveryText = By
			.xpath("//div[@class='order-summary-pod']/descendant::h4[contains(text(),'Appliance Delivery')]");
	static final By applianceDeliveryCharge = By.xpath("//div[@class='order-summary-pod']/descendant::h4[contains(text(),'Appliance Delivery')]/./../..//div[2]//h4[2]");
	static final By regPwd = By.id("newPasswordField");
	static final By regConfirmPwd = By.id("confirm-password-field");
	static final By regBtn = By.id("registerBtn");
	static final By callOutPopup = By.id("appliance-new-feature");
	static final By expressDeliveryLabel = By.xpath("(//h4[contains(text(),'Express Delivery :')])[1]");
	static final By assemblyThankYouPg = By.id("appliance-new-feature");
	static final By verifyOrderConfEmailPage = By.xpath("//td[contains(text(),'. We have received your order')]");
	static final By closeCallout = By.xpath("//button[@class='md-close']");
	static final By HDPP = By.xpath("//span[@class='hdpp-info-banner m-right-large left m-bottom-large' and @title='Home Depot Protection Plan']");
	static final By NextStepMsg = By.cssSelector("div.hdpp-delivery-msg");
	static final By ProdDescLink=By.xpath("//*[@class='item-desc left p-right-small overflowHidden']//a");
	
	// NextStepMsg
	static By certonaTYP = By.cssSelector("div.certona1main.grid");
	static By certonaAddToCartBtn = By
			.cssSelector("#thankyou1_rr > div > div:nth-child(1) > div > a.overlayCartTrigger.dynamic_btn.orange_btn.c > span");

	static By ApplianceNewFeatureOverlay = By.xpath("//div[@id='appliance-new-feature']//button[@class='md-close']");
	static By Header = By.xpath("(//div[@class='header'])[1]//h3[1]");
	static By OrderSummarySection = By.xpath("(//*[@class='order-summary order-summary-container clear'])[1]|(//*[@class='order-summary order-summary-container'])[1]");
	static By PaymentContainer = By.xpath("//*[@class='clear payment-container-content']|//*[@class='order-summary payment-container fullWidth']");
	static By SubTotal = By
			.xpath("(//*[contains(text(),'Merchandise Subtotal : ')])[1]|(//*[contains(text(),'Subtotal : ')])[1]");
	static By OrderSummary = By.xpath("(//*[@class='order-summary-pod'])[1]");
	static By MerchSubtotal = By.xpath("(//*[contains(text(),'Merchandise Subtotal : ')])[1]");
	static By subtotalsection = By.xpath("(//*[contains(text(),'Subtotal : ')])[1]");
	static By AppSubtotal = By.xpath("(//*[contains(text(),'Appliance Subtotal : ')])[1]");
	static By SummaryInnersection = By
			.xpath("(//*[@class='order-summary-pod'])[1]//div[@class='left left-summary left-pod']|(//*[@class='order-summary-pod'])[1]//div[@class='p-custom-inner-block']");

	static By certonaAddToCartBtnAppl = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add to cart')]");
	static By certonaAddToCartLink = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]/..");
	static By certonaAddToCartLinkAppl = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add to cart')]/..");
	static By POField = By.xpath("//div[@class='order-summary payment-container fullWidth']//h3[contains(text(),'PO #')]");
	static By CustomImage=By.className("blinds-custom-image");
	static By BlindDesc=By.cssSelector(".iDesc .title");
    static final By EstimatedSalesTax=By.xpath("(//*[@data-modal-content='#estimated-sales-tax-tip-content']/..)[1]");
    static final By salestax=By.xpath("(//*[@id='sales-tax'])[2]");
    static final By weakPwdMsg = By.xpath("//span[contains(text(),'Passwords must be a minimum of 8 characters')]");
    static final By pwdMismatchMsg = By.xpath("//span[@class='password-match-fail error-container']");
    static final By PromotionCodeText=By.xpath("//h3[contains(text(),'Promotion Code')]");
    static final By Promotion=By.xpath("//td[@class='total price-negative']");
    static final By applDelDate=By.xpath("//div[@class='pod-summary']/div/h3[2]");
    static final By guestUserNmShipAddress=By.xpath("//div[@class='right']");
    static final By lnkMyAccount = By.id("headerMyAccount");
	static final By myListPg = By.xpath("//a[contains(text(),'My Lists')]");
	static final By orderStatusLink = By.xpath("//a[@class='order-status thdOrange']");
	static final By orderStatusPg = By.xpath("//div[@class='checkOrderStatus']");
    
	public ThankYouPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify Thank You page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ThankYouPage verifyThankYouPage() throws Exception {

		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

			return this;
		}
		Thread.sleep(commonData.mediumWait);
		wh.waitForElementPresent(verifyOrderPage, 2);

		if (wh.noWaitElementPresent(verifyOrderPage)) {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"'Thank You for Your Order' page is displayed with Order Number : <b>" + wh.getText(orderNumber)
							+ "</b>", StepResult.PASS);
			String order = wh.getText(orderNumber);
			commonData.orderNumber = order.substring(1).trim();
		} else {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"'Thank You for Your Order' page was not displayed.", StepResult.FAIL);

			rc.terminateTestCase("Thank You for Your Order");
		}

		return this;
	}

	/**
	 * Method to verify Thank You page along with Express Delivery Label
	 * 
	 * @return
	 * @throws Exception
	 *             Kxn8362
	 */

	public ThankYouPage verifyThankYouPageWithExpressDeliveryLabel() throws Exception {
		wh.waitForPageLoaded();
		if (isProdEnv) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

			return this;
		}

		wh.waitForElementPresent(expressDeliveryLabel, 2);

		if (wh.noWaitElementPresent(expressDeliveryLabel)) {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"'Thank You for Your Order' page is displayed with Order Number : <b>" + wh.getText(orderNumber)
							+ "</b>" + "And Express Delivery label is also displayed", StepResult.PASS);
		} else {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"'Thank You for Your Order' page was not displayed with Express Delivery Label.", StepResult.FAIL);

			rc.terminateTestCase("Thank You for Your Order");
		}

		return this;
	}

	/**
	 * Verify the delivery charges in thank you page order PODs
	 * 
	 * @author YXG8356
	 * @throws Exception
	 */
	public ThankYouPage verifyDeliveryChargeInThankYouPage() throws Exception {

		List<WebElement> DeliveryTxt_elements = driver.findElements(applianceDeliveryText);
		List<WebElement> DeliveryCharge_ele = driver.findElements(applianceDeliveryCharge);

		// Verify Apply Delivery Text in Thank you page order summary
		if (wh.isElementPresent(DeliveryTxt_elements.get(0), 2)) {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is displayed in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is not displayed in right rail", StepResult.FAIL);
		}

		// Verify Appliance Delivery Charge in Thank you page order summary
		String applianceDeliveryChargeAmt = wh.getText(DeliveryCharge_ele.get(0));
		double aSubtotalAmt = commonData.applianceSubTotal;

		if (aSubtotalAmt >= 396.00) {

			if (applianceDeliveryChargeAmt.equals("FREE")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is not displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

		else {
			if (!applianceDeliveryChargeAmt.equals("FREE") && applianceDeliveryChargeAmt.contains("$59.00")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

		// Verify Apply Delivery Text in Thank you page main summary
		if (wh.isElementPresent(DeliveryTxt_elements.get(1), 2)) {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is displayed in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is not displayed in right rail", StepResult.FAIL);
		}

		// Verify Appliance Delivery Charge in Thank you page order summary
		String applianceDeliveryChargeAmt_main = wh.getText(DeliveryCharge_ele.get(1));

		if (aSubtotalAmt >= 396.00) {

			if (applianceDeliveryChargeAmt_main.equals("FREE")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is not displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

		else {
			if (!applianceDeliveryChargeAmt_main.equals("FREE") && applianceDeliveryChargeAmt_main.contains("$59.00")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + aSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}
		return this;
	}

	/**
	 * Method to Register in Thank You page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ThankYouPage registerInThankYouPg() throws Exception {

		String strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, strPassword);

			wh.waitForPageLoaded();

			wh.clickElement(regBtn);

			report.addReportStep("Enter password and click on create account",
					"Password entered and create account button is clicked", StepResult.PASS);
		} else {

			report.addReportStep("Enter password and click on create account",
					"Password field is not present in thank you page", StepResult.FAIL);

			rc.terminateTestCase("Thank You for Your Order");
		}

		return this;
	}

	/**
	 * Method to verify callout option popup
	 * 
	 * @return ThankYouPage
	 * @throws Exception
	 */
	public ThankYouPage verifyCallOutOptionPopup() throws Exception {

		if (wh.isElementPresent(callOutPopup)) {

			report.addReportStep("Verify whether call out popup is displayed for appliance item in TYP",
					"Call out popup is displayed for appliance item in TYP", StepResult.PASS);
		} else {

			report.addReportStep("Verify whether call out popup is displayed for appliance item in TYP",
					"Call out popup is not displayed for appliance item in TYP", StepResult.FAIL);

			rc.terminateTestCase("Call out popup");
		}

		return this;
	}

	/**
	 * Method to verify no call out option popup
	 * 
	 * @return ThankYouPage
	 * @throws Exception
	 */
	public ThankYouPage verifyNoCallOutOptionPopup() throws Exception {

		if (!wh.isElementPresent(callOutPopup)) {

			report.addReportStep("Verify whether call out popup is not displayed for mixed cart in TYP",
					"Call out popup is not displayed for mixed cart in TYP", StepResult.PASS);
		} else {

			report.addReportStep("Verify whether call out popup is not displayed for mixed cart in TYP",
					"Call out popup is displayed for mixed cart in TYP", StepResult.FAIL);

			rc.terminateTestCase("Call out popup");
		}

		return this;
	}

	/**
	 * Method to wait for an hour
	 * 
	 * @return
	 * @throws Exception
	 */
	public ThankYouPage idleWaitForAnHour() throws Exception {
		Thread.sleep(3600000);
		return this;
	}

	/**
	 * To verify assembly option in thank you page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ThankYouPage verifyAssemblyOptionInThankYouPg() throws Exception {
		wh.waitForPageLoaded();
		if (isProdEnv) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

			return this;
		}

		if (wh.isElementPresent(assemblyThankYouPg, 2)) {

			report.addReportStep("Verify Assembly option is displayed in Thank you page below product description POD",
					"Assembly option is displayed in Thank you page below product description POD", StepResult.PASS);
		} else {

			report.addReportStep("Verify Assembly option is displayed in Thank you page below product description POD",
					"Assembly option is not displayed in Thank you page below product description POD", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * To verify no assembly option in thank you page
	 * 
	 * @return ThankYouPage
	 * @throws Exception
	 */
	public ThankYouPage verifyNoAssemblyOptionInThankYouPg() throws Exception {
		wh.waitForPageLoaded();
		if (isProdEnv) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

			return this;
		}

		if (wh.isElementNotPresent(assemblyThankYouPg)) {

			report.addReportStep(
					"Verify Assembly option is not displayed in Thank you page below product description POD",
					"Assembly option is not displayed in Thank you page below product description POD", StepResult.PASS);
		} else {

			report.addReportStep(
					"Verify Assembly option is not displayed in Thank you page below product description POD",
					"Assembly option is displayed in Thank you page below product description POD", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Verify Unit Price Cart
	 * 
	 * @throws Exception
	 */
	public ThankYouPage verifyUnitPriceOrderConfirmation() throws Exception {

		for (String sku : commonData.skuList) {

			By unitPriceCart = By.xpath("//a[contains(@href,'" + sku + "')]/../following-sibling::div[1]/h3");

			// By prodDesc = By.xpath("//a[contains(@href,'" + sku + "')]/h3");

			if (wh.isElementPresent(unitPriceCart, 2)) {
				String unitPrice = wh.getText(unitPriceCart);
				// String prodDescr = wh.getText(prodDesc);
				String finalPrice;
				if (unitPrice.contains(",")) {
					finalPrice = unitPrice.replaceAll(",", "");
				} else {
					finalPrice = unitPrice;
				}
				for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {

					if (sku.contains(entry.getKey())) {
						if (finalPrice.contains(entry.getValue())) {
							report.addReportStep(
									"Verify whether unit price in Thank You page is equivalent to Expected Price",
									"Unit price in cart page " + unitPrice + " is equivalent to Expected Price"
											+ entry.getValue(), StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether unit price in Thank You page is equivalent to Expected Price",
									"Unit price in cart page is not equivalent to Expected Price", StepResult.FAIL);
						}
					}
					System.out.println(entry.getKey() + " - " + entry.getValue());
				}

			} else {
				report.addReportStep("Verify whether unit price in Thank You page is equivalent to Expected Price",
						"Unit price is not displayed", StepResult.FAIL);
			}
		}
		return this;
	}

	/**
	 * verify total Price Cart
	 * 
	 * @throws Exception
	 */
	public ThankYouPage verifySubTotalOrderConfirmation() throws Exception {
		By subTot_OrderSummary = By.xpath("(//h3[contains(text(),'Subtotal')]/../following-sibling::div/h3[1])[1]");
		By subTot_Footer = By.xpath("(//h3[contains(text(),'Subtotal')]/../following-sibling::div/h3[1])[2]");
		String sum = "";

		String subTot_1, subTot_2;
		if (wh.isElementPresent(subTot_OrderSummary, 2)) {
			subTot_1 = wh.getText(subTot_Footer);
			subTot_2 = wh.getText(subTot_Footer);

			sum = commonData.subTotal;

			String subTotal1 = subTot_1.substring(1).replace(",", "");
			String subTotal2 = subTot_2.substring(1).replace(",", "");

			if (subTotal1.equals(sum) && subTotal2.equals(sum)) {
				report.addReportStep(
						"Verify whether subtotal in Thank You page is equivalent to sum of all the prices in cart",
						"Subtotal in cart page<b> " + subTotal1 + "</b> is equivalent to sum of all the prices <b>"
								+ sum + "</b>", StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify whether subtotal in Thank You page is equivalent to sum of all the prices in cart",
						"Subtotal in cart page<b> " + subTotal1 + "</b> is not equivalent to sum of all the prices <b>"
								+ sum + "</b>", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify whether subtotal in Thank You page is equivalent to sum of all the prices in cart",
					"Subtotal in cart page is not equivalent to sum of all the prices in Thank You Page",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify estimated subtotal is sum of all totals
	 * 
	 * @return Shopping Cart page
	 * @throws Exception
	 */
	public ThankYouPage verifyTotalPrice() throws Exception {

		double totalSumPrice_OS = 0;
		double totalSumPrice_F = 0;

		String actualTotal_OS = wh.getText(By.xpath("(//*[@id='total-price'])[1]")).replace(",", "");
		String actualTotal_F = wh.getText(By.xpath("(//*[@id='total-price'])[2]")).replace(",", "");
		By orderTotalRightRail1 = By.xpath("(//*[@class='right right-pod text-right'])[1]");
		By orderTotalRightRail2 = By.xpath("(//*[@class='right right-pod text-right'])[2]");

		if (wh.isElementPresent(orderTotalRightRail1) && wh.isElementPresent(orderTotalRightRail2)) {

			WebElement ele1 = driver.findElement(orderTotalRightRail1);

			List<WebElement> totalPrices1 = ele1.findElements(By.tagName("*"));

			for (WebElement element : totalPrices1) {
				String priceTotal = wh.getText(element);
				if (priceTotal.contains("$")) {
					priceTotal = priceTotal.replace("$", "");
					priceTotal = priceTotal.replace(",", "");
					totalSumPrice_OS += Double.parseDouble(priceTotal);
				}
			}

			WebElement ele = driver.findElement(orderTotalRightRail2);

			List<WebElement> totalPrices2 = ele.findElements(By.tagName("*"));

			for (WebElement element : totalPrices2) {
				String priceTotal = wh.getText(element);
				if (priceTotal.contains("$")) {
					priceTotal = priceTotal.replace("$", "");
					priceTotal = priceTotal.replace(",", "");
					totalSumPrice_F += Double.parseDouble(priceTotal);
				}
			}

			totalSumPrice_F = Double.parseDouble(new DecimalFormat("##.##").format(totalSumPrice_F));
			totalSumPrice_OS = Double.parseDouble(new DecimalFormat("##.##").format(totalSumPrice_OS));

			String totalSum_F = Double.toString(totalSumPrice_F);
			String totalSum_OS = Double.toString(totalSumPrice_OS);

			if (actualTotal_OS.contains(totalSum_OS) && actualTotal_F.contains(totalSum_F)) {
				report.addReportStep("Verify Estimated subtotal is sum of all subtotals", "Estimated subtotal "
						+ actualTotal_OS + " is equal to Sum of all subtotals " + totalSum_OS, StepResult.PASS);
			} else {
				report.addReportStep("Verify Estimated subtotal is sum of all subtotals", "Estimated subtotal "
						+ actualTotal_OS + " is not equal to Sum of all subtotals " + totalSum_OS, StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify order total price section", "Order Total price section not displayed",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify close callout option popup
	 * 
	 * @return ThankYouPage
	 * @throws Exception
	 */
	public ThankYouPage verifyCallOutPopupClosed() throws Exception {
		
		Thread.sleep(commonData.mediumWait);

		if (wh.isElementPresent(closeCallout)) {
			wh.clickElement(closeCallout);

			report.addReportStep("Verify whether call out popup is closed for appliance item in TYP",
					"Call out popup is closed for appliance item in TYP", StepResult.PASS);
		} else {

			report.addReportStep("Verify whether call out popup is closed for appliance item in TYP",
					"Call out popup is not closed for appliance item in TYP", StepResult.FAIL);

			rc.terminateTestCase("Call out popup");
		}

		return this;
	}

	// ******************HDPP********************************************

	public ThankYouPage verifyCertonaSectionTYP() throws Exception {
		Thread.sleep(5000);
		if (wh.isElementPresent(certonaTYP, 4)) {
			report.addReportStep("Verify <b>Certona</b> section is displayed", "<b>Certona</b> section is displayed",
					StepResult.PASS);

			String sku = null;
			if (wh.isElementPresent(certonaAddToCartLink)) {
				String href = wh.getAttribute(certonaAddToCartLink, "href");
				String[] href1 = href.split("catEntryId=");

				sku = href1[1].substring(0, 9);

			} else if (wh.isElementPresent(certonaAddToCartLinkAppl)) {
				sku = wh.getAttribute(certonaAddToCartLinkAppl, "data-prodid");
			}

			if (!sku.equals(null)) {
				commonData.sku = sku;
				commonData.skuList.add(sku);
			}

		} else {
			report.addReportStep("Verify <b>Certona</b> section is displayed",
					"<b>Certona</b> section is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Certona Section");
		}
		return this;

	}

	/**
	 * Method to click Add to cart first item from certona section in PIP
	 * 
	 * @return this
	 * @throws Exception
	 */
	public ThankYouPage clickAddtoCartCertonaTYP() throws Exception {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,200)", "");
		Thread.sleep(8000);
		if (wh.isElementPresent(certonaAddToCartBtn, 2)) {

			wh.clickElement(certonaAddToCartBtn);

			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is clicked in certona section", StepResult.PASS);

		} else {
			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is not clicked in certona section", StepResult.FAIL);
		}
		Thread.sleep(8000);
		return this;

	}

	/**
	 * Method to verify the order confirmation page details like billing
	 * information, credit card details and subtotal
	 * 
	 * @return this
	 * @throws Exception
	 */
	public ThankYouPage verifyOrderConfirmationPageDetails() throws Exception {

		String strMercSubTotal = null;

		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

			return this;
		}
		if (wh.isElementPresent(ApplianceNewFeatureOverlay, 2)) {
			wh.clickElement(ApplianceNewFeatureOverlay);
			Thread.sleep(2000);
		}

		if (wh.isElementPresent(Header, 2)) {
			String strOrderNo = driver.findElement(By.xpath("(//div[@class='header'])[1]//h3[2]")).getText().trim();
			System.out.println(strOrderNo);
			commonData.strOrderId = strOrderNo;
			report.addReportStep("Review all the Order Details In Order Confirmation Page", "The Order Number:<b>"
					+ strOrderNo + "</b> is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"Order number is not displayed ", StepResult.FAIL);
		}

		if (wh.isElementPresent(OrderSummarySection, 2)) {
			report.addReportStep("Verify Order Summary section of order confirmation page",
					"Order Summary section was displayed in order coonfirmation page", StepResult.PASS);

		} else {
			report.addReportStep(
					"Verify this details are displayed under 'Your Order Has Been Received' section of order confirmation page",
					"Order Summary section was not displayed in order coonfirmation page", StepResult.FAIL);
		}

		if (wh.isElementPresent(PaymentContainer, 2)) {
			String strBillingInfm1 = driver.findElement(
					By.xpath("//*[contains(@class,'payment-container-content')]//h3[1]")).getText();
			System.out.println(strBillingInfm1);
			String strBillingInfm2 = driver.findElement(
					By.xpath("//*[contains(@class,'payment-container-content')]//h3[2]")).getText();
			System.out.println(strBillingInfm2);
			String strBillingInfm3 = driver.findElement(
					By.xpath("//*[contains(@class,'payment-container-content')]//h3[3]")).getText();
			System.out.println(strBillingInfm3);

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"The billing Information : <b>" + strBillingInfm1 + "</b> <b>" + strBillingInfm2 + "</b> <b>"
							+ strBillingInfm2 + "</b> is displayed", StepResult.PASS);

		} else {
			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"The billing Information is not displayed", StepResult.FAIL);
		}

		boolean blnMerchandiseAdded = false;

		try {
			if (commonData.isMerAdded || (wh.isElementPresent(SubTotal, 2))) {
				blnMerchandiseAdded = true;
			}

		} catch (Exception e) {
			System.out.println("");
		}

		if (blnMerchandiseAdded) {
			if (wh.isElementPresent(OrderSummary, 2)) {

				if (wh.isElementPresent(MerchSubtotal, 2)) {

					strMercSubTotal = driver.findElement(
							By.xpath("(//*[contains(text(),'Merchandise Subtotal : ')])[1]")).getText();

				}

				if (wh.isElementPresent(subtotalsection, 2)) {

					strMercSubTotal = driver
							.findElement(
									By.xpath("//order-summary[@data='CONFIRMATION_ORDER_SUMMARY']//div[@class='right right-pod text-right']//h3[1]"))
							.getText();

				}
				System.out.println(strMercSubTotal);

				report.addReportStep("Review all the Order Details In Order Confirmation Page",
						"System displayed the <b>Merchandise subtotal: " + strMercSubTotal + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Review all the Order Details In Order Confirmation Page",
						"System did not display the <b>Merchandise subtotal</b>", StepResult.FAIL);
			}
		}

		boolean blnApplnAdded = false;

		try {
			if (commonData.isApplianceAdded || (wh.isElementPresent(AppSubtotal, 2))) {
				blnApplnAdded = true;
			}

		} catch (Exception e) {
			System.out.println("");
		}

		if (blnApplnAdded) {
			if (wh.isElementPresent(AppSubtotal, 2)) {
				strMercSubTotal = driver.findElement(By.xpath("(//*[contains(text(),'Appliance Subtotal : ')])[1]"))
						.getText();
				System.out.println(strMercSubTotal);

				report.addReportStep("Review all the Order Details In Order Confirmation Page",
						"System displayed the <b>Appliance subtotal" + strMercSubTotal + "</b>", StepResult.PASS);
			}
		}

		wh.ignorePopup(driver);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		if (wh.isElementPresent(SummaryInnersection, 2)) {

			if (wh.isElementPresent(
					By.xpath("(//*[@class='order-summary-pod'])[1]//div[@class='right text-right']//h4[2]"), 1))
			/*
			 * if (driver .findElement( By.xpath(
			 * "(//*[@class='order-summary-pod'])[1]//div[@class='left left-summary left-pod']//h4[2]//i"
			 * )))
			 */{

				String strEstimatedTotal = driver.findElement(By.xpath("(//div[@class='right text-right']//h3[1])[1]"))
						.getText();

				System.out.println(strEstimatedTotal);

				report.addReportStep("Review all the Order Details In Order Confirmation Page",
						"System displayed the estimated Sales Tax : <b>" + strEstimatedTotal + "</b>", StepResult.PASS);
			} else if (driver
					.findElement(
							By.xpath("//order-summary[@data='CONFIRMATION_ORDER_SUMMARY']//i[@class='icon-more-info tip-opener-mcc']/ancestor::node()[1]//i"))
					.getText().contains("Sales Tax")) {

				String strEstimatedTotal = driver
						.findElement(
								By.xpath("//order-summary[@data='CONFIRMATION_ORDER_SUMMARY']//i[@class='icon-more-info tip-opener-mcc']/ancestor::node()[2]//h4[contains(@class,'pricing-section')]"))
						.getText();

				System.out.println(strEstimatedTotal);
				report.addReportStep("Review all the Order Details In Order Confirmation Page",
						"System did not display the estimated Sales Tax", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System did not display the estimated Sales Tax", StepResult.FAIL);
		}

		if (wh.isElementPresent(By.xpath("(//h4[contains(text(),'Shipping ')]/../../div[2]//h4[1])[2]"), 2)) {
			String strTotalShippingCharges = driver.findElement(
					By.xpath("(//h4[contains(text(),'Shipping ')]/../../div[2]//h4[2])[1]")).getText();
			System.out.println(strTotalShippingCharges);

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System displayed the total Shipping Charges : " + strTotalShippingCharges + ", Total.",
					StepResult.PASS);
		} else if (wh.isElementPresent(By.xpath("(//h4[contains(text(),'Pick Up')])[1]"), 2)) {
			String strTotalShippingCharges = driver.findElement(
					By.xpath("(//h4[contains(text(),'Pick Up')]/../../div[2]//h4[1])[2]")).getText();
			System.out.println(strTotalShippingCharges);

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System displayed the total Shipping Charges : " + strTotalShippingCharges + ", Total.",
					StepResult.PASS);
		} else if (wh.isElementPresent(By.xpath("//h4[contains(text(),'Appliance Delivery :')]"), 2)) {
			String strTotalShippingCharges = driver.findElement(
					By.xpath("//h4[contains(text(),'Appliance Delivery :')]/../../div[2]/h4")).getText();
			System.out.println(strTotalShippingCharges);

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System displayed the total Shipping Charges : " + strTotalShippingCharges + ", Total.",
					StepResult.PASS);
		} else if (wh.isElementPresent(By.xpath("(//h4[contains(text(),'Express Delivery :')])[1]"), 2)) {
			String strTotalShippingCharges = driver.findElement(
					By.xpath("//h4[contains(text(),'Express Delivery :')]/../../div[2]/h4")).getText();
			System.out.println(strTotalShippingCharges);

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System displayed the total Shipping Charges : " + strTotalShippingCharges + ", Total.",
					StepResult.PASS);
		} else {

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System did not display the total Shipping Charges, Total.", StepResult.FAIL);
		}

		if (wh.isElementPresent(By.xpath("(//*[@class='bottom-pod'])[1]"), 1)) {
			// obj updated on 22sep
			String strTotal = driver.findElement(By.xpath("(//*[@id='total-price'])[2]")).getText();
			System.out.println(strTotal);

			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System displayed the <b>Total " + strTotal + "</b>", StepResult.PASS);
		} else {
			report.addReportStep("Review all the Order Details In Order Confirmation Page",
					"System did not display the <b>Total</b>", StepResult.FAIL);
		}

		if (wh.isElementPresent(
				By.xpath("//*[@class='order-summary payment-container fullWidth']//div[@class='m-top-large bold']"), 1)) {
			String cardNum = driver
					.findElement(
							By.xpath("//*[@class='order-summary payment-container fullWidth']//div[@class='m-top-large bold']"))
					.getText();
			report.addReportStep(
					"Verify the Card Details is under payment information section is displayed In Order Confirmation Page",
					"Card Details:<b>" + cardNum
							+ "</b> is under payment information section is displayed In Order Confirmation Page ",
					StepResult.DONE);

			System.out.println(cardNum);
			commonData.cardNum = cardNum;

			if (!cardNum.contains("PayPal")) {
				int length = 0;
				for (int i = 0; i < cardNum.length(); i++)
					if (cardNum.charAt(i) == '*')
						length++;

				// if (length >= 12)
				if (length >= 11) // Modified by Srr8476 9/21/15
					report.addReportStep("Review all the Order Details In Order Confirmation Page",
							"The applied payment details are displayed", StepResult.PASS);
				else
					report.addReportStep("Review all the Order Details In Order Confirmation Page",
							" The Applied payment details are not displayed", StepResult.FAIL);

				boolean blnAmount = false;
				if (cardNum.contains("*")) {
					String tempAmount = cardNum.substring(cardNum.indexOf("*"), cardNum.length());
					if (tempAmount.length() > 1) {
						blnAmount = true;
					}
				} else {
					blnAmount = false;
				}

				if (blnAmount)
					report.addReportStep(
							"User enters valid security ID and clicks on SUBMIT ORDER button.",
							"The amount of the transaction made is displayed next to the <b>last 4 digits of card number</b>",
							StepResult.PASS);
				else
					report.addReportStep(
							"User enters valid security ID and clicks on SUBMIT ORDER button.",
							"The amount of the transaction made is not displayed next to the <b>last 4 digits of card number</b>",
							StepResult.FAIL);
			}
		}

		// By.xpath("//div[@id='card-details']/span[2]"))

		Thread.sleep(8000);
		return this;
	}

	/**
	 * Component to verify PO number not present in order confirmation page
	 * 
	 * @throws InterruptedException
	 * 
	 * @FunctionName verifyPoNumberOrderConfirmationPage
	 */
	public boolean verifyPoNumberNotPresentInOrderConfirmationPage() throws InterruptedException {
		if (wh.isElementNotPresent(POField)) {

			report.addReportStep("Verify the PO Number field  in Order Confirmation page",
					"PO number field is not Present in order confirmation page", StepResult.PASS);
			return true;
		} else {
			report.addReportStep("Verify the PO Number field  in Order Confirmation page",
					"PO number field is  Present in order confirmation page", StepResult.FAIL);
			return false;

		}
	}

	/**
	 * verifying Product image and name on order conformation page
	 * 
	 * @throws Exception
	 *
	 */
	public void verifyImgProductNameOnConfirmationPage() throws Exception {
		String strProdImg = driver.findElement(By.xpath("//*[@class='tpl-content-wrapper']//img")).getAttribute("src");
		System.out.println(strProdImg);
		wh.isElementPresent(By.xpath("//*[@class='bold break']"), 5);
		String strProdName = driver.findElement(By.xpath("//*[@class='bold break']")).getText();
		System.out.println(strProdName);
		boolean blnProdName = driver.findElement(By.xpath("//*[@class='bold break']")).isDisplayed();
		if (blnProdName) {
			System.out.println("pass");
			report.addReportStep("Product name should be displayed ", "<b> Product name:" + strProdName
					+ "</b> is displayed", StepResult.PASS);
			report.addReportStep("Product image should be displayed ", "<b> Product image:" + strProdImg
					+ "</b> is displayed", StepResult.PASS);
		} else {
			System.out.println("fail");
			report.addReportStep("Product name and image should be displayed",
					"Product name and image are not displayed", StepResult.PASS);
		}

	}

	public ThankYouPage verifyHDPP() throws Exception {

		if (wh.isElementPresent(HDPP)) {

			report.addReportStep("Verify HDPP in TYP", "Verfied HDPP in TYP", StepResult.PASS);
		} else {

			report.addReportStep("Verify HDPP in TYP", "HDPP is not present in TYP", StepResult.FAIL);

		}

		return this;
	}

	public ThankYouPage verifyNoHDPP() throws Exception {

		if (wh.isElementPresent(HDPP)) {

			report.addReportStep("Verify HDPP in TYP", "Verfied HDPP in TYP", StepResult.FAIL);
		} else {

			report.addReportStep("Verify HDPP in TYP", "HDPP is not present in TYP", StepResult.PASS);

		}

		return this;
	}

	public ThankYouPage verifyNextStepMSG() throws Exception {

		if (wh.isElementPresent(NextStepMsg)) {

			report.addReportStep("Verify NextStepMsg in TYP", "Verfied NextStepMsg in TYP", StepResult.PASS);
		} else {

			report.addReportStep("Verify NextStepMsg in TYP", "NextStepMsg is not present in TYP", StepResult.FAIL);

		}

		return this;
	}

	public ThankYouPage verifyNoNextStepMSG() throws Exception {

		if (!wh.isElementPresent(NextStepMsg)) {

			report.addReportStep("Verify NextStepMsg in TYP", "Verfied no NextStepMsg in TYP", StepResult.PASS);
		} else {

			report.addReportStep("Verify NextStepMsg in TYP", "NextStepMsg is t present in TYP", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Component to verify PO number not present in order confirmation page
	 * 
	 * @throws Exception
	 * 
	 * @FunctionName verifyPoNumberOrderConfirmationPage
	 */
	public ThankYouPage verifyPOFieldInThankYouPage() throws Exception {
		if (wh.isElementPresent(POField, 2)) {
			String strPOfield = wh.getText(POField);
			System.out.println(strPOfield);
			String strPO = commonData.strPO;
			if (strPOfield.contains(strPO)) {
				report.addReportStep("Verify the PO Number field  in Order Confirmation page", "PO number" + strPOfield
						+ "is Present in order confirmation page", StepResult.PASS);
			} else {
				report.addReportStep("Verify the PO Number field  in Order Confirmation page",
						"PO number field is not Present in order confirmation page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify the PO Number field  in Order Confirmation page",
					"PO number field is not Present in order confirmation page", StepResult.FAIL);
		}
		return this;
	}
	
	/**
	 * Component to verify Blinds Custom Image
	 * @throws Exception 
	 */
	public void verifyCustomImage() throws Exception {

		if(wh.isElementPresent(CustomImage, 4))
		{
			report.addReportStep(
					"Verify that Blinds Custom Image is displayed in the product section",
					"<b>Blinds Custom Image is displayed with product </b>",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"Verify that Blinds Custom Image is displayed in the product section",
					"<b>Blinds Custom Image is not displayed with product </b>",
					StepResult.FAIL);
		}

	}
	
	/**
	 * Component to verify that blinds product title is displayed
	 * @throws Exception 
	 * 
	 * 
	 */
	public void verifyBlindsItemDescription() throws Exception {

		if(wh.isElementPresent(BlindDesc, 2))
		{
			String strTempTitle = driver.findElement(BlindDesc).getText();
			report.addReportStep(
					"Verify the blinds product title is displayed", "Title <b>"
							+ strTempTitle + "</b> is displayed", StepResult.PASS);
		} else {
			report.addReportStep(
					"Verify that Blinds product title is displayed",
					"The product title is not displayed", StepResult.FAIL);
		}
	}
	
	/**
	 * Component to check the discounted amount after applying promotion
	 * 
	 * 
	 * @since Aug 7, 2013
	 * @author PXM8043
	 * @throws InterruptedException
	 */
	public void verifyAllTotalsfromOrderConfirmPage() {

		try {

			List<WebElement> lstleftsummary = driver
					.findElements(By
							.xpath("(//*[@class='p-custom-inner-block'])[1]//div[1]"));
			System.out.println(lstleftsummary.size());
			List<WebElement> lstritesummary = driver
					.findElements(By
							.xpath("(//*[@class='p-custom-inner-block'])[1]//div[2]"));
			System.out.println(lstritesummary.size());
			ArrayList<String> strrite = new ArrayList();
			ArrayList<String> strleft = new ArrayList();
			for (WebElement leftsummary : lstleftsummary) {
				String strtemp = leftsummary.getText();

				strleft.add(strtemp);
			}
			for (WebElement ritesummary : lstritesummary) {
				String strtemp = ritesummary.getText();

				strrite.add(strtemp);
			}
			for (int i = 0, j = 0; i < strleft.size(); i++) {
				// subtotal
				if (strleft.get(i).contains("Subtotal")) {
					String strMerValue = strrite.get(i);
					if (strMerValue.contains("$")) {
						strMerValue = strMerValue.substring(
								strMerValue.indexOf("$") + 1,
								strMerValue.length()).trim();

						if (strMerValue.contains(",")) {
							strMerValue = strMerValue.replace(",", "");
						}
					}

					try {
						commonData.doubMerchandiseSubTotalCart = Double
								.parseDouble(strMerValue);
						report.addReportStep(
								"Verify the Merchandise subtotal in Cart page",
								"Subtotal : "
										+ commonData.doubMerchandiseSubTotalCart
										+ " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out
								.println("Unable to fetch the merchandise subtotal");
						commonData.doubMerchandiseSubTotalCart = 0;
						report.addReportStep(
								"Verify the Merchandise subtotal in Cart page",
								"Subtotal is not displayed", StepResult.FAIL);
					}
				}

				// To verify Estimated subtotal
				if (strleft.get(i).contains("Estimated Subtotal")) {
					String strEstValue = strrite.get(i);
					if (strEstValue.contains("$")) {
						strEstValue = strEstValue.substring(
								strEstValue.indexOf("$") + 1,
								strEstValue.length()).trim();

						if (strEstValue.contains(",")) {
							strEstValue = strEstValue.replace(",", "");
						}
					}

					try {
						commonData.doubSubtTotalCart = Double
								.parseDouble(strEstValue);
						report.addReportStep(
								"Verify the  Estimated subtotal in Cart page",
								"Subtotal : "
										+ commonData.doubSubtTotalCart
										+ " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the subtotal");
						commonData.doubSubtTotalCart = 0;
						report.addReportStep(
								"Verify the subtotal in Cart page",
								"Subtotal is not displayed", StepResult.FAIL);
					}
				}

				// To fetch Appliance subtotal
				if (strleft.get(i).contains("Appliance Subtotal")) {
					String strAppSubtotalValue = strrite.get(i);
					if (strAppSubtotalValue.contains("$")) {
						strAppSubtotalValue = strAppSubtotalValue.substring(
								strAppSubtotalValue.indexOf("$") + 1,
								strAppSubtotalValue.length()).trim();

						if (strAppSubtotalValue.contains(",")) {
							strAppSubtotalValue = strAppSubtotalValue.replace(
									",", "");
						}
					}

					try {
						commonData.doubApplianceSubtotalCart = Double
								.parseDouble(strAppSubtotalValue);
						report.addReportStep(
								"Verify the Appliance  subtotal in Cart page",
								"Subtotal : "
										+ commonData.doubSubtTotalCart
										+ " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the subtotal");
						commonData.doubApplianceSubtotalCart = 0;
						report.addReportStep(
								"Verify the Appliance subtotal in Cart page",
								"Subtotal is not displayed", StepResult.FAIL);
					}
				}

				// To fetch Estimated Sales Tax
				if (strleft.get(i).contains("Sales Tax")) {
					String strEstimatedTax = strrite.get(i);
					if (strEstimatedTax.contains("$")) {
						strEstimatedTax = strEstimatedTax.substring(
								strEstimatedTax.indexOf("$") + 1,
								strEstimatedTax.length()).trim();

						if (strEstimatedTax.contains(",")) {
							strEstimatedTax = strEstimatedTax.replace(",", "");
						}
					}

					try {
						commonData.doubEstimatedTaxCart = Double
								.parseDouble(strEstimatedTax);
						report.addReportStep(
								"Verify the Estimated tax in Cart page",
								"Estimated tax : "
										+ commonData.doubEstimatedTaxCart
										+ " is displayed", StepResult.PASS);
					} catch (Exception e) {
						if (strEstimatedTax.contains("FREE")
								|| strEstimatedTax.contains("----")) {
							commonData.doubEstimatedTaxCart = 0;
							report.addReportStep(
									"Verify the  sales tax in Cart page",
									"sales tax is  displayed as FREE",
									StepResult.PASS);
						} else {
							System.out
									.println("Unable to fetch the Estimated tax");
							commonData.doubEstimatedTaxCart = 0;
							report.addReportStep(
									"Verify the Estimated tax in Cart page",
									"Estimated tax is not displayed",
									StepResult.FAIL);
						}

					}
				}

				// To fetch pickup in store value
				if (strleft.get(i).contains("Pick Up In Store")) {
					String strPickUpvalue = strrite.get(i);
					if (strPickUpvalue.contains("$")) {
						strPickUpvalue = strPickUpvalue.substring(
								strPickUpvalue.indexOf("$") + 1,
								strPickUpvalue.length()).trim();

						if (strPickUpvalue.contains(",")) {
							strPickUpvalue = strPickUpvalue.replace(",", "");
						}
					}

					try {
						commonData.doubPickupTotalCart = Double
								.parseDouble(strPickUpvalue);
						report.addReportStep(
								"Verify the pick up in store total in Cart page",
								"Pick up in store total : "
										+ commonData.doubPickupTotalCart
										+ " is displayed", StepResult.PASS);
					} catch (Exception e) {
						if (strPickUpvalue.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep(
									"Verify the  Pick up in store total in Cart page",
									"Pick up in store total is  displayed as FREE",
									StepResult.PASS);
						} else {
							System.out
									.println("Unable to fetch the Estimated tax");
							commonData.doubPickupTotalCart = 0;
							report.addReportStep(
									"Verify the pick up in store total in Cart page",
									"Pick up in store total is not displayed",
									StepResult.FAIL);
						}
					}
				}

				// To fetch Estimated Shipping Charge
				if (strleft.get(i).contains("Shipping")) {
					String strShippingChargeValue = strrite.get(i);
					if (strShippingChargeValue.contains("$")) {
						strShippingChargeValue = strShippingChargeValue
								.substring(
										strShippingChargeValue.indexOf("$") + 1,
										strShippingChargeValue.length()).trim();
						if (strShippingChargeValue.contains(",")) {
							strShippingChargeValue = strShippingChargeValue
									.replace(",", "");
						}
					}

					try {
						commonData.doubShipChargesCart = Double
								.parseDouble(strShippingChargeValue);
						report.addReportStep(
								"Verify the Estimated Shipping Charge in Cart page",
								"Estimated Shipping Charge : "
										+ commonData.doubApplianceDeliveryCart
										+ " is displayed", StepResult.PASS);

					} catch (Exception e) {
						if (strShippingChargeValue.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep(
									"Verify the Estimated Shipping Charge in Cart page",
									" Estimated Shipping Charge is  displayed as FREE",
									StepResult.PASS);
						} else {
							System.out
									.println("Unable to fetch the Appliance delivery");
							commonData.doubApplianceDeliveryCart = 0;
							report.addReportStep(
									"Verify the Estimated Shipping Charge   in Cart page",
									" Estimated Shipping Charge is not displayed",
									StepResult.FAIL);
						}
					}
				}

				// To fetch Appliance delivery Value
				if (strleft.get(i).contains("Appliance Delivery")) {
					String strApplianceValue = strrite.get(i);
					if (strApplianceValue.contains("$")) {
						strApplianceValue = strApplianceValue.substring(
								strApplianceValue.indexOf("$") + 1,
								strApplianceValue.length()).trim();
						if (strApplianceValue.contains(",")) {
							strApplianceValue = strApplianceValue.replace(",",
									"");
						}
					}

					try {
						commonData.doubApplianceDeliveryCart = Double
								.parseDouble(strApplianceValue);
						report.addReportStep(
								"Verify the Appliance delivery Charge in Cart page",
								"Appliance delivery Charge : "
										+ commonData.doubApplianceDeliveryCart
										+ " is displayed", StepResult.PASS);

					} catch (Exception e) {
						if (strApplianceValue.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep(
									"Verify the  Appliance deliver charges in Cart page",
									" Appliance deliver charge is  displayed as FREE",
									StepResult.PASS);
						} else {
							System.out
									.println("Unable to fetch the Appliance delivery");
							commonData.doubApplianceDeliveryCart = 0;
							report.addReportStep(
									"Verify the Appliance delivery Charge in Cart page",
									"Appliance delivery Charge is not displayed",
									StepResult.FAIL);
						}
					}
				}

				// To fetch You Saved value
				if (strleft.get(i).contains("You Saved ")) {
					String strYouSaved = strrite.get(i);
				if (strYouSaved.contains("$")) {
						strYouSaved = strYouSaved.substring(
								strYouSaved.indexOf("$") + 1,
								strYouSaved.length()).trim();

						if (strYouSaved.contains(",")) {
							strYouSaved = strYouSaved.replace(",", "");
						}
					}

					try {
						commonData.doubYouSavedCart = Double
								.parseDouble(strYouSaved);
						report.addReportStep(
								"Verify the 'You saved' total in Cart page",
								"You saved : "
										+ commonData.doubYouSavedCart
										+ " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out
								.println("Unable to fetch the you save total");
						commonData.doubYouSavedCart = 0;
						report.addReportStep(
								"Verify the 'You saved' total in Payment page",
								"'You saved' is not displayed", StepResult.FAIL);
					}
				}
			}
			System.out.println(commonData.doubMerchandiseSubTotalCart);
			System.out.println(commonData.doubSubtTotalCart);
			System.out.println(commonData.doubShipChargesCart);
			System.out.println(commonData.doubEstimatedTaxCart);
			System.out.println(commonData.doubPickupTotalCart);
			System.out.println(commonData.doubApplianceDeliveryCart);
			System.out.println(commonData.doubApplianceSubtotalCart);
			System.out.println(commonData.doubYouSavedCart);
			System.out.println(commonData.doubEstimatedTotalCart);
			System.out.println(commonData.doubtotalCart);
			System.out.println("Done'");

		}

		catch (Exception e) {
			System.out.println("Unable to get the totals from Shopping page");
			report.addReportStep(
					"Verify that Items totals in Order summary table",
					"Unable to validate the Totals", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}
	
	/**
	 * Component to update order no in CommonData
	 * @throws Exception 
	 * 
	 */

	public String orderNumberIncommonData() throws Exception {

		String strOrderNumber = "";
		
		if(wh.isElementPresent(orderNumber, 6))
		{
			strOrderNumber = driver
					.findElement(orderNumber)
					.getText();
			System.out.println(strOrderNumber);
			commonData.orderNumber = strOrderNumber;

			report.addReportStep(
					"Verify Order Number is updated in common data",
					"Order Number is updated in common data", StepResult.DONE);
			return strOrderNumber;
		} else {

			report.addReportStep(
					"Verify Order Number is updated in common data",
					"Order Number is not updated in common data",
					StepResult.WARNING);
			return strOrderNumber;
		}
	}
	
	/**
	 * Component to Verify whether system calculates 'Estimated Sales Tax' and
	 * display it under Merchandise Subtotal part in 'Thank for your order' page
	 * 
	 * @throws Exception 
	 */
	public boolean verifyEstimatedSalesTaxInOrderConfirmPage()
			throws Exception {
		wh.waitForElementPresent(EstimatedSalesTax);
		String strEstimatedSalesTaxText = driver
				.findElement(EstimatedSalesTax).getText().trim();
		System.out.println(strEstimatedSalesTaxText);
		wh.waitForElementPresent(salestax);
		String strEstimatedSalexTax = driver.findElement(salestax).getText()
				.split("\\$")[1].trim();
		System.out.println(strEstimatedSalexTax);

		String strShippingEstimatedSalesTaxValue = commonData.strEstimatedSalesTaxValue;
		System.out.println(strShippingEstimatedSalesTaxValue);
		if (strShippingEstimatedSalesTaxValue.contains(strEstimatedSalexTax)) {
			report.addReportStep(
					"Verify whether system calculates <b>'Estimated Sales Tax' and display it under Merchandise Subtotal part in <b>'Thank for your order' </b>page",
					"System should calculate <b>'"
							+ strEstimatedSalesTaxText
							+ "' and display "
							+ strEstimatedSalexTax
							+ " </b>it under Merchandise Subtotal part in <b>'Thank for your order' </b>page",
							StepResult.PASS);
			return true;
		} else {
			report.addReportStep(
					"Verify whether system calculates 'Estimated Sales Tax' and display it under Merchandise Subtotal part in <b>'Thank for your order' </b>page",
					"System should not calculate 'Estimated Sales Tax' and <b>not display  </b>it under Merchandise Subtotal part in <b>'Thank for your order' </b>page",
					StepResult.FAIL);
			return false;
		}
	}
	
	
	/**
	 * Component to Verify Tax is displayed page after applying Tax Exempt ID in
	 * Payment Page
	 *
	 * @throws Exception 
	 */
	public void verifyEstimatedSalesInOrderConfirmPage()
			throws Exception {

		String strEstimatedSalesTaxText = driver
				.findElement(EstimatedSalesTax).getText().trim();
		System.out.println(strEstimatedSalesTaxText);
		wh.waitForElementPresent(salestax);
		String strEstimatedSalexTaxValue = driver.findElement(salestax).getText();
				//.split("\\$")[1].trim();
		System.out.println(strEstimatedSalexTaxValue);
		if (strEstimatedSalexTaxValue.matches("\\$[0-9]*.[0-9]{2}")) {
			report.addReportStep("Estimated sales should be displayed", "<b>"
					+ strEstimatedSalexTaxValue + "</b> is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Estimated sales should be displayed",
					"Estimated sales is not displayed", StepResult.FAIL);
		}
	}
	

	/**
	 * 
	 * Description : compare date & time in pick up option page & order details
	 * page
     * @throws Exception 
	 */

	public void compareDateTimeInPickUpOptionAndOrderDetailPg()
			throws Exception {

		// **************** manipulating data from the pickup options page
		ArrayList<String> strSelectDate = commonData.strSelectDate;
		ArrayList<String> strSelectTime = commonData.strSelectTime;
		ArrayList<String> strDateAndTime = commonData.strDateAndTime;
		ArrayList<String> strDateAndTime2 = commonData.strDateAndTime2;
		System.out.println(strSelectDate);
		System.out.println(strSelectTime);
		System.out.println(strDateAndTime);
		System.out.println(strDateAndTime2);
		if(wh.isElementPresent(By.xpath("//td[@class='myacct-detailstable-ShippingDetails']/a/span"),5))
		{
			List<WebElement> PickUpDates = driver
					.findElements(By
							.xpath("//td[@class='myacct-detailstable-ShippingDetails']/a/span"));
			for (WebElement webDates : PickUpDates) {
				webDates.click();
			}
		}

		int intSizeOfArray = strSelectDate.size();

		for (int i = 0; i < intSizeOfArray; i++) {
			String strSelecteDate1 = strSelectDate.get(i).split(", ")[1];
			strDateAndTime.add(strSelecteDate1 + " " + "at" + " "
					+ strSelectTime.get(i));
		}

		if(wh.isElementPresent(By.xpath("//td[contains(text(),'Order is scheduled to be picked up on')]//strong"), 3)){
			List<WebElement> lstPickUpDates = driver
					.findElements(By
							.xpath("//td[contains(text(),'Order is scheduled to be picked up on')]"));
			for (WebElement webDates : lstPickUpDates) {

				String strDateTime = webDates.getText();
				strDateAndTime2.add(strDateTime);
				System.out.println(strDateTime);

			}

		} else {
			report.addReportStep("get the pick up dates from the page",
					"Unable to find the pick up dates", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

		int k = 1;
		System.out.println("Comparing " + strDateAndTime2 + " with "
				+ strDateAndTime);
		boolean blnfound1 = false;
		/* boolean blnFount2=false; */
		for (int i = 0; i < strDateAndTime2.size(); i++) {

			for (int j = 0; j < strDateAndTime.size(); j++) {

				// Time n date are verified in the condition below
				String strTempDate1 = strDateAndTime2.get(i).substring(0,
						strDateAndTime2.get(i).lastIndexOf("/") + 5);
				String strTempTime1 = strDateAndTime2.get(i).substring(
						strDateAndTime2.get(i).lastIndexOf(":") - 2,
						strDateAndTime2.get(i).length());

				String strTempDate2 = strDateAndTime.get(j).substring(0,
						strDateAndTime.get(j).lastIndexOf("/") + 5);
				String strTempTime2 = strDateAndTime.get(j).substring(
						strDateAndTime.get(j).lastIndexOf(":") - 2,
						strDateAndTime.get(j).length());
				/*
				 * if (strDateAndTime2.get(i).contains(strDateAndTime.get(i))) {
				 */
				if (strTempDate1.contains(strTempDate2)
						&& strTempTime1.contains(strTempTime2)) {
					blnfound1 = true;
					break;
				} else {
					blnfound1 = false;
				}
				k++;

			}

			if (blnfound1) {
				System.out
				.println("Item Dates are displayed in pickup options page and order information page Date and Time are the same");
				report.addReportStep(
						"Verify only Pickup date and time were getting displayed on the Order Information Page when an order is created with Pickup date and time for store"
								+ k + "",
								"Pickup date and time were getting displayed on the Order Information Page when an order is created with Pickup date and time for the selected store"
										+ k + "", StepResult.PASS);
			} else {
				System.out
				.println("Different Dates are displayed for the item");
				report.addReportStep(
						"Verify only Pickup date and time were getting displayed on the Order Information Page when an order is created with Pickup date and time for store"
								+ k + "",
								"Pickup date and time were getting displayed on the Order Information Page when an order was not created with Pickup date and time for the selected store"
										+ k + "", StepResult.FAIL);

			}
		}
	}
	
	
	/* Component to verify the Order level
	 * status in Order confirmation page
	 */
	public void orderLevelStatus() {
		int count = 0;
		List<WebElement> lst = driver.findElements(By
				.xpath("//a[@class='order'or @class='modal_overlay order']"));
		System.out.println(lst.size());
		String strStatus = null;
		for (int i = 0; i < lst.size(); i++) {
			System.out.println(lst.get(i).getText());
			strStatus = lst.get(i).getText();
			if (lst.get(i).getText().trim().contains("Order Created")
					|| lst.get(i).getText().trim().contains("Being Processed")
					|| lst.get(i).getText().trim().contains("Cancelled"))
				count = count + 1;
		}
		if (count == lst.size())
			report.addReportStep(
					"Check the order level status  in the Order Details page",
					"Order level status  as " + strStatus + " is displayed'",
					StepResult.PASS);
		else
			report.addReportStep(
					"Check the order level status  in the Order Details page",
					"Order level status as " + strStatus
					+ " is  not displayed'", StepResult.FAIL);
	}
	
	/**
	 * 
	 * Description : verify default order information message in ThankYou Page
	 * 
	 * @throws Exception 
	 */
	public void verifyDefaultMsgInOrderInfoPg() throws Exception {
		if(wh.isElementPresent(By.xpath("//*[contains(text(),'Available for Pick Up:')]"), 4))
		{
			report.addReportStep(
					"default message is getting displayed on the Order Information Page when an order is created ",
					"Only Default Message is getting displayed on the Order Information Page when an order is created",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"default message is getting displayed on the Order Information Page when an order is created ",
					"Only Default Message is not getting displayed on the Order Information Page when an order is created",
					StepResult.FAIL);
		}

	}

	public void registerInThankYouPgWithWeakPwd(String strPassword) throws Exception {

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, strPassword);

			report.addReportStep("Enter password for registration", "Password entered for registration",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter password for registration", "Password field is not present in payment page",
					StepResult.FAIL);

			rc.terminateTestCase("Payment page registration");
		}

	}

	public void verifyWeakPwdMsgThankYouPg() throws Exception {

		if (wh.isElementPresent(weakPwdMsg, 7)) {
			String strMsg = driver.findElement(weakPwdMsg).getText();
			if (strMsg.contains(
					"Passwords must be a minimum of 8 characters")) {
				report.addReportStep("Verify the Weak password msg is displayed",
						" Weak password msg " + strMsg + " is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify the  Weak password msg is displayed",
						"Weak password msg " + strMsg + " is not displayed properly", StepResult.FAIL);
			}
			String strCardErr = wh.getCssValue(weakPwdMsg, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for weak password", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for weak password",
						"Err msg is not displayed in red color", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify the Weak password msg is displayed", "Weak password msg is not displayed",
					StepResult.FAIL);

		}

	}
	
	public void enterMismatchPwdTYP() throws Exception {

		String strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);
		String mismatchPwd = dataTable.getData("NewRegPwd");

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, mismatchPwd);
			driver.findElement(regConfirmPwd).sendKeys(Keys.TAB);

			report.addReportStep("Enter mismatch password in confirm pwd field", "Mismatch password entered",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter mismatch password in confirm pwd field", "Mismatch password not entered",
					StepResult.FAIL);

		}

	}

	public void verifyPwdMismatchErrMsgTYP() throws Exception {

		if (wh.isElementPresent(pwdMismatchMsg, 7)) {
			String strMsg = driver.findElement(pwdMismatchMsg).getText();
			if (strMsg.contains("Your passwords don't match")) {
				report.addReportStep("Verify the password mismatch err msg is displayed",
						"  Password mismatch err msg <b> " + strMsg + " </b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify the   password mismatch err msg is displayed",
						" password mismatch err msg <b> " + strMsg + " </b> is not displayed properly", StepResult.FAIL);
			}
			String strCardErr = wh.getCssValue(pwdMismatchMsg, "color");
			System.out.println("========================> "+ strCardErr);
			if (strCardErr.contains("rgba(51, 51, 51, 1)")) {
				report.addReportStep("Verify error msg styling for password mismatch",
						"Err msg is displayed in red color", StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for password mismatch",
						"Err msg is not displayed in red color", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify the password mismatch err msg is displayed",
					"Password mismatch err msg is not displayed", StepResult.FAIL);

		}
	}
	
	/**
	 * Component to verify the promotion code is displayed in Order Confirmation
	 * Page
	 * 
	 * @throws Exception 
	 */
	public void verifyPromotionDetailsCnfmPage() throws Exception {
		wh.waitForElementPresent(PromotionCodeText, 2);
		String strPromotionCode = driver.findElement(PromotionCodeText).getText();
		System.out.println(strPromotionCode);
		String strPromtion = driver.findElement(Promotion).getText();
		System.out.println(strPromtion);
		if (strPromotionCode.contains("Promotion Code")) {
			report.addReportStep(
					"Promotion details should be displayed in order confirmation page",
					"Promotion Code is <b>" + strPromtion + " </b> displayed",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"Promotion details should be displayed in order confirmation page",
					"Promotion details are not displayed", StepResult.FAIL);
		}
	}

	public void verifySelectedApplDeliveryDateTYP() throws Exception {
		if (wh.isElementPresent(applDelDate, 5)) {
			String deliveryDate = wh.getText(applDelDate);
			if ((!commonData.applDelDate.isEmpty()) && (deliveryDate.contains(commonData.applDelDate))) {
				report.addReportStep("Verify appliance delivery date is displayed",
						"Appliance delivery date <b> " + deliveryDate + " </b>is displayed correctly", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery date is displayed",
						"Appliance delivery date <b> " + deliveryDate + " </b>is displayed correctly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify appliance delivery date is displayed",
					"Appliance delivery date is not displayed", StepResult.FAIL);
		}
	}
	
	
	public void clickOnProdDescInTY() throws Exception
	{
		if(wh.isElementPresent(ProdDescLink, 4))
		{
			wh.jsClick(ProdDescLink);
			report.addReportStep("Verify Product Description Link is clicked in TY page", "Product Description Link is clicked in TY page", StepResult.PASS);
		}
		else
		{
			report.addReportStep("Verify Product Description Link is clicked in TY page", "Product Description Link is not clicked in TY page", StepResult.FAIL);
		}
	}
	
	/**
	 * Component to update guest user ship address in CommonData
	 * 
	 * @throws Exception
	 * 
	 */

	public ThankYouPage storeGuestUserShipAddress() throws Exception {

		if (wh.isElementPresent(guestUserNmShipAddress, 6)) {
			String guestUserNameShipAddressFromTY = driver.findElement(guestUserNmShipAddress).getText();
			System.out.println(guestUserNmShipAddress);
			commonData.guestUserNameAndShipAddressStored = guestUserNameShipAddressFromTY;

			report.addReportStep("Verify Guest user address is updated in common data",
					"Guest user address is updated in common data", StepResult.DONE);

		} else
			report.addReportStep("Verify Guest user address is updated in common data",
					"Guest user address is not updated in common data", StepResult.WARNING);

		return this;
	}
	
	public void clickMyListInHeader() throws Exception {
		if (wh.isElementPresent(lnkMyAccount, 4)) {
			wh.jsClick(lnkMyAccount);
			report.addReportStep("Verify my account link is clicked", "My account Link is clicked in TY page",
					StepResult.PASS);
			wh.jsClick(myListPg);
			report.addReportStep("Verif My List link is clicked", "My List Link is clicked in TY page",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify my account link is clicked", "My account Link is not clicked in TY page",
					StepResult.FAIL);
		}
	}
	
	public void clickOrderStatusLink() throws Exception {
		if (wh.isElementPresent(orderStatusLink, 4)) {
			wh.jsClick(orderStatusLink);
			report.addReportStep("Verify order status link is clicked", "Order status Link is clicked in TY page",
					StepResult.PASS);

			if (wh.isElementPresent(orderStatusPg, 4)) {
				report.addReportStep("Verify order status page is displayed", "Order status page is not displayed",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify order status page is displayed", "Order status page is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify order status link is clicked", "Order status Link is not clicked in TY page",
					StepResult.FAIL);
		}
	}

}
