package com.homer.po;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import org.json.JSONArray;
import org.json.JSONObject;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Metadata;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;


	public class DataBase extends PageBase<DataBase> {
		
		
	public DataBase(InstanceContainer ic) {
		super(ic);
	}
	
	/**
	 * Function to connect to Cassandra database. 
	 * 
	 * @param node
	 * @throws SQLException 
	 */
	public String[] executeQuery(String sql) throws SQLException {
	
		Cluster cluster;
		Session session;
		
		try{
		
			// Connect the Cassendra cluster with credentials
			cluster = Cluster.builder()
			         .addContactPoint(commonData.cassandraURL)
			         .withCredentials(commonData.cassandraUserId, commonData.cassandraPwd)
			         .build();
		
		  // Get the connected cluster
		   Metadata metadata = cluster.getMetadata();
		   
		   System.out.printf("Connected to cluster: %s\n", 
		         metadata.getClusterName());
		   
		   //Creating the DB session and connect to the keyspace
		   session = cluster.connect("hdcom");	   
		   
		   //Executing SQL and store it in result set
		   ResultSet results = session.execute(sql);

		   report.addReportStep("Connect Cassendra DB and execute SQL Query","Connected to Cassandra DB and Executed the Query",StepResult.PASS);
		   
			if (results.isExhausted()) {

				results = session.execute(sql);
			}
			  
			//Print Price	
			String result;
			String headers;
			
			try{
				result = results.one().toString();
				result = result.replaceAll("\\[", "");
				result = result.replaceAll("]", "");
				result = result.replace("Row", "");
				
				headers = results.getColumnDefinitions().toString();
				headers = headers.replaceAll("\\[","");
				headers = headers.replaceAll("]", "");
				headers = headers.replace("Columns", "");
			}
			catch(Exception ex){
				result="";
				headers="";
			}
			
			//Close the connection
			session.close();
			cluster.close();
			
			if(result.isEmpty()){
				return null;
			}
			else{
				 return new String[]{headers,result};
			}
			 
			
		}
		
		catch(Exception ex){
			report.addReportStep("Connect Cassendra DB and execute SQL Query", "Exception when connecting DB", StepResult.FAIL);
			ex.printStackTrace();
			return null;
		}
		
		
	}
	
	/**
	 * To get price
	 * @param sku
	 * @return
	 * @throws Exception
	 */

	public String getOnlinePriceFromCassandraDB(String sku) throws Exception{
		
		String price="";	
		String[] queryresult;
		boolean defaultOnlinestore=false;
		
		String strCurrentLocalStore = getCurrentLocalStore();
		
		//To Check currentlocalization
		if (!strCurrentLocalStore.isEmpty()){
			
			queryresult = executeQuery("select price,bopis,bodfs,status from itemlist where itemid="
					+ sku+" and strnbr="+strCurrentLocalStore);
			
			//To Check Item is assorted to local store
			if(queryresult!=null){
				
				String[] arrHeaders = queryresult[0].split(",");
				String[] arrResult = queryresult[1].split(",");
				
				int statusIndex = getRequiredResultIndex(arrHeaders,"status");
				String status = arrResult[statusIndex].trim();
				
				int bopisIndex = getRequiredResultIndex(arrHeaders,"bopis");
				String bopis = arrResult[bopisIndex].trim();
				
				int bodfsIndex = getRequiredResultIndex(arrHeaders,"bodfs");
				String bodfs = arrResult[bodfsIndex].trim();
				
				//To Check the item clearance and bopis,bodfs eligibility
				if (!status.equals("500") && (bopis.equals("true") || bodfs.equals("true"))){
					int priceIndex = getRequiredResultIndex(arrHeaders,"price");
					price = arrResult[priceIndex];
				}
				
				else{
					defaultOnlinestore=true;
				}
				
			}
			
			else{
				defaultOnlinestore=true;
			}
		}
		
		else{
			defaultOnlinestore=true;
		}
		
		if(defaultOnlinestore){
			queryresult = executeQuery("select price from itemlist where itemid="
					+ sku+" and strnbr=8119");
			price = queryresult[1];
		}
	
		return price;	
	
	}
	
	/**
	 * To get price
	 * @param sku
	 * @return
	 * @throws Exception
	 */
	public String getStorePriceCassandraDB(String sku) throws Exception{
		
		String price;	
		
		String store;
		
		//store = dataTable.getData(DataColumn.LocalizeStore);
		store = getCurrentLocalStore();
		
		String[] queryresult = executeQuery("select price from itemlist where itemid="
						+ sku+" and strnbr="+store);
		
		price =queryresult[1];
		
		return price;
	}
	
	/**
	 * To get price
	 * @param sku
	 * @return
	 * @throws Exception
	 */
	public String getAlternateStorePriceCassandraDB(String sku,String store) throws Exception{
			
		String[] queryresult;
		String price="";
		boolean defaultOnlinestore = false;
		if (!store.isEmpty()) {

			queryresult = executeQuery("select price,bopis,bodfs,status from itemlist where itemid="
					+ sku + " and strnbr=" + store);
		} else {
			queryresult = null;
		}
		
		//To Check Item is assorted to local store
		if(queryresult!=null){
			
			String[] arrHeaders = queryresult[0].split(",");
			String[] arrResult = queryresult[1].split(",");
			
			int statusIndex = getRequiredResultIndex(arrHeaders,"status");
			String status = arrResult[statusIndex].trim();
			
			int bopisIndex = getRequiredResultIndex(arrHeaders,"bopis");
			String bopis = arrResult[bopisIndex].trim();
			
			int bodfsIndex = getRequiredResultIndex(arrHeaders,"bodfs");
			String bodfs = arrResult[bodfsIndex].trim();
			
			//To Check the item clearance and bopis,bodfs eligibility
			if (!status.equals("500") && (bopis.equals("true") || bodfs.equals("true"))){
				int priceIndex = getRequiredResultIndex(arrHeaders,"price");
				price = arrResult[priceIndex];
			}
			
			else{
				defaultOnlinestore=true;
			}
			
		}
		
		else{
			defaultOnlinestore=true;
		}

		if(defaultOnlinestore){
			queryresult = executeQuery("select price from itemlist where itemid="
					+ sku+" and strnbr=8119");
			price = queryresult[1];
		}

	
		return price;
	}
	
	/**
	 * Method to get the index from the array
	 * 
	 * @param arr
	 * @param column
	 * @return index
	 * @throws Exception
	 */
	public int getRequiredResultIndex(String[] arr,String column) throws Exception{
		int index = 0;
		
		for (int i = 0; i < arr.length; i++){
			if(arr[i].contains(column)){
				index= i;
				break;
			}
		}
		return index;
	}

	
	/**
	 * Get Price from cassandra reference application
	 * 
	 * 
	 */
	
	public String getPriceFromCassandraRefAPP(String sku,String store) throws Exception{
	
		HttpURLConnection connection = null;  
		String priceType = dataTable.getData("PriceType");

		String price = "";
		String was2 = "";
		if(store.equals("")){
			store = getCurrentLocalStore();
		}
		
		
		try {
			
			String endPointUrl = "http://"+commonData.cassandraRefAppIPandPort+"/itemAll/"+sku;
						
			String JSON_DATA  = rc.getXMLResponse(endPointUrl);

		    final JSONObject obj = new JSONObject(JSON_DATA);
		       
		    final JSONArray itemlist = obj.getJSONArray("itemList");
		    final int n = itemlist.length();
		    int count=0;
		    for (int i = 0; i < n; ++i) {
		      
		      final JSONObject results = itemlist.getJSONObject(i);
		      
		      if (results.getString("store").equals("8119")){
		    	  		    	  
		    	  if(count==0){
			    	  price = results.getString("price");
			    	  was2 = results.getString("was2");
		    	  }
		    	  else if(Double.parseDouble(results.getString("price"))<Double.parseDouble(price)){
		    		  price = results.getString("price");
			    	  was2 = results.getString("was2");
		    	  }
		    	  count=count+1;
		      }
		      
		      
		      if (results.getString("store").equals(store) ){
		    	  
		    	  String status = results.getString("status");
		    	  String bopis = results.getJSONObject("attributeMap").getString("BOPIS");
		    	  String bodfs = results.getJSONObject("attributeMap").getString("BODFS");
		    	  
		    	  //To Check the item clearance and bopis,bodfs eligibility
					if (!status.equals("500") && (bopis.equals("true") || bodfs.equals("true"))){
						
						if (priceType.contains("bulk")) {
							price = results.getString("bulkPrices");
							price = price.replace("[", "").replace("{", "").replace("}", "").replace("]", "");
							//.replaceAll("}]", "");
							String[] arrBulkprice = price.split(",");
							
							if (!(arrBulkprice.length<1)){
								   String arr[] = arrBulkprice[3].split(":");
									price = arr[1];
							}
							else{
								price="";
							}
	
						}
						else{
							price = results.getString("price");
						}
						
				    	was2 = results.getString("was2");
				    	break;
					}
		      }
		      		      
		    }
		    
	 	} catch (Exception e) {
		     e.printStackTrace();
		      return "NA";
		} 
	 	finally {
		  if(connection != null) {
			  connection.disconnect(); 
		  }
	 	}
		
		commonData.unitPriceDB = price;
		commonData.strikeThroPriceDB=was2;
		commonData.unitPrice.put(sku, price);
		
		report.addReportStep("Read Price From Cassandra RefApp", "Price read from cassandra Ref App", StepResult.DONE);
		return price;

	}
	
	/**
	 * To Get the price displayed in pricing service
	 * Modified by u93wcs to get the store promotion from pricing API.
	 * @param sku
	 * @return
	 * @throws Exception
	 */
	public String getUnitPriceFromPricingService(String sku, String store) throws Exception {

		HttpURLConnection connection = null;
		String priceType = dataTable.getData("PriceType");
		String strCurrentEnvironment = HelperClass.baseModel.runEnvironment;

		String price = "";
		String was2 = "";
		String was1 = "";
		String longdesc = "";
		String shortdesc = "";
		
		if (store.equals("")) {
			store = getCurrentLocalStore();
		}

		try {

		/*	String endPointUrl = "http://origin.api-" + strCurrentEnvironment
					+ ".homedepotdev.com/ProductAPI/v1/price?itemId=" + sku + "&storeId=" + store
					+ "&key=Y866fcsCAniNigQGfIjyk7YRF1m7sKoJ";
			*/
			// Pricing API - google cloud stage environment
			
			String endPointUrl = "http://origin-api.gcp-dev.homedepot.com/pricing/v1/item/"+sku+"/store/"+store+"/price";

			String JSON_DATA = rc.getXMLResponse(endPointUrl);

			final JSONObject obj = new JSONObject(JSON_DATA);
			
			final JSONArray itemlist = obj.getJSONArray("items");

			final JSONObject results = itemlist.getJSONObject(0);
			
			final JSONObject result = results.getJSONObject("priceDetail");
			
			try{
				price = result.getString("specialPrice");
				was2 = result.getString("originalPrice");
				was1 = result.getString("specialBuyPrice");
			}
			catch (Exception ex){
				
			}
			

			if (priceType.contains("bulk")) {

				final JSONArray itemlist1 = obj.getJSONArray("items");

				final JSONObject results1 = itemlist.getJSONObject(0);
				
				final JSONObject result1 = results.getJSONObject("priceDetail");;

				price = result1.getString("price");

			}
			
		final JSONObject result2 = results.optJSONObject("storePromotion");
			
			if (result2 != null) {
			
			try{
				longdesc = result2.getString("descriptionLong");
				System.out.println(longdesc);
				shortdesc = result2.getString("descriptionShort");
				System.out.println(shortdesc);
			}
			catch (Exception ex){
				
			}
			}
			
			else if  (result2 == null)
			{
				longdesc = "";
				System.out.println(longdesc);
				shortdesc = "";
				System.out.println(shortdesc);	
				
			}
			

		} catch (Exception e) {
			e.printStackTrace();
			return "NA";
		} finally {
			if (connection != null) {
				connection.disconnect();
			}
		}

		commonData.unitPriceDB = price;
		commonData.strikeThroPriceDB = was2;
		commonData.specialBuyPrice = was1;
		commonData.unitPrice.put(sku, price);
		commonData.longdesc = longdesc;
		commonData.shortdesc = shortdesc;

		report.addReportStep("Read Price & Store Promotion From Price API", "Price & Store Promotion read from Price API", StepResult.DONE);
		return price;

	}

}