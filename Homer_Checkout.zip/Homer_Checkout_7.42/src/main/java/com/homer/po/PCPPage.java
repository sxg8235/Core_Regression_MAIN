package com.homer.po;

import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class PCPPage extends PageBase<PCPPage> {
	
	public static By verifyPCPPage = By.id("PCPProductsContainer");
	public static String verifyProdPresent ="a[class='item_description'][href$='##PRODID##']";
	public static String prodImage ="//div[@class='content_image']/a[contains(@href,'##PRODID##')]";
	public static String productDIV = "//a[contains(@href,'##PRODID##')]//ancestor::div[contains(@class,'product dynamic pod grid_6')]";
	public static By mapMsg = By.cssSelector("span[class='normal b mapMessage']");
	public static By prodPrice = By.xpath("//div[@class='xlarge item_price']");
	public static By prodDesc = By.className("item_description");
	public static By prodWASPrice = By.xpath("//div[@class='item_pricing_wrapper']/div[1]/span");
	public static By prodSpecialBuyPrice = By.xpath("//div[@class='item_pricing_wrapper']/div[2]/span");
	static final By firstCheckBox = By.xpath("(//input[contains(@id,'compare')])[1]");
	static final By secondCheckBox = By.xpath("(//input[contains(@id,'compare')])[2]");
	static final By compareBtn = By.xpath("//a[@class='comparenow btn btn-small Compare_btn']");
	static final By addTocartBtn = By.xpath("(//a[contains(.,'Add To Cart')])[1]");
	static final By bulidAndBuyBtn = By.xpath("(//a[contains(.,'BUILD AND BUY')])[1]");
	static final By verifyAddToCartModal = By.xpath("//*[contains(text(),'Added in Cart') or contains(text(),'Added to Cart')]");
	static final By applianceATCOverlay = By.xpath("//span[contains(text(),'Check Availability')]");
	static final By strikeThroPrice = By.xpath("//span[@class='strike-through']");
	static final By unitPriceSTH  = By.xpath("//div[@class='offerprice']");
	
	//----------for hdpp----------
    static By certonaPCP = By.cssSelector("div.certona1main.grid");
    static By certonaAddToCartBtn = By.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]");
	static final By addCart = By.xpath("//button[@name='add-to-cart-btn']");
	static final By storeInventory = By.cssSelector("#products > div:nth-child(1) > form > div.content.dynamic.col-1-1.alpha.omega > div:nth-child(4) > div.bopis_options > a");
	static final By storeQuantity = By.cssSelector("#bssStores > div.localizedStore > div.quantFull-Cntnr > div.storeInfo-Col.quant-Text.first-Col.control-group > div > input.input-mini.localStr-Qnt.smrtQtyInp");
	static By price = By.xpath("//*[@id='PCPProductsContainer']/div[1]/div[2]/div/div/div[2]/div[1]/div");
	
	
	boolean wasPriceDisplay;
	boolean effRTLPriceDisplay;
	boolean noWASPrice;
	boolean noSpecialBuyPrice;
	boolean specialBuyPriceDisplay;
	
	public PCPPage(InstanceContainer ic) {
		super(ic);
		
		this.ic = ic;
		this.report = ic.report;
		this.driver = ic.driver;
		this.wh = ic.wh;
		
		this.wasPriceDisplay = ic.wasPriceDisplay;
		this.effRTLPriceDisplay = ic.effRTLPriceDisplay;
		this.noWASPrice = ic.noWASPrice;
		this.specialBuyPriceDisplay = ic.specialBuyPriceDisplay;
		rc = ic.rc;
	}
	

	/**
	 * To verify PCP Page
	 * 
	 * @throws Exception
	 */
	public PCPPage verifyPCPPage() throws Exception {
		
		
		
		if(wh.isElementPresent(verifyPCPPage, 2)) {
			
			report.addReportStep("Verify PCP page is displayed",
					"PCP page is displayed successfully", 
					StepResult.PASS);
			
		} else {
			
			report.addReportStep("Verify PCP page is displayed",
					"PCP page is not displayed successfully", 
					StepResult.FAIL);
		}
		
		return this;
	}
	
	/**
	 * Method to verify Free with $45 Message in PLP
	 * 
	 * @return
	 * @throws Exception
	 */
	public PCPPage verifyPriceSection() throws Exception {
		String skuNumber = dataTable.getData("SKUNumber");
		verifyPriceDisplayed(skuNumber);
		
		if(!noWASPrice) {
		
			verifyWASPriceDisplayed(skuNumber);
		}		
		
		return this;
	}
	
	/**
	 * Method to verify price is displayed or 'See final price in cart' message is displayed
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PCPPage verifyPriceDisplayed(String skuNumber) throws Exception {
		
		String productDIVBy = productDIV.replace("##PRODID##", skuNumber);		
		WebElement pcpDiv = driver.findElement(By.xpath(productDIVBy));

		String price1 = wh.getText(pcpDiv, prodPrice).replace("$", "").replace(",", "");
		
		String pcpPrice = price1.split("\\/")[0];
		double price = wh.getDouble(pcpPrice);
		String strPrice = new Double(price).toString();
		String cassandraPrice="";
		String prodDescr = wh.getText(pcpDiv,prodDesc);
		
		for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {
			if (prodDescr.contains(entry.getKey())) {
					cassandraPrice = entry.getValue();
					break;
			}
		}
							
		if(strPrice.equals(cassandraPrice)){
			
			report.addReportStep("Product price should be displayed and message",
					"Product price is displayed "+strPrice, 
					StepResult.PASS);
		} 
		else if(wh.getText(pcpDiv, mapMsg).contains("Add to Cart to See Price")) {
				
				report.addReportStep("Product price should not be displayed and message 'See final price in cart' should be displayed",
						"Product price should not be displayed and message 'See final price in cart' is displayed", 
						StepResult.PASS);		
			}
		else {
			
			report.addReportStep("Product price should be displayed and message 'See final price in cart' should not be displayed",
					"Product price is not displayed as expected", 
					StepResult.FAIL);
		}			
					
		return this;
	}
	
	
	/**
	 * Method to verify was price is displayed or 'See final price in cart' message is displayed
	 * @param skuNumber
	 * @return
	 * @throws Exception
	 */
	public PCPPage verifyWASPriceDisplayed(String skuNumber) throws Exception {
		
		String productDIVBy = productDIV.replace("##PRODID##", skuNumber);		
		WebElement pcpDiv = driver.findElement(By.xpath(productDIVBy));
		
		if(wasPriceDisplay) {
			
			double price = wh.getDouble(wh.getText(pcpDiv, prodWASPrice).replace("$", "").replace(",", "")); 
			System.out.println(price);
			
			if(ic.wasPrice == price) {
				
				report.addReportStep("Product WAS price should be displayed",
						"Product WAS price is displayed", 
						StepResult.PASS);
				
			} else {
				
				report.addReportStep("Product WAS price should be displayed",
						"Product WAS price is not displayed", 
						StepResult.PASS);
			}			
			
		} else {			

			//System.out.println(wh.getText(pcpDiv, prodPrice));
			
			if(wh.getText(pcpDiv, mapMsg).contains("Add to Cart to See Price")) {
				
				report.addReportStep("Product WAS price should not be displayed and message 'See final price in cart' should be displayed",
						"Product WAS price is not displayed and message 'See final price in cart' is displayed", 
						StepResult.PASS);
				
			} else {
				
				report.addReportStep("Product WAS price should not be displayed and message 'See final price in cart' should be displayed",
						"Product message is not displayed as expected", 
						StepResult.FAIL);
			}	
		}
		
		return this;
	}

	/**
	 * Method to enter keyword 
	 * @return
	 * @throws Exception 
	 */
	
	public PIPPage enterSkuNo() throws Exception {
		String sku = dataTable.getData("SKUNumber");
		wh.sendKeys(searchTxtBox, sku);
		wh.clickElement(searchBtn);
		
		report.addReportStep("Type '" + sku	+ "' in search text box and click on search button",
				"Typed '" + sku	+ "' in search text box and clicked on search button",
				StepResult.PASS);
		
		return new PIPPage(ic);		
	}
	
	/**
	 * To Select the items to compare PCP
	 * 
	 * @throws Exception
	 */
	public PCPPage selectItemsToCompare() throws Exception {

		if (wh.isElementPresent(firstCheckBox, 2)) {
			wh.clickElement(firstCheckBox);
			wh.clickElement(secondCheckBox);
			report.addReportStep("Verify two items are selected to compare",
					"Two items are selected to compare", StepResult.PASS);
			wh.clickElement(compareBtn);

			report.addReportStep("Verify whether compare button is clicked",
					"Compare button is clicked", StepResult.PASS);

		} else {

			report.addReportStep("Verify whether compare button is clicked",
					"compare button is not clicked", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to click Bulid and Buy
	 * @return
	 * @throws Exception
	 */
	public PIPPage clickBuildAndBuyButton() throws Exception {

		if (wh.isElementPresent(bulidAndBuyBtn, 20)) {

			//addMCCparamter();

			wh.clickElement(bulidAndBuyBtn);

		} else {

			report.addReportStep("On PCP page, add to cart button should display",
					"'Add to Cart' button was not displayed.", StepResult.FAIL);

			rc.terminateTestCase("PCP Add To Cart");
		}

		return new PIPPage(ic);
	}

	
	/**
	 * Method to click add to cart
	 * @return
	 * @throws Exception
	 */
	public ATCOverlay clickAddToCartButton() throws Exception {
		
		
		
		if (wh.isElementPresent(addTocartBtn, 20)) {
			
			addMCCparamter();
			
			wh.clickElement(addTocartBtn);		
			
		} else {

			report.addReportStep(
					"On PCP page, add to cart button should display",
					"'Add to Cart' button was not displayed.", StepResult.FAIL);
			
			rc.terminateTestCase("PCP Add To Cart");
		}	
		
		if (wh.isElementPresent(verifyAddToCartModal,5) || wh.isElementPresent(applianceATCOverlay,5)) {
			
			report.addReportStep("Click on 'Add to Cart' button",
					"Appliance check availability overlay or Added to Cart overlay is displayed",
					StepResult.PASS);
		}
		else{
			rc.terminateTestCase("Appliance Overlay or Add to Cart");
		}
		return new ATCOverlay(ic);
	}

	//-------The below section is for HDPP---------------------
		public void clickStoreInventory() throws Exception {
			if (wh.isElementPresent(storeInventory, 2)) {

				wh.clickElement(storeInventory);

				report.addReportStep("Verify whether store inventory button is clicked",
						"Store inventory button is clicked", StepResult.PASS);

			} else {

				report.addReportStep("Verify whether store inventory button is clicked",
						"store inventory button is not clicked", StepResult.FAIL);
			}

		}


		public void enterQuantity() throws Exception {
			
			if (wh.isElementPresent(storeQuantity, 2)) {
				wh.sendKeys(storeQuantity,"1");
				
				Thread.sleep(2000l);
	           commonData.pcpQuantity=1;

				report.addReportStep("Verify quantity is entered",
						"Quantity is entered", StepResult.PASS);

			} else {

				report.addReportStep("Verify quantity is entered",
						"Quantity is entered", StepResult.FAIL);
			}
		}


		public void addcart() throws Exception {
			if (wh.isElementPresent(addTocartBtn, 6)) {
				addMCCparamter();
				wh.clickElement(addTocartBtn);
				
				Thread.sleep(2000l);

				report.addReportStep("Verify whether add to cart button is clicked",
						"Add to cart button is clicked", StepResult.PASS);

			} else {

				report.addReportStep("Verify whether Add to cart button is clicked",
						"Add to cart is not clicked", StepResult.FAIL);
			}
		}
		
		public PCPPage verifyCertonaSectionPCP() throws Exception {
			Thread.sleep(5000);
			if (wh.isElementPresent(certonaPCP, 4)) {
				report.addReportStep("Verify <b>Certona</b> section is displayed" , 
						"<b>Certona</b> section is displayed", 
						StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify <b>Certona</b> section is displayed",
						"<b>Certona</b> section is not displayed", StepResult.FAIL);
			}
			return this;

		}
		
		/**
		 * Method to click Add to cart first item from certona section in PIP
		 * 
		 * @return this
		 * @throws Exception
		 */
		public PCPPage clickAddtoCartCertonaPCP() throws Exception {
			Thread.sleep(2000);
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.scrollBy(0,2250)", "");
			Thread.sleep(8000);
			if (wh.isElementPresent(certonaAddToCartBtn, 0)) {
				addMCCparamter();
				wh.clickElement(certonaAddToCartBtn);
				
				report.addReportStep("Click Add to cart button in certona section" , 
						"Add to cart button is clicked in certona section", 
						StepResult.PASS);

			} else {
				report.addReportStep(
						"Click Add to cart button in certona section",
						"Add to cart button is not clicked in certona section", StepResult.FAIL);
			}
			Thread.sleep(8000);
			return this;

		}
		
		public void captureprice() throws Exception {
			
			String pcp_price=wh.getText(price).replace("$","").trim();
			
			System.out.println(pcp_price);
			
			commonData.pcpPrice =pcp_price ;
			
		}


		public PCPPage verifyQuantity() throws Exception{
			       
			int pcpquantity=commonData.pcpQuantity;

			if(pcpquantity==1){
				
				report.addReportStep("Verify Product Quantity '"+pcpquantity+"' should be displayed on ATC Modal", 
						"Product quantity '"+pcpquantity+"' displayed on ATC Modal", StepResult.PASS);
				
			}else{
				
				report.addReportStep("Verify Product Quantity '"+pcpquantity+"' should be displayed on ATC Modal", 
						"Product quantity '"+pcpquantity+"' is not displayed on ATC Modal", StepResult.FAIL);
			}
				
			return this;
			
		}
}
