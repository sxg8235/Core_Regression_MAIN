package com.homer.po;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

public class WCSLogsvalidation extends PageBase<WCSLogsvalidation> {

	String log_hostname = null;
	String log_username = null;
	String log_password = null;
	String PIE_Encrypt_Nbr = null;
	String Xref_card_Nbr = null;
	String Card_Expry_date = null;
	String Card_Cvv = null;
	String PIE_Encrypt_value = null;
	String XRef_card_nbr = null;
	String rspnse = null;
	String dcson = null;
	String rqst_id = null;
	String rqst_tkn = null;
	static String tempString = null;
	static String tempString_2 = null;
	static String tempString_3 = null;
	static long startTime;
	String strCardNumber = dataTable.getData("CardNumber");
	static String strOrderId = null;
	static String strOrderId_1 = null;
	static String payauthid = null;
	static String xrefnbr = null;
	static Pattern TAG_REGEX_1 = null;
	static Pattern TAG_REGEX_2 = null;
	static Pattern TAG_REGEX_3 = null;
	Channel channel;
	Session session;

	
	public WCSLogsvalidation(InstanceContainer ic) {
		super(ic);
	}


	public void wcsLogsValidation() throws InterruptedException, JSchException,
			SftpException, IOException {

		startTime = System.currentTimeMillis();
		String directory = "/opt/isv/logs/WC_THD";
		int port = 22;
		String myString1 = null;
		String myString2 = null;
		StringBuilder sb = new StringBuilder();
		String line;
		payauthid = commonData.strpayauthId;
		xrefnbr = commonData.strxrefnbr;
		strOrderId = commonData.strOrderId;
		strOrderId_1 = strOrderId.trim().substring(1);
		String strCardType = dataTable.getData("CardType");
		//GrepResults results = null;
		log_connection_hostname();
		log_connection_username();
		log_connection_password();

		java.util.Properties config = new java.util.Properties();
		config.put("StrictHostKeyChecking", "no");

		JSch ssh = new JSch();
		session = ssh.getSession(log_username, log_hostname, port);
		session.setConfig(config);
		session.setPassword(log_password);
		session.connect();
		channel = session.openChannel("sftp");
		channel.connect();

		ChannelSftp sftp = (ChannelSftp) channel;
		sftp.cd(directory);

		// ===============================================================================================================================================
		// Dynamically read the LOG file

		Vector<ChannelSftp.LsEntry> files = sftp.ls("*");
		System.out
				.printf("Found %d files in dir %s%n", files.size(), directory);

		for (ChannelSftp.LsEntry file : files) {
			if (file.getAttrs().isDir()) {
				continue;
			}

			if (file.getFilename().equals("SystemOut.log")) {
				System.out.printf("Reading file : %s%n", file.getFilename());
				System.out.printf("Reading file : %s%n", file.getAttrs()
						.getSize());
				System.out.println("File size in MB is :"
						+ (double) file.getAttrs().getSize() / (1024 * 1024));

			/*	Profile remoteProfile = ProfileBuilder.newBuilder()
						.name("Remote server log")
						.filePath("/opt/isv/logs/WC_THD/SystemOut.log")
						.onRemotehost(log_hostname)
						.credentials(log_username, log_password).build();
				results = grep(constantExpression(strOrderId_1),
					on(remoteProfile));
				// System.out.println("Grep results :" + results);
				myString1 = results.toString();*/

				// if (myString1.contains(strOrderId) &&
				// myString1.contains("xml")) {
				if (myString1.contains(strOrderId)
						|| myString1.contains("ns3:")
						|| myString1.contains("retrievalReferenceNumber")) {
					BufferedReader br = new BufferedReader(
							new InputStreamReader(sftp.get(file.getFilename())));
					try {
						while ((line = br.readLine()) != null) {
							sb.append(line);

						}
						// System.out.println(sb);
						myString2 = sb.toString();

					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						if (br != null) {
							try {
								br.close();
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					}

					if (myString2.contains(strOrderId)
							|| myString2.contains(strOrderId_1)) {

						System.out.println("Order ID Found");

						if (strCardType.toLowerCase().contains("home depot")||strCardType.toLowerCase().contains("hd proxy")) {
							tempString = Arrays.toString(getTagValues(
									sb.toString()).toArray());
							tempString = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
									// + tempString + "</ns3:fraud_check_req>";
									+ tempString
									+ strOrderId
									+ "</ns3:merchant_ref_cd> </ns3:fraud_check_req>";
							tempString = tempString.replace("'yes'?>[<ns3",
									"'yes'?><ns3");
							tempString = tempString.replace("]" + strOrderId,
									strOrderId);

							tempString_2 = Arrays.toString(getTagValues_2(
									sb.toString()).toArray());
							tempString_2 = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
									// + tempString + "</ns3:fraud_check_req>";
									+ tempString_2
									+ strOrderId_1
									+ "</retrievalReferenceNumber> </transactionCommonData> </CardPaymentRequest>";
							tempString_2 = tempString_2.replace(
									"'yes'?>[<Card", "'yes'?><Card");
							tempString_2 = tempString_2.replace("]"
									+ strOrderId_1, strOrderId_1);

						} else {
							tempString = Arrays.toString(getTagValues(
									sb.toString()).toArray());
							tempString = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
									// + tempString + "</ns3:fraud_check_req>";
									+ tempString
									+ strOrderId
									+ "</ns3:merchant_ref_cd> </ns3:fraud_check_req>";
							tempString = tempString.replace("'yes'?>[<ns3",
									"'yes'?><ns3");
							tempString = tempString.replace("]" + strOrderId,
									strOrderId);

							if(payauthid.equals(null)) {
								
								report.addReportStep(
										"Verify the Order details in SystemOut.Log Response XML",
										"Pay Auth Id is null in DB & hence cannot fetch the SystemOut.Log Response XML",
										StepResult.DONE);				
							}
							else {
								
							tempString_3 = Arrays.toString(getTagValues_3(
									sb.toString()).toArray());
							tempString_3 = "<?xml version='1.0' encoding='UTF-8' standalone='yes'?>"
	 								//+ tempString + "</ns3:fraud_check_req>";
	 						        + tempString_3 + payauthid + "</request_id> </fraud_check_resp>";
							tempString_3 = tempString_3
									.replace("'yes'?>[<fraud_check_resp>", "'yes'?><fraud_check_resp>");
							tempString_3 = tempString_3.replace("]" + payauthid, payauthid);
						}
						}

						System.out.println(tempString);
						System.out.println(tempString_2);
						System.out.println(tempString_3);

						// BufferedWriter out = new BufferedWriter(new
						// FileWriter(
						// "C:\\Beehivexml\\TestXML_2.txt"));
						// try {
						// out.write(tempString);
						// } catch (IOException e) {
						// e.printStackTrace();
						// } finally {
						// out.close();
						// }
						readxml();
						channel.disconnect();
						session.disconnect();
						System.out
								.println("Log Session has been disconnected ");
						report.addReportStep("Disconnect the LOG session",
								"Log Session has been disconnected ",
								StepResult.DONE);
						long endTime = System.currentTimeMillis();
						long totalTime = endTime - startTime;
						int seconds = (int) ((totalTime / 1000));
						System.out
								.println("Total Seconds of Log Validation :  : "
										+ seconds);
						int minutes = (int) ((totalTime / 1000) / 60);
						System.out.println("Total Minutes of Log Validation : "
								+ minutes);
					}
				}

				else {

					System.out.println("Order ID and XML Not Found");
					report.addReportStep(
							"Verify the Credit card details in SystemOut.Log",
							"XML Details are not available in SystemOut.Log",
							StepResult.FAIL);
				}
			}
		}
	}

	private static List<String> getTagValues(final String str) {
		TAG_REGEX_1 = Pattern.compile("<\\?xml.*\\?>(.*?)" + strOrderId
				+ "</ns3:merchant_ref_cd>");

		final List<String> tagValues = new ArrayList<String>();
		final Matcher matcher = TAG_REGEX_1.matcher(str);

		if (matcher.find()) {
			System.out.println("XML Found ");
			tagValues.add(matcher.group(1));

		} else {
			System.out.println("XML Not Found ");
		}

		return tagValues;

	}

	private static List<String> getTagValues_2(final String str) {

		TAG_REGEX_2 = Pattern
		// .compile("<ns3:fraud_check_req>(.+?)</ns3:fraud_check_req>");
				.compile("<\\?xml.*\\?>(.*?)" + strOrderId_1
						+ "</retrievalReferenceNumber>");

		final List<String> tagValues_2 = new ArrayList<String>();
		final Matcher matcher = TAG_REGEX_2.matcher(str);

		if (matcher.find()) {
			System.out.println("XML Found ");
			tagValues_2.add(matcher.group(1));

		} else {
			System.out.println("XML Not Found ");
		}

		return tagValues_2;

	}

	private static List<String> getTagValues_3(final String str) {
		TAG_REGEX_3 = Pattern
		// .compile("<ns3:fraud_check_req>(.+?)</ns3:fraud_check_req>");
				//.compile("<xref_nbr>" + xrefnbr	+ "</xref_nbr>(.*?)</request_id>");
		      .compile("<\\?xml.*\\?>(.*?)"+ payauthid +"</request_id>");

		final List<String> tagValues_3 = new ArrayList<String>();
		final Matcher matcher = TAG_REGEX_3.matcher(str);

		if (matcher.find()) {
			System.out.println("XML Found ");
			tagValues_3.add(matcher.group(1));

		} else {
			System.out.println("XML Not Found ");
		}

		return tagValues_3;

	}

	public void readxml() {
		payauthid = commonData.strpayauthId;
		String strOrderId = commonData.strOrderId;
		String strCardType = dataTable.getData("CardType");
		NodeList nList=null;
		NodeList nList_2=null;
		Document doc_2;
		NodeList nList_3=null;
		Document doc_3;

		try {

			String cardNum = commonData.cardNum;
			if (cardNum.toLowerCase().contains("paypal")) {
				strCardNumber = cardNum;
			}
			DocumentBuilder builder = DocumentBuilderFactory.newInstance()
					.newDocumentBuilder();
			InputSource src_1 = new InputSource();
			src_1.setCharacterStream(new StringReader(tempString));
			Document doc = builder.parse(src_1);
			doc.getDocumentElement().normalize();

			System.out.println("Root element :"
					+ doc.getDocumentElement().getNodeName());
			 System.out.println("----------------------------");
			nList = (NodeList) doc.getElementsByTagName("ns3:credit_card_data");

			System.out.println("----------------------------");

			for (int i = 0; i < nList.getLength(); i++) {

				NodeList childList = nList.item(i).getChildNodes();
				for (int j = 0; j < childList.getLength(); j++) {
					Node childNode = childList.item(j);

					if (childNode.getNodeName().contains("card_nbr")) {
						System.out.println("Original Card Number : "
								+ strCardNumber);
						System.out.println("PIE Encrypted Card Number : "
								+ childNode.getTextContent());
						PIE_Encrypt_Nbr = childNode.getTextContent();
					}

					else if (childNode.getNodeName().contains("xref_nbr")) {
						System.out.println("XRef Card Number : "
								+ childNode.getTextContent());
						Xref_card_Nbr = childNode.getTextContent();
					}

					else if (childNode.getNodeName().contains(
							"cr_card_expir_dt")) {
						System.out.println("Card Expiry Date : "
								+ childNode.getTextContent());
						Card_Expry_date = childNode.getTextContent();
					}

					else if (childNode.getNodeName().contains("cc_id")) {
						System.out.println("Card CVV : "
								+ childNode.getTextContent());
						Card_Cvv = childNode.getTextContent();
					}

					else if (childNode.getNodeName().contains("key_block")) {
						System.out.println("Card PIE Encrypted value : "
								+ childNode.getTextContent());
						PIE_Encrypt_value = childNode.getTextContent();
					}

				}
			}

			if (strCardType.toLowerCase().contains("home depot")||strCardType.toLowerCase().contains("hd proxy")) {
				InputSource src_2 = new InputSource();
				src_2.setCharacterStream(new StringReader(tempString_2));
				doc_2 = builder.parse(src_2);
				doc_2.getDocumentElement().normalize();

				System.out.println("Root element :"
						+ doc_2.getDocumentElement().getNodeName());
				 System.out.println("----------------------------");
				nList_2 = (NodeList) doc_2
						.getElementsByTagName("tenderCreditDebit");
				System.out.println("----------------------------");

				for (int i = 0; i < nList_2.getLength(); i++) {

					NodeList childList_2 = nList_2.item(i).getChildNodes();
					for (int j = 0; j < childList_2.getLength(); j++) {
						Node childNode_2 = childList_2.item(j);

						if (childNode_2.getNodeName().contains(
								"primaryAccountNumber")) {
							System.out.println("PIE Encrypted Card Number : "
									+ childNode_2.getTextContent());
							PIE_Encrypt_Nbr = childNode_2.getTextContent();
						} else if (childNode_2.getNodeName().contains(
								"terminalKeyBlock")) {
							System.out.println("Card PIE Encrypted value : "
									+ childNode_2.getTextContent());
							PIE_Encrypt_value = childNode_2.getTextContent();

						}
					}
				}
			}
			
			report.addReportStep(
					"Verify the Order details in SystemOut.Log Request XML",
					"Order details are displayed in SystemOut.Log Request XML."
							+ ";<br>"
							+ "Order Number :"
							+ "<b>"+strOrderId+";</b>"+"<br>"
							+ "Original Card Number :"
							+ "<b>"+strCardNumber+";</b>"+"<br>"
							+ "Pie Encrypted Card Number in System.out Log Request XML :"
							+ "<b>"+PIE_Encrypt_Nbr+";</b>"+"<br>"
							+ "XRef Card Number in System.out Log Request XML :"
							+ "<b>"+Xref_card_Nbr+";</b>"+"<br>"
							+ "Card Expiry Date in System.out Log Request XML :"
							+ "<b>"+Card_Expry_date+";</b>"+"<br>"
							+ "Card CVV in System.out Log Request XML :"
							+ "<b>"+Card_Cvv+";</b>"+"<br>"
							+ "Card PIE Encrypted value in System.out Log Request XML :"
							+ "<b>"+PIE_Encrypt_value +";</b>", StepResult.DONE);

			if (!strCardNumber.toLowerCase().contains("paypal")) {
				if (PIE_Encrypt_Nbr == null && Xref_card_Nbr == null) {

					report.addReportStep(
							"Verify the PIE/XRef details in SystemOut.Log",
							"PIE/XRef details are not available", StepResult.FAIL);
				} else {

					report.addReportStep(
							"Verify the PIE/XRef details in SystemOut.Log",
							"PIE/XRef details are available", StepResult.DONE);

				}
			}

			else {
				report.addReportStep(
						"Verify the PIE/XRef details in SystemOut.Log",
						"Tender Type used is Paypal", StepResult.DONE);

			}		
			
			//Reponse XML
			
			if(payauthid.equals(null)) {
				
				report.addReportStep(
						"Verify the Order details in SystemOut.Log Response XML",
						"Pay Auth Id is null in DB & hence cannot fetch the SystemOut.Log Response XML",
						StepResult.DONE);				
			}
			
			else {
				
			if (!strCardNumber.toLowerCase().contains("paypal")) {
				InputSource src_3 = new InputSource();	
				src_3.setCharacterStream(new StringReader(tempString_3));
			 doc_3 = builder.parse(src_3);
			 doc_3.getDocumentElement().normalize();

			System.out.println("Root element :"
					+ doc_3.getDocumentElement().getNodeName());	
			 System.out.println("----------------------------");
			 nList_3 = (NodeList) doc_3
					.getElementsByTagName("fraud_check_resp");
			 System.out.println("----------------------------");

				for (int i = 0; i < nList_3.getLength(); i++) {

					NodeList childList_3 = nList_3.item(i).getChildNodes();
					for (int j = 0; j < childList_3.getLength(); j++) {
						Node childNode_3 = childList_3.item(j);

						// Element eElement = (Element) nList.item(i);
						// System.out.println(eElement.getNodeName());

						if (childNode_3.getNodeName().contains("xref_nbr")) {
							System.out.println("XREF Card Number : "
									+ childNode_3.getTextContent());
							XRef_card_nbr = childNode_3.getTextContent();
						}
						else if (childNode_3.getNodeName().contains("resp_desc")) {
							System.out.println("Response : "
									+ childNode_3.getTextContent());
							rspnse = childNode_3.getTextContent();

						}
						
						else if (childNode_3.getNodeName().contains("decision")) {
							System.out.println("Decision : "
									+ childNode_3.getTextContent());
							dcson = childNode_3.getTextContent();

						}
						
						else if (childNode_3.getNodeName().contains("request_id")) {
							System.out.println("Request ID : "
									+ childNode_3.getTextContent());
							rqst_id = childNode_3.getTextContent();

						}
						
						else if (childNode_3.getNodeName().contains("rqst_token")) {
							System.out.println("Request Token : "
									+ childNode_3.getTextContent());
							rqst_tkn= childNode_3.getTextContent();

						}
					}
				}
				
				report.addReportStep(
						"Verify the Order details in SystemOut.Log Response XML",
						"Order details are displayed in SystemOut.Log Response XML"+"</br>"
								+ "Request ID in System.out Log Request XML :"
								+ "<b>"+rqst_id+";</b>"+"<br>"
								+ "Request Token in System.out Log Response XML :"
								+ "<b>"+rqst_tkn+";</b>"+"<br>"
								+ "Request Decision in System.out Log Response XML :"
								+ "<b>"+dcson+";</b>"+"<br>"
								+ "Request Response in System.out Log Response XML :"
								+ "<b>"+rspnse+";</b>"+"<br>"
								+ "XRef Card Number in System.out Log Response XML :"
								+ "<b>"+XRef_card_nbr+";</b>", StepResult.DONE);
			
			}
			else {
				
				report.addReportStep(
						"Verify the Order details in SystemOut.Log Response XML",
						"Tender Type used is Paypal & hence cannot fetch the SystemOut.Log Response XML",
						StepResult.DONE);
				
			}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String log_connection_hostname() {

		//String envirnmnt = properties.getProperty("Environment");
		String envirnmnt = HelperClass.baseModel.runEnvironment;
		log_hostname = null;

		if (envirnmnt.equalsIgnoreCase("qa71")) {

			log_hostname = "cpaiqaha.homedepot.com";
		}

		else if (envirnmnt.equalsIgnoreCase("qa72")) {

			log_hostname = "cpaiqaba.homedepot.com";
		}

		else if (envirnmnt.equalsIgnoreCase("qa73")) {

			log_hostname = "cpaiqafa.homedepot.com";

		} else if (envirnmnt.equalsIgnoreCase("qa74")) {

			log_hostname = "cpaiqauh.homedepot.com";
		}

		else if (envirnmnt.equalsIgnoreCase("st71")) {

			log_hostname = "cpaist5a.homedepot.com";
		}

		else if (envirnmnt.equalsIgnoreCase("st72")) {

			log_hostname = "cpaist3a.homedepot.com";
		}

		else if (envirnmnt.equalsIgnoreCase("st73")) {

			log_hostname = "cpaist9a.homedepot.com";
		}

		else if (envirnmnt.equalsIgnoreCase("ps71")) {

			log_hostname = "cpaiqa8a.homedepot.com";
		}

		return log_hostname;

	}

	public String log_connection_username() {
		//String envirnmnt = properties.getProperty("Environment");
		String envirnmnt = HelperClass.baseModel.runEnvironment;
		log_username = null;

		if (envirnmnt.equalsIgnoreCase("qa71")) {

			log_username = "tauser02";
		}

		else if (envirnmnt.equalsIgnoreCase("qa72")) {

			log_username = "tauser02";
		}

		else if (envirnmnt.equalsIgnoreCase("qa73")) {

			log_username = "tauser02";

		} else if (envirnmnt.equalsIgnoreCase("qa74")) {

			log_username = "tauser02";
		}

		else if (envirnmnt.equalsIgnoreCase("st71")) {

			log_username = "tauser03";
		}

		else if (envirnmnt.equalsIgnoreCase("st72")) {

			log_username = "tauser03";
		}

		else if (envirnmnt.equalsIgnoreCase("st73")) {

			log_username = "";
		}

		else if (envirnmnt.equalsIgnoreCase("ps71")) {

			log_username = "";
		}

		return log_username;

	}

	public String log_connection_password() {

		//String envirnmnt = properties.getProperty("Environment");
		String envirnmnt = HelperClass.baseModel.runEnvironment;
		log_password = null;

		if (envirnmnt.equalsIgnoreCase("qa71")) {

			log_password = "1nd0n3s1a";
		}

		else if (envirnmnt.equalsIgnoreCase("qa72")) {

			log_password = "1nd0n3s1a";
		}

		else if (envirnmnt.equalsIgnoreCase("qa73")) {

			log_password = "1nd0n3s1a";

		} else if (envirnmnt.equalsIgnoreCase("qa74")) {

			log_password = "1nd0n3s1a";
		}

		else if (envirnmnt.equalsIgnoreCase("st71")) {

			log_password = "webster6";
		}

		else if (envirnmnt.equalsIgnoreCase("st72")) {

			log_password = "webster6";
		}

		else if (envirnmnt.equalsIgnoreCase("st73")) {

			log_password = "";
		}

		else if (envirnmnt.equalsIgnoreCase("ps71")) {

			log_password = "";
		}

		return log_password;

	}

}
