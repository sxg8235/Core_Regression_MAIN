package com.homer.po;

import java.util.List;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;

public class MyAccountPage extends PageBase<MyAccountPage> {

	static By betaWebServerBtn = By.xpath("//button[@id='button1'][contains(text(),'Beta Webservers')]");
	static By testWebServerBtn = By.xpath("//button[@id='button1'][contains(text(),'Test Webserver')]");

	static final By lnkMyAccount = By.id("headerMyAccount");
	static final By lnkReg = By.linkText("REGISTER");
	static final By tagReg = By.xpath("//a[@href='#tab_register']");

	static final By lnkSignout = By.linkText("Sign Out");
	static final By registrationTitle = By.xpath("//*[contains(text(),'My Account Registration')][1]");
	static final By txtFirstName = By.id("dualSignIn-firstName");
	static final By txtLastName = By.id("dualSignIn-lastName");
	static final By txtZipcode = By.id("dualSignIn-zipcode");
	static final By txtEmail = By.id("dualSignIn-registrationEmail");
	static final By txtPassword = By.id("dualSignIn-registrationPassword");
	static final By txtConfirmPassword = By.id("dualSignIn-confirmPassword");
	static final By btnRegister = By.xpath("//button[contains(text(),'REGISTER')]");
	static final By btnSubscribe = By.id("completeRegistration");
	static final By regUserName = By.xpath("//span[@class='headerMyAccount__title--name']");

	protected static final By myAccountPg = By.xpath("//h4[contains(text(),'My Account')]");
	protected static final By checkAll = By.xpath("//label[@for='checkAll1']");
	protected static final By addToCartLink = By.xpath("//a[contains(text(),'ADD SELECTED TO CART')]");
	protected static final By addToCartLinkTab = By.xpath("//a[contains(text(),'add to cart')]");
	protected static final By taxExcempt = By.xpath("//a[contains(text(),'Tax Exempt ID')]");
	protected static final By taxExcemptTxt = By.id("taxExemptID");
	protected static final By saveBtn = By.id("saveTaxIdBtn");
	protected static final By taxExcemptSaveOverlay = By.id("fancybox-close");
	protected static final By RemovetaxExempt = By.xpath("//*[@id='removeYourTaxID']"); //
	protected static final By RemovetaxExemptOverlay = By.xpath("//*[@id='confirmRemove']");//
	protected static final By closeExemptSaveOverlay = By.id("fancybox-close");//
	protected static final By accountInfo = By.xpath("//a[contains(text(),'Account Information')]");
	protected static final By firstNameTxt = By.id("firstname");
	protected static final By updateBtn = By.id("updateAccount");
	protected static final By updatedOverlay = By.id("fancybox-close");
	protected static final By checkoutNow = By.xpath("//*[contains(text(),'CHECKOUT NOW')]");
	protected static final By storeLink = By.xpath("//span[contains(text(),'Change Store')]");
	protected static final By storeSearchTxtBox = By.id("findStores");
	protected static final By findStrBtn = By.xpath("//a[contains(text(),'Find Stores')]");
	protected static final By makeThisMyStoreBtn = By.xpath("//a[contains(text(),'Make This My Store')]");
	protected static final By pwdTxt = By.name("logonPassword");
	protected static final By signInBtn = By.id("signInPage");
	protected static final By viewCartTab = By.cssSelector("#add-to-cart-btn");
	static final By saveCreditCardLink = By.xpath("//a[contains(text(),'Saved Credit Cards')]");
	protected static final By MyAccountTitle = By.cssSelector("#headerMyAccountTitle");
	protected static final By MyAccountPageTitle = By.xpath("//h1[@class='page-title']");
	protected static final By Accountprofile = By.xpath("//*[contains(text(),'Account Profile')]");
	static final By OverlayZipcode = By.name("zipcode");
	static final By CurrentCity = By.xpath("//*[@id='edit-address-overlay-content_city_select']");
	static final By CurrentState = By.id("edit-address-overlay-content_state_label");
	static final By UpdateButtonInOverlay = By.xpath("//*[@class='btn btn-gray edit-address-button md-submit']");
	protected static final By AddressBookLink = By.linkText("Address Book");
	protected static final By AddAddressButton = By.id("AddAddr");
	protected static final By AddAddressFirstName = By.id("first-name");
	protected static final By AddAddressLastName = By.id("last-name");
	protected static final By AddAddressAddress1 = By.id("address-1");
	protected static final By AddAddressPhoneNum1 = By.name("fieldphone1");
	protected static final By AddAddressPhoneNum2 = By.name("fieldphone2");
	protected static final By AddAddressPhoneNum3 = By.name("fieldphone3");
	protected static final By Zipcode = By.id("zip");
	protected static final By NickName = By.id("nick-name");
	protected static final By UpdateAddress = By.id("UpdateShipping");
	static final By lnkSavedCard = By.xpath("//*[@id='acctProfile']//li[2]");
	static final By savedcard = By.xpath("//*[@class='calculatorContent']//h3");
	static final By cardSection = By.xpath("//*[@class='dataTables_wrapper']//tbody");

	static final By strikeThroPrice = By.xpath("//span[@class='wasPrice']");
	static final By unitPriceSTH = By.xpath("//div[@class='perPiece']");

	static final By addPlan_myaccount = By.xpath("//a[contains(@class,'no-shrink')]/img");
	static By certonaList = By.cssSelector("div.certona1main.grid");
	static By certonaAddToCartBtn = By
			.xpath("//div[@class='certona1main grid']/div[1]//span[contains(text(),'Add To Cart')]");

	static final By cardHolderName = By.id("cardHolderName");
	static final By cardBrand = By.id("cardBrand");
	static final By cardNumber = By.id("cardNumber");
	static final By cardExpMonth = By.id("cardExpiryMonth");
	static final By cardExpiryYear = By.id("cardExpiryYear");
	static final By firstName = By.id("firstName");
	static final By lastName = By.id("lastName");
	static final By txtAddress1 = By.id("address1");
	static final By txtZip = By.id("zipCode");
	static final By billingPh1 = By.name("billing_fieldphone1");
	static final By billingPh2 = By.name("billing_fieldphone2");
	static final By billingPh3 = By.name("billing_fieldphone3");
	static final By creditCardheading = By.xpath("//h3[@class='creditcardHeading']");
	static final By openPopup = By.id("openPopup");
	static final By fancyBoxClose = By.id("fancybox-close");
	static final By addCardBtn = By.id("addCardBtn");
	static final By savedAddresses = By.id("savedAddresses");

	static final By THDLogo = By.xpath("//*[@class='thdTablet-logo']|//*[@class='headerLogo']");
	static final By OrdersAndPurchasesLink = By.linkText("Orders & Purchases");
	static final By OrderNumber = By.xpath("//*[@class='orderDetailLink ordNum btn btn-orange ordNumBtnStyle']");
	static final By OrderStatus = By.xpath("//strong[contains(text(),'Order Status:')]");
	static final By BeingProcessed = By.xpath("//strong[contains(.,'Being Processed')]/..");
	static final By OrderDate = By.xpath("//strong[contains(.,'Order Date')]/..");
	static final By PickUpdetailsButton = By.cssSelector("span.icon-learn-more");
	static final By StoreNameLink = By.xpath("//a[@class='map-link']");
	static final By ItemforPickUp = By.xpath("//*[@class='myacct-detailstable-PD-bopis-content-text']//a//b");
	static final By statusOrtracking = By.cssSelector("td.myacct-detailstable-SST-header");
	static final By TrackingStatus = By.cssSelector("td.myacct-detailstable-SST-content > b");
	static final By PickupPerson = By.cssSelector("td.myacct-pickingtable-PickUpPerson-header");
	static final By PickUpPersonValue = By.cssSelector("p.fn");
	static final By StoreDetails = By.cssSelector("td.myacct-pickingtable-StoreDetails-header");
	static final By StoreDetailsValue = By.cssSelector("td.myacct-pickingtable-StoreDetails-content");
	static final By DesignatedPickupDateTime = By.cssSelector("td.myacct-pickingtable-DPDT-header");
	static final By DesignatedPickupDateTimeValue = By.cssSelector("td.myacct-pickingtable-DPDT-content");
	static final By ProductImage = By.cssSelector("img.noImageThumb");
	static final By Description = By.cssSelector("td.myacct-detailstable-PD-header");
	static final By DescriptionValue = By.cssSelector("a.pip > b");
	static final By QtyOrdered = By.cssSelector("td.myacct-detailstable-Qty-header");
	static final By QtyOrderedValue = By.cssSelector("td.myacct-detailstable-Qty-content");;
	static final By QtyPickedUp = By.cssSelector("td.myacct-pickingtable-QtyPicked-header");
	static final By Total = By.xpath("//td[contains(text(),'Item Total')]");
	static final By TotalValue = By.xpath("//div[@id='detailePricingSection']/div/div[4]/div[2]");
	static final By QtyPickedUpValue = By.cssSelector("td.myacct-detailstable-Qty-content-bopis");
	static final By OrderNumInTablet = By.xpath("//span[contains(text(),'Order#')]");
	static final By orderStatusTablet = By.xpath(
			"//*[@class='order-fulfillment-progress right text-muted m-right-xlarge']//h3|//*[@id='orderDetails']/tbody/tr/td[5]//a");
	static final By BeingProcessedtablet = By.xpath("//*[contains(text(),'Being Processed')]");
	static final By OrderDateValuetablet = By.xpath("//span[@class='tiny text-muted']");
	static final By StoreDetailsIntablet = By.xpath("//*[@class='pod-summary']//*[@class='right']");
	static final By FullfillmentTypetablet = By.xpath("//*[@class='pod-summary']//*[@class='left']//h3[1]");
	static final By PickUpPersontablet = By.xpath("//h3[contains(text(),'Pick Up Person')]");
	static final By storenameIntablet = By.xpath("//*[@class='right']//h3[1]");
	static final By ProductImageTablet = By.xpath("//*[@class='tpl-content online-border flex-box']//img");
	static final By ProductDescTablet = By.xpath("(//*[@class='tpl-content online-border flex-box']//h4)[2]");
	static final By qtyOrderedTablet = By.xpath("(//*[@class='flex1'][1])[1]");
	static final By qtyOrederdtabletvalue = By.xpath("(//*[@class='flex1'][1])[2]");
	static final By ItemTotaltablet = By.xpath("//*[contains(text(),'Item Total')]");
	static final By TotalValueTablet = By.xpath("(//*[@class='flex1']//h3[@class='bold'])[2]");
	static final By ordno = By.xpath("//*[@id='OrderSummaryInfo']//h1");
	static final By orderstatusAppliance = By.xpath("//*[@class='myacct-detailstable-SST-content']//b");
	// Full site registration page
	static final By tabFirstName = By.xpath("//input[@id='firstName']");
	static final By tabLastName = By.xpath("//input[@id='lastName']");
	static final By tabZipcode = By.xpath("//input[@id='zipcode']");
	static final By tabEmail = By.xpath("//input[@id='email']");
	static final By tabPwd = By.xpath("//input[@id='newPasswordField']");
	static final By tabConfPwd = By.xpath("//input[@id='confirmPasswordField']");
	static final By tabRegister = By.xpath("//input[@type='submit']");
	static final By trackOrder = By.xpath("//*[contains(text(),'Track Your Order')]");
	static final By txtOrderNo = By.xpath("//input[@id='orderNumText']");
	static final By txtTrackEmail = By.xpath("//input[@name='emailaddress']");
	static final By trackOrderBtn = By.xpath("//*[@id='trackOrderBtn']");
	static final By addrErr = By.xpath("//ul[@class='error-text']/li");
	static final By OnlineOrder = By.xpath("//a[contains(text(),'Online Orders')]");

	// IE9 browser
	static final By regEmail = By.xpath("//input[@id='registrationEmail']");
	static final By regPass = By.xpath("//input[@id='registrationPassword']");
	static final By regConfirmPass = By.xpath("//input[@id='confirmPassword']");
	static final By regSubmit = By.xpath("//a[@id='Register']");
	static final By myAccountReg = By.xpath("//h1[@class='page-title']");
	// Norton logo
	static final By nortonlogo = By.id("veriSignImg");
	static final By verisignSiteName = By.xpath("(//td[@class='cell2'])[1]");
	static final By verisignsealmisuse = By.id("reportSealMisuse");
	static final By verisignSeal = By.id("vrsn_seal");

	static final By InvalidTaxExemptErrormsg = By.xpath("//*[@id='error_msg']");
	static final By addressColumn=By.xpath("//th[@class='myacct-col2 ui-state-default']");
	static final By MyActtableBody=By.xpath("//*[@id='addrBookTbl']/tbody");
	static final By addressDataTable=By.xpath("//*[@id='addrBookTbl']");
	public MyAccountPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Component to register the user
	 * 
	 * @since Aug 26, 2015
	 * @author yxg8356
	 * @throws Exception
	 */
	public MyAccountPage registerUser() throws Exception {

		String strFirstName = dataTable.getCommonData(CommonDataColumn.ShippingFirstName);
		String strLastName = dataTable.getCommonData(CommonDataColumn.ShippingLastName);
		String strZipCode = dataTable.getCommonData(CommonDataColumn.ShippingZipCode);
		String strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);

		Random randomGenerator = new Random();
		String strTimeStmp = "Run_" + rc.getCurrentFormattedTime().replace(" ", "_").replace(":", "-")
				+ randomGenerator.nextInt(100);

		String strEmail = strTimeStmp + "@homedepot.com";
		commonData.strEmail = strEmail;
		commonData.strPassword = strPassword;

		if (wh.isElementPresent(lnkMyAccount, 6)) {
			wh.jsClick(lnkMyAccount);
			wh.clickElement(lnkReg);
			// wh.jsClick(tagReg);
		} else {

			wh.clickElement(lnkMyAccount);

			if (wh.isElementPresent(lnkSignout, 3)) {
				wh.clickElement(lnkSignout);
			}
			if (wh.isElementPresent(lnkMyAccount, 3)) {
				wh.jsClick(lnkMyAccount);
				wh.clickElement(lnkReg);
				// wh.jsClick(tagReg);
			} else {
				report.addReportStep("Click on Register link present on the homedepot page",
						"Register link on the homedepot page is not displayed", StepResult.FAIL);
				rc.terminateTestCase("User Registration Link");
			}
		}

		// Full site registration page for tablet site
		wh.waitForPageLoaded();

		if (wh.isElementPresent(myAccountReg)) {

			wh.sendKeys(tabFirstName, strFirstName);
			wh.sendKeys(tabLastName, strLastName);
			wh.sendKeys(tabZipcode, strZipCode);
			wh.sendKeys(regEmail, strEmail);
			wh.sendKeys(regPass, strPassword);
			wh.sendKeys(regConfirmPass, strPassword);

			if (wh.isElementPresent(regSubmit, 15)) {

				wh.clickElement(regSubmit);

				if (wh.isElementPresent(btnSubscribe, 4)) {

					wh.clickElement(btnSubscribe);

					// close registration tour.
					if (wh.isElementPresent(By.id("fancybox-close"))) {
						wh.clickElement(By.id("fancybox-close"));
					}

				}
			}

		} else if (wh.isElementPresent(tabFirstName)) {

			// Enter details
			wh.sendKeys(tabFirstName, strFirstName);
			wh.sendKeys(tabLastName, strLastName);
			wh.sendKeys(tabZipcode, strZipCode);
			wh.sendKeys(tabEmail, strEmail);
			wh.sendKeys(tabPwd, strPassword);
			wh.sendKeys(tabConfPwd, strPassword);
			Thread.sleep(commonData.littleWait);
			// Click Register Button
			if (wh.isElementPresent(tabRegister, 15)) {

				wh.clickElement(tabRegister);

				Thread.sleep(commonData.littleWait);

				// Complete Registration
				if (wh.isElementPresent(btnSubscribe, 4)) {
					wh.clickElement(btnSubscribe);

					// close registration tour.
					if (wh.isElementPresent(By.id("fancybox-close"))) {
						wh.clickElement(By.id("fancybox-close"));

					}

				}

				else {
					report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
							"<b>" + strFirstName + "</b> account is created", StepResult.DONE);
					// get the registration user name
					if (wh.isElementPresent(regUserName, 3)) {
						String strUserName = wh.getText(regUserName);

						if (strUserName.contains(strFirstName)) {
							report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
									"<b>" + strFirstName + "</b> account has been created", StepResult.PASS);

						}

						else {
							report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
									"<b>" + strFirstName + "</b> account is not created", StepResult.FAIL);
							rc.terminateTestCase("Registered account");
						}
					}

					else {
						report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
								"<b>" + strFirstName + "</b> account is not created", StepResult.FAIL);
						rc.terminateTestCase("Registered account");
					}

				}
			}

			else {
				report.addReportStep("Verify <b> Register Button </b> is displayed",
						"<b>Register Button</b>  is not displayed", StepResult.FAIL);
				rc.terminateTestCase();
			}
		}
		// Dual sign in overlay
		else if (wh.isElementPresent(registrationTitle, 15)) {

			// Enter details
			wh.sendKeys(txtFirstName, strFirstName);
			wh.sendKeys(txtLastName, strLastName);
			wh.sendKeys(txtZipcode, strZipCode);
			wh.sendKeys(txtEmail, strEmail);
			wh.sendKeys(txtPassword, strPassword);
		wh.sendKeys(txtConfirmPassword, strPassword);
			Thread.sleep(commonData.littleWait);

			// Click Register Button
			if (wh.isElementPresent(btnRegister, 15)) {

				wh.clickElement(btnRegister);

				Thread.sleep(commonData.littleWait);

				// Complete Registration
				if (wh.isElementPresent(btnSubscribe, 4)) {
					wh.clickElement(btnSubscribe);

					// close registration tour.
					if (wh.isElementPresent(By.id("fancybox-close"))) {
						wh.clickElement(By.id("fancybox-close"));

					}

					// get the registration user name
				if (wh.isElementPresent(regUserName, 3)) {
						String strUserName = wh.getText(regUserName);

						if (strUserName.contains(strFirstName)) {
							report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
									"<b>" + strFirstName + "</b> account has been created", StepResult.PASS);

						}

						else {
							report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
									"<b>" + strFirstName + "</b> account is not created", StepResult.FAIL);
							rc.terminateTestCase("Registered account");
						}
					}

					else {
						report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
								"<b>" + strFirstName + "</b> account is not created", StepResult.FAIL);
						rc.terminateTestCase("Registered account");
					}

				}

				else {
					report.addReportStep("Verify <b>" + strFirstName + "</b> account has been created",
							"<b>" + strFirstName + "</b> account is not created", StepResult.FAIL);
					rc.terminateTestCase("Registered account");
				}

			}

			else {
				report.addReportStep("Verify <b> Register Button </b> is displayed",
						"<b>Register Button</b>  is not displayed", StepResult.FAIL);
				rc.terminateTestCase("Registered Button");
			}
			addMCCparamter();

		}

		else {
			report.addReportStep("Verify My account registration section displayed",
					"My account registration displayed successfully", StepResult.FAIL);
			rc.terminateTestCase("My account registration");
		}
				
			
		return this;
				

	}

	/**
	 * Method to verify Shopping Cart Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage verifyMyAccountPage() throws Exception {

		if (wh.isElementPresent(myAccountPg, 5)) {

			report.addReportStep("Verify My Account Page", "My Account page is displayed", StepResult.PASS);
		} else {

			report.addReportStep("Verify My Account Page", "My Account page is not displayed", StepResult.FAIL);

			rc.terminateTestCase("Shopping Cart Page");
		}

		return this;
	}

	/*
	 * To Click Add to cart from my list
	 */
	public MyAccountPage clickAddToCartFromList() throws Exception {

		if (wh.isElementPresent(checkAll, 5)) {

			wh.clickElement(checkAll);

			wh.clickElement(addToCartLink);

			report.addReportStep("Click add to cart link from my list page",
					"Add to cart link is clicked in my list page", StepResult.PASS);
		} else if (wh.isElementPresent(addToCartLinkTab, 5)) {

			wh.clickElement(addToCartLink);

			report.addReportStep("Click add to cart link from my list page",
					"Add to cart link is clicked in my list page", StepResult.PASS);
		} else {

			report.addReportStep("Click add to cart link from my list page",
					"Add to cart link is not clicked in my list page", StepResult.FAIL);

			rc.terminateTestCase("Shopping Cart Page");
		}

		return this;
	}

	/**
	 * Method to save tax excempt id
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage saveTaxExcemptId() throws Exception {

		String taxId = dataTable.getCommonData(CommonDataColumn.InvalidTaxExempt);

		if (wh.isElementPresent(taxExcempt, 5)) {
			wh.clickElement(taxExcempt);

			wh.sendKeys(taxExcemptTxt, taxId);
			wh.clickElement(saveBtn);

			if (wh.isElementPresent(taxExcemptSaveOverlay, 5)) {
				wh.clickElement(taxExcemptSaveOverlay);
			}
			report.addReportStep("Enter tax excempt id and save the details",
					"Tax excempt id is entered and details are saved", StepResult.PASS);
		} else {

			report.addReportStep("Enter tax excempt id and save the details",
					"Tax excempt id is not entered and details are not saved", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Method to Edit account information in My Account page
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage editAccountInfo() throws Exception {

		if (wh.isElementPresent(accountInfo, 5)) {
			wh.clickElement(accountInfo);

			wh.clearElement(firstNameTxt);
			wh.sendKeys(firstNameTxt, "Edit");
			wh.clickElement(updateBtn);

			if (wh.isElementPresent(updatedOverlay, 5)) {
				wh.clickElement(updatedOverlay);
			}
			report.addReportStep("Edit Account information and update the details",
					"Account information is edited and details are updated", StepResult.PASS);
		} else {

			report.addReportStep("Edit Account information and update the details",
					"Account information is not edited and details are not updated", StepResult.FAIL);

		}

		Thread.sleep(5000);

		return this;
	}

	/**
	 * Method to verify Added to Cart Overlay
	 * 
	 * @return MyAccountPage
	 * @throws Exception
	 */
	public MyAccountPage verifyItemAddedOverlay() throws Exception {

		if (wh.isElementPresent(checkoutNow, 15)) {
			report.addReportStep("Verify Added to cart overlay displayed", "Added to cart overlay displayed",
					StepResult.PASS);
		} else if (wh.isElementPresent(viewCartTab, 15)) {
			report.addReportStep("Verify item is added to cart and view cart is displayed",
					"Added to cart and view cart is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Verify item is added to cart and view cart is displayed",
					"Added to cart and view cart is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to Edit account information in My Account page
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage changeStoreDetailsMyAccount() throws Exception {

		String store = dataTable.getData("LocalizeStore");

		if (wh.isElementPresent(accountInfo, 5)) {
			wh.clickElement(accountInfo);

			if (wh.isElementPresent(storeLink, 5)) {
				wh.clickElement(storeLink);

				wh.clearElement(storeSearchTxtBox);
				wh.sendKeys(storeSearchTxtBox, store);
				wh.clickElement(findStrBtn);

				if (wh.isElementPresent(By.xpath("//*[@id='nearByStores']//a[contains(@href,'" + store + "')]"), 5)) {
					wh.clickElement(By.xpath("//*[@id='nearByStores']//a[contains(@href,'" + store + "')]"));
					Thread.sleep(commonData.mediumWait);
				}

				if (wh.isElementPresent(makeThisMyStoreBtn, 5)) {
					wh.clickElement(makeThisMyStoreBtn);
					Thread.sleep(commonData.littleWait);
				}
				report.addReportStep("Edit store and update the details in My Account",
						"Store details are changed in My Account", StepResult.PASS);
			}

			else {
				report.addReportStep("Edit store and update the details in My Account",
						"Change store is not displayed and Store details are not changed in My Account",
						StepResult.FAIL);
			}

		} else {

			report.addReportStep("Edit store and update the details in My Account",
					"Account info link is not displayed and Store details are not changed in My Account",
					StepResult.FAIL);

		}

		Thread.sleep(5000);

		return this;
	}

	/**
	 * Method to Sign in for persistent user in My Account page
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage persistentUserSignIn() throws Exception {

		if (wh.isElementPresent(pwdTxt, 5)) {
			wh.sendKeys(pwdTxt, commonData.strPassword);
			wh.clickElement(signInBtn);

			if (wh.isElementPresent(updatedOverlay, 7)) {
				wh.clickElement(updatedOverlay);
			}
			report.addReportStep("Enter password and sign in for persistent user in My Account page",
					"Password entered and sign in clicked in My Account page", StepResult.PASS);
		} else {

			report.addReportStep("Enter password and sign in for persistent user in My Account page",
					"Password not entered and sign in not clicked in My Account page", StepResult.FAIL);

		}

		Thread.sleep(commonData.smallWait);

		return this;
	}

	/**
	 * 
	 * Description : Save credit card to account
	 * 
	 * @throws Exception
	 *
	 *
	 */
	public void saveCreditCard() throws Exception {

		String CardNumber = null;
		String CardType = dataTable.getData("CardType");
		String strCardType = "";

		if (CardType.toLowerCase().contains("visa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.VISA_card);
			strCardType = "Visa";

		}

		else if (CardType.toLowerCase().contains("master")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.MASTER_card);
			strCardType = "Mastercard";
		}

		else if (CardType.toLowerCase().contains("amex")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.AMEX_card);
			strCardType = "American Express";
		}

		else if (CardType.toLowerCase().contains("discover")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.DISCOVER_card);
			strCardType = "Discover Network";
		}

		else if (CardType.toLowerCase().contains("consumer")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCONSUMER_card);
			strCardType = "Home Depot Consumer Card";
		}

		else if (CardType.toLowerCase().contains("commercial")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCOMMERCIAL_card);
			strCardType = "Home Depot Commercial";
		}

		else if (CardType.toLowerCase().contains("gsa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.GSA_card);
		}

		else if (CardType.isEmpty()) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.CardNumber);
			strCardType = dataTable.getCommonData(CommonDataColumn.CardType);
		}

		Thread.sleep(commonData.littleWait);
		String strCardHolderName = dataTable.getCommonData(CommonDataColumn.BuyerName);
		String strExpiryMonth = dataTable.getCommonData(CommonDataColumn.SaveExpirationMonth);
		String strExpiryYear = dataTable.getCommonData(CommonDataColumn.ExpirationYear);
		String strFirstName = dataTable.getCommonData(CommonDataColumn.ShippingFirstName);
		String strLastName = dataTable.getCommonData(CommonDataColumn.ShippingLastName);
		String strZipCode = dataTable.getCommonData(CommonDataColumn.ShippingZipCode);

		String strBillingPhonenum = dataTable.getCommonData(CommonDataColumn.ShippingPhNo);
		String strAddress = dataTable.getCommonData(CommonDataColumn.ShippingAddr);
		wh.ignorePopup(driver);

		if (wh.isElementPresent(saveCreditCardLink, 8)) {
			wh.clickElement(saveCreditCardLink);

			report.addReportStep("Click Save a credit card link in My Account page",
					"Save a credit card link is clicked in My Account page", StepResult.PASS);
			Thread.sleep(commonData.smallWait);
			if (wh.isElementPresent(addCardBtn, 8)) {
				wh.clickElement(addCardBtn);

				report.addReportStep("Click Add a credit card button in My Account page",
						"Add a credit card button is clicked in My Account page", StepResult.PASS);
				Thread.sleep(commonData.smallWait);
			}

			else {
				report.addReportStep("Click Add a credit card button in My Account page",
						"Add a credit card button is not present in My Account page", StepResult.FAIL);

			}
		}

		else {
			report.addReportStep("Click Save a credit card link in My Account page",
					"Save a credit card link is not present in My Account page", StepResult.FAIL);

		}

		if (wh.isElementPresent(cardHolderName, 8)) {
			wh.sendKeys(cardHolderName, strCardHolderName);
			wh.selectValue(cardBrand, strCardType);
			wh.sendKeys(cardNumber, CardNumber);

			if (!strCardType.contains("Home Depot")) {
				wh.selectValue(cardExpMonth, strExpiryMonth);
				wh.selectValue(cardExpiryYear, strExpiryYear);
			}

			// cf.clickLink(driver, "xpath", "//a[contains(text(),'Add New
			// Address')]", "Add New Address");
			wh.sendKeys(firstName, strFirstName);
			wh.sendKeys(lastName, strLastName);
			wh.sendKeys(txtAddress1, strAddress);
			wh.sendKeys(txtZip, strZipCode);
			Thread.sleep(commonData.littleWait);
			commonData.Zipcode = strZipCode;

			wh.sendKeys(billingPh1, strBillingPhonenum.substring(0, 3));
			wh.sendKeys(billingPh2, strBillingPhonenum.substring(2, 5));
			wh.sendKeys(billingPh3, strBillingPhonenum.substring(5, 10));

			wh.clickElement(By.xpath("//h3[@class='creditcardHeading']"));

			Thread.sleep(commonData.smallWait);

			wh.clickElement(openPopup);

			Thread.sleep(commonData.mediumWait);
			wh.ignorePopup(driver);

			try {
				wh.clickElement(fancyBoxClose);
			}

			catch (Exception e) {
				report.addReportStep("Verify that Express checkout details confirmation dialog is displayed",
						"Express checkout confirmation fancy box is not displayeds", StepResult.FAIL);
			}
			wh.ignorePopup(driver);

			Thread.sleep(commonData.littleWait);
		} else {
			report.addReportStep("verify that express checkout dialog is displayed",
					"Express checkout dialog is not displayed", StepResult.FAIL);
		}

		Thread.sleep(commonData.smallWait);

	}

	/**
	 * 
	 * Description : Save credit card to account
	 * 
	 * @throws Exception
	 *
	 *
	 */
	public void saveCreditCardInMyAcct() throws Exception {
		String CardNumber = null;
		String CardType = dataTable.getData("CardType");
		String zipWithDiffCity = dataTable.getData("Shipping_ZipCode");
		String strCardType = "";

		if (CardType.toLowerCase().contains("visa")) {
			strCardType = "Visa";
			CardNumber = dataTable.getCommonData(CommonDataColumn.VISA_card);

		}

		else if (CardType.toLowerCase().contains("master")) {
			strCardType = "Mastercard";
			CardNumber = dataTable.getCommonData(CommonDataColumn.MASTER_card);
		}

		else if (CardType.toLowerCase().contains("amex")) {
			strCardType = "American Express";
			CardNumber = dataTable.getCommonData(CommonDataColumn.AMEX_card);
		}

		else if (CardType.toLowerCase().contains("discover")) {
			strCardType = "Discover Network";
			CardNumber = dataTable.getCommonData(CommonDataColumn.DISCOVER_card);
		}

		else if (CardType.toLowerCase().contains("consumer")) {
			strCardType = "Home Depot Consumer Card";
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCONSUMER_card);
		}

		else if (CardType.toLowerCase().contains("commercial") || CardType.toLowerCase().contains("prox")) {
			strCardType = "Home Depot Commercial";
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCOMMERCIAL_card);
		}

		else if (CardType.toLowerCase().contains("gsa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.GSA_card);
		}

		else if (CardType.isEmpty()) {
		}

		Thread.sleep(commonData.littleWait);
		String strCardHolderName = dataTable.getCommonData(CommonDataColumn.BuyerName);
		String strExpiryMonth = dataTable.getCommonData(CommonDataColumn.SaveExpirationMonth);
		String strExpiryYear = dataTable.getCommonData(CommonDataColumn.ExpirationYear);
		String strFirstName = dataTable.getCommonData(CommonDataColumn.ShippingFirstName);
		String strLastName = dataTable.getCommonData(CommonDataColumn.ShippingLastName);
		String strZipCode = null;
		if (!zipWithDiffCity.isEmpty()) {
			strZipCode = zipWithDiffCity;
		} else {
			strZipCode = dataTable.getCommonData(CommonDataColumn.ShippingZipCode);
		}
		String strBillingPhonenum = dataTable.getCommonData(CommonDataColumn.ShippingPhNo);
		String strAddress = dataTable.getCommonData(CommonDataColumn.ShippingAddr);
		wh.ignorePopup(driver);

		if (wh.isElementPresent(saveCreditCardLink, 8)) {
			wh.clickElement(saveCreditCardLink);

			report.addReportStep("Click Save a credit card link in My Account page",
					"Save a credit card link is clicked in My Account page", StepResult.PASS);
			Thread.sleep(commonData.smallWait);
			if (wh.isElementPresent(addCardBtn, 8)) {
				wh.clickElement(addCardBtn);

				report.addReportStep("Click Add a credit card button in My Account page",
						"Add a credit card button is clicked in My Account page", StepResult.PASS);
				Thread.sleep(commonData.smallWait);
			}

			else {
				report.addReportStep("Click Add a credit card button in My Account page",
						"Add a credit card button is not present in My Account page", StepResult.FAIL);

			}
		}

		else {
			report.addReportStep("Click Save a credit card link in My Account page",
					"Save a credit card link is not present in My Account page", StepResult.FAIL);

		}

		if (wh.isElementPresent(cardHolderName, 8)) {
			wh.sendKeys(cardHolderName, strCardHolderName);
			wh.selectValue(cardBrand, strCardType);
			wh.sendKeys(cardNumber, CardNumber);

			if (!strCardType.contains("Home Depot")) {
				wh.selectValue(cardExpMonth, strExpiryMonth);
				wh.selectValue(cardExpiryYear, strExpiryYear);
			}

			// cf.clickLink(driver, "xpath", "//a[contains(text(),'Add New
			// Address')]", "Add New Address");
			wh.sendKeys(firstName, strFirstName);
			wh.sendKeys(lastName, strLastName);
			wh.sendKeys(txtAddress1, strAddress);
			wh.sendKeys(txtZip, strZipCode);
			Thread.sleep(commonData.littleWait);
			commonData.Zipcode = strZipCode;

			wh.sendKeys(billingPh1, strBillingPhonenum.substring(0, 3));
			wh.sendKeys(billingPh2, strBillingPhonenum.substring(2, 5));
			wh.sendKeys(billingPh3, strBillingPhonenum.substring(5, 10));

			wh.clickElement(By.xpath("//h3[@class='creditcardHeading']"));

			Thread.sleep(commonData.smallWait);

			wh.clickElement(openPopup);

			Thread.sleep(commonData.mediumWait);
			wh.ignorePopup(driver);

			try {
				wh.clickElement(fancyBoxClose);
			}

			catch (Exception e) {
				report.addReportStep("Verify that Express checkout details confirmation dialog is displayed",
						"Express checkout confirmation fancy box is not displayeds", StepResult.FAIL);
			}
			wh.ignorePopup(driver);

			Thread.sleep(commonData.littleWait);
		} else {
			report.addReportStep("verify that express checkout dialog is displayed",
					"Express checkout dialog is not displayed", StepResult.FAIL);
		}

		Thread.sleep(commonData.smallWait);

	}

	/**
	 * 
	 * Description : Save Another credit card to account
	 * 
	 * @throws Exception
	 *
	 *
	 */
	public void saveAnotherCreditCard() throws Exception {
		Thread.sleep(commonData.littleWait);

		String CardNumber = null;
		String CardType = dataTable.getData("CardType2");
		String strCardType = "";

		if (CardType.toLowerCase().contains("visa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.VISA_card);
			strCardType = "Visa";

		}

		else if (CardType.toLowerCase().contains("master")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.MASTER_card);
			strCardType = "Mastercard";
		}

		else if (CardType.toLowerCase().contains("amex")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.AMEX_card);
			strCardType = "American Express";
		}

		else if (CardType.toLowerCase().contains("discover")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.DISCOVER_card);
			strCardType = "Discover Network";
		}

		else if (CardType.toLowerCase().contains("consumer")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCONSUMER_card);
			strCardType = "Home Depot Consumer Card";
		}

		else if (CardType.toLowerCase().contains("commercial")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCOMMERCIAL_card);
			strCardType = "Home Depot Commercial";
		}

		else if (CardType.toLowerCase().contains("gsa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.GSA_card);
		}

		else if (CardType.isEmpty()) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.CardNumber);
		}

		String strCardHolderName = dataTable.getCommonData(CommonDataColumn.BuyerName);
		String strExpiryMonth = dataTable.getCommonData(CommonDataColumn.SaveExpirationMonth);
		String strExpiryYear = dataTable.getCommonData(CommonDataColumn.ExpirationYear);

		wh.ignorePopup(driver);

		if (wh.isElementPresent(By.xpath("//a[contains(text(),'Manage All Cards')]"), 8)) {
			wh.clickElement(By.xpath("//a[contains(text(),'Manage All Cards')]"));

			report.addReportStep("Click Manage All cards link in My Account page",
					"Manage All cards link is clicked in My Account page", StepResult.PASS);
			Thread.sleep(commonData.smallWait);

		}

		else {
			report.addReportStep("Click Manage All cards link in My Account page",
					"Manage All cards link is not present in My Account page", StepResult.FAIL);

		}

		if (wh.isElementPresent(addCardBtn, 8)) {
			wh.clickElement(addCardBtn);

			report.addReportStep("Click Add a credit card button in My Account page",
					"Add a credit card button is clicked in My Account page", StepResult.PASS);
			Thread.sleep(commonData.smallWait);
		}

		else {
			report.addReportStep("Click Add a credit card button in My Account page",
					"Add a credit card button is not present in My Account page", StepResult.FAIL);

		}

		if (wh.isElementPresent(cardHolderName, 8)) {
			wh.sendKeys(cardHolderName, strCardHolderName);
			wh.selectValue(cardBrand, strCardType);
			wh.sendKeys(cardNumber, CardNumber);

			if (!strCardType.contains("Home Depot")) {
				wh.selectValue(cardExpMonth, strExpiryMonth);
				wh.selectValue(cardExpiryYear, strExpiryYear);
			}

			new Select(driver.findElement(savedAddresses)).selectByIndex(1);

			// cf.clickLink(driver, "xpath", "//a[contains(text(),'Add New
			// Address')]", "Add New Address");

			wh.clickElement(creditCardheading);

			Thread.sleep(commonData.smallWait);

			wh.clickElement(openPopup);

			Thread.sleep(commonData.mediumWait);
			wh.ignorePopup(driver);

			try {
				wh.clickElement(fancyBoxClose);
			}

			catch (Exception e) {
				report.addReportStep("Verify that Express checkout details confirmation dialog is displayed",
						"Express checkout confirmation fancy box is not displayeds", StepResult.FAIL);
			}
			wh.ignorePopup(driver);

			Thread.sleep(commonData.littleWait);
		} else {
			report.addReportStep("verify that express checkout dialog is displayed",
					"Express checkout dialog is not displayed", StepResult.FAIL);
		}

		Thread.sleep(commonData.smallWait);

	}

	/**
	 * Method to click checkout now overlay
	 * 
	 * @return MyAccountPage
	 * @throws Exception
	 */
	public MyAccountPage clickCheckoutNowOverlay() throws Exception {

		if (wh.isElementPresent(checkoutNow, 15)) {
			wh.clickElement(checkoutNow);
			report.addReportStep("Verify Checkout Now is clicked on the overlay", "Checkout Now button is clicked",
					StepResult.PASS);

		} else if (wh.isElementPresent(viewCartTab, 15)) {
			wh.jsClick(viewCartTab);
			report.addReportStep("Verify View cart is clicked in mylist page", "View cart is clicked in mylist page",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify Checkout Now is clicked on the overlay", "Checkout Now button is not clicked",
					StepResult.FAIL);
		}

		wh.waitForLoaderImage();

		return this;

	}

	// for hdpp

	public MyAccountPage verifyProduct() {

		wh.waitForPageLoaded();
		String catentryProd = dataTable.getData(DataColumn.ProductID);
		System.out.println("Value from table is" + catentryProd);
		List<WebElement> eles = driver.findElements(By.cssSelector("#catentryId"));
		System.out.println(eles.size());
		for (int i = 0; i < eles.size(); i++) {
			if (eles.get(i).getText().contains(catentryProd)) {
				break;

			}

		}
		report.addReportStep("Verify product is present on the page", "Product is  present on the page",
				StepResult.PASS);

		return this;
	}

	public MyAccountPage verifyPlan() {

		wh.waitForPageLoaded();
		String catentryProd = dataTable.getData(DataColumn.PlanID);
		System.out.println("Value from table is" + catentryProd);
		List<WebElement> eles = driver.findElements(By.cssSelector("#catentryId"));
		System.out.println(eles.size());
		for (int i = 0; i < eles.size(); i++) {
			if (eles.get(i).getText().contains(catentryProd)) {
				break;

			}

		}
		report.addReportStep("Verify plan is present on the page", "Plan is  present on the page", StepResult.PASS);

		return this;
	}

	public MyAccountPage verifyListCertona() throws Exception {
		Thread.sleep(5000);
		if (wh.isElementPresent(certonaList, 4)) {
			report.addReportStep("Verify <b>Certona</b> section is displayed", "<b>Certona</b> section is displayed",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify <b>Certona</b> section is displayed",
					"<b>Certona</b> section is not displayed", StepResult.FAIL);
		}
		return this;

	}

	public MyAccountPage clickListCertona() throws Exception {
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,2250)", "");
		Thread.sleep(8000);
		if (wh.isElementPresent(certonaAddToCartBtn, 0)) {

			wh.clickElement(certonaAddToCartBtn);

			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is clicked in certona section", StepResult.PASS);

		} else {
			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is not clicked in certona section", StepResult.FAIL);
		}
		Thread.sleep(8000);
		return this;

	}

	public MyAccountPage verifyPlannotadded() throws Exception {

		if (wh.isElementPresent(addPlan_myaccount, 5)) {

			report.addReportStep("Verify Add Plan Option is displayed  in overlay",
					"Add Plan Option is displayed  in overlay", StepResult.FAIL);
		}

		else {
			report.addReportStep("Verify Add Plan Option is  not displayed  in overlay",
					"Add Plan Option is not displayed  in overlay", StepResult.PASS);
		}

		return this;
	}

	public MyAccountPage clickMyAccount() throws Exception {
		if (wh.isElementPresent(MyAccountTitle, 5)) {
			try {
				wh.clickElement(MyAccountTitle);
				Thread.sleep(100);
				wh.clickElement(Accountprofile);
				Thread.sleep(100);
				report.addReportStep("Click the MyAccount in the Page header", "Link clicked", StepResult.PASS);
				if (wh.isElementPresent(MyAccountPageTitle))

				{
					String strTempValue = driver.findElement(MyAccountPageTitle).getText();

					if (strTempValue.toLowerCase().contains("account")) {
						report.addReportStep("Verify that My account page is displayed", "The page is displayed",
								StepResult.PASS);
					} else {
						report.addReportStep("Verify that My account page is displayed",
								"My account page is not displayed", StepResult.FAIL);
					}
				}

			} catch (Exception e) {
				report.addReportStep("Click the MyAccount in the Page header", "Link  not clicked", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Click the MyAccount in the Page header", "Link not Found", StepResult.FAIL);
		}
		return this;
	}

	public void selectAddressBook() throws Exception {
		if (wh.isElementPresent(AddressBookLink)) {
			wh.clickElement(AddressBookLink);
			report.addReportStep("Click on Address book link in the left side navigation",
					"Address book on the left side navigation is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on Address book link in the left side navigation", "Unable to click the link",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	public MyAccountPage clickAddAddressInAddressBook() throws Exception {
		wh.jsClick(AddAddressButton);
		String internationalZipCd = dataTable.getData("International_ZipCode");
		if (wh.isElementPresent(NickName)) {
			report.addReportStep("Verify <b>NickName</b> field is not present in Add Address page",
					"<b>Nick name</b> field is present", StepResult.FAIL);
		} else
			report.addReportStep("Verify <b>NickName</b> field is not present in Add Address page",
					"<b>Nick name</b> field is not present", StepResult.PASS);
		if (wh.isElementPresent(AddAddressFirstName, 2)) {

			wh.sendKeys(AddAddressFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

			wh.sendKeys(AddAddressLastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

			wh.sendKeys(AddAddressAddress1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			if (!internationalZipCd.isEmpty()) {
				wh.sendKeys(Zipcode, internationalZipCd);
			} else {
				wh.sendKeys(Zipcode, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			}

			if (wh.isElementPresent(AddAddressPhoneNum1)) {
				wh.sendKeys(AddAddressPhoneNum1,
						dataTable.getCommonData(CommonDataColumn.ShippingPhNo).substring(0, 3));
				wh.sendKeys(AddAddressPhoneNum2,
						dataTable.getCommonData(CommonDataColumn.ShippingPhNo).substring(2, 5));
				wh.sendKeys(AddAddressPhoneNum3,
						dataTable.getCommonData(CommonDataColumn.ShippingPhNo).substring(5, 9));
			}
		}
		report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);
		wh.jsClick(UpdateAddress);
		;
		Thread.sleep(3000);
		return this;
	}

	public void verifyMyaccountLink() throws Exception {
		wh.jsClick(THDLogo);
		Thread.sleep(1000);
		wh.jsClick(MyAccountTitle);
		// wh.jsClick(OrdersAndPurchasesLink);
		wh.ignorePopup(driver);
		Thread.sleep(1000);

		// This is common for both Tablet and Fullsite
		if (wh.isElementPresent(OrdersAndPurchasesLink, 5)) {
			wh.jsClick(OrdersAndPurchasesLink);
			report.addReportStep("Click on Orders and Purchases link", "clicked Orders and Purchases link ",
					StepResult.PASS);
		} else {
			report.addReportStep("Click on Orders and Purchases link", "Orders and Purchases link not clicked",
					StepResult.FAIL);
		}

		// For Guest user
		if (wh.isElementPresent(trackOrder, 5)) {
			System.out.println(commonData.strEmailGuest);
			System.out.println(commonData.orderNumber);
			wh.sendKeys(txtOrderNo, commonData.orderNumber);
			wh.sendKeys(txtTrackEmail, commonData.strEmailGuest);
			wh.clickElement(trackOrderBtn);
			Thread.sleep(1000);
		}
	}

	/**
	 * Component to verify if order number in confirmation page is same as order
	 * number in information page. Also performs "2 hours" verification.
	 * 
	 * @throws Exception
	 * 
	 **/
	public void verifyOrderNumInOrderDetails() throws Exception {
		Thread.sleep(3000);
		if (verifyOrderNoInOrderDetailsPg().equals(commonData.strOrderId))
			report.addReportStep("Verify whether Order Number in Information and Confirmation page should be equal",
					"Both order number are equal", StepResult.PASS);
		else
			report.addReportStep("Verify whether Order Number in Information and Confirmation page should be equal",
					"Both order number are not equal", StepResult.FAIL);

	}

	/**
	 * 
	 * Description : verify the Order number in Order details page
	 * 
	 * @throws Exception
	 * 
	 */
	public String verifyOrderNoInOrderDetailsPg() throws Exception {
		if (wh.isElementPresent(OrderNumber, 2)) {
			String strOrderNum = driver.findElement(OrderNumber).getText();
			return strOrderNum;
		} else if (wh.isElementPresent(OrderNumInTablet, 2)) {
			String strOrderNum = driver.findElement(OrderNumInTablet).getText().split("#")[1].trim();
			return strOrderNum;
		} else if (wh.isElementPresent(ordno, 2)) {
			String strOrderNum = driver.findElement(ordno).getText().split("# ")[1].trim();
			String strOrderNo = strOrderNum.split(" ")[0].trim();
			return strOrderNo;
		} else {
			return "noOrderNum";
		}

	}

	/*
	 * 
	 * This component is used to click Order Number in Online Orders Page
	 */
	public void clickOrderNumber() throws Exception {
		if (wh.isElementPresent(OrderNumber, 5)) {
			wh.jsClick(OrderNumber);
			report.addReportStep("Click Order Number", "Order Number is clicked", StepResult.PASS);
		} else if (wh.isElementPresent(OrderNumInTablet, 5)) {
			wh.jsClick(OrderNumInTablet);
			report.addReportStep("Click Order Number", "Order Number is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click Order Number", "Order Number is clicked", StepResult.FAIL);
		}

	}

	public void verifyOrderDetaisPageforBopisItem() throws Exception {
		verifyOrderInformationInMyacc();
		verifyItemsForPickup();
		verifyPickupStoreInfo();
		verifyOrderQtyAndDescInMyacc();
	}

	public void verifyOrderInformationInMyacc() throws Exception {
		// Fullsite
		if (wh.isElementPresent(OrderStatus, 2)) {
			String strOrderStatus = driver.findElement(OrderStatus).getText();
			System.out.println(strOrderStatus);
			String strOrderStatusValue = driver.findElement(BeingProcessed).getText();
			System.out.println(strOrderStatusValue);
			String strOrderDate = driver.findElement(OrderDate).getText();
			System.out.println(strOrderDate);
			String strOrderDateValue = driver.findElement(OrderDate).getText().split(":")[1];
			System.out.println(strOrderDateValue);
			if (wh.isElementPresent(BeingProcessed, 5) && wh.isElementPresent(OrderDate, 5)) {
				report.addReportStep("Order Status and Order Date should be displayed",
						"<b>" + strOrderStatus + "" + strOrderStatusValue + "</b> " + "</br>and" + "<b>" + strOrderDate
								+ ":" + strOrderDateValue + "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Order Status and Order Date should be displayed",
						"Order Status and Order Date are not displayed", StepResult.FAIL);
			}
		}
		// Tablet
		else {
			String strOrderStatus = driver.findElement(orderStatusTablet).getText();
			System.out.println(strOrderStatus);
			String strOrderStatusValue = driver.findElement(BeingProcessedtablet).getText();
			System.out.println(strOrderStatusValue);
			String strOrderDate = driver.findElement(OrderDateValuetablet).getText();
			System.out.println(strOrderDate);
			String strOrderDateValue = driver.findElement(OrderDateValuetablet).getText();
			System.out.println(strOrderDateValue);
			if (wh.isElementPresent(OrderDateValuetablet, 3) && wh.isElementPresent(BeingProcessedtablet, 5)) {
				report.addReportStep("Order Status and Order Date should be displayed",
						"<b>" + strOrderStatus + "" + strOrderStatusValue + "</b> " + "</br>and" + "<b>" + strOrderDate
								+ ":" + strOrderDateValue + "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Order Status and Order Date should be displayed",
						"Order Status and Order Date are not displayed", StepResult.FAIL);
			}
		}
	}

	public void verifyItemsForPickup() throws Exception {
		// Fullsite
		if (wh.isElementPresent(PickUpdetailsButton, 5)) {
			if (wh.isElementPresent(PickUpdetailsButton, 5)) {
				wh.jsClick(PickUpdetailsButton);
			}
			String strItemsforPickup = driver.findElement(ItemforPickUp).getText();
			System.out.println(strItemsforPickup);
			String strStoreName = driver.findElement(StoreNameLink).getText();
			System.out.println(strStoreName);
			if (wh.isElementPresent(StoreNameLink, 5) && wh.isElementPresent(ItemforPickUp, 5)) {
				report.addReportStep("'Items for Pickup' and 'Store Name ' should be displayed",
						"<b>" + strItemsforPickup + "</b>" + "</br> and<b>" + strStoreName + "</b>are dispalyed",
						StepResult.PASS);
			} else {
				report.addReportStep("'Items for Pickup' and 'Store Name ' should be displayed",
						"'Items for Pickup' and 'Store Name' are not displayed", StepResult.FAIL);
			}
		}
		// Tablet
		else {
			if (wh.isElementPresent(StoreDetailsIntablet, 2)) {
				String strItemsforPickup = driver.findElement(FullfillmentTypetablet).getText();
				System.out.println(strItemsforPickup);
				if (wh.isElementPresent(FullfillmentTypetablet, 5)) {
					report.addReportStep("'Items for Pickup' and 'Store Name ' should be displayed",
							"<b>" + strItemsforPickup + "</b>" + "</br>" + "</b>are dispalyed", StepResult.PASS);
				}
			} else {
				report.addReportStep("'Items for Pickup' and 'Store Name ' should be displayed",
						"'Items for Pickup' and 'Store Name' are not displayed", StepResult.FAIL);
			}

		}
	}

	public void verifyPickupStoreInfo() throws Exception {
		// Fullsite
		if (wh.isElementPresent(statusOrtracking, 3)) {
			String strStepResult = driver.findElement(statusOrtracking).getText();
			System.out.println(strStepResult);
			String strStepResultValue = driver.findElement(TrackingStatus).getText();
			System.out.println(strStepResultValue);
			String strPickUpPerson = driver.findElement(PickupPerson).getText();
			System.out.println(strPickUpPerson);
			String strPickUpPersonValue = driver.findElement(PickUpPersonValue).getText();
			System.out.println(strPickUpPersonValue);
			String strStoreDetails = driver.findElement(StoreDetails).getText();
			System.out.println(strStoreDetails);
			String strStoreDetailsValue = driver.findElement(StoreDetailsValue).getText();
			System.out.println(strStoreDetailsValue);
			String strDesignatedPickupDateTime = driver.findElement(DesignatedPickupDateTime).getText();
			System.out.println(strDesignatedPickupDateTime);
			String strDesignatedPickupDateTimeValue = driver.findElement(DesignatedPickupDateTimeValue).getText();
			System.out.println(strDesignatedPickupDateTimeValue);
			if (strStepResult.contains("Status / Tracking") && strPickUpPerson.contains("Pick Up Person")
					&& strStoreDetails.contains("Store Details")
					&& strDesignatedPickupDateTime.contains("Designated Pickup Date/Time")) {
				report.addReportStep(
						"Status,Pick Up Person,Store Details,Designated Pickup Date/Time should be displayed",
						"<b>" + strStepResult + " : " + strStepResultValue + "<br />" + strPickUpPerson + " : "
								+ strPickUpPersonValue + "<br />" + strStoreDetails + " : " + strStoreDetailsValue
								+ "<br />" + strDesignatedPickupDateTime + " : " + strDesignatedPickupDateTimeValue
								+ "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"Status,Pick Up Person,Store Details,Designated Pickup Date/Time should be displayed",
						"Status,Pick Up Person,Store Details,Designated Pickup Date/Time are not displayed",
						StepResult.FAIL);
			}
		}
		// tablet
		else {
			String strStatus = driver.findElement(orderStatusTablet).getText();
			System.out.println(strStatus);
			String strStatusValue = driver.findElement(BeingProcessedtablet).getText();
			System.out.println(strStatusValue);
			String strPickUpPerson = driver.findElement(PickUpPersontablet).getText();
			System.out.println(strPickUpPerson);
			String strPickUpPersonValue = driver.findElement(PickUpPersontablet).getText();
			System.out.println(strPickUpPersonValue);
			String strStoreDetails = driver.findElement(storenameIntablet).getText();
			System.out.println(strStoreDetails);
			String strStoreDetailsValue = driver.findElement(storenameIntablet).getText();
			System.out.println(strStoreDetailsValue);
			if (strStatus.contains("Being Processed") && strPickUpPerson.contains("Pick Up Person")
					&& strStoreDetails.contains("#")) {
				report.addReportStep(
						"Status,Pick Up Person,Store Details,Designated Pickup Date/Time should be displayed",
						"<b>" + strStatus + " : " + strStatusValue + "<br />" + strPickUpPerson + " : "
								+ strPickUpPersonValue + "<br />" + strStoreDetails + " : " + strStoreDetailsValue
								+ "<br />" + "</b> are displayed",
						StepResult.PASS);

			} else {
				report.addReportStep(
						"Status,Pick Up Person,Store Details,Designated Pickup Date/Time should be displayed",
						"Status,Pick Up Person,Store Details,Designated Pickup Date/Time are not displayed",
						StepResult.FAIL);

			}
		}
	}

	public void verifyOrderQtyAndDescInMyacc() throws Exception {
		// Fullsite
		if (wh.isElementPresent(ProductImage, 5)) {
			String strProductImg = driver.findElement(ProductImage).getAttribute("src");
			System.out.println(strProductImg);
			boolean blnProductImg = wh.isElementPresent(ProductImage, 5);
			System.out.println(strProductImg);
			String strDescription = driver.findElement(Description).getText();
			System.out.println(strDescription);
			String strDescriptionValue = driver.findElement(DescriptionValue).getText();
			System.out.println(strDescriptionValue);
			String strQtyOrdered = driver.findElement(QtyOrdered).getText();
			System.out.println(strQtyOrdered);
			String strQtyOrderedValue = driver.findElement(QtyOrderedValue).getText();
			System.out.println(strQtyOrderedValue);
			String strQtyPickedUp = driver.findElement(QtyPickedUp).getText();
			System.out.println(strQtyPickedUp);
			String strQtyPickedUpValue = driver.findElement(QtyPickedUpValue).getText();
			System.out.println(strQtyPickedUpValue);
			String strTotal = driver.findElement(Total).getText();
			System.out.println(strTotal);
			String strTotalValue = driver.findElement(TotalValue).getText();
			System.out.println(strTotalValue);
			if (strDescription.contains("Product Description") && strQtyOrdered.contains("Qty")
					&& strQtyPickedUp.contains("Recv") && strTotal.contains("Item Total")) {
				report.addReportStep(
						"Product image,Description,Qty Ordered,Qty Picked Up,Qty Fulfilled and Total should be displayed",
						"<b>" + "Product Image" + " : <img src=" + strProductImg + " width=" + 100 + " height=" + 100
								+ "><br />" + strDescription + " : " + strDescriptionValue + "<br /> " + strQtyOrdered
								+ " : " + strQtyOrderedValue + "<br /> " + strQtyPickedUp + " : " + strQtyPickedUpValue
								+ "<br />" + "<br />" + strTotal + " : " + strTotalValue + "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"Product image,Description,Qty Ordered,Qty Picked Up,Qty Fulfilled and Total should be displayed",
						"Product image,Description,Qty Ordered,Qty Picked Up,Qty Fulfilled and Total are not displayed",
						StepResult.FAIL);
			}
		}
		// Tablet
		else {
			String strProductImg = driver.findElement(ProductImageTablet).getAttribute("src");
			System.out.println(strProductImg);
			boolean blnProductImg = wh.isElementPresent(ProductImageTablet, 5);
			System.out.println(strProductImg);
			String strDescription = driver.findElement(ProductDescTablet).getText();
			System.out.println(strDescription);
			String strDescriptionValue = driver.findElement(ProductDescTablet).getText();
			System.out.println(strDescriptionValue);
			String strQtyOrdered = driver.findElement(qtyOrderedTablet).getText();
			System.out.println(strQtyOrdered);
			String strQtyOrderedValue = driver.findElement(qtyOrederdtabletvalue).getText();
			System.out.println(strQtyOrderedValue);
			String strQtyPickedUp = driver.findElement(qtyOrderedTablet).getText();
			System.out.println(strQtyPickedUp);
			String strQtyPickedUpValue = driver.findElement(qtyOrederdtabletvalue).getText();
			System.out.println(strQtyPickedUpValue);
			String strTotal = driver.findElement(ItemTotaltablet).getText();
			System.out.println(strTotal);
			String strTotalValue = driver.findElement(TotalValueTablet).getText();
			System.out.println(strTotalValue);
			if (strDescription.contains("Description") && strQtyOrdered.contains("Qty")
					&& strQtyPickedUp.contains("Qty") && strTotal.contains("Item Total")) {

				report.addReportStep(
						"Product image,Description,Qty Ordered,Qty Picked Up,Qty Fulfilled and Total should be displayed",
						"<b>" + "Product Image" + " : <img src=" + strProductImg + " width=" + 100 + " height=" + 100
								+ "><br />" + strDescription + " : " + strDescriptionValue + "<br /> " + strQtyOrdered
								+ " : " + strQtyOrderedValue + "<br /> " + strQtyPickedUp + " : " + strQtyPickedUpValue
								+ "<br />" + "<br />" + strTotal + " : " + strTotalValue + "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"Product image,Description,Qty Ordered,Qty Picked Up,Qty Fulfilled and Total should be displayed",
						"Product image,Description,Qty Ordered,Qty Picked Up,Qty Fulfilled and Total are not displayed",
						StepResult.FAIL);
			}
		}
	}

	/**
	 * 
	 * Description : verify the credit card saved from payment page
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyCCSavedFromPaymentPage() throws Exception {
		if (wh.isElementPresent(MyAccountPageTitle)) {
			String strTempValue = driver.findElement(MyAccountPageTitle).getText();

			if (strTempValue.toLowerCase().contains("account")) {
				report.addReportStep("Verify that My account page is displayed",
						"Full Site My Account page is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that My account page is displayed", "My account page is not displayed",
						StepResult.FAIL);
			}
			wh.clickElement(lnkSavedCard);
			Thread.sleep(1000);
			if (wh.isElementPresent(savedcard)) {
				String strcard = wh.getText(cardSection);
				System.out.println(strcard);
				if (strcard.contains("Visa")) {
					report.addReportStep("verify credit card saved", "credit card " + strcard + "is saved",
							StepResult.PASS);
				} else {
					report.addReportStep("verify credit card saved", "credit card is not saved", StepResult.FAIL);
				}
			}
		} else {
			report.addReportStep("verify My Account page", "My Account page is not displayed", StepResult.FAIL);
		}
	}

	public void verifyApplianceOrderInfoInMyacc() throws Exception {
		// Fullsite
		if (wh.isElementPresent(OrderStatus, 2)) {
			String strOrderStatus = driver.findElement(OrderStatus).getText();
			System.out.println(strOrderStatus);
			String strOrderStatusValue = driver.findElement(orderstatusAppliance).getText();
			System.out.println(strOrderStatusValue);
			String strOrderDate = driver.findElement(OrderDate).getText();
			System.out.println(strOrderDate);
			String strOrderDateValue = driver.findElement(OrderDate).getText().split(":")[1];
			System.out.println(strOrderDateValue);
			if (wh.isElementPresent(orderstatusAppliance, 5) && wh.isElementPresent(OrderDate, 5)) {
				report.addReportStep("Order Status and Order Date should be displayed",
						"<b>" + strOrderStatus + "" + strOrderStatusValue + "</b> " + "</br>and" + "<b>" + strOrderDate
								+ ":" + strOrderDateValue + "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Order Status and Order Date should be displayed",
						"Order Status and Order Date are not displayed", StepResult.FAIL);
			}
		}
		// Tablet
		else {
			String strOrderStatus = driver.findElement(orderStatusTablet).getText();
			System.out.println(strOrderStatus);
			String strOrderStatusValue = driver.findElement(BeingProcessedtablet).getText();
			System.out.println(strOrderStatusValue);
			String strOrderDate = driver.findElement(OrderDateValuetablet).getText();
			System.out.println(strOrderDate);
			String strOrderDateValue = driver.findElement(OrderDateValuetablet).getText();
			System.out.println(strOrderDateValue);
			if (wh.isElementPresent(OrderDateValuetablet, 3) && wh.isElementPresent(BeingProcessedtablet, 5)) {
				report.addReportStep("Order Status and Order Date should be displayed",
						"<b>" + strOrderStatus + "" + strOrderStatusValue + "</b> " + "</br>and" + "<b>" + strOrderDate
								+ ":" + strOrderDateValue + "</b> are displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Order Status and Order Date should be displayed",
						"Order Status and Order Date are not displayed", StepResult.FAIL);
			}
		}
	}

	/**
	 * Component to verify international address not saved
	 * 
	 * @since Mar 11,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyInternatioanlAddressNotSaved() throws Exception {
		if (wh.isElementPresent(addrErr)) {
			String strErr = wh.getText(addrErr);
			report.addReportStep("Verify international address not saved error message",
					"Error message <n> " + strErr + " </b> is displayed", StepResult.PASS);

		} else {
			report.addReportStep("Verify international address not saved error message",
					"Error message is not displayed", StepResult.FAIL);

		}

	}

	// ////***********Instant Rebate***********/////

	public MyAccountPage addaddresstoaddressbook() throws Exception {

		String zipcode1 = dataTable.getData(DataColumn.ZipCode);
		commonData.IRzipcodeList.add(zipcode1);
		String zipcode2 = dataTable.getData(DataColumn.ChangeZipCode);
		commonData.IRzipcodeList.add(zipcode2);
		for (int i = 0; i < 2; i++) {
			String ziptoadd = commonData.IRzipcodeList.get(i);
			wh.jsClick(AddAddressButton);
			if (wh.isElementPresent(NickName)) {
				report.addReportStep("Verify <b>NickName</b> field is not present in Add Address page",
						"<b>Nick name</b> field is present", StepResult.FAIL);
			} else
				report.addReportStep("Verify <b>NickName</b> field is not present in Add Address page",
						"<b>Nick name</b> field is not present", StepResult.PASS);
			if (wh.isElementPresent(AddAddressFirstName, 2)) {

				wh.sendKeys(AddAddressFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));

				wh.sendKeys(AddAddressLastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));

				wh.sendKeys(AddAddressAddress1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));

				wh.sendKeys(Zipcode, ziptoadd);

				if (wh.isElementPresent(AddAddressPhoneNum1)) {
					wh.sendKeys(AddAddressPhoneNum1,
							dataTable.getCommonData(CommonDataColumn.ShippingPhNo).substring(0, 3));
					wh.sendKeys(AddAddressPhoneNum2,
							dataTable.getCommonData(CommonDataColumn.ShippingPhNo).substring(2, 5));
					wh.sendKeys(AddAddressPhoneNum3,
							dataTable.getCommonData(CommonDataColumn.ShippingPhNo).substring(5, 9));
				}
			}
			report.addReportStep("Enter Shipping Details", "Shipping Details entered", StepResult.PASS);
			wh.jsClick(UpdateAddress);
			Thread.sleep(3000);
		}
		return this;
	}

	// //******End of Instant Rebate************////

	/**
	 * Method to Remove tax exempt id
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage verifyRemoveTaxExempt() throws Exception {

		wh.clickElement(RemovetaxExempt);
		report.addReportStep("Click on Remove tax exempt id link", "Remove Tax exempt id link is clicked",
				StepResult.PASS);

		wh.clickElement(RemovetaxExemptOverlay);
		wh.jsClick(RemovetaxExemptOverlay);

		report.addReportStep("Click on Yes,Remove btn", "Yes,Remove Btn is clicked", StepResult.PASS);

		wh.clickElement(closeExemptSaveOverlay);

		report.addReportStep("Remove tax exempt id", "Tax exempt id is removed", StepResult.PASS);

		return this;
	}

	/**
	 * 
	 * Description : click veri sign link in my account page
	 * 
	 * @author RXP8655
	 */
	public void clickVeriSignLInkInMyacc() {
		wh.ignorePopup(driver);
		try {

			wh.clickElement(nortonlogo);
			report.addReportStep("Click VeriSign Link", "VeriSign FAQs page is displayed", StepResult.PASS);
		} catch (Exception e) {
			report.addReportStep("Click VeriSign Link", "VeriSign FAQs page is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * To verify Norton page in Account page
	 * 
	 * @throws Exception
	 * 
	 * @FunctionName verifyVeriSignPage
	 * @InputParameters None
	 * @Author Cognizant
	 * @DateCreated Jul 25, 2012
	 */
	public void verifyVeriSignPage() throws Exception {
		wh.ignorePopup(driver);
		boolean strSauceModeOn = HelperClass.baseModel.runOnSauceLabs;
		// String strSauceModeOn = properties.getProperty("SauceLabMode");
		boolean blnIsWindowSwitchSuccess = false;

		if (!strSauceModeOn) { // off
			final String thisWindow = driver.getWindowHandle();

			try {
				String newWindow = new WebDriverWait(driver, 20).until(new ExpectedCondition<String>() {
					public String apply(WebDriver d) {
						Set<String> handles = d.getWindowHandles();
						handles.remove(thisWindow);
						return handles.size() > 0 ? handles.iterator().next() : null;
					}
				});

				driver.switchTo().window(newWindow);
				verifyFAQPage();

				driver.close();
				driver.switchTo().window(thisWindow);

				verifyVeriSignSeal();

			} catch (Exception e) {
				openVeriSignInAlterWay();
			}

		} else {
			openVeriSignInAlterWay();
		}

		if (strSauceModeOn) {
			verifyFAQPage();
			verifyVeriSignSeal();
		}
	}

	/**
	 * 
	 * Description : verify the FAQ Page
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifyFAQPage() throws Exception {

		if (wh.isElementPresent(verisignSiteName) || wh.isElementPresent(verisignsealmisuse)) {

			report.addReportStep(
					"In My Accout Page on the left side of Footer section Click and validate 'VeriSign' Trusted Seal",
					"It is navigated to Verisign FAQs Page", StepResult.PASS);
		} else {
			report.addReportStep(
					"In My Accout Page on the left side of Footer section Click and validate 'VeriSign' Trusted Seal",
					"It is not navigated to Verisign FAQs Page", StepResult.FAIL);
		}

	}

	/**
	 * Description : verify veri sign seal
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifyVeriSignSeal() throws Exception {

		if (wh.isElementPresent(verisignSeal)) {
			report.addReportStep(
					"VeriSign Trusted Seal should not be displayed under the header section on My Account Page",
					"Validate on My Account page the VeriSign Trusted seal is present below the header section",
					StepResult.FAIL);
		} else {
			report.addReportStep(
					"VeriSign Trusted Seal should not be displayed under the header section on My Account Page",
					"Validate on My Account page the VeriSign Trusted seal is not present below the header section",
					StepResult.PASS);
		}
	}

	/**
	 * Component to verify the veriSign page by opening it using href link
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void openVeriSignInAlterWay() throws Exception {

		if (wh.isElementPresent(nortonlogo)) {
			try {
				String strVerisignLink = wh.getAttribute(nortonlogo, "href");
				driver.get(strVerisignLink);

			} catch (Exception e) {

			}
		} else {

		}

	}

	/**
	 * Method to save Invalid 4 digit tax excempt id
	 * 
	 * @return
	 * @throws Exception
	 */

	public MyAccountPage fourdigitInvalidsaveTaxExcemptId() throws Exception {

		String taxId = dataTable.getCommonData(CommonDataColumn.fourDigitInvalidTaxExmptId);

		if (wh.isElementPresent(taxExcempt, 5)) {
			wh.clickElement(taxExcempt);

			wh.sendKeys(taxExcemptTxt, taxId);
			wh.clickElement(saveBtn);

			if (wh.isElementPresent(taxExcemptSaveOverlay, 5)) {
				wh.clickElement(taxExcemptSaveOverlay);
			}
			report.addReportStep("Enter tax excempt id and save the details",
					"Tax excempt id is entered and details are saved", StepResult.PASS);
		} else {

			report.addReportStep("Enter tax excempt id and save the details",
					"Tax excempt id is not entered and details are not saved", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * verifyInvalidTaxExemptIdLengthRU
	 * 
	 * @return
	 * @throws Exception
	 */
	public MyAccountPage verifyInvalidTaxExemptIdLengthRU() throws Exception {

		if (wh.isElementPresent(InvalidTaxExemptErrormsg)) {
			String TXE = driver.findElement(InvalidTaxExemptErrormsg).getText();
			if (TXE.contains("Home Depot Tax Exempt ID")) {
				report.addReportStep("Verify the error displayed", "Error message - " + TXE + " is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify the error displayed",
						"Error message - " + TXE + " is not displayed properly", StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify TaxExempt field element is present", "TaxExempt field element is not present ",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * 
	 * Description : click the online order in my account page
	 * 
	 * @throws Exception
	 * 
	 */
	public void clickOnlineOrdersInMyAccPg() throws Exception {
		if (wh.isElementPresent(OnlineOrder, 2)) {
			wh.jsClick(OnlineOrder);
			report.addReportStep("Verlify Online Orders ", "Online Orders Link is clicked", StepResult.PASS);
		} else {
			report.addReportStep("Verlify Online Orders ", "Online Orders Link is not clicked", StepResult.FAIL);
		}
	}

	/**
	 * 
	 * Description : verify store order history in my account page
	 * 
	 */

	public void verifyInStoreOrderHistory() {
		List<WebElement> lstColumns = driver.findElements(By.xpath("//tr[@class='tablesorter-headerRow']/th"));
		int count = 0;
		for (WebElement eachColumn : lstColumns) {
			String strColName = eachColumn.getText();
			if (strColName.equals("Order Date") || strColName.equals("Order Number")

					|| strColName.equals("Order StepResult") || strColName.equals("Order Total")
					|| strColName.equals("PO/Job Code"))
				count++;

		}
		if (count == 4)
			report.addReportStep("Verify the columns displayed in store-to-Store Orders page",
					"Page is displaying the following column names 1.Order Date \r\n" + "2.Order Number\r\n"
							+ "3.Order StepResult\r\n" + "4.Order Total\r\n" + "5.PO/Job Code\"\r\n",
					StepResult.PASS);
		else
			report.addReportStep("Verify the columns displayed in store-to-Store Orders page",
					"Page is not displaying the following column names 1.Order Date \r\n" + "2.Order Number\r\n"
							+ "3.Order StepResult\r\n" + "4.Order Total\r\n" + "5.PO/Job Code\"\r\n",
					StepResult.FAIL);
	}

	/**
	 * MLTC3017 and MLTC3019 Component to verify guest user order ID is not
	 * listed in register user profile
	 * 
	 * 
	 * @throws Exception
	 * 
	 **/
	public MyAccountPage verifyGuestUserOrderNumberInMyAcctPg() throws Exception {
		Thread.sleep(3000);
		String guestUserOrderId = commonData.orderNumber;
		System.out.println("Order no in thank you page" + guestUserOrderId);
		if (!verifyOrderNoInOrderDetailsPg().equals(guestUserOrderId))
			// System.out.println("first Order no in my account
			// page"+strOrderNum);
			report.addReportStep(
					"Verify if guest user address' W" + guestUserOrderId + "' is not listed in register user profile",
					"Guest user address is not listed in register user profile W" + guestUserOrderId, StepResult.PASS);
		else
			report.addReportStep(
					"Verify if guest user address'" + guestUserOrderId + "' is not listed in register user profile",
					"Guest user address is listed in register user profile" + guestUserOrderId, StepResult.FAIL);
		return this;
	}

	/**
	 * MLTC-3017 and MLTC-3019 Component to verify guest user shipping address
	 * is not listed in register user profile
	 * 
	 * 
	 * @throws Exception
	 * 
	 **/
	public MyAccountPage verifyGuestUserAddressInMyAcctPg() throws Exception {
		wh.waitForPageLoaded();
		String gUserShipAddr = commonData.guestUserNameAndShipAddressStored;
		System.out.println(gUserShipAddr);
		int j = 0;
		WebElement htmltable = driver.findElement(MyActtableBody);
		List<WebElement> rows = htmltable.findElements(By.tagName("tr"));
		System.out.println("Number of rows:" + rows.size());
		for (int rnum = 1; rnum < rows.size(); rnum++) {
			// System.out.println(rows.get(rnum).getText());
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			System.out.println("Number of columns:" + columns.size());
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				String myActAddr = columns.get(cnum).getText();
				if (gUserShipAddr.contains(myActAddr)) {
					j++;
				}

			}
		}
		if (j > 0)
			report.addReportStep(
					"Verify if guest user address'" + gUserShipAddr + "' is not listed in register user profile",
					"Guest user address is listed in register user profile", StepResult.FAIL);
		else
			report.addReportStep(
					"Verify if guest user address'" + gUserShipAddr + "' is not listed in register user profile",
					"Guest user address is not listed in register user profile", StepResult.PASS);

		return this;

	}
}
