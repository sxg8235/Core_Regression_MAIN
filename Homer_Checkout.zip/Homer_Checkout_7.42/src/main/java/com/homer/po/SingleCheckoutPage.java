package com.homer.po;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class SingleCheckoutPage extends PageBase<SingleCheckoutPage> {

	static final By guestWelcomeText = By.id("slider_panel_-2_summary");
	static final By verifySigninSection = By.id("slider_panel_-2_wrapper");

	/* PICK UP OPTION SECTION AND SUMMARY */

	static final By pickupOptionSection = By.xpath("//div[@class='radio-btns-wrapper  pickupLocationOptions']");
	static final By pickupOptionSummary = By.id("pickup-options-summary");
	static final By pickupContinueBtn = By
			.xpath("(//a[@class='button button--primary button--shortleft sliderNextButton'])[1]");
	static final By pickupEditlink = By
			.xpath("//span[@class ='p-all-small right text-primary ac-label edit-panel slider_panel_0_edit pointer']");

	static final By chooseProDesk = By.xpath("//label[@for='item_pickup_locations_2']");
	// static final By
	// chooseProDesk=By.xpath("//input[@id='item_pickup_locations_2']");
	static final By editChooseAnotherPerson = By.xpath("//a[@class='text-primary edit-pickup-person']");
	static final By pickSectionLocation = By.xpath("//h4[@class='bold]");
	static final By pickSummaryLocation = By.xpath("//div[@class='summary-address-wrapper']/h4");
	static final By pickupPersondetails = By.xpath("//div[@class=pickupPersonDetails']");
	static final By pickupOptionModifyLink = By
			.xpath("//span[@class='right text-primary m-right-small pointer modify']");
	static final By errorMessage = By.xpath("//span[@class='checkout-error-message']");

	static final By PickUpTime = By.xpath("//select[contains(@id,'pickup-times')]");
	static final By savePickupTime = By.id("pickupTimingsChange");
	static final By PickUptimedetails = By.xpath("//div[@class='pickupDateTime']");
	static final By choosenDate = By.xpath("//h3[@class='pickup-date']");
	static final By choosentime = By.xpath("//h3[@class='m-bottom-normal pickup-time']");
	static final By pickupdateOverlay = By.id("change-pickup-time-slot");
	static final By PickUpDate = By.xpath("//select[contains(@id,'pickup-dates')]");
	static final By editChoosePickUpTime = By.xpath("//a[@class='text-primary edit-date-time']");

	/* PAYMENT SECTION AND SUMMARY */

	static final By paymentSection = By
			.xpath("//div[@class='col-12-12-xs col-12-12-sm col-12-12-md col-12-12-lg p-top-normal payment-pane']");
	static final By paymentContinueBtn = By
			.xpath("(//a[@class='button button--primary button--shortleft sliderNextButton'])[2]");

	static final By cardNumber = By.id("newCardNumber");
	static final By nameOnCard = By.id("cardHolderName");
	static final By buyerNameSavedCard = By.cssSelector("div.buyer-name > input#savedCardName");
	static final By buyerNameNewCard = By.cssSelector("div.buyer-name > input#cardHolderName");
	static final By expirationMonth = By.id("expiration-month");
	static final By expirationYear = By.id("expiration-year");
	static final By cardSecurityID = By.id("cvv");
	static final By poJobCode = By.id("POJobCode");
	static final By firstName = By.xpath("(//input[@name='firstName'])[1]");
	static final By lastName = By.xpath("(//input[@name='lastName'])[1]");
	static final By address1 = By.xpath("(//input[@name='address1'])[1]");
	static final By zipCode = By.xpath("(//input[@name='zipcode'])[1]");
	static final By phoneNumber = By.xpath("(//input[@name='phone'])[2]");
	static final By emailAddress = By.id("payment_email");

	static final By chooseInstore = By.xpath("//h3[contains(text(),'Choose In-Store Pickup Location')]");
	static final By deskTxt = By.xpath("//div[@class='clear radio-btns-wrapper left']");
	static final By pickupPersonOverlay = By.id("pickup-another-person");
	static final By WhoFirstName = By.xpath("//input[@id='pickup-first-name']");
	static final By WhoLasttName = By.xpath("//input[@id='pickup-last-name']");
	static final By WhoEmail = By.xpath("//input[@id='pickup-email']");
	static final By MobileNum = By.xpath("//input[@id='pickup-phone-no']");
	static final By savechangePerson = By.xpath("//a[@id='pickupPersonChange']");
	static final By chooseAnotherPerson = By.xpath("//h4[contains(text(),'Choose another person')]");
	static final By MobilePh = By.id("pickup-mobile-phone");
	static final By img = By.xpath("//div[@class='m-top-medium product-item']/img");
	static final By saveTripHeadin = By.xpath("//*[@class='md-content']//h3[contains(text(),'Single Store')]");
	static final By firstStoreInSaveTrip = By
			.xpath("//*[@class='md-content']//*[@class='radio-set m-bottom-normal'][1]");
	static final By updateStoreSelection = By.xpath("//*[contains(text(),'UPDATE STORE SELECTION')]");
	static final By storeSection = By.xpath("//*[@class='pickup-options-layout overflowHidden']");
	private Object element;
	boolean isMulti;

	static final By errorMsg = By.className("checkout-error-message");
	static final By btnGoToPaypal = By.xpath("(//a[contains(.,'GO TO PAYPAL')])[2]");
	static final By rdoPaypal = By.className("paymentPaypalLogo");
	static final By savedAddr = By.xpath("(//div[@class='address-module m-bottom-normal'])[2]");
	static final By cartBreadCrumb = By.xpath("//div[@class='pod-progress-bar']//span[contains(text(),'CART')]");
	static final By regPwd = By.xpath("(//input[@id='newPasswordField'])[2]");
	static final By regConfirmPwd = By.xpath("(//input[@id='confirm-password-field'])[2]");
	static final By estimatedSalesTaxlabel = By.xpath("//span[contains(text(),'Estimated Sales Tax :')]");
	static final By estimatedSalesTax = By.xpath("*//h4[@id='sales-tax']");
	static final By cvvError = By.xpath("//div[@for='cvv']");
	static final By savedTaxExempt = By.id("taxExemptNo");
	static final By salesTax = By.id("sales-tax");
	static final By loadingIcon = By.cssSelector("div.containerLoading.loader-image");
	static final By btnBack = By.xpath("(//*[@id='slider_panel_1']//a[text()='Back'])[1]");
	static final By shippingChargeRightRail = By.id("shippingCharge");
	static final By subTot = By.xpath("//h3[contains(text(),'Subtotal')]/../h3[2]");
	static final By rightRail = By.xpath("//div[@class='checkout-summary clear']");
	// static final By
	// rightRail=By.xpath("/*[@id='checkout']/div[5]/section/div[3]/div/order-summary/div/div");
	// static final By savedCard = By.id("savedCards");
	static final By savedCard = By.id("savedCards");
	static final By savedCardCvv = By.id("savedCardCVV");
	static final By cvvCleared = By.cssSelector("input.more-info.saved-card-cvv.pymt-fld-hghlgt");
	static final By savedCreditCardRadioGrp = By.cssSelector("div.credit-cards-saved > div.radio-set.m-bottom-normal");
	static final By newCardRadioGrp = By.cssSelector("div.newCard-cntr.m-top-normal > div.radio-set.m-bottom-normal");
	static final By payPalRadio = By.cssSelector("div.radio-set.m-bottom-normal > label.tab11.paypal-label");
	static final By savedCardDropDown = By.cssSelector("div.select-card.select-expiredate");
	static final By gcSection = By.cssSelector("div.payment-gc-sec");
	static final By billingSection = By.xpath("//h4[contains(text(),'Billing Address')]");
	static final By newCardSection = By.cssSelector("div.newCard-cntr.m-top-normal");
	static final By expirationMonthYear = By.cssSelector("div.newcards-expiredate.select-expiredate");
	static final By newCardRadio = By.xpath("//label[contains(text(),'New Card')]");
	static final By creditCardRadio = By.xpath("//h4[contains(text(),'Credit card')]");
	static final By totalRightRail = By.xpath("//h3[contains(text(),'Total')]/span");
	static final By EditLinkInPayment = By.xpath("//*[contains(text(),'Modify')]");
	static final By orderSummary = By.xpath("//div[@class='display-table fullWidth layout-fixed']/div/h3[2]");
	static final By orderSummaryExtras = By.xpath("//div[@class='display-table fullWidth layout-fixed']/div/h4[2]");

	static final By paymentSummarySection = By.xpath("//*[@id='slider_panel_1_summary']");
	static final By billingandContactSection = By.id("slider_panel_2_wrapper");
	static final By billingContinueBtn = By
			.xpath("(//a[@class='button button--primary button--shortleft sliderNextButton'])[3]");
	static final By billingSummarySection = By.xpath("//div[@id='slider_panel_2_summary']");
	static final By submitOrdBtn = By
			.xpath("(//a[@class='button button--primary button--shortleft sliderNextButton'])[4]");
	static final By paymentEditLink = By
			.xpath("//span[@class='p-all-small right text-primary ac-label edit-panel slider_panel_1_edit pointer']");
	static final By billingEditlink = By.xpath("//span[@index='2']");
	static final By paymentSummaryCardNumber = By.xpath("//h3[@class='summary-card-type bold m-left-small']");

	// CARD IMAGES

	static final By visaCardImage = By.xpath("//i[@class='summary-card-type-img icon-payment-visa']");
	static final By mcCardImage = By.xpath("//i[@class='summary-card-type-img icon-payment-mastercard']");
	static final By amexCardImage = By.xpath("//i[@class='summary-card-type-img icon-payment-amex']");
	static final By discCardImage = By.xpath("//i[@class='summary-card-type-img icon-payment-discover']");
	static final By hdcomCardImage = By.xpath("//i[@class='summary-card-type-img icon-payment-hdcom']");
	static final By hdconCardImage = By.xpath("//i[@class='summary-card-type-img icon-payment-hdcon']");

	public SingleCheckoutPage(InstanceContainer ic) {
		super(ic);

	}

	public void addOPCParameter() throws Exception {
		if (commonData.desktopUserAgent) {

			wh.waitForPageLoaded();
			wh.waitForPageLoaded();

			String currentURL = driver.getCurrentUrl();

			if (currentURL.contains("mcc=true") || currentURL.contains("MCCCheckout")) {

				if (currentURL.contains("?")) {
					driver.get(currentURL + "&qa=singletest1");
				} else {
					driver.get(currentURL + "?qa=singletest1");
				}

				wh.waitForPageLoaded();
				wh.waitForPageLoaded();

				report.addReportStep("Enter OnePageCheckout  parameter in Cart url",
						"OnePageCheckout  Parameter is entered in Cart url", StepResult.DONE);

				Thread.sleep(commonData.LongWait);

				Set<?> cookies = driver.manage().getCookies();
				Iterator<?> iter = cookies.iterator();
				while (iter.hasNext()) {
					Cookie cookie = (Cookie) iter.next();
					String strCookieName = cookie.toString();

					if (strCookieName.contains("ONEPAGE_CHECKOUT_ON")) {

						strCookieName = strCookieName.substring(0, strCookieName.indexOf("="));

						report.addReportStep("Check OnePage Checkout Cookie is added</b>",
								"Cookie <b>" + strCookieName + "</b> is added", StepResult.DONE);
					}

				}

			}
		}

	}

	/************** SIGN IN SECTION ************************/

	public void verifySigninSection() throws Exception {

		if (wh.isElementPresent(verifySigninSection, 15)) {

			report.addReportStep("Verify Signin Section in Single Checkout page",
					"Sign in Section is displayed in Single checkout page", StepResult.PASS);
		}

		else {

			report.addReportStep("Verify Signin Section in Single Checkout page",
					"Sign in Section is not displayed in Single checkout page", StepResult.FAIL);
			rc.terminateTestCase("Secure Signin Page");
		}

		if (wh.isElementPresent(guestWelcomeText, 15)) {
			String welcomeText = driver.findElement(guestWelcomeText).getText();

			if (welcomeText.contains("guest")) {

				report.addReportStep("Verify Welcome message in the Sign in section",
						"<b>Verified Welcome message for Guest user sign in  as </b> " + welcomeText, StepResult.PASS);

			}

			else {
				report.addReportStep("Verify Welcome message in the Sign in section",
						"<b>Verified Welcome message for Registered user as</b>  " + welcomeText, StepResult.FAIL);
			}

		}
	}

	/************** PICKUP OPTION SECTION ************************/

	public void verifyPickupOptionSection() throws Exception {

		wh.waitForElementPresent(pickupOptionSection, 5);

		if (wh.isElementPresent(pickupOptionSection, 2)) {

			report.addReportStep("Verify Pickup Option section is displayed", "Pick up Option section is displayed",
					StepResult.PASS);

		} else {

			report.addReportStep("Verify Pickup Option section is displayed", "Pickup Option section  is not displayed",
					StepResult.FAIL);
			rc.terminateTestCase("PickUpOptionSection");
		}

		if (wh.isElementNotPresent(pickupOptionModifyLink)) {
			report.addReportStep("Verify modify link is not present in Pick up Today at column in right rail",
					"Modify link is not present in Pick up Today at column in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify modify link is not present in Pick up Today at column in right rail",
					"Modify link is  present in Pick up Today at column in right rail", StepResult.FAIL);
		}

	}

	public void clickContinueButton() throws Exception {

		if (wh.isElementPresent(pickupContinueBtn, 5)) {
			wh.clickElement(pickupContinueBtn);
			System.out.println("Button is clicked");

			report.addReportStep("Click Continue button ", "Continue button is clicked", StepResult.DONE);
		}

	}

	public void verifyPickupOptionSummary() throws Exception {

		wh.waitForElementPresent(pickupOptionSummary, 5);

		if (wh.isElementPresent(pickupOptionSummary, 2)) {

			report.addReportStep("Verify Pickup Option Summary is displayed", "Pickup Option Summary is displayed",
					StepResult.PASS);

			/*
			 * if (wh.isElementPresent(pickupEditlink, 15)) {
			 * 
			 * report.addReportStep(
			 * "Verify Edit link in  PickupOptionSummary section ",
			 * "Edit link is displayed in PickupOptionSummary section",
			 * StepResult.PASS); }
			 * 
			 * else {
			 * 
			 * report.addReportStep(
			 * "Verify Edit link in  PickupOptionSummary section",
			 * "Edit link is not displayed in PickupOptionSummary section",
			 * StepResult.FAIL);
			 * 
			 * }
			 * 
			 * 
			 */

		} else {

			report.addReportStep("Verify Pickup Option Summary is displayed", "Pickup Option Summary is not displayed",
					StepResult.FAIL);
		}

		/*
		 * if(wh.isElementPresent(pickupOptionModifyLink)) {
		 * report.addReportStep(
		 * "Verify modify link is  present in Pick up Today at column in right rail"
		 * ,"Modify link is  present in Pick up Today at column in right rail",
		 * StepResult.PASS); }
		 * 
		 * else { report.addReportStep(
		 * "Verify modify link is  present in Pick up Today at column in right rail"
		 * ,
		 * "Modify link is not present in Pick up Today at column in right rail"
		 * , StepResult.FAIL); }
		 */

	}

	public void selectProDesk() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(chooseProDesk, 5)) {
			wh.clickElement(chooseProDesk);

			report.addReportStep("Click Pro Desk as a pickup Location ", "Pro Desk is selected as Pick Up Location",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Click Pro Desk as a pickup Location ",
					"Pro Desk is  not selected as Pick Up Location", StepResult.FAIL);
		}

	}

	/*** 02/08/2016 ***/

	public void clickEditLink() throws Exception {

		if (wh.isElementPresent(pickupEditlink, 15)) {

			wh.jsClick(pickupEditlink);

			report.addReportStep("Verify Edit link is clicked ", "Edit link is clicked in PickupOptionSummary section",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Edit link is clicked ",
					"Edit link is not clicked in PickUpOption Summary section", StepResult.FAIL);
		}

	}

	public void editCart() throws Exception {

		By editCartLink = By.xpath("//h3[@class='text-primary right edit-cart-link pointer']");

		if (wh.isElementPresent(editCartLink, 7)) {

			wh.clickElement(editCartLink);
			report.addReportStep("Click on Edit cart link ", "Edit cart link is clicked", StepResult.PASS);

		}

	}

	public void verifyChangedPickupPerson() throws Exception {

		String changedPickupPerson = driver.findElement(pickupPersondetails).getText();

		if (wh.isElementPresent(pickupPersondetails, 5)) {

			report.addReportStep("Check whether the pickup person details present  ",
					"Pickupperson details" + changedPickupPerson, StepResult.PASS);

		}
		// return this;
	}

	public void clickModifyLinkInRightRail() throws Exception {
		if (wh.isElementPresent(pickupOptionModifyLink)) {

			wh.jsClick(pickupOptionModifyLink);
			report.addReportStep("Verify modify link is clicked in Pick up Today at column in right rail",
					"Modify link is clicked in Pick up Today at column in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify modify link is clicked in Pick up Today at column in right rail",
					"Modify link is not click in Pick up Today at column in right rail", StepResult.FAIL);
		}
	}

	public void checkForErrorMessage() throws Exception {

		if (wh.isElementPresent(errorMessage)) {
			String errMsg = driver.findElement(errorMessage).getText();
			report.addReportStep("Verify Checkout page for any error message  ",
					"Error message: <b> " + errMsg + "</b> is Displayed ", StepResult.DONE);
			rc.terminateTestCase("Payment Section would");
		}

	}

	public void verifyChooseAnotherPersonDetailsModified() throws Exception {

		if (wh.isElementPresent(editChooseAnotherPerson, 5)) {
			wh.clickElement(editChooseAnotherPerson);

			report.addReportStep("Click on Edit this information ", "Edit this information is clicked ",
					StepResult.PASS);

		}

		else {
			report.addReportStep("Click on Edit this information ", "Edit this information is not present ",
					StepResult.FAIL);

		}

		if (wh.isElementPresent(pickupPersonOverlay, 7)) {
			wh.sendKeys(WhoFirstName, dataTable.getData(DataColumn.Firstname));

			wh.sendKeys(WhoLasttName, dataTable.getData(DataColumn.Lastname));

			wh.sendKeys(WhoEmail, dataTable.getCommonData(CommonDataColumn.GuestEmail));

			wh.sendKeys(MobileNum, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));

			wh.jsClick(savechangePerson);
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is saved", StepResult.PASS);
		} else {
			report.addReportStep("Verify Choose another person details is saved in pick up options page",
					"Choose another person details is not saved", StepResult.FAIL);
		}

	}

	public void verifyChooseTimeandDateModified() throws Exception {

		wh.clickElement(editChoosePickUpTime);
		report.addReportStep(" click on edit this information in PickUp optio  page.",
				"<b>edit this information </b> radio button is selected", StepResult.DONE);
		if (wh.isElementPresent(pickupdateOverlay, 2)) {

			try {
				Select selPickUpdate = new Select(driver.findElement(PickUpDate));
				int randomIndex = (int) (Math.random() * 10);
				selPickUpdate.selectByIndex(randomIndex);

				String strTempDate = selPickUpdate.getFirstSelectedOption().getText();
				commonData.strSelectDate.add(strTempDate);

				report.addReportStep("Select a date from the Pickup date drop down",
						"Date <b>" + strTempDate + "</b> selected", StepResult.PASS);

			} catch (Exception e) {
				report.addReportStep("Select a date from the Pickup date drop down",
						"Unable to select a Date from the drop down", StepResult.FAIL);
			}

		}

		// if (cf.waitForElement(driver,PickUpTime, 2)) {

		try {
			Select selPickUpTime = new Select(driver.findElement(PickUpTime));
			int randomIndex = (int) (Math.random() * 10);
			selPickUpTime.selectByIndex(randomIndex);

			String strTempTime = selPickUpTime.getFirstSelectedOption().getText();
			commonData.strSelectTime.add(strTempTime);
			report.addReportStep("Select a date from the Pickup Time drop down",
					"Time <b>" + strTempTime + "</b> selected", StepResult.PASS);

		} catch (Exception e) {
			report.addReportStep("Select a Time from the Pickup Time drop down",
					"Unable to select a Time from the drop down", StepResult.FAIL);
		}

		wh.jsClick(savePickupTime);
		// }
		wh.waitForPageLoaded();

	}

	/**************
	 * PAYMENT and Billing SECTION AND SUMMARY
	 ************************/

	/** Payment Section and Summary **/

	public SingleCheckoutPage verifyPaymentSection() throws Exception {

		if (wh.isElementPresent(paymentSection, 5)) {

			report.addReportStep("Verify Payment section is displayed '", " Payment section is displayed",
					StepResult.PASS);

		} else {

			report.addReportStep("Verify Payment section is displayed'", " Payment section is not displayed",
					StepResult.FAIL);

			rc.terminateTestCase("Payment Section");
		}

		return this;
	}

	public boolean verifyPOforCreditCards() throws InterruptedException {

		try {
			new WebDriverWait(driver, 4).until(ExpectedConditions.presenceOfElementLocated(By.id("POJobCode"))).click();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public SingleCheckoutPage fillCreditCardDetails() throws Exception {

		String CardNumber = null;
		String CardType = dataTable.getData("CardType");

		if (CardType.toLowerCase().contains("visa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.VISA_card);
		}

		else if (CardType.toLowerCase().contains("master")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.MASTER_card);
		}

		else if (CardType.toLowerCase().contains("amex")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.AMEX_card);
		}

		else if (CardType.toLowerCase().contains("discover")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.DISCOVER_card);
		}

		else if (CardType.toLowerCase().contains("consumer")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCONSUMER_card);
		}

		else if (CardType.toLowerCase().contains("commercial")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCOMMERCIAL_card);
		}

		else if (CardType.toLowerCase().contains("gsa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.GSA_card);
		}

		else if (CardType.isEmpty()) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.CardNumber);
		}

		wh.sendKeys(cardNumber, CardNumber);
		driver.findElement(cardNumber).sendKeys(Keys.TAB);

		if (CardType.toLowerCase().contains("commercial")) {
			wh.sendKeys(buyerNameNewCard, dataTable.getCommonData(CommonDataColumn.BuyerName));
		}

		else if (CardType.toLowerCase().contains("consumer")) {

		}

		else {
			wh.selectValue(expirationMonth, dataTable.getCommonData(CommonDataColumn.ExpirationMonth));
			wh.selectValue(expirationYear, dataTable.getCommonData(CommonDataColumn.ExpirationYear));
		}

		if (CardType.toLowerCase().contains("amex")) {
			wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CVV_Amex));
		} else {
			wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CardSecurityID));
		}

		// To Verify PO Job Code
		if (CardType.toLowerCase().contains("consumer") || CardType.toLowerCase().contains("amex")) {
			if (verifyPOforCreditCards()) {
				report.addReportStep("Verifying PO number", "PO field is Displayed", StepResult.FAIL);
			} else {
				report.addReportStep("Verifying PO number", "PO field is not Displayed", StepResult.PASS);
			}

		}

		else {
			if (verifyPOforCreditCards()) {
				// String strPOField = dataTable.getData("POJobCode");
				String strPOField = dataTable.getCommonData(CommonDataColumn.POJobCode);
				commonData.strPO = strPOField;
				wh.sendKeys(poJobCode, strPOField);
				report.addReportStep(
						"Entering PO number <b>" + strPOField + " </b>in the PO number Field in payment method page",
						"PO field is Displayed and PO Number <b>" + strPOField + " </b>is entered", StepResult.PASS);
			} else {
				report.addReportStep(" Verify whether the PO # field should displayed", "PO # field is not displayed.",
						StepResult.FAIL);
			}
		}

		String cardNumberMasked = driver.findElement(cardNumber).getText();

		if (cardNumberMasked.contains("*")) {
			report.addReportStep("Verify Card Number is masked ",
					"Card Number " + CardNumber + " is masked as" + cardNumberMasked, StepResult.PASS);
		}

		else
			report.addReportStep("Verify Card Number is masked ", "Card Number " + CardNumber + " is not masked ",
					StepResult.FAIL);

		return this;

	}

	public void clickContinue() throws Exception {
		if (wh.isElementPresent(paymentContinueBtn, 5)) {
			wh.clickElement(paymentContinueBtn);

			report.addReportStep("Click Continue button ", "Continue button is clicked", StepResult.PASS);
		}

		else {
			report.addReportStep("Click Continue button ", "Continue button is clicked", StepResult.FAIL);
		}

	}

	public SingleCheckoutPage verifyPaymentSummary() throws Exception {

		String paymentSummaryTitle = driver.findElement(By.xpath("//h3[@class='title m-bottom-normal left']"))
				.getText();

		String paymentSummaryContent = driver.findElement(By.xpath("//li[@class='display-table summary-card']"))
				.getText();

		if (wh.isElementPresent(paymentSummarySection, 5)) {

			report.addReportStep("Verify Payment Summary section is displayed '",
					" " + paymentSummaryTitle + "' Summary section is displayed", StepResult.PASS);

			String cardNumberSummary = driver.findElement(paymentSummaryCardNumber).getText().trim();

			/************* VERIFYING CARD IMAGE and Card Name ******/

			if ((wh.isElementPresent(visaCardImage)) && (cardNumberSummary.contains("visa Card"))) {
				report.addReportStep("Verify Card Image is displayed '", " Visa Card Image is displayed",
						StepResult.PASS);
			}

			else if ((wh.isElementPresent(mcCardImage)) && (cardNumberSummary.contains("master card"))) {
				report.addReportStep("Verify Card Image is displayed '", " MASTER Card Image is displayed",
						StepResult.PASS);

			} else if ((wh.isElementPresent(amexCardImage)) && (cardNumberSummary.contains("amex Card"))) {
				report.addReportStep("Verify Card Image is displayed '", " Amex Card Image is displayed",
						StepResult.PASS);

			} else if ((wh.isElementPresent(discCardImage)) && (cardNumberSummary.contains("discover Card"))) {
				report.addReportStep("Verify Card Image is displayed '", " Discover Card Image is displayed",
						StepResult.PASS);

			} else if ((wh.isElementPresent(hdcomCardImage)) && (cardNumberSummary.contains("hdcom Card"))) {
				report.addReportStep("Verify Card Image is displayed '", " HD Commericial Card Image is displayed",
						StepResult.PASS);

			}

			else if ((wh.isElementPresent(hdconCardImage)) && (cardNumberSummary.contains("hdcon Card"))) {
				report.addReportStep("Verify Card Image is displayed '", " Hd Consumer Card Image is displayed",
						StepResult.PASS);

			}

			else {
				report.addReportStep("Verify card Image and Cardname is displayed ",
						"Card Image or Card name is not displayed properly", StepResult.FAIL);
			}

			/************* VERIFYING SUMMARY CONTENT ******/

			if (paymentSummaryContent != "") {
				report.addReportStep("Verify Content in Payment Summary section ",
						"Below are the content in Payment Summary section" + "<br/>" + paymentSummaryContent,
						StepResult.PASS);
			}

			else {
				report.addReportStep("Verify Content in Payment Summary section ",
						"Payment Summary is empty" + "<br/>" + paymentSummaryContent, StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify Payment Summary section is displayed'",
					" " + paymentSummaryTitle + "' Summary section is not displayed", StepResult.FAIL);

			rc.terminateTestCase("Payment Summary");
		}

		if (wh.isElementPresent(paymentEditLink, 15)) {

			report.addReportStep("Verify Edit link in  Payment Summary section ",
					"Edit link is displayed in Payment Summary section", StepResult.PASS);
		}

		else {

			report.addReportStep("Verify Edit link in Payment Summary section",
					"Edit link is not displayed in Payment Summary section", StepResult.FAIL);
			rc.terminateTestCase("Payment Summary");
		}

		return this;

	}

	// *** BILLING SECTION AND SUMMARY**//

	public SingleCheckoutPage verifyBillingSection() throws Exception {

		if (wh.isElementPresent(billingandContactSection, 5)) {

			report.addReportStep("Verify Billing section is displayed ", " Billing  section is displayed",
					StepResult.PASS);

		} else {

			report.addReportStep("Verify Billing section is displayed", " Billing  section is not displayed",
					StepResult.FAIL);

			rc.terminateTestCase("Billing section");
		}

		return this;

	}

	public SingleCheckoutPage fillBillingInfo() throws Exception {

		if (wh.isElementPresent(firstName, 2)) {

			wh.sendKeys(firstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
			wh.sendKeys(lastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.sendKeys(address1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(zipCode, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			wh.sendKeys(phoneNumber, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			wh.sendKeys(emailAddress, dataTable.getCommonData(CommonDataColumn.GuestEmail));
			Thread.sleep(commonData.littleWait);

		}

		report.addReportStep("Enter Billing  information", "Billing information entered", StepResult.PASS);

		return this;

	}

	public void clickBillingContinue() throws Exception {
		if (wh.isElementPresent(billingContinueBtn, 5)) {
			wh.clickElement(billingContinueBtn);

			report.addReportStep("Click Continue button ", "Continue button is clicked", StepResult.PASS);
		}

		else {
			report.addReportStep("Click Continue button ", "Continue button is clicked", StepResult.FAIL);
		}

	}

	public SingleCheckoutPage verifyBillingSummary() throws Exception {

		String billingSummaryTitle = driver.findElement(By.xpath("//*[@id='slider_panel_2_wrapper']/div[1]/div[1]/h3"))
				.getText();
		String billingSummaryContent = driver.findElement(By.xpath("//*[@id='slider_panel_2_summary']")).getText();

		if (wh.isElementPresent(billingSummarySection, 5)) {

			report.addReportStep("Verify Billing Summary section is displayed ",
					" " + billingSummaryTitle + "Summary section is displayed", StepResult.PASS);

			if (billingSummaryContent != "") {

				report.addReportStep(" Verify the content of Billing Summary section is displayed ",
						"Content of the billing Summary is<br/>" + billingSummaryContent, StepResult.PASS);
			} else {
				report.addReportStep(" Verify the content of Billing Summary section is displayed ",
						"Billing Summary is empty", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify Billing Summary section is displayed",
					" " + billingSummaryTitle + "Summary section is not displayed", StepResult.FAIL);

			rc.terminateTestCase("Billing Summary");
		}

		if (wh.isElementPresent(billingEditlink, 15)) {

			report.addReportStep("Verify Edit link in  Billing Summary section ",
					"Edit link is displayed in Billing Summary section", StepResult.PASS);
		}

		else {

			report.addReportStep("Verify Edit link in  Billing Summary section",
					"Edit link is not displayed in  Billing Summary section", StepResult.FAIL);
			rc.terminateTestCase("Billing Summary");
		}

		return this;

	}

	public ThankYouPage submitOrder1() throws Exception {

		ThankYouPage thankYouPage;

		if (rc.isProdEnvironment()) {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"We do not place Orders on Production", StepResult.WARNING);
			rc.terminateTestCase();

			thankYouPage = new ThankYouPage(ic);
			thankYouPage.isProdEnv = true;

			return thankYouPage;

		} else {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-550)", "");
			// Thread.sleep(commonData.smallWait);

			wh.clickElement(submitOrdBtn);
			Thread.sleep(commonData.LongWait);

			if (wh.isElementPresent(submitOrdBtn)) {

				wh.jsClick(submitOrdBtn);

				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details",
						"Submitted order for sku : " + commonData.sku, StepResult.PASS);
			} else {

				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details",
						"Submit button not clicked ", StepResult.FAIL);
				rc.terminateTestCase("Thank You for Your Order");

			}

			if (wh.isElementPresent(errorMsg)) {

				String errorMessage = driver.findElement(errorMsg).getText();

				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
						" <b> Below Error mesage is displayed after clicking submit button</b>" + errorMessage,
						StepResult.FAIL);
				rc.terminateTestCase("Thank You for Your Order");
			}

			thankYouPage = new ThankYouPage(ic);

			return thankYouPage;
		}
	}

	public SingleCheckoutPage hidePaymentSection() throws Exception {

		if ((wh.isElementNotPresent(paymentSection))) {
			report.addReportStep("Verify Payment Section  is hidden '", "Payment Section is hidden", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Payment Section is hidden '", "Payment Section is not hidden",
					StepResult.FAIL);
		}

		return this;
	}

	public void clickEditLinkSummary() throws Exception {

		if (wh.isElementPresent(paymentEditLink, 15)) {

			wh.jsClick(paymentEditLink);

			report.addReportStep("Verify Edit link is clicked ", "Edit link is clicked in Payment Summary section",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Edit link is clicked ", "Edit link is not clicked in Payment Summary section",
					StepResult.FAIL);
		}
	}

	public SingleCheckoutPage modifyPaymentDetails() throws Exception {

		wh.sendKeys(cardNumber, dataTable.getCommonData(CommonDataColumn.CardNumber));

		driver.findElement(cardNumber).sendKeys(Keys.TAB);
		if (wh.isElementPresent(buyerNameNewCard, 5)) {
			wh.sendKeys(buyerNameNewCard, dataTable.getCommonData(CommonDataColumn.BuyerName));
		} else {
			wh.selectValue(expirationMonth, dataTable.getCommonData(CommonDataColumn.ExpirationMonth));
			wh.selectValue(expirationYear, dataTable.getCommonData(CommonDataColumn.ExpirationYear));
		}
		wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CardSecurityID));

		return this;

	}

	public SingleCheckoutPage hideBillingSection() throws Exception {

		if ((wh.isElementNotPresent(billingSection))) {
			report.addReportStep("Verify billing Section  is hidden '", "Billing Section is hidden", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Billing Section is hidden '", "Billing Section is not hidden",
					StepResult.FAIL);
		}

		return this;

	}

}
