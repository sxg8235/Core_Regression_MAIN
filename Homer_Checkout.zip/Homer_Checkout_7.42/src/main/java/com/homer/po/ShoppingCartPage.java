package com.homer.po;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.*;

import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;
import com.homer.helper.HelperClass;
import com.homer.dao.DataClass;

public class ShoppingCartPage extends PageBase<ShoppingCartPage> {

	static final By verifyShoppingCartPage = By.id("cart-style-container");
	static final By checkoutNowBtn = By.id("checkout-btn");
	static final By emptyCartText = By.xpath("//*[contains(text(),'Your shopping cart is empty')]");
	static final By btnPaypal = By.xpath("//*[@id='checkout-btn']/preceding-sibling::a[@id='CartCheckoutPPId1']");
	static final By applianceSubtotalAmount = By.cssSelector(".orChargeItem.cartApplianceSubTotal>.orCharges");
	static final By shoppingCartHeader = By.cssSelector("header.col-1-1.alpha.omega");
	static final By applianceDeliveryText = By
			.xpath("(//*[@class='p-custom-inner-block']//h3[contains(@class,'applianceDeliveryPricing')])[2]");
	static final By applianceDeliveryCharge = By
			.cssSelector(".right.text-right.p-bottom-normal>.text-secondary.applianceDeliveryPricing");
	static final By txtPromoCode = By.id("promoCode");
	static final By btnApplyPromo = By.id("promo-apply");
	static final By verifyAssemblyOption = By.xpath("(//*[@class='assemblyOptionSelection'])[1]");
	static final By rdoAssemblyYes = By.xpath("(//div[@class='assemblyOptionSelection']/div[1])[1]");
	static final By addToList = By.xpath("//div[contains(text(),'Add to List')]");
	static final By regEmail = By.id("email_id");
	static final By regPwd = By.id("password");
	static final By regSignInBtn = By.id("signIn");
	static final By regusername = By.xpath("//span[@class='headerMyAccount__title--legal']");
	static final By expressCheckoutClick = By.xpath("//a[contains(text(),'EXPRESS CHECKOUT')]");
	static final By removeLink = By.cssSelector("a.delete-cart-item");
	static final By removesecondLink = By.xpath("(//a[@class='delete-cart-item'])[2]");
	static final By loadingIcon = By.cssSelector("div.containerLoading.loader-image");
	static final By editParts = By.xpath("//a[@class='text-primary editPS_MCC show']");
	static final By changeZippAppl = By.id("changeZipcodeLinkMCC");
	static final By removePromo = By.xpath("//a[contains(text(),'remove ')]");
	static final By subTotTxt = By.xpath("//h3[contains(text(),'Subtotal')]");
	static final By assemblyYes = By.xpath("//label[contains(text(),'Yes, assemble it for me')]");
	static final By assemblyNo = By.xpath("//label[contains(text(),'No')]");
	static final By modelNumber = By.xpath("//*[contains(text(),'Model')]");
	static final By cartErrMsg = By.className("cart-error-message");
	static final By qtyTxtBox = By.xpath("//*[contains(@class,'qty-wrapper')]/input[contains(@id,'quantity')]");
	static final By expressdeliverybutton = By
			.xpath("//*[@id='cartLineItem_1072600494']/div/div[2]/div[1]/div[2]/div/div[2]/div/div[2]/label/div/div/h4");
	static final By zipCodeAvailArrow = By.xpath("(//button[contains(@id,'checkBODFS_AVAIL')])[1]");
	static final By readOnlyZipCode = By
			.xpath("(//*[contains(@style,'display:block') and contains(@class,'avaialbleDelivery')]//span[@class='bold'])[1]");
	static final By yourAccountLink = By.id("headerMyAccount");
	static final By cartFulfillmentOptions = By
			.xpath("//*[contains(@class,'prodSection')]//*[contains(@class,'cart-fulfillment-options')]");
	static final By shipToHomeSubSec = By.xpath("//label[contains(@for,'ShipToHome')]//p");
	static final By expressDeliveryRadio = By
			.xpath("(//label[contains(@for,'DeliverFromStore')]//div[contains(@class,'radio-header')])[1]");
	static final By errMsgInvalidZipCode = By
			.xpath("(//div[contains(@id,'zipCodeError')]//span[contains(text(),'Please enter a valid zip code')])[1]");
	static final By zipCodeBODFS = By.xpath("(//input[contains(@id,'zipCode_For_BODFS')])[1]");
	static final By assemblyYesMsg = By
			.cssSelector("div.p-top-small.normal-weight.text-muted.assembly-option-info-text");
	By Quantity = By.xpath("//input[contains(@name,'quantity_')]");
	static final By qtyErr = By.cssSelector("span.cart-error-message");
	static final By pageLevelErrMsgCart = By.xpath("//*[@id='errorDescriptions']//span");
	static final By bodfsQtyErr = By.xpath("//*[contains(@id,'bodfs-qty-error')]/span");
	static final By estimatedDeliveryDate = By
			.xpath("(//*[contains(@style,'display:block') and contains(@class,'avaialbleDelivery')]//span[@class='bold'])[2]|(//*[contains(@class,'est-delivery-date')]//span)[2]");
	static final By PromoerrorMsg1 = By.cssSelector("span.cart-error-message");
	static final By PromoerrorMsg2 = By.cssSelector("p.text-small.m-bottom-normal");
	static final By orderTotalRightRail = By.cssSelector(".right.text-right.p-bottom-normal");
	static final By estimatedSubtotal = By.xpath("//h3[contains(@class,'orCharges')]");
	static final By OnlineProd = By.xpath("//h4[contains(.,'Ship to Home')]");
	static final By OnlineProd1 = By.xpath("//h4[contains(.,'Ship to Home')][2]");
	static final By sthChecked = By.xpath("//div[@class='radio-set m-bottom-normal']/input");
	static final By zipCodeOverlay = By.id("smrtSearchInput");
	static final By SearchBtnoverlay = By.xpath("//a[@class='smtOvbtnStoreFinder']/span");
	static final By SearchBtnoverlayFullSite = By.xpath("//a[@id='smtOvbtnStoreFinder']/span");
	static final By SearchBtnoverlayTabSite=By.xpath("//*[@class='smtOvbtnStoreFinder']//span");
	static final By updateCartBtn = By.xpath("//a[contains(text(),'UPDATE CART')]");
	static final By updateCartBtnFullSite = By.xpath("//button[contains(text(),'UPDATE CART')]");
	static final By verifyEstimatedSubtotal = By.xpath("//*[text()='Estimated Subtotal']");
	static final By estimatedSubtotalValue = By.xpath("//*[text()='Estimated Subtotal']/../../div[2]/h3[1]");
	static final By lineItemTotalCart = By.xpath("//*[contains(@id,'cartLineItem')]//h3[@class='bold price-section']");
	static final By leftTxtOrderSummary = By
			.xpath("//*[contains(@class,'left text-left order-summary-leftwidth')]//h3|//*[contains(@class,'left text-left order-summary-leftwidth')]//h4");
	static final By rightTxtOrderSummary = By.xpath("//*[@class='right text-right p-bottom-normal']//h3");
	static final By shippingMethodSection = By.id("ship-method");
	static final By standardShippingRadioBTN = By.xpath("//div [@class ='radio-custom radio-custom-active']");
	static final By shippingCharge = By.xpath("//span[@class = ' ship-price']");
	static final By bodfsDeliveryPrice = By
			.xpath("(//*[@class='deliveryServiceContainer'])[1]/span[contains(text(),'As Low as')]");
	static final By strikeThroPrice = By.xpath("//h3[@class='m-bottom-xsmall strike-through']");
	static final By prodImageInCart = By.cssSelector("div.alpha.omega.col-cart-line-image.cart-line-image");
	static final By nowPrice = By.xpath("//h3[contains(@id,'unitPrice')]/../h3");
	static final By eleOSPickUpInStore = By.xpath("//h4[contains(text(),'Pick Up In Store Today')]");
	static final By eleOShipToStore = By.xpath("//h4[contains(text(),'Ship to Store')]");
	static final By copyBlinds = By.xpath("//a[contains(text(),'Copy')]");
	static final By addCartBlinds = By.xpath("//button[contains(text(),'ADD THIS TO CART')]");
	static final By lnkAccountProfile = By.xpath("//a[contains(text(),'Account Profile')]");
	static final By promoPrices = By.xpath("//div[@class='right text-right p-bottom-normal']/h3[@class='bold']");
	static final By editBlinds = By.xpath("//a[@class='bold blinds-edit']");
	static final By roomSelectorUpdate = By.xpath("(//div[@class='bdc-room-selector-item-image'])[2]");
	static final By updateCartBlinds = By.xpath("//button[contains(text(),'UPDATE MY CART')]");
	static final By changeZipCodeBODFS = By.xpath("//a[contains(text(),'(change)')]");
	static final By updatedStore = By.xpath("//p[@class='reveal bb-inline buy-box-message']/span[3]");
	static final By updatedStoretxt = By.cssSelector("p.reveal.bb-inline.buy-box-message.show-on-select");
	static final By changeExpressDeliveryZipcode = By.xpath("//*[@id='fancybox-content']//h3");
	static final By ExpressDeliveryFromStroreLabel = By
			.xpath("//*[@class='tpl-content']//h4[contains(text(),'Express Delivery from Store')]");
	static final By ExpressDeliveryLabelInOrderSummarySection = By
			.xpath("//*[@class='order-summary  clear']//div[1]//h3[contains(text(),'Express Delivery')]");
	static final By itemInCart = By.xpath("//*[@class='tpl-content overflowHidden']");
	static final By addToListLink=By.cssSelector("div[id*='add-to-list-']");

	static final By BlinsDetailOverlay = By.cssSelector(".triggerBlindsDetailsOverlay");
	static final By CustomAttrName = By.cssSelector(".blinds-config");
	static final By CopyDesignLink = By.xpath("//a[@class='cust-detail-btn']/span|//*[@class='bold blinds-copy']");
	static final By OrderMyBlindsButton = By.cssSelector(".bdc-btn.bdc-btn-submit.bdc-btn-jumbo.w100pc");
	static final By SwatchImage = By.xpath("//img[@class='bdc-choiceswatch-image']");
	static final By Color = By.xpath("(//*[@class='bdc-choiceswatch-figcaption'])[3]");
	static final By width = By.xpath("//*[@class='blinds-custom-config']//h4[2]//span[2]");
	static final By height = By.xpath("//*[@class='blinds-custom-config']//h4[3]//span[2]");
	static final By configwidth = By.xpath("//select[@id='gcc-pcp-option-width-whole']");
	static final By configHeight = By.xpath("//select[@id='gcc-pcp-option-height-whole']");
	static final By configMount = By.xpath("//*[@class='bdc-prdcfg-option bdc-prdcfg-option-mount']");
	static final By mountOpt2 = By.xpath("//*[@class='bdc-prdcfg-option bdc-prdcfg-option-mount']//li[2]");
	static final By mount = By.xpath("//*[@class=' custom-even-row ']/./..//p[contains(text(),'Mount')]");
	static final By customDetails = By.xpath("//a[@class='blinds-custom-details bold']");
	static final By customDetailsClose = By.xpath("//*[@class='md-close']");
	static final By ProdDesc = By.xpath("//*[@class='bold break m-right-small']");
	static final By disclaimerMsg = By.xpath("//div[@class='m-right-normal pad disclaimer-message']");
	static final By bopisChecked = By.xpath("(//*[@class='radio-set m-bottom-normal'])[2]//input");
	static final By bodfsChecked = By
			.xpath("//h4[contains(text(),'Express Delivery from Store')]/../../../../..//input");
	static final By bulkPricingMsg = By.xpath("//span[contains(text(),'Get Bulk Pricing')]");
	static final By miniCartCount = By
			.xpath("//ul[@class='headerCart__dropdown headerCart__dropdown--expanded']/li/a/span");
	static final By STHFulfillmentActive = By.xpath("//input[contains(@id,'ShipToHome') and @value='ShipToHome']");
	static final By STHButton = By.xpath("//div[@class='chkShipToHome']");
	static final By BlindsDetailOverlay = By.cssSelector(".triggerBlindsDetailsOverlay");
	static final By BlindsModal = By.cssSelector("div[class='md-content']");
	static final By ModalTitle = By.cssSelector("span[class='md-title']");
	static final By BlindsModalHeading = By.xpath("(//*[@id='heading']//h3)[1]");
	static final By BasePrice = By.xpath("(//*[@id='heading']//span)[1]");
	static final By BasePriceValue = By.xpath("(//*[@id='heading']//span)[2]");
	static final By BlindsDetailsImage = By.xpath("//*[@class='blinds-img']");
	static final By BlindDetailAttributeValue = By
			.xpath("//*[@class='right right-content-cls line-height-more']//div[contains(@class,'custom')]");
	static final By BlindTotal = By.id("blindsTotal");

	static final By Buybox = By.xpath("//*[@class='tpl-content overflowHidden']");
	static final By Room = By
			.xpath("//*[@class='blinds-attr-name' and contains(text(),'Room Name:')]/..//*[@class='blinds-attr-val']");
	static final By RemoveLink = By.xpath("//*[@class='cartAddToListNremove']//*[@class='remove']/a");
	static final By Total = By.xpath("(//*[@class='order-summary  clear']//div[@class='bottom-pod']//h3)[2]");
	static final By Emptycart = By.cssSelector(".emptyCartContent");
	static final By promoValue = By
			.xpath("//*[@class='right text-right p-bottom-normal']//h3[contains(text(),'-')][1]");
	static final By QualifierAmountSaved = By.xpath("//h3[contains(text(),'You Saved')]");
	static final By QualifierAmountSavedvalue = By.xpath("//h3[contains(text(),'You Saved')]/../../div[2]/h3[2]");
	static final By QualifierPromoValue = By.xpath("//*[@class='right text-right p-bottom-normal']/../div[2]/h3[1]");
	static final By certonaAddToCartBtnCart = By.xpath("//a[@class='overlayCartTrigger dynamic_btn orange_btn c']");
	static final By limPerOrderErrMsg = By
			.xpath("//span[contains(text(),'Quantity requested exceeds purchase limit for this order')]");
	static final By limPerOrderCount = By.xpath("//div[@class='text-muted']");
	static final By itemUpdMsg1 = By.xpath("//p[@class='bold m-top-xsmall small m-left-large'][1]");
	static final By itemUpdMsg2 = By.xpath("//p[@class='bold m-top-xsmall small m-left-large'][2]");
	static final By CountDownTimer = By.cssSelector("#detaCountdown_");
	static final By ETA = By.xpath("//*[contains(text(),'Estimated Arrival:')]");
	static final By FromValue = By.xpath("(//*[contains(@id,'shippingCharge_')])[1]");
	static final By limitperorder = By.id("errorDescriptions");
	static final By warningPromo = By
			.xpath("//*[@class='cart-promotions content']//*[contains(text(),'Your order must')]");
	static final By UnitPrice = By.xpath("//*[contains(@id,'unitPrice_')]");
	static final By warninMsgSTS = By.xpath("//div[@id='cautionSTS']");
	static final By freeShipMsg = By.className("freeShippingMsg");
	static final By SummarySec=By.cssSelector(".bold.orCharges");
	static final By OrderSummarySec=By.cssSelector(".order-summary.clear");

	// // ************This section is for
	// // HDPP********************************************
	static final By miniCart = By.cssSelector("#miniCartNum");
	static final By hdppText_cart = By.cssSelector("div.pod-warranty-add.m-bottom-large.right>div>p.bold");
	static final By addPlan_cart = By.cssSelector("a.add-plan");
	static final By hddp_added = By
			.xpath("//span[@class='hdpp-info-banner m-right-large left m-bottom-large' and @title='Home Depot Protection Plan']");

	static final By addtoList = By.xpath("//h3[contains(@id,'unitPrice')]/../h3");
	static final By removeLinkPlanOption = By
			.xpath("//div[contains(@class,'child-item')]/div/div[2]/div[2]/div[2]/div[1]/div/a");
	static final By planqtyTxtBox = By.xpath("//div[@class='qty-wrapper quantity-section text-right'][2]");
	static final By you_save_dollar_promo = By.xpath("//div[@class='right p-right-normal']/h3[2]");
	static final By learnMoreLinkcart = By.xpath("//div[@class='right p-right-normal']/h3[2]");
	static final By toolTipcart = By.xpath("//div[@class='right p-right-normal']/h3[2]");
	static final By bossRadio = By.xpath("//div[@class='right p-right-normal']/h3[2]");
	static final By updateBtn = By.xpath("//*[@id='addToCartContainer']/button");
	static final By guidanceTextbefore = By.cssSelector("div.pod-warranty-add.m-bottom-large.right>div>p.bold");
	static final By guidanceTextafter = By.cssSelector("div.pod-warranty-add.m-bottom-large.right>div>p.bold");
	static final By newList = By.xpath("//*[@id='itemCopiedLinkundefined']/span");
	static final By estimatedSubtotalbopis = By.xpath("//h3[@class='bold orCharges']");
	static final By qtyError = By
			.xpath("//span[@class='cart-error-message']|//*[@class='bold m-top-xsmall small m-left-large']");

	static final By seeDetailsLink = By.xpath("//a[@class='text-primary bold tip-opener-mcc']");
	static final By FreeShippingToolTip = By.xpath("//div[@class='tip-content-mcc']");
	static final By addToListOverlay = By.id("popupAddList");
	static final By errMsgZipcd = By.id("checkAvailableError");
	static final By errMsgDelUnavail = By.id("contactLocalStr");

	// ***Added for Checkoutfrom ATC overlay*******
	static final By partsandServicesText = By.xpath("//*[contains(text(),'Parts & Services')]");
	static final By assemblyOptionError = By.xpath("//*[contains(text(),'Please choose an assembly option.')]");
	static final By miniCartBtn = By.id("headerCart");
	static final By IsAssemblyRadioButtonChosen = By
			.cssSelector("div.assemblyIncluded.bg-default.p-all-normal.border-paper");
	static final By availableqty = By.xpath("//p[@class='reveal bb-inline buy-box-message show-on-select ']/span[1]");
	static final By overlayErrMsg = By.xpath("(//*[@id='smartOverlay']//span)[1]");
	static final By backorderMsg = By.xpath("//div[@class='error-in-container show']");

	// ******************************************************************************************

	// ******************************Instant
	// Rebates********************************************

	static final By changeStoreLink = By.xpath("//a[@href='#localizationModalContent']");
	static final By changeStoreOverlay = By.id("fancybox-content");
	static final By storeFinderBox = By.id("txtStoreFinder");
	static final By storeFinderBtn = By.id("btnStoreFinder");
	static final By makeThisYourStoreLink = By.xpath("//a[contains(text(),'Make this your store')]");
	static final By ApplFulfillmentOptions = By
			.xpath("//*[contains(@class,'prodSection')]//h4[contains(.,'Home Delivery')]");
	static final By promoSection = By.xpath("//h3[contains(@class,'m-bottom-small order-summary-promoheight')]");
	static final By partsAndServices = By.className("md-content");
	static final By partsAndServicesOverlay = By.xpath("//span[contains(text(),'Select Parts and Services')]");

	// ******************************Instant
	// Rebates********************************************

	public ShoppingCartPage(InstanceContainer ic) {
		super(ic);

	}

	/**
	 * Method to verify Shopping Cart Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage verifyShoppingCartPage() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(verifyShoppingCartPage, 20)) {

			report.addReportStep("Verify Shopping Cart Page", "Shopping Cart Page is displayed", StepResult.PASS);
		} else {

			report.addReportStep("Verify Shopping Cart Page", "Shopping Cart Page is not displayed", StepResult.FAIL);

			rc.terminateTestCase("Shopping Cart Page");
		}

		return this;
	}

	/**
	 * Method to click checkout now
	 * 
	 * @return
	 * @throws Exception
	 */
	public CheckoutSignInPage clickCheckoutNow() throws Exception {

		if (wh.isElementPresent(checkoutNowBtn, 30)) {

			wh.jsClick(checkoutNowBtn);

			report.addReportStep("Click checkout now button in Shopping Cart Page",
					"Clicked check out now button in Shopping Cart Page", StepResult.PASS);
		} else {
			report.addReportStep("Click checkout now button in Shopping Cart Page",
					"Clicked check out now button in Shopping Cart Page", StepResult.FAIL);
			rc.terminateTestCase();
		}
		return new CheckoutSignInPage(ic);
	}

	/**
	 * Method to verify shopping cart is not empty
	 * 
	 * @author YXG8356
	 * @since Aug 19,2015
	 * @throws Exception
	 */
	public ShoppingCartPage verifyShoppingCartNotEmpty() throws Exception {

		if (wh.isElementNotPresent(emptyCartText)) {

			report.addReportStep("Verify Shopping Cart Page", "Shopping Cart Page is not empty", StepResult.PASS);
		} else {

			report.addReportStep("Verify Shopping Cart Page", "Shopping Cart Page is empty", StepResult.FAIL);

			rc.terminateTestCase("Shopping Cart Page");
		}

		return this;
	}

	/**
	 * 
	 * Description: verify PayPal button is present in Shopping cart page
	 * 
	 * @throws Exception
	 */

	public ShoppingCartPage verifyPayPalBtnCartPg() throws Exception {

		if (wh.isElementPresent(btnPaypal, 15)) {

			report.addReportStep(
					"Verify <b>Checkout with Paypal</b> button should be displayed in the shopping cart page",
					"<b>Checkout with Paypal</b> button is displayed in the shopping cart page", StepResult.PASS);

		} else {
			report.addReportStep(
					"Verify <b>Checkout with Paypal</b> button should be displayed in the shopping cart page",
					"<b>Checkout with Paypal</b> button is NOT displayed in the shopping cart page", StepResult.FAIL);
			rc.terminateTestCase("Paypal Button in cart page");
		}
		return this;
	}

	/**
	 * To click paypal button in Shopping cart page
	 * 
	 * @since Dec 4, 2012
	 * @author autotest Modified by : Prabha
	 * @throws Exception
	 */
	public void clickPaypalbuttonInCartPage() throws Exception {

		if (wh.isElementPresent(btnPaypal, 15)) {
			wh.clickElement(btnPaypal);
		}

		else {
			report.addReportStep("Click <b>Checkout with PayPal </b>button in shopping cart page",
					"<b>Checkout with PayPal </b>button is not clicked", StepResult.FAIL);
			rc.terminateTestCase("Paypal Button in cart page");
		}

	}

	/**
	 * verify appliance delivery charge changes in cart page.
	 * 
	 * @author YXG8356
	 * @since Aug 31,2015
	 * @throws Exception
	 */

	public ShoppingCartPage verifyADCChanges() throws Exception {

		// Verify Appliance Delivery Charge in Thank you page order summary
		double applianceSubtotalAmt = commonData.applianceSubTotal;
		String applianceDeliveryChargeAmt = wh.getText(applianceDeliveryCharge);

		// Verify How to get it section

		if (wh.getText(shoppingCartHeader).contains("How To Get It")) {
			report.addReportStep("Verify How to Get it section for appliance item",
					"How to Get it section is displayed for appliance item", StepResult.PASS);

			// Verify Delivery is displayed as How to Get it for appliance item

			List<WebElement> noOfAppl = driver.findElements(By.xpath("//*[@class='bold p-left45']"));

			for (WebElement cElement : noOfAppl) {

				if (wh.getText(cElement).equals("Home Delivery")) {
					report.addReportStep("Verify How to Get it section for appliance item",
							"Delivery is displayed as how to get it for appliance item", StepResult.PASS);
				}

				else {
					report.addReportStep("Verify How to Get it section for appliance item",
							"Delivery is not displayed as how to get it for appliance item", StepResult.FAIL);
				}
			}

			// Verify appliance delivery section

			/* Appliance deliver zipcode */
			String applZip = wh.getText(By.id("appliance_message"));

			if (applZip.contains("All appliances will be delivered to ZIP code:")) {
				report.addReportStep("Verify Appliance delivery zipcode", "Appliance delivery zipcode is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Appliance delivery zipcode",
						"Appliance delivery zipcode is not displayed", StepResult.FAIL);
			}

			/* Verify appliance delivery message */
			if (wh.getText(By.cssSelector(".p-top-xsmall.freeDeliveryApplianceInfo")).contains(
					"Free delivery on appliance purchases of $396 or more.")) {
				report.addReportStep("Verify Appliance free delivery message",
						"Appliance free delivery requirement message is displayed", StepResult.PASS);
			} else if (applianceSubtotalAmt > 396.00) {
				report.addReportStep("Verify Appliance free delivery message",
						"Appliance free delivery requirement message is not displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify Appliance free delivery message",
						"Appliance free delivery requirement message is not displayed", StepResult.FAIL);
			}

			/* See details */
			if (wh.isElementPresent(By.cssSelector(".p-top-xsmall.freeDeliveryApplianceInfo>a"), 5)) {
				report.addReportStep("Verify appliance delivery charge info tool tip",
						"appliance delivery charge info tool tip is displayed", StepResult.PASS);

				wh.clickElement(By.cssSelector(".p-top-xsmall.freeDeliveryApplianceInfo>a"));
				Thread.sleep(100);

				// Verify tool tip contents
				if (wh.isElementPresent(By.xpath("//*[@class='quick-tip-mcc add-shadow-mcc']"), 5)) {
					report.addReportStep("Verify appliance delivery charge info tool tip opened on clicking",
							"appliance delivery charge info tool tip is opened on clicking", StepResult.PASS);

					// verify tool tip is displayed properly
					String tooltipHeader = wh.getText(By.className("tip-title-mcc"));
					String tooltipContent = wh.getText(By.xpath("//*[@class='tip-content-mcc']/div"));

					if (wh.isElementPresent(By.xpath("//*[@class='quick-tip-mcc add-shadow-mcc']"))
							&& wh.isElementPresent(By.className("md-close")) && !tooltipHeader.isEmpty()
							&& !tooltipContent.isEmpty()) {
						report.addReportStep("Verify appliance delivery charge info tool tip content on clicking",
								"Tool tip contents are displayed properly. Tool tip header : <b>" + tooltipHeader
										+ "</b>. Tool tip content : <b>" + tooltipContent + "</b>", StepResult.PASS);
					} else {
						report.addReportStep("Verify appliance delivery charge info tool tip content on clicking",
								"Tool tip contents not displayed properly. Tool tip header : <b>" + tooltipHeader
										+ "</b>. Tool tip content : <b>" + tooltipContent + "</b>", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify appliance delivery charge info tool tip opened on clicking",
							"appliance delivery charge info tool tip is not opened on clicking", StepResult.FAIL);
				}

			}

			else if (applianceSubtotalAmt >= 396.00) {
				report.addReportStep("Verify appliance delivery charge info tool tip",
						"appliance delivery charge info tool tip is not displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge info tool tip",
						"appliance delivery charge info tool tip is not displayed", StepResult.FAIL);
			}

		}

		else {
			report.addReportStep("Verify How to Get it section for appliance item",
					"How to Get it section is not displayed for appliance item", StepResult.FAIL);
		}

		// Verify order summary delivery charge

		if (wh.isElementPresent(applianceDeliveryText, 5)) {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is displayed in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify appliacne delivery Text displayed in right rail",
					"Appliance delivery text is not displayed in right rail", StepResult.FAIL);
		}

		if (applianceSubtotalAmt >= 396.00) {

			if (applianceDeliveryChargeAmt.equals("FREE")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ applianceSubtotalAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is not displayed as <b>FREE</b> for appliance subtotal amount <b>"
								+ applianceSubtotalAmt + "</b>", StepResult.FAIL);
			}
		}

		else {
			if (!applianceDeliveryChargeAmt.equals("FREE") && applianceDeliveryChargeAmt.contains("$")) {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + applianceSubtotalAmt + "</b>",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify appliance delivery charge in right rail",
						"Appliance delivery charge is displayed as <b>" + applianceDeliveryChargeAmt
								+ "</b> for appliance subtotal amount <b>" + applianceSubtotalAmt + "</b>",
						StepResult.FAIL);
			}
		}

		return this;

	}

	/**
	 * Method to applu promotion
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage applyPromotion() throws Exception {

		String pormoCode = dataTable.getData(DataColumn.PromoCode);

		if (wh.isElementPresent(txtPromoCode) && !pormoCode.isEmpty()) {

			wh.sendKeys(txtPromoCode, pormoCode);

			wh.clickElement(btnApplyPromo);

			report.addReportStep("Apply Promotion", "Promotion Code <b>" + pormoCode + "</b> applied", StepResult.PASS);
			Thread.sleep(commonData.smallWait);

		} else {
			report.addReportStep("Apply Promotion",
					"Promotion Code text box not displayed or promotion code data empty", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to verify how to get it section free delivery message
	 * 
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyHowToGetItSectionFreeDelMsg() throws Exception {

		if (wh.getText(shoppingCartHeader).contains("How To Get It")) {
			report.addReportStep("Verify How to Get it section for appliance item",
					"How to Get it section is displayed for appliance item", StepResult.PASS);

			// Verify Delivery is displayed as How to Get it for appliance item

			List<WebElement> noOfAppl = driver.findElements(By.xpath("//*[@class='bold p-left45']"));

			for (WebElement cElement : noOfAppl) {

				if (wh.getText(cElement).equals("Home Delivery")) {
					report.addReportStep("Verify How to Get it section for appliance item",
							"Delivery is displayed as how to get it for appliance item", StepResult.PASS);
				}

				else {
					report.addReportStep("Verify How to Get it section for appliance item",
							"Delivery is not displayed as how to get it for appliance item", StepResult.FAIL);
				}
			}
		} else {
			report.addReportStep("Verify appliance delivery Text displayed in right rail",
					"Appliance delivery text is not displayed in right rail", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * to store appliance subtotal value
	 */

	public ShoppingCartPage saveApplianceSubtotal() throws Exception {

		report.addReportStep("Save Appliance Subtotal", "Appliance subtotal is already saved", StepResult.DONE);
		return this;

	}

	/**
	 * Method to select assembly option
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage selectAssemblyOption() throws Exception {

		if (wh.isElementPresent(verifyAssemblyOption)) {

			report.addReportStep("Verify BOPIS assembly option in cart page", "Bopis assembly option is present",
					StepResult.PASS);

			wh.clickElement(rdoAssemblyYes);

		} else {
			report.addReportStep("Verify BOPIS assembly option in cart page", "Bopis assembly option is not present",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to click add to list cart
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage clickAddToListCart() throws Exception {

		if (wh.isElementPresent(addToList)) {

			report.addReportStep("Verify Add to list option in cart page", "Add to list option is present",
					StepResult.PASS);

			wh.clickElement(addToList);

		} else {
			report.addReportStep("Verify Add to list option in cart page", "Add to list option is not present",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to verify signed user retained in cart
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifySigneduserRetainedCart() throws Exception {

		wh.waitForPageLoaded();
		Thread.sleep(commonData.LongWait);
		if (wh.isElementPresent(regusername)) {

			String user = driver.findElement(regusername).getText();

			if (user.contains("Hello")) {
				report.addReportStep("Verify registered user name is displayed in the Header",
						"Registered user name is displayed in the Header", StepResult.PASS);
			} else {
				report.addReportStep("Verify registered user name is displayed in the Header",
						"Registered user name is not displayed in the Header", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify registered user name is displayed in the Header",
					"Registered user Header is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to sign in cart page header
	 * 
	 * @param email
	 * @param password
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage signInCartHeader(String email, String password) throws Exception {

		wh.clickElement(lnkSignIn);
		wh.clickElement(signInLink);

		if (wh.isElementPresentAfterWait(verifySignInPage)) {

			report.addReportStep("Click on 'Sign in' link present on the top right side of the page",
					"Sign In page displayed successfully", StepResult.PASS);

			wh.sendKeys(emailTxtBox, email);
			wh.sendKeys(passwordTxtBox, password);
			wh.clickElement(signInBtn);
			Thread.sleep(commonData.smallWait);
			wh.waitForPageLoaded();

		} else {
			report.addReportStep("Click on Sign In link", "Sign In page did not get displayed", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Method to click express checkout in cart page
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage clickExpressCheckoutCart() throws Exception {
		if (wh.isElementPresent(expressCheckoutClick)) {

			wh.clickElement(expressCheckoutClick);

			report.addReportStep("Verify Express Checkout button is clicked in cart page",
					"Express Checkout button is clicked in cart page", StepResult.PASS);

		} else {
			report.addReportStep("Verify Express Checkout button is clicked in cart page",
					"Express Checkout button is not clicked in cart page", StepResult.FAIL);
		}

		Thread.sleep(commonData.mediumWait);

		return this;
	}

	/**
	 * Method to remove item from cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage removeItemFromCart() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(removeLink)) {

			wh.clickElement(removeLink);

			report.addReportStep("Remove item from cart", "Item is removed from cart", StepResult.PASS);
			Thread.sleep(commonData.mediumWait);

		} else {
			report.addReportStep("Remove item from cart", "Item is not removed from cart", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to verify loading icon in cart page
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyLoadingIconCart() throws Exception {

		if (wh.isElementPresent(loadingIcon)) {

			report.addReportStep("Verify Loading Icon is displayed on delay", "Loading Icon is displayed on delay",
					StepResult.PASS);

		} else {
			report.addReportStep("Verify Loading Icon is displayed on delay", "Loading Icon is not displayed",
					StepResult.WARNING);
		}

		return this;

	}

	/**
	 * Method to click edit parts and serivces
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage clickEditPartAndServices() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(editParts)) {

			wh.clickElement(editParts);

			report.addReportStep("Click Edit Parts and services in cart", "Edit Parts and services is clicked in cart",
					StepResult.PASS);

		} else {
			report.addReportStep("Click Edit Parts and services in cart",
					"Edit Parts and services is not clicked in cart", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to click change zipcode for appliance
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickChangeZipCodeAppliance() throws Exception {

		wh.waitForPageLoaded();

		List<WebElement> lstApplFullfillments = wh.getElements(ApplFulfillmentOptions);
		System.out.println(lstApplFullfillments.size());
		if (lstApplFullfillments.size() > 1) {
			if (wh.isElementNotPresent(changeZippAppl)) {
				report.addReportStep("Verify Change link for zipcode change in cart",
						"Change link is not displayed when there are multiple appliance items in cart", StepResult.PASS);
			} else {
				report.addReportStep("Verify Change link for zipcode change in cart",
						"Change link is displayed as there are multiple appliance items in cart", StepResult.FAIL);
			}
		} else if (wh.isElementPresent(changeZippAppl)) {

			report.addReportStep("Verify Change link for appliance in cart",
					"Change link is displayed for appliance in cart", StepResult.PASS);

			wh.clickElement(changeZippAppl);

			report.addReportStep("Click Change link for zipcode change in cart", "Change link is clicked in cart",
					StepResult.PASS);

		} else {
			report.addReportStep("Click Change link for zipcode change in cart", "Change link is not present in cart",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to remove promo code from cart page
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage removePromoCart() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(removePromo)) {

			wh.clickElement(removePromo);

			report.addReportStep("Click Remove link for removing promotion in cart",
					"Remove link is clicked for removing promotion in cart", StepResult.PASS);

		} else {
			report.addReportStep("Click Remove link for removing promotion in cart",
					"Remove link is not clicked in cart", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to verify no radio button is displayed
	 * 
	 * @throws InterruptedException
	 */
	public void verifyNoRadioButton() throws InterruptedException {
		if (wh.isElementNotPresent(By.xpath("//div[@class='radio-set m-bottom-normal']/input[@type='radio']"))) {

			report.addReportStep("Verify that radio button is not dispalyed for single fulfillment",
					"Radio button is not dispalyed", StepResult.PASS);

		} else {
			report.addReportStep("Verify that radio button is not dispalyed for single fulfillment",
					"Radio button is dispalyed", StepResult.FAIL);
		}
	}

	/**
	 * Method to verify subtotal text
	 * 
	 * @throws Exception
	 */
	public void verifySubtotalTxt() throws Exception {
		if (wh.isElementPresent(subTotTxt)) {
			String subTottxt = driver.findElement(subTotTxt).getText();
			if (subTottxt.contains("Subtotal")) {
				report.addReportStep("Verify that Subtotal text is displayed in all checkout pages",
						" Subtotal text is displayed in all checkout pages", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Subtotal text is displayed in all checkout pages",
						" Subtotal text is not displayed in all checkout pages properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that Subtotal text is displayed in all checkout pages",
					" Subtotal text is not displayed in all checkout pages", StepResult.PASS);
		}
	}

	/**
	 * Method to click assembly radio button
	 * 
	 * @param arg
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickAssemblyRadioButton(String arg) throws Exception {
		String assemblyRadio = arg;
		if (assemblyRadio.contains("yes")) {
			if (wh.isElementPresent(assemblyYes)) {

				wh.clickElement(assemblyYes);
				Thread.sleep(commonData.tinyWait);

				report.addReportStep("Click Yes option for assembly sku in cart",
						"Yes option is clicked for assembly sku in cart", StepResult.PASS);

			} else {
				report.addReportStep("Click Yes option for assembly sku in cart",
						"Yes option is not clicked for assembly sku in cart", StepResult.FAIL);
			}
		} else if (assemblyRadio.contains("no")) {
			if (wh.isElementPresent(assemblyNo)) {

				wh.clickElement(assemblyNo);
				Thread.sleep(commonData.tinyWait);

				report.addReportStep("Click No option for assembly sku in cart",
						"No option is clicked for assembly sku in cart", StepResult.PASS);

			} else {
				report.addReportStep("Click No option for assembly sku in cart",
						"No option is not clicked for assembly sku in cart", StepResult.FAIL);
			}
		}

		return this;

	}

	/**
	 * Method to verify intended product displayed on shopping cart page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ShoppingCartPage verifyShoppingCartPageForIntendedProduct() throws Exception {

		wh.waitForPageLoaded();

		String modelNum = commonData.pipModelNumber;
		Boolean bItemFound = false;

		if (wh.getElementsCount(modelNumber) > 0) {

			List<WebElement> wElements = wh.getElements(modelNumber);
			for (WebElement wE : wElements) {

				if (wE.getText().contains(modelNum)) {

					report.addReportStep("Verify intended product with model number '" + modelNum
							+ "' should be displayed on Shopping cart page",
							"Shopping Cart page displayed for intended product with model num-" + modelNum,
							StepResult.PASS);
					bItemFound = true;
					break;
				}

			}

			if (!bItemFound) {
				report.addReportStep("Verify intended product with model number '" + modelNum
						+ "' should be displayed on Shopping cart page",
						"Shopping Cart page for intended product model num '" + modelNum + "' not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify intended product with model number '" + modelNum
					+ "' should be displayed on Shopping cart page",
					"Shopping Cart page for intended product model num '" + modelNum + "' not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Method to verifying that product qty displayed on cart page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public ShoppingCartPage verifyCartPageForSelectedQTY() throws Exception {

		wh.waitForPageLoaded();

		int iPipQty = commonData.pipQty;

		if (wh.isElementPresent(qtyTxtBox)) {

			int iCartQty = Integer.parseInt(wh.getAttribute(qtyTxtBox, "value"));

			if (iPipQty == iCartQty) {

				report.addReportStep("Verify Product Quantity '" + iPipQty + "' should be displayed on Cart page",
						"Product quantity '" + iPipQty + "' displayed on Cart page", StepResult.PASS);

			} else {

				report.addReportStep("Verify Product Quantity '" + iPipQty + "' should be displayed on Cart page",
						"Product quantity '" + iPipQty + "' is not displayed on Cart page", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify Product Quantity '" + iPipQty + "' should be displayed on Cart page",
					"Product quantity '" + iPipQty + "' is not displayed on Cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Verify the Express Delivery Radio button in Shopping cart page
	 * 
	 * @kxn8362
	 * @throws Exception
	 */
	public ShoppingCartPage verifyExpressDeliveryFromStoreRadioButton() throws Exception {

		if (wh.isElementPresent(expressdeliverybutton)) {

			report.addReportStep("Express Delivery From Store Label is ", "is displayed in Shipping Cart page",
					StepResult.PASS);

		} else {
			report.addReportStep("Express Delivery From Store Label is", "is not displayed in Shipping Cart page",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Description: verify PayPal button is not present in Shopping cart page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */

	public ShoppingCartPage verifyPayPalBtnNotPresentCartPage() throws Exception {

		if (wh.isElementNotPresent(btnPaypal)) {

			report.addReportStep(
					"Verify <b>Checkout with Paypal</b> button should not be displayed in the shopping cart page",
					"<b>Checkout with Paypal</b> button is NOT displayed in the shopping cart page", StepResult.PASS);

		} else {
			report.addReportStep(
					"Verify <b>Checkout with Paypal</b> button should not be displayed in the shopping cart page",
					"<b>Checkout with Paypal</b> button is displayed in the shopping cart page", StepResult.FAIL);
			// rc.terminateTestCase("Paypal Button in cart page");
		}
		return this;
	}

	/**
	 * Component to click the BODFS zipcode arrow
	 * 
	 * 
	 * @since Apr 22, 2015
	 * @author dxp8263
	 * @throws Exception
	 */
	public void clickBODFSZipCodeArrow() throws Exception {

		if (wh.isElementPresent(zipCodeAvailArrow)) {

			wh.clickElement(zipCodeAvailArrow);
			Thread.sleep(2000);
			report.addReportStep("Verify Zipcode arrow should be clicked", "Zipcode arrow is clicked", StepResult.PASS);

		} else {

			report.addReportStep("Verify Zipcode arrow should be clicked", "Zipcode arrow is not clicked",
					StepResult.FAIL);
		}

	}

	/**
	 * Description- verify read only zip code displayed and retained
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public void verifyBodfsReadOnlyZipCode() throws Exception {

		String strZipCode;

		strZipCode = commonData.bodfsZipCodeCart;
		if (strZipCode == null) {
			strZipCode = dataTable.getData("ZipCode");
		}

		if (wh.isElementPresent(readOnlyZipCode)) {

			if (wh.getText(readOnlyZipCode).contains(strZipCode)) {
				report.addReportStep("Verify read only zipcode '" + strZipCode + "' is displayed and retained",
						"Read only zip code '" + strZipCode + "' is displayed and retained", StepResult.PASS);
			} else {
				report.addReportStep("Verify read only zipcode '" + strZipCode + "' is displayed and retained",
						"Read only zipcode '" + strZipCode + "' is not retained", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify read only zipcode '" + strZipCode + "' is displayed and retained",
					"Read only zip code is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Description- verify read only zip code retained once store is changed
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public void verifyReadOnlyZipCodeRetained() throws Exception {

		String strZipCode = dataTable.getData("ZipCode");

		if (wh.isElementPresent(readOnlyZipCode)) {

			if (wh.getText(readOnlyZipCode).contains(strZipCode)) {
				report.addReportStep("Verify read only zipcode '" + strZipCode
						+ "' is retained after changing the store", "Read only zipcode '" + strZipCode
						+ "' is retained after changing the store", StepResult.PASS);
			} else {
				report.addReportStep("Verify read only zipcode '" + strZipCode
						+ "' is retained after changing the store", "Read only zipcode '" + strZipCode
						+ "' is not retained after changing the store", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify read only zipcode '" + strZipCode + "' is retained after changing the store",
					"Read only zipcode '" + strZipCode + "' is not retained after changing the store", StepResult.FAIL);
		}

	}

	/**
	 * Method to click on Yout account in cart page
	 * 
	 * @throws Exception
	 */
	public void clickYourAccountInCart() throws Exception {

		if (wh.isElementPresent(yourAccountLink)) {

			wh.clickElement(yourAccountLink);
			wh.clickElement(lnkAccountProfile);

			report.addReportStep("Verify Your Account link is clicked", "Your Account link is clicked", StepResult.PASS);

		} else {

			report.addReportStep("Verify Your Account link is clicked", "Your Account link is not clicked",
					StepResult.FAIL);
		}

	}

	/**
	 * Function To validate the BODFS_STH fulfillment in cart *
	 * 
	 * @since OCT 26 2015
	 * @author rsm8521
	 * @throws Exception
	 */

	public void verifyCartpageforBODFS_STHItem() throws Exception {

		Boolean bResult = false;
		List<WebElement> lstFullfillments = wh.getElements(cartFulfillmentOptions);
		System.out.println(lstFullfillments.size());
		for (WebElement web : lstFullfillments) {
			System.out.println(web.getText());
			if (web.getText().contains("Ship to Home") && web.getText().contains("Express Delivery from Store")) {
				if (wh.isElementPresent(shipToHomeSubSec, 2)) {
					bResult = true;
					report.addReportStep("Fullfillments should be displayed for BODFS_STH", "<b>" + web.getText()
							+ "</b> BODFS_STH fullfillments are displayed", StepResult.PASS);
					// web.findElement(expressDeliveryRadio).click();

				} else {
					report.addReportStep("Fullfillments should be displayed for BODFS_STH",
							"Fullfillments are not displayed for BODFS_STH", StepResult.FAIL);
				}
				break;
			}
		}
		if (!bResult) {
			rc.terminateTestCase("BODFS_STH Fulfillments on Cart");
		}
	}

	/**
	 * Description- click Express delivery radio button in shopping cart page
	 * 
	 * @since April 13,2015
	 * @author raj8328, modified by rsm8521 on OCT 26,2015
	 * @throws Exception
	 */
	public ShoppingCartPage clickExpressDeliverRadiobutton() throws Exception {

		if (wh.isElementPresent(expressDeliveryRadio, 2)) {
			wh.clickElement(expressDeliveryRadio);
			Thread.sleep(3000l);

			report.addReportStep("Select Express Delivery from Store radio button on cart",
					"Express Delivery radio button selected on cart", StepResult.PASS);

		} else {
			report.addReportStep("Select Express Delivery from Store radio button on cart",
					"Express Delivery radio button not selected on cart", StepResult.FAIL);
			rc.terminateTestCase("Express Delivery radio on Cart");
		}
		return this;

	}

	/**
	 * Enter invalid zip code and lookup on cart page
	 * 
	 * @since OCT 27, 2015
	 * @author rsm8521
	 * @throws Exception
	 */

	public ShoppingCartPage enterInvalidZipcodeBODFSCartpage() throws Exception {

		String strZipCode = dataTable.getData(DataColumn.ChangeZipCode);
		if (wh.isElementPresent(zipCodeBODFS, 5)) {

			wh.sendKeys(zipCodeBODFS, strZipCode);
			report.addReportStep("Enter invalid zip code in BODFS zip code field",
					"Invalid zip code entered in BODFS zip code field", StepResult.PASS);

		} else {
			report.addReportStep("Enter invalid zip code in BODFS zip code field",
					"Invalid zip code not entered, BODFS zip code field not displayed", StepResult.FAIL);
		}
		return this;

	}

	public ShoppingCartPage entervalidZipcodeBODFSCartpage() throws Exception {

		String strZipCode = dataTable.getData(DataColumn.ChangeZipCode);
		;
		if (wh.isElementPresent(zipCodeBODFS, 5)) {

			wh.sendKeys(zipCodeBODFS, strZipCode);
			report.addReportStep("Enter invalid zip code in BODFS zip code field",
					"Invalid zip code entered in BODFS zip code field", StepResult.PASS);

		} else {
			report.addReportStep("Enter invalid zip code in BODFS zip code field",
					"Invalid zip code not entered, BODFS zip code field not displayed", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to verify invalid zip code error message on cart page *
	 * 
	 * @since April 13,2015
	 * @author raj8328, modified by rsm8521 on OCT, 26,2015
	 * @throws dException
	 */
	public ShoppingCartPage verifyWrongZipocodeBODFSErrMsg() throws Exception {
		if (wh.isElementPresent(errMsgInvalidZipCode, 7)) {
			report.addReportStep(
					"Verify the error Msg : 'Please enter a valid ZIP Code' is displayed in cart page while entering Invlid zipcode for BODFS",
					"The error Msg : 'Please enter a valid ZIP Code' is displayed in cart page while entering Invlid zipcode for BODFS",
					StepResult.PASS);
		} else {
			report.addReportStep(
					"Verify the error Msg : 'Please enter a valid ZIP Code' is displayed in cart page while entering Invlid zipcode for BODFS",
					"The error Msg : 'Please enter a valid ZIP Code' is not displayed in cart page while entering Invlid zipcode for BODFS",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * To verify assembly yes message
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage verifyAssemblyYesMessage() throws Exception {
		wh.waitForPageLoaded();
		if (wh.isElementPresent(assemblyYesMsg, 7)) {
			String msg = wh.getText(assemblyYesMsg);
			if (msg.contains("Assembly times may vary and we cannot guarantee orders will be available with in 2 hours. We'll email when your order is ready")) {
				report.addReportStep("Verify Assembly message is displayed on selecting Yes", "Assembly message: "
						+ msg + "is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify Assembly message is displayed on selecting Yes", "Assembly message: "
						+ msg + "is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Assembly message is displayed on selecting Yes",
					"Assembly message is not displayed on selecting Yes", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * To clear quantity on cart page
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage clearQtyCartPg() throws Exception {

		wh.waitForPageLoaded();

		driver.findElement(By.xpath("//h1[contains(text(),'Questions? We can help')]")).click();

		wh.waitForPageLoaded();

		Thread.sleep(8000);
		if (wh.isElementPresent(Quantity, 5)) {
			String strQtyinShoppingCart = driver.findElement(Quantity).getAttribute("value");
			if (!strQtyinShoppingCart.isEmpty()) {
				report.addReportStep("Verify that quantity displayed in Cart Page", "quantity value is <b> "
						+ strQtyinShoppingCart + " </b>in cart page", StepResult.PASS);

				driver.findElement(Quantity).sendKeys("\u0008");

				Thread.sleep(2000);
				driver.findElement(Quantity).sendKeys(Keys.TAB);
				Thread.sleep(2000);
				report.addReportStep("Verify that quantity is cleared in cart", "Quantity is cleared in cart page",
						StepResult.PASS);

			}
		} else {
			report.addReportStep("Verify that quantity displayed in Cart Page",
					"Quantity  is not displayed in Cart Page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * To verify quanity error message
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage verifyQtyErrorMessage() throws Exception {
		wh.waitForPageLoaded();
		if (wh.isElementPresent(qtyErr, 7)) {
			String msg = wh.getText(qtyErr);
			if (msg.contains("The value in the quantity field is invalid. Ensure the value is a positive integer and try again")) {
				report.addReportStep("Verify Qty Error message is displayed on clearing the qty",
						"Qty error message: <b>" + msg + " </b>is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify Qty Error message is displayed on clearing the qty",
						"Qty error message: <b>" + msg + "</b> is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Qty Error message is displayed on clearing the qty",
					"Qty error message is not displayed on clearing the qty", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Verify Unit Price Cart
	 * 
	 * @throws Exception
	 */
	public void verifyUnitPriceCart() throws Exception {

		String priceType = dataTable.getData("PriceType");
		// HashMap<String,String> unitPrice = new HashMap<String,String>();
		String unitPrice = "";
		String itemType = dataTable.getData("ItemType");
		int i = 0;
		if (itemType.equalsIgnoreCase("DiffZipcodeSingleItem")) {
			i++;
		}

		for (String sku : commonData.skuList) {

			By unitPriceCart;
			By strikeThorugh = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../../descendant::h3[@class='m-bottom-xsmall strike-through']");
			unitPriceCart = By
					.xpath("//a[contains(@href,'"
							+ sku
							+ "')]/../../descendant::div[contains(@class,'col-cart-price')]/h3[contains(@class,'bold') and contains(@class,'m-bottom-xsmall')]");

			if (i == 1) {
				i++;
				continue;
			}

			if (priceType.equalsIgnoreCase("strikethro_cart")) {

				for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {
					if (sku.contains(entry.getKey())) {
						unitPrice = entry.getValue();
						break;
					}
				}

				By savingsMsg = By
						.xpath("//a[contains(@href,'"
								+ sku
								+ "')]/../../descendant::div[contains(@class,'col-cart-price')]/h3[contains(@class,'bold') and contains(@class,'text-success')]");
				getStrikeThroPriceCart(savingsMsg, unitPrice, sku);
				verifyUnitPriceStrikeThroSkuCart(strikeThorugh);
			}

			if (wh.isElementPresent(unitPriceCart, 7)) {

				unitPrice = wh.getText(unitPriceCart).replaceAll(",", "").replace("$", "");

				getProdDescription(sku);

				if (commonData.unitPrice.entrySet().isEmpty()) {
					commonData.unitPrice.put(sku, unitPrice);
				}

				for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {

					if (sku.contains(entry.getKey())) {

						commonData.itemDescPrice.put(commonData.prodDescription, entry.getValue());

						if (unitPrice.contains(entry.getValue())) {

							report.addReportStep(
									"Verify whether unit price in cart page is equivalent to Expected Price",
									"Unit price in cart page " + unitPrice + " is equivalent to Expected Price"
											+ entry.getValue(), StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether unit price in cart page is equivalent to Expected Price",
									"Unit price in cart page " + unitPrice + " is not equivalent to Expected Price"
											+ entry.getValue(), StepResult.FAIL);
						}
					}

					System.out.println(entry.getKey() + " - " + entry.getValue());

				}

			} else {
				report.addReportStep("Verify whether unit price in cart page is equivalent to Expected Price",
						"Unit price is not displayed", StepResult.FAIL);
			}

			if (priceType.equalsIgnoreCase("strikethro") || priceType.contains("promo")) {
				verifyUnitPriceStrikeThroSkuCart(strikeThorugh);
			}

		}
	}

	/**
	 * Component to change zip code for BODFS item in shopping cart page
	 * 
	 * @since Nov 3, 2015
	 * @author rsm8521
	 * @throws Exception
	 */

	public ShoppingCartPage changeZipcodeForBODFSItem() throws Exception {

		String strZipCode = dataTable.getData(DataColumn.ChangeZipCode);
		commonData.bodfsZipCodeCart = strZipCode;
		String strChangeStore = dataTable.getData(DataColumn.storeID);
		commonData.alternateStore = strChangeStore;
		if (wh.isElementPresent(zipCodeBODFS, 5)) {

			wh.sendKeys(zipCodeBODFS, strZipCode);
			report.addReportStep("Enter new zip code in BODFS zip code field",
					"New zip code entered in BODFS zip code field", StepResult.PASS);

		} else {
			report.addReportStep("Enter new zip code in BODFS zip code field",
					"New zip code not entered, BODFS zip code field not displayed", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to verify page level error message item not in stock for BODFS
	 * item
	 * 
	 * @since April 22,2015
	 * @author RXP8655
	 * @throws InterruptedException
	 */
	public ShoppingCartPage verifyItemNotInStockErrMsg() throws Exception {

		if (wh.isElementPresent(pageLevelErrMsgCart, 10)) {
			String strErrMsg = wh.getText(pageLevelErrMsgCart);

			if (strErrMsg
					.contains("Sorry, some items in your order are not in stock for delivery to the selected ZIP code. Please select another fulfillment method.")) {
				report.addReportStep(
						"Verify Page level error message <b>'some items in your order are not in stock for delivery'</b> displayed",
						"Page level error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Page level error message: 'item not in stock for delivery' displayed",
						"Page level error message <b>'some items in your order are not in stock for delivery'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify Page level error message: 'item not in stock for delivery' displayed",
					"Page level error message <b>'some items in your order are not in stock for delivery'</b> is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify zero inventory error message for BODFS item
	 * 
	 * @since April 22,2015
	 * @author RXP8655
	 * @throws InterruptedException
	 */
	public ShoppingCartPage verifyZeroInvErrorMsg() throws Exception {

		if (wh.isElementPresent(bodfsQtyErr, 10)) {
			String strErrMsg = wh.getText(bodfsQtyErr);

			if (strErrMsg.contains("0 in stock for the selected ZIP code.")) {
				report.addReportStep(
						"Verify item level error message <b>'0 in stock for the selected ZIP code.'</b> displayed",
						"Item level error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify item level error message <b>'0 in stock for the selected ZIP code.'</b> displayed",
						"Item level error message <b>'0 in stock for the selected ZIP code.'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify item level error message <b>'0 in stock for the selected ZIP code.'</b> displayed",
					"Item level error message <b>'0 in stock for the selected ZIP code.'</b> is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * verify total Price Cart
	 * 
	 * @throws Exception
	 */
	public void verifyTotalPriceCart() throws Exception {

		for (String sku : commonData.skuList) {

			By unitPriceCart = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../../descendant::h3[contains(@class,'price-section')]");
			By eleQuantity = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../../descendant::input[contains(@name,'quantity_')]");
			By applPnsPrice = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../../descendant::div[contains(@class,'col-parts-services-price')]/h3");
			By applPnsTxt = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../../descendant::h3[contains(text(),'Parts & Services')]");

			getProdDescription(sku);
			String finalPrice = wh.getText(unitPriceCart).replaceAll(",", "");
			// String prodDescr = wh.getText(prodDesc);
			String qty = wh.getAttribute(eleQuantity, "value");
			// String finalPrice;
			String appliancePnSPrice;
			double aPrice = 0;

			// To Get appliance parts and services price
			if (wh.isElementPresent(applPnsTxt, 1)) {
				List<WebElement> arrAppliancePnsPrice = driver.findElements(applPnsPrice);

				for (WebElement ele : arrAppliancePnsPrice) {
					appliancePnSPrice = wh.getText(ele).trim();
					if (!appliancePnSPrice.contains("Included in the actual price")) {
						appliancePnSPrice = appliancePnSPrice.replace("$", "");
						appliancePnSPrice = appliancePnSPrice.replace(",", "");
						aPrice = aPrice + Double.parseDouble(appliancePnSPrice);
					}
				}
			}

			String priceType = dataTable.getData("PriceType");
			if (priceType.equalsIgnoreCase("strikethro_cart")) {
				for (Entry<String, String> entry : commonData.calcUnitPrice.entrySet()) {

					if (sku.contains(entry.getKey())) {

						double quantity = Double.parseDouble(qty);
						double expectedPrice = Double.parseDouble(entry.getValue());
						expectedPrice = expectedPrice * quantity;

						if (aPrice != 0) {
							double applianceTotalPrice = expectedPrice + aPrice;
							commonData.itemTotal.put(entry.getKey(), Double.toString(applianceTotalPrice));
							commonData.itemDescPrice.put(commonData.prodDescription,Double.toString(applianceTotalPrice));
						} else {
							commonData.itemTotal.put(entry.getKey(), Double.toString(expectedPrice));
							commonData.itemDescPrice.put(commonData.prodDescription,Double.toString(expectedPrice));
						}

						if (finalPrice.contains(Double.toString(expectedPrice))) {
							report.addReportStep(
									"Verify whether total price in cart page is equivalent to Expected Price",
									"Total price in cart page " + finalPrice + " is equivalent to Expected Price"
											+ expectedPrice, StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether total price in cart page is equivalent to Expected Price",
									"Total price in cart page " + finalPrice + " is equivalent not to Expected Price"
											+ expectedPrice, StepResult.FAIL);
						}
					}
					System.out.println(entry.getKey() + " - " + entry.getValue());
				}
			} else {
				for (Entry<String, String> entry : commonData.unitPrice.entrySet()) {

					if (sku.contains(entry.getKey())) {

						double quantity = Double.parseDouble(qty);
						double expectedPrice = Double.parseDouble(entry.getValue());
						expectedPrice = expectedPrice * quantity;

						if (aPrice != 0) {
							double applianceTotalPrice = expectedPrice + aPrice;
							commonData.itemTotal.put(entry.getKey(), Double.toString(applianceTotalPrice));
							commonData.itemDescPrice.put(commonData.prodDescription,Double.toString(applianceTotalPrice));
						} else {
							commonData.itemTotal.put(entry.getKey(), Double.toString(expectedPrice));
							commonData.itemDescPrice.put(commonData.prodDescription,Double.toString(expectedPrice));
						}

						expectedPrice = Math.round(expectedPrice * 100.0) / 100.0;

						if (finalPrice.contains(Double.toString(expectedPrice))) {
							report.addReportStep(
									"Verify whether total price in cart page is equivalent to Expected Price",
									"Total price in cart page " + finalPrice + " is equivalent to Expected Price"
											+ expectedPrice, StepResult.PASS);
							break;

						} else {
							report.addReportStep(
									"Verify whether total price in cart page is equivalent to Expected Price",
									"Total price in cart page " + finalPrice + " is not equivalent to Expected Price"
											+ expectedPrice, StepResult.FAIL);
						}
					}
					System.out.println(entry.getKey() + " - " + entry.getValue());
				}
			}

		}

	}

	/**
	 * verify total Price Cart
	 * 
	 * @throws Exception
	 */
	public void verifySubTotalCart() throws Exception {

		By subTotCart = By.xpath("//h3[text()='Subtotal']/../following-sibling::div/h3[1]");
		double sum = 0;
		String itemType = dataTable.getData("ItemType");
		String priceType = dataTable.getData("PriceType");
		String subTot;
		if (wh.isElementPresent(subTotCart, 2)) {
			subTot = wh.getText(subTotCart);
			if (itemType.equalsIgnoreCase("sameitem")) {
				for (String sku : commonData.skuList) {
					/*
					 * By prodDesc = By.xpath("//a[contains(@href,'" +
					 * commonData.sku + "')]/h3"); String prodDescr =
					 * wh.getText(prodDesc);
					 */

					for (Entry<String, String> entry : commonData.itemTotal.entrySet()) {
						if (sku.contains(entry.getKey())) {
							sum += Double.parseDouble(entry.getValue());
						}
					}
					break;
				}

			} else {
				for (String sku : commonData.skuList) {

					// By prodDesc = By.xpath("//a[contains(@href,'" + sku +
					// "')]/h3");
					// String prodDescr = wh.getText(prodDesc);

					for (Entry<String, String> entry : commonData.itemTotal.entrySet()) {
						if (sku.contains(entry.getKey())) {
							sum += Double.parseDouble(entry.getValue());
						}
					}

				}
			}

			sum = Double.parseDouble(new DecimalFormat("##.##").format(sum));
			if (commonData.protPlanPrice != null) {
				sum = sum + Double.parseDouble(commonData.protPlanPrice);
			}

			String subTotal = subTot.substring(1).replace(",", "");

			commonData.subTotal = subTotal;

			if (Math.abs(sum - Double.parseDouble(subTotal)) == 0) {
				report.addReportStep(
						"Verify whether subtotal in cart page is equivalent to sum of all the prices in cart",
						"Subtotal in cart page<b> " + subTotal + "</b> is equivalent to sum of all the prices<b>" + sum
								+ "</b>", StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify whether subtotal in cart page is equivalent to sum of all the prices in cart",
						"Subtotal in cart page<b> " + subTotal + "</b> is not equivalent to sum of all the prices<b>"
								+ sum + "</b>", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify whether subtotal in cart page is equivalent to sum of all the prices in cart",
					"Subtotal in cart page is not equivalent to sum of all the prices in cart", StepResult.FAIL);
		}
		if (priceType.equalsIgnoreCase("plcc")) {
			getPLCCPromoPrice();
		}
	}

	/**
	 * Component to Increase QTY in shopping cart page
	 * 
	 * @since Nov 9,2015
	 * @author RXP8655
	 * @throws InterruptedException
	 */
	public ShoppingCartPage increaseItemQtyCartPage() throws Exception {

		if (wh.isElementPresent(qtyTxtBox, 7)) {

			String strQTY = wh.getAttribute(qtyTxtBox, "value");
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY + 1).toString();
			commonData.prodQuantity = strNewQty;
			commonData.prodQuantityFulfilment = strNewQty;
			wh.sendKeys(qtyTxtBox, strNewQty);
			Thread.sleep(4000l);
			driver.findElement(qtyTxtBox).sendKeys(Keys.TAB);
			// driver.findElement(qtyTxtBox).sendKeys(Keys.TAB);
			// wh.jsClick(txtPromoCode);
			// Thread.sleep(3000l);

			/*
			 * Click on cart button to refresh the page to get the QTY updated
			 */
			if (!commonData.desktopUserAgent) {
				if (wh.isElementPresent(By.xpath("//*[@id='thdTablet-nav-cart']"), 7)) {
					wh.clickElement(By.xpath("//*[@id='thdTablet-nav-cart']"));
					Thread.sleep(3000);
				}
			}

			if (wh.getAttribute(qtyTxtBox, "value").equals(strNewQty)) {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + strNewQty + "</b> displayed in shopping cart page",
						StepResult.PASS);
				// wh.clickElement(qtyTxtBox);
				// driver.findElement(qtyTxtBox).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + strNewQty + "</b> is not displayed in shopping cart page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Increase the product quantity in shopping cart page",
					"QTY box not displayed in shopping cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify Earliest Delivery Estimate: date is displayed
	 * 
	 * @since Apr, 2015
	 * @author SXI8382
	 * @throws InterruptedException
	 */
	public ShoppingCartPage verifyEarliestDeliveryEstimateDate() throws Exception {

		if (wh.isElementPresent(estimatedDeliveryDate, 7)) {
			String strEarliest = wh.getText(estimatedDeliveryDate);
			commonData.EarliestArrivalDate = strEarliest;
			report.addReportStep("Earliest Delivery Estimate date should be displayed", "Estimated delivery by <b>"
					+ strEarliest + " </b> is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Earliest Delivery Estimate date should be displayed",
					"Earliest Delivery Estimate date is not displayed", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * component to verify Earliest delivery date is retained
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyEarliestdeliveryDateIsRetained() throws Exception {
		String currentEarliestDeliverydate = wh.getText(estimatedDeliveryDate);
		if (currentEarliestDeliverydate.equals(commonData.EarliestArrivalDate)) {
			report.addReportStep("Earliest Delivery Estimate date should be Retained", "Estimated delivery by <b>"
					+ currentEarliestDeliverydate + " </b> is Retained", StepResult.PASS);
		} else {
			report.addReportStep("Earliest Delivery Estimate date should be Retained",
					"Earliest Delivery Estimate date is not Retained", StepResult.FAIL);
		}

	}

	/*
	 * Component to verify multiple products in cart
	 */

	public void verifyMultipleProductsIncart() {
		List<WebElement> lstItems = driver.findElements(By.xpath("//h4[contains(text(),'Model')]"));
		System.out.println(lstItems.size());
		for (WebElement eachItem1 : lstItems) {

			String title = eachItem1.getText();
			System.out.println(title);
			report.addReportStep("Capturing the product details in shopping cart page", "Captured Product is : <b>"
					+ title + "</b>", StepResult.DONE);
		}
	}

	/**
	 * Method to verify estimated subtotal is sum of all totals
	 * 
	 * @return Shopping Cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyEstimatedSubtotal() throws Exception {

		double totalSumEstimatedPrice = 0;

		String actualEstimatedSubtotal = wh.getText(estimatedSubtotal).replace(",", "");

		if (wh.isElementPresent(orderTotalRightRail)) {

			WebElement ele = driver.findElement(orderTotalRightRail);

			List<WebElement> totalPrices = ele.findElements(By.tagName("h3"));

			for (WebElement element : totalPrices) {
				String priceTotal = wh.getText(element);
				if (priceTotal.contains("$")) {
					priceTotal = priceTotal.replace("$", "");
					priceTotal = priceTotal.replace(",", "");

					totalSumEstimatedPrice += Double.parseDouble(priceTotal);
					report.addReportStep("Verify Estimated subtotal", "Estimated subtotal" + totalSumEstimatedPrice
							+ "is displayed", StepResult.DONE);
				}
			}

			totalSumEstimatedPrice = Double.parseDouble(new DecimalFormat("##.##").format(totalSumEstimatedPrice));
			String totalSumEstPrice = Double.toString(totalSumEstimatedPrice);
			commonData.strEstTotal = totalSumEstPrice;
			if (actualEstimatedSubtotal.contains(totalSumEstPrice)) {
				report.addReportStep("Verify Estimated subtotal is sum of all subtotals", "Estimated subtotal "
						+ actualEstimatedSubtotal + " is equal to Sum of all subtotals " + totalSumEstPrice,
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Estimated subtotal is sum of all subtotals", "Estimated subtotal "
						+ actualEstimatedSubtotal + " is not equal to Sum of all subtotals " + totalSumEstPrice,
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify order total price section", "Order Total price section not displayed",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * clickShipToHomeRadioButton
	 * 
	 * @throws Exception
	 */
	public void clickShipToHomeRadioButton() throws Exception {

		if (wh.isElementPresent(OnlineProd)) {
			driver.findElement(OnlineProd).click();
			wh.waitForPageLoaded();
			Thread.sleep(2000l);

			report.addReportStep("Click the Ship To Home radio button cart page",
					"Ship To Home radio button is clicked in cart page", StepResult.PASS);
			String checkedValue = driver.findElement(sthChecked).getAttribute("checked");
			if (checkedValue.contains("true")) {
				report.addReportStep("Verify the Ship To Home radio button is selcted and value is true in cart page",
						"Ship To Home radio button is selcted and value is true in cart page", StepResult.PASS);

			} else {
				report.addReportStep("Verify the Ship To Home radio button is selcted and value is true in cart page",
						"Ship To Home radio button is selcted and value is not true in cart page", StepResult.PASS);
			}

		} else {
			report.addReportStep("Click the Ship To Home radio button cart page",
					"Ship To Home radio button is not clicked in cart page", StepResult.FAIL);
		}

	}

	/**
	 * clickchangeStoreAndUpdateCart
	 * 
	 * @throws Exception
	 */
	public void clickchangeStoreAndUpdateCart() throws Exception {
		String sku = dataTable.getData(DataColumn.SKU);
		By changestoreBtn = By.xpath("//a[contains(@data-itemid,'" + sku + "')]");

		String strChangeStore = dataTable.getData(DataColumn.storeID);
		commonData.alternateStore = strChangeStore;

		// wh.ignorePopup(driver);
		if (commonData.desktopUserAgent) {
			if (wh.isElementPresent(changestoreBtn)) {

				wh.clickElement(changestoreBtn);
				if (wh.isElementPresent(zipCodeOverlay)) {
					report.addReportStep("Check Inventory Overlay", "Check Inventory Overlay opened from Cart Page",
							StepResult.PASS);
					driver.findElement(zipCodeOverlay).clear();
					driver.findElement(zipCodeOverlay).sendKeys(strChangeStore);
					Thread.sleep(commonData.smallWait);
					wh.clickElement(SearchBtnoverlayFullSite);
					Thread.sleep(commonData.smallWait);
					Thread.sleep(2000l);
					driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
							.sendKeys("1");
					commonData.prodQuantitybopis = "1";
					if (wh.isElementPresent(updateCartBtn)) {
						wh.clickElement(updateCartBtn);
					}

					else {
						wh.clickElement(updateCartBtnFullSite);
					}
					Thread.sleep(commonData.smallWait);

				} else {
					report.addReportStep("Check Inventory Overlay",
							"Check Inventory Overlay is not opened from Cart Page", StepResult.FAIL);
				}
			}
		} else {

			if (wh.isElementPresent(changestoreBtn)) {

				wh.clickElement(changestoreBtn);
				if (wh.isElementPresent(zipCodeOverlay)) {
					report.addReportStep("Check Inventory Overlay", "Check Inventory Overlay opened from Cart Page",
							StepResult.PASS);
					driver.findElement(zipCodeOverlay).clear();
					driver.findElement(zipCodeOverlay).sendKeys(strChangeStore);
					wh.clickElement(SearchBtnoverlay);
					Thread.sleep(2000);
					driver.findElement(
							By.xpath("//input[contains(@class,'quantity bopis-input bopis-qty sborder border-all border-secondary')]"))
							.sendKeys("1");
					if (wh.isElementPresent(updateCartBtn)) {
						wh.clickElement(updateCartBtn);
					}

					else {
						wh.clickElement(updateCartBtnFullSite);
					}

				} else {
					report.addReportStep("Check Inventory Overlay",
							"Check Inventory Overlay is not opened from Cart Page", StepResult.FAIL);
				}
			}
		}

	}

	/**
	 * Get product description
	 * 
	 * @throws Exception
	 */
	public ShoppingCartPage getProdDescription(String sku) throws Exception {

		By prodDesc = By.xpath("//a[contains(@href,'" + sku + "')]/h3");

		if (wh.isElementPresent(prodDesc, 7)) {
			String productTitle = driver.findElement(prodDesc).getText().substring(0, 9);
			commonData.prodDescription = productTitle.trim();
			report.addReportStep("Verify whether the product description is retrived from cart page",
					"Product description is taken from cart page", StepResult.PASS);
		}
		return this;
	}

	/**
	 * Component to compare cart Subtotal with all line item total
	 * 
	 * @since Apr, 2015
	 * @author SXI8382
	 * @throws InterruptedException
	 */

	public ShoppingCartPage compareLineItemTotalInCartWithSubTotal() throws Exception {

		Double dblLineItemTotal = 0.0;
		Double dblCartSubtotal = 0.0;

		List<WebElement> webElms = wh.getElements(lineItemTotalCart);
		By subTotCart = By.xpath("//h3[text()='Subtotal']/../following-sibling::div/h3[1]");

		if (webElms.size() > 0 && wh.isElementPresent(subTotCart)) {
			dblCartSubtotal = Double.parseDouble(wh.getText(subTotCart).trim().substring(1));
			dblCartSubtotal = Double.parseDouble(new DecimalFormat("##.##").format(dblCartSubtotal));

			for (WebElement webElm : webElms) {
				double itemTotal = Double.parseDouble(webElm.getText().trim().substring(1));
				dblLineItemTotal += itemTotal;
			}
			if (Double.compare(dblCartSubtotal, dblLineItemTotal) == 0) {
				report.addReportStep(
						"Verify <b>Subtotal</b> in cart order summary section is sum of all line item total",
						"Subtotal  : <b>" + dblCartSubtotal + "</b> is sum of all line item total", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify <b>Subtotal</b> in cart order summary section is sum of all line item total",
						"Subtotal " + dblCartSubtotal + " is not equal to Sum of all line item totals "
								+ dblLineItemTotal, StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify <b>Subtotal</b> in cart order summary section is sum of all line item total",
					"Subtotal or line item totals is not displayed in shopping cart page", StepResult.FAIL);
		}

		// dblCartSubtotal=commonData.dblSubTotalCart;

		return this;
	}

	/**
	 * Component to verify Earliest Delivery Estimate: date is displayed
	 * 
	 * @since Apr, 2015
	 * @author SXI8382
	 * @throws InterruptedException
	 */

	public ShoppingCartPage verifyCartOrderSummarySection() throws Exception {

		Double dblSubtotal = 0.0;
		Double dblPickInStore = 0.0;
		Double dblExprDelTotal = 0.0;
		Double dblEstShippTotal = 0.0;
		Double dblSalesTax = 0.0;
		Double dblApplDelivery=0.0;
		Double dblEstimatedSubTotal = 0.0;
		String strTemp = "";
		String sTempValue = "";

		List<WebElement> webElmL = wh.getElements(leftTxtOrderSummary);
		List<WebElement> webElmR = wh.getElements(rightTxtOrderSummary);

		if (webElmR.size() > 0 && webElmL.size() > 0) {

			for (int i = 0; i < webElmL.size(); i++) {
				strTemp = webElmL.get(i).getText().trim();

				if (strTemp.toLowerCase().contains("subtotal")) {
					sTempValue = webElmR.get(i).getText().trim();
					if (sTempValue.contains("$")) {
						sTempValue = sTempValue.substring(1).trim();
						String strtemp = sTempValue.split("\\.")[0].trim();
						System.out.println(strtemp.length());
						if (strtemp.length() == 2) {
							try {
								dblSubtotal = Double.parseDouble(sTempValue);
								dblSubtotal = Double.parseDouble(new DecimalFormat("##.##").format(dblSubtotal));
								report.addReportStep(
										"Verify <b>Subtotal</b> is displayed in cart order summary section",
										"Subtotal : <b>" + dblSubtotal + "</b> is displayed", StepResult.PASS);
							} catch (Exception e) {
								System.out.println("Unable to fetch the subtotal");
								report.addReportStep(
										"Verify <b>Subtotal</b> is displayed in cart order summary section",
										"Subtotal is not displayed", StepResult.FAIL);
							}
						}

						if (strtemp.length() == 3) {
							try {
								dblSubtotal = Double.parseDouble(sTempValue);
								dblSubtotal = Double.parseDouble(new DecimalFormat("###.##").format(dblSubtotal));
								report.addReportStep(
										"Verify <b>Subtotal</b> is displayed in cart order summary section",
										"Subtotal : <b>" + dblSubtotal + "</b> is displayed", StepResult.PASS);
							} catch (Exception e) {
								System.out.println("Unable to fetch the subtotal");
								report.addReportStep(
										"Verify <b>Subtotal</b> is displayed in cart order summary section",
										"Subtotal is not displayed", StepResult.FAIL);
							}
						}
					}
					commonData.dblSubTotalCart = dblSubtotal;
				} else if (strTemp.toLowerCase().contains("pick up in store")) {
					sTempValue = webElmR.get(i).getText().trim();
					if (sTempValue.contains("$")) {
						sTempValue = sTempValue.substring(1).trim();
					}
					try {
						dblPickInStore = Double.parseDouble(sTempValue);
						dblPickInStore = Double.parseDouble(new DecimalFormat("##.##").format(dblPickInStore));
						report.addReportStep(
								"Verify <b>Pickup in store</b> total is displayed in cart order summary section",
								"Pick up in store total : <b>" + dblPickInStore + "</b> is displayed", StepResult.PASS);
					} catch (Exception e) {
						if (sTempValue.contains("FREE")) {
							report.addReportStep(
									"Verify <b>Pickup in store</b> total is displayed in cart order summary section",
									"Pick up in store total is displayed as FREE", StepResult.PASS);
						} else {
							report.addReportStep(
									"Verify <b>Pickup in store</b> total is displayed in cart order summary section",
									"Pick up in store total is not displayed", StepResult.FAIL);
						}

					}
					commonData.dblPickInStoreTotalcart = dblPickInStore;

				} 
				else if (strTemp.toLowerCase().contains("appliance delivery")) {
					sTempValue = webElmR.get(i).getText().trim();
					if (sTempValue.contains("$")) {
						sTempValue = sTempValue.substring(1).trim();
					}
					try {
						dblApplDelivery = Double.parseDouble(sTempValue);
						dblApplDelivery = Double.parseDouble(new DecimalFormat("##.##").format(dblPickInStore));
						report.addReportStep(
								"Verify <b>Appliance Delivery </b> total is displayed in cart order summary section",
								"Appliance Delivery  total : <b>" + dblApplDelivery + "</b> is displayed", StepResult.PASS);
					} catch (Exception e) {
						if (sTempValue.contains("FREE")) {
							report.addReportStep(
									"Verify <b>Appliance Delivery </b> total is displayed in cart order summary section",
									"Appliance Delivery  is displayed as FREE", StepResult.PASS);
						} else {
							report.addReportStep(
									"Verify <b>Appliance Delivery </b> total is displayed in cart order summary section",
									"Appliance Delivery  is not displayed", StepResult.FAIL);
						}

					}
					commonData.dblPickInStoreTotalcart = dblApplDelivery;

				} else if (strTemp.toLowerCase().contains("estimated express delivery")) {
					sTempValue = webElmR.get(i).getText().trim();
					if (sTempValue.contains("$")) {
						sTempValue = sTempValue.substring(1).trim();
					}
					try {
						dblExprDelTotal = Double.parseDouble(sTempValue);
						dblExprDelTotal = Double.parseDouble(new DecimalFormat("##.##").format(dblExprDelTotal));
						report.addReportStep(
								"Verify <b>Estimated Express Delivery</b> charges is displayed in cart order summary section",
								"Express delivery total : <b>" + dblExprDelTotal + "</b> is displayed", StepResult.PASS);
					} catch (Exception e) {

						if (sTempValue.contains("FREE")) {
							report.addReportStep(
									"Verify <b>Estimated Express Delivery</b> charges is displayed in cart order summary section",
									"Express delivery total is displayed as FREE", StepResult.PASS);
						} else {
							report.addReportStep(
									"Verify <b>Estimated Express Delivery</b> charges is displayed in cart order summary section",
									"Express delivery total is not displayed", StepResult.FAIL);
						}
					}
					commonData.dblExpDelChargesCart = dblExprDelTotal;

				} else if (strTemp.toLowerCase().contains("estimated shipping")) {
					sTempValue = webElmR.get(i).getText().trim();
					if (sTempValue.contains("$")) {
						sTempValue = sTempValue.substring(1).trim();
					}
					try {
						dblEstShippTotal = Double.parseDouble(sTempValue);
						dblEstShippTotal = Double.parseDouble(new DecimalFormat("##.##").format(dblEstShippTotal));
						report.addReportStep(
								"Verify <b>Estimated Shipping charges</b> is displayed in cart order summary section",
								"Express delivery total : <b>" + dblEstShippTotal + "</b> is displayed",
								StepResult.PASS);
					} catch (Exception e) {
						if (sTempValue.contains("FREE")) {
							report.addReportStep(
									"Verify <b>Estimated Shipping charges</b> is displayed in cart order summary section",
									"Estimated Shipping charges is displayed as FREE", StepResult.PASS);
						} else {
							report.addReportStep(
									"Verify <b>Estimated Shipping charges</b> is displayed in cart order summary section",
									"Estimated Shipping charges is not displayed", StepResult.FAIL);
						}

					}
					commonData.dblEstShippingChargesCart = dblEstShippTotal;

				} else if (strTemp.toLowerCase().contains("sales tax")) {
					sTempValue = webElmR.get(i).getText().trim();
					if (sTempValue.contains("$")) {
						sTempValue = sTempValue.substring(1).trim();
					}
					try {
						dblSalesTax = Double.parseDouble(sTempValue);
						dblSalesTax = Double.parseDouble(new DecimalFormat("##.##").format(dblSalesTax));
						report.addReportStep("Verify <b>Sales Tax</b> is displayed in cart order summary section",
								"Sales Tax : <b>" + dblSalesTax + "</b> is displayed", StepResult.PASS);
					} catch (Exception e) {
						if (sTempValue.contains("-")) {
							report.addReportStep("Verify <b>Sales Tax</b> is displayed in cart order summary section",
									"Sales Tax is displayed as <b>---</b>", StepResult.PASS);
						} else {
							report.addReportStep("Verify <b>Sales Tax</b> is displayed in cart order summary section",
									"Sales Tax is not displayed", StepResult.FAIL);
						}

					}
					commonData.dblSalesTax = dblSalesTax;
				}
			}

			if (wh.isElementPresent(verifyEstimatedSubtotal, 2)) {
				strTemp = wh.getText(verifyEstimatedSubtotal).trim();
				String strEstSub = wh.getText(estimatedSubtotalValue).trim();
				if (strTemp.toLowerCase().contains("estimated subtotal")) {
					if (strEstSub.contains("$")) {
						sTempValue = strEstSub.substring(strEstSub.indexOf("$") + 1, strEstSub.length()).trim();
						sTempValue.length();
						System.out.println(sTempValue);
					}
					try {
						dblEstimatedSubTotal = Double.parseDouble(sTempValue);
						if (sTempValue.length() == 5) {
							dblEstimatedSubTotal = Double.parseDouble(new DecimalFormat("##.##")
									.format(dblEstimatedSubTotal));
						}
						if (sTempValue.length() == 6) {
							dblEstimatedSubTotal = Double.parseDouble(new DecimalFormat("###.##")
									.format(dblEstimatedSubTotal));
						}
						report.addReportStep(
								"Verify <b>Estimated Subtotal</b> is displayed in cart order summary section",
								"Estimated Subtotal : <b>" + dblEstimatedSubTotal + "</b> is displayed",
								StepResult.PASS);
					} catch (Exception e) {
						report.addReportStep(
								"Verify <b>Estimated Subtotal</b> is displayed in cart order summary section",
								"Estimated Subtotal is not displayed", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify <b>Estimated Subtotal</b> is displayed in cart order summary section",
							"Estimated Subtotal is not displayed", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify <b>Estimated Subtotal</b> is displayed in cart order summary section",
						"Estimated Subtotal is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify order summary section is displayed in shopping cart page",
					"Order summary section is not displayed", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Verify Unit Price Cart with certona
	 * 
	 * @throws Exception
	 */
	public void verifyUnitPriceCartWithCertona() throws Exception {
		By unitPriceCart = By.xpath("//h3[contains(@id,'unitPrice')]");
		if (wh.isElementPresent(unitPriceCart, 7)) {
			String unitPrice = wh.getText(unitPriceCart).substring(1);
			String finalPrice;
			if (unitPrice.contains(",")) {
				finalPrice = unitPrice.replaceAll(",", "");
			} else {
				finalPrice = unitPrice;
			}
			if (commonData.unitPriceDB.contains(finalPrice)) {
				report.addReportStep("Verify whether unit price in cart page is equivalent to Certona price",
						"Unit price in cart page " + unitPrice + " is equivalent to Certona price"
								+ commonData.unitPriceDB, StepResult.PASS);

			} else {
				report.addReportStep("Verify whether unit price in cart page is equivalent to Certona price",
						"Unit price in cart page " + unitPrice + " is not equivalent to Certona price"
								+ commonData.unitPriceDB, StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify whether unit price in cart page is equivalent to Certona price",
					"Unit price is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Description- Component to verify only bodfs item displayed in cart
	 * 
	 * @since Nov 12,2015
	 * @author rsm8521,
	 * @throws Exception
	 */
	public ShoppingCartPage VerifyBODFSOnlyfulfillmentInCart() throws Exception {

		By fullTypes = By.xpath("(//div[contains(@class,'cart-fulfillment-options')])[1]//label");
		if (wh.getElementsCount(fullTypes) == 1) {
			if (wh.getText(fullTypes).contains("Express Delivery from Store")) {
				report.addReportStep("Verify BODFS only item is displayed in cart", "BODFS only item is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify BODFS only item is displayed in cart", "BODFS only item is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify BODFS only item is displayed in cart", "BODFS only item is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Verify the Shipping Charge in Shopping Method section
	 * 
	 * @kxn8362
	 * @throws Exception
	 */
	public ShoppingCartPage verifyShippingCharge() throws Exception {
		if (wh.isElementPresent(shippingMethodSection, 10)) {
			if (wh.isElementPresent(standardShippingRadioBTN)) {
				String test = wh.getText(standardShippingRadioBTN);
				if (test.contentEquals(DataColumn.ShipMethod)) {
					wh.clickElement(standardShippingRadioBTN);
					report.addReportStep("Express Delivery From Store Label is ", "is displayed in Shipping Cart page",
							StepResult.PASS);
				}
				if (wh.isElementPresent(shippingCharge)) {
					String test1 = wh.getText(shippingCharge);
					if (test1.contentEquals(DataColumn.ShippingCharge)) {
						report.addReportStep("Express Delivery From Store Label is ",
								"is displayed in Shipping Cart page", StepResult.PASS);
					}
				}

			}

			report.addReportStep("Express Delivery From Store Label is ", "is displayed in Shipping Cart page",
					StepResult.PASS);

		} else {
			report.addReportStep("Express Delivery From Store Label is", "is not displayed in Shipping Cart page",
					StepResult.FAIL);
		}

		if (wh.isElementPresent(expressdeliverybutton)) {

			report.addReportStep("Express Delivery From Store Label is ", "is displayed in Shipping Cart page",
					StepResult.PASS);

		} else {
			report.addReportStep("Express Delivery From Store Label is", "is not displayed in Shipping Cart page",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * To update quantity on cart page
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage updateQtyCartPg() throws Exception {

		String qty = dataTable.getData(DataColumn.Quantity);

		wh.waitForPageLoaded();

		Thread.sleep(commonData.smallWait);
		if (wh.isElementPresent(Quantity, 5)) {
			String strQtyinShoppingCart = driver.findElement(Quantity).getAttribute("value");
			if (!strQtyinShoppingCart.isEmpty()) {
				report.addReportStep("Verify that quantity displayed in Cart Page", "quantity value is <b> "
						+ strQtyinShoppingCart + " </b>in cart page", StepResult.PASS);

				driver.findElement(Quantity).sendKeys("\u0008");
				wh.sendKeys(Quantity, qty);
				driver.findElement(By.xpath("//h1[contains(text(),'Questions? We can help')]")).click();
				Thread.sleep(commonData.smallWait);

				report.addReportStep("Verify that quantity entered is " + qty, "Quantity is entered as " + qty
						+ " in cart page", StepResult.PASS);

			}
		} else {
			report.addReportStep("Verify that quantity entered is " + qty, "Quantity is not displayed in Cart Page",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Description- Component to verify delivery price in shopping cart
	 * 
	 * @since Nov 18,2015
	 * @author rsm8521,
	 * @throws Exception
	 */
	public ShoppingCartPage getDeliveryPriceOfBODFSITem() throws Exception {

		if (wh.isElementPresent(bodfsDeliveryPrice, 7)) {
			String strDeliveryPrice = wh.getText(bodfsDeliveryPrice).trim().substring(11, 16).trim();
			System.out.println("Delivery price: " + strDeliveryPrice);
			commonData.strDeliveryPrice = strDeliveryPrice;
			report.addReportStep("Verify Bodfs delivery price is displayed", "Bodfs delivery price <b>"
					+ strDeliveryPrice + "</b> is displayed", StepResult.PASS);

		} else if (wh.isElementPresent(By
				.xpath("(//*[@class='deliveryServiceContainer'])[1]/span[contains(text(),'FREE')]"))) {
			String strDeliveryPrice = "FREE";
			System.out.println("Delivery price: " + strDeliveryPrice);
			commonData.strDeliveryPrice = strDeliveryPrice;
			report.addReportStep("Verify Bodfs delivery price is displayed", "Bodfs delivery price <b>"
					+ strDeliveryPrice + "</b> is displayed", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Bodfs delivery price is displayed", "BODFS delivery price is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description- Component to verify delivery price in shopping cart is same
	 * 
	 * @since Nov 18,2015
	 * @author rsm8521,
	 * @throws Exception
	 */
	public ShoppingCartPage verifyDelvryPriceSameAsInShoppingCartPage() throws Exception {

		String strDeliveryPrice = "";

		String strPrice = commonData.strDeliveryPrice;
		if (wh.isElementPresent(bodfsDeliveryPrice, 7)) {
			strDeliveryPrice = wh.getText(bodfsDeliveryPrice).trim().substring(11, 16).trim();
			System.out.println("Delivery price: " + strDeliveryPrice);
			if (strPrice.matches(strDeliveryPrice)) {
				report.addReportStep("Verify delivery price is same in cart", "Delivery price <b>" + strDeliveryPrice
						+ "</b> is same in cart", StepResult.PASS);

			} else {
				report.addReportStep("Verify delivery price is same in cart page", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is not same as <b>" + strPrice + "</b> in cart", StepResult.FAIL);
			}
		} else if (wh.isElementPresent(By
				.xpath("(//*[@class='deliveryServiceContainer'])[1]/span[contains(text(),'FREE')]"))) {
			strDeliveryPrice = "FREE";
			System.out.println("Delivery price: " + strDeliveryPrice);
			if (strPrice.matches(strDeliveryPrice)) {
				report.addReportStep("Verify delivery price is same in cart", "Delivery price <b>" + strDeliveryPrice
						+ "</b> is same in cart", StepResult.PASS);

			} else {
				report.addReportStep("Verify delivery price is same in cart page", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is not same as <b>" + strPrice + "</b> in cart", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify delivery price is same in cart page", "BODFS delivery price is not displayed",
					StepResult.FAIL);
		}

		/* verify delivery price in order summary same as in bodfs item price */
		String sExprDelvCharges = getEstimatedExprDelvryChargesCart();
		if (sExprDelvCharges.matches(strDeliveryPrice)) {
			report.addReportStep("Verify delivery price is same in Order Summary section", "Delivery price <b>"
					+ strDeliveryPrice + "</b> in cart is same as in Order Summary section", StepResult.PASS);
		} else {
			report.addReportStep("Verify delivery price is same in Order Summary section", "Delivery price <b>"
					+ strDeliveryPrice + "</b> in cart is not same as <b>" + sExprDelvCharges
					+ "</b> in order summary section", StepResult.FAIL);
		}

		return this;

	}

	public void verifyUnitPriceStrikeThroSkuCart(By strikeThroPrice) throws Exception {

		if (wh.isElementPresent(strikeThroPrice, 5)) {
			String strikePrice = wh.getText(strikeThroPrice);
			strikePrice = strikePrice.replaceAll(",", "");

			if (strikePrice.contains(commonData.strikeThroPriceDB)) {
				report.addReportStep("Verify strike thro price is equal to DB price", "Strike thro price" + strikePrice
						+ "is equal to DB price" + commonData.strikeThroPriceDB, StepResult.PASS);

			} else {
				report.addReportStep("Verify strike thro price is equal to DB price", "Strike thro price" + strikePrice
						+ "is not equal to DB price" + commonData.strikeThroPriceDB, StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify strike thro price is equal to DB price",
					"Strike thro price is not equal to DB price", StepResult.FAIL);
		}

	}

	/**
	 * Description- Component to verify delivery price in shopping cart is
	 * different when change the bodfs zip
	 * 
	 * @since Nov 18,2015
	 * @author rsm8521,
	 * @throws Exception
	 */
	public ShoppingCartPage verifyDelvryPriceDifferentAsInShoppingCartPage() throws Exception {
		String strDeliveryPrice = "";

		String strPrice = commonData.strDeliveryPrice;

		if (wh.isElementPresent(bodfsDeliveryPrice, 7)) {
			strDeliveryPrice = wh.getText(bodfsDeliveryPrice).trim().substring(11, 16).trim();
			System.out.println("Delivery price: " + strDeliveryPrice);
			commonData.strDeliveryPrice = strDeliveryPrice;
			if (strPrice.matches(strDeliveryPrice)) {
				report.addReportStep("Verify delivery price is different in cart", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is same in cart", StepResult.FAIL);
			} else {
				report.addReportStep("Verify delivery price is different in cart", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is different and not same as <b>" + strPrice + "</b> in cart",
						StepResult.PASS);
			}
		} else if (wh.isElementPresent(By
				.xpath("(//*[@class='deliveryServiceContainer'])[1]/span[contains(text(),'FREE')]"))) {
			strDeliveryPrice = "FREE";
			System.out.println("Delivery price: " + strDeliveryPrice);
			commonData.strDeliveryPrice = strDeliveryPrice;
			if (strPrice.matches(strDeliveryPrice)) {
				report.addReportStep("Verify delivery price is different in cart", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is same in cart", StepResult.FAIL);
			} else {
				report.addReportStep("Verify delivery price is different in cart", "Delivery price <b>"
						+ strDeliveryPrice + "</b> is different and not same as <b>" + strPrice + "</b> in cart",
						StepResult.PASS);
			}
		} else {
			report.addReportStep("Verify delivery price is different in cart", "BODFS delivery price is not displayed",
					StepResult.FAIL);
		}

		/* verify delivery price in order summary same as in bodfs item price */
		String sExprDelvCharges = getEstimatedExprDelvryChargesCart();
		if (sExprDelvCharges.matches(strDeliveryPrice)) {
			report.addReportStep("Verify delivery price is same in Order Summary section", "Delivery price <b>"
					+ strDeliveryPrice + "</b> in cart is same as in Order Summary section", StepResult.PASS);
		} else {
			report.addReportStep("Verify delivery price is same in Order Summary section", "Delivery price <b>"
					+ strDeliveryPrice + "</b> in cart is not same as <b>" + sExprDelvCharges
					+ "</b> in order summary section", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Description- Component to get estimated delivery price in shopping cart
	 * 
	 * @since Nov 18,2015
	 * @author rsm8521,
	 * @throws Exception
	 */
	public String getEstimatedExprDelvryChargesCart() throws Exception {

		/* verify delivery price in order summary */
		String sExprDelvCharges = null;
		Boolean bExprDelvChar = false;

		List<WebElement> webElmL = wh.getElements(leftTxtOrderSummary);
		List<WebElement> webElmR = wh.getElements(rightTxtOrderSummary);
		if (webElmR.size() > 0 && webElmL.size() > 0) {
			for (int i = 0; i < webElmL.size(); i++) {
				String strTemp = webElmL.get(i).getText().trim();
				if (strTemp.toLowerCase().contains("express delivery")) {
					sExprDelvCharges = webElmR.get(i).getText().trim();
					if (sExprDelvCharges.contains("$")) {
						sExprDelvCharges = sExprDelvCharges.substring(1).trim();

					} else if (sExprDelvCharges.contains("FREE")) {
						sExprDelvCharges = "FREE";

					} else {
						report.addReportStep("Verify Express Delivery price in Order Summary section",
								"Express Delivery price is not displayed in Order Summary section", StepResult.FAIL);
					}
					bExprDelvChar = true;
					break;
				}

			}
			if (!bExprDelvChar) {
				report.addReportStep("Verify Express Delivery price in Order Summary section",
						"Express Delivery price is not displayed in Order Summary section", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Express Delivery price in Order Summary section",
					"Express Delivery price is not displayed in Order Summary section", StepResult.FAIL);
		}

		return sExprDelvCharges;

	}

	/**
	 * Component to verify page level error message item not available for
	 * delivery in this Zip
	 * 
	 * @since Nov 23,2015
	 * @author RSM8521
	 * @throws Exception
	 */
	public ShoppingCartPage VerifyItemNotAvailForDelvryinZipErrMsg() throws Exception {

		if (wh.isElementPresent(pageLevelErrMsgCart, 10)) {
			String strErrMsg = wh.getText(pageLevelErrMsgCart);

			if (strErrMsg
					.contains("Sorry, item is not available for delivery in this ZIP code. Enter a valid ZIP code or select another fulfillment method.")) {
				report.addReportStep(
						"Verify Page level error message <b>'Sorry, item is not available for delivery in this ZIP code. Enter a valid ZIP code or select another fulfillment method.'</b> displayed",
						"Page level error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Page level error message <b>'Sorry, item is not available for delivery in this ZIP code. Enter a valid ZIP code or select another fulfillment method.'</b> displayed",
						"Page level error message <b>'Sorry, item is not available for delivery in this ZIP code'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify Page level error message: 'item not in stock for delivery' displayed",
					"Page level error message <b>'Sorry, item is not available for delivery in this ZIP code'</b> is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify item level err msg 'Item not available for the
	 * selected ZIP code'
	 * 
	 * @since April 22,2015
	 * @author RXP8655
	 * @throws InterruptedException
	 */
	public ShoppingCartPage verifyItemNotAvailForSelectZipErr() throws Exception {

		if (wh.isElementPresent(bodfsQtyErr, 10)) {
			String strErrMsg = wh.getText(bodfsQtyErr);

			if (strErrMsg.contains("Item not available for the selected ZIP code.")) {
				report.addReportStep(
						"Verify item level error message <b>'Item not available for the selected ZIP code.'</b> is displayed",
						"Item level error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify item level error message <b>'Item not available for the selected ZIP code.'</b> is displayed",
						"Item level error message <b>'Item not available for the selected ZIP code.'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify item level error message <b>'Item not available for the selected ZIP code.'</b> is displayed",
					"Item level error message <b>'Item not available for the selected ZIP code.'</b> is not displayed",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify item store changed when localized store is changed
	 * from header
	 * 
	 * @throws InterruptedException
	 */
	public ShoppingCartPage verifyItemStoreChanged() throws Exception {

		String zipcode = dataTable.getData(DataColumn.ChangeZipCode);

		if (wh.isElementPresent(By.xpath("//div[@class='tpl-content-wrapper']"), 5)) {

			for (String skuOption : commonData.skuList) {
				String store = wh.getText(By.xpath("//a[contains(@href,'" + skuOption
						+ "')]/../..//p[contains(@class,'reveal bb-inline buy-box-message')]"));
				if (store.contains(zipcode)) {
					report.addReportStep("Verify store is changed for the item " + skuOption, "Store is changed to "
							+ zipcode + " as the localized store changed from header", StepResult.PASS);
					String refresh = driver.getCurrentUrl();
					driver.get(refresh);
					Thread.sleep(commonData.mediumWait);
				} else {
					report.addReportStep("Verify store is changed for the item " + skuOption,
							"Store is not changed to the localized store changed from header", StepResult.FAIL);
					String refresh = driver.getCurrentUrl();
					driver.get(refresh);
					Thread.sleep(commonData.mediumWait);
				}

			}
		} else {

			report.addReportStep("Verify the store changed for the items added as the localized store changed",
					"Items are not available in cart page", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to verify item store not changed when localized store is
	 * changed from header
	 * 
	 * @throws InterruptedException
	 */
	public ShoppingCartPage verifyItemStoreNotChanged() throws Exception {

		String zipcode = dataTable.getData(DataColumn.ChangeZipCode);

		if (wh.isElementPresent(By.xpath("//div[@class='tpl-content-wrapper']"), 5)) {

			for (String skuOption : commonData.skuList) {
				String store = wh.getText(By.xpath("//a[contains(@href,'" + skuOption
						+ "')]/../..//p[contains(@class,'reveal bb-inline buy-box-message')]"));
				if (!store.contains(zipcode)) {
					report.addReportStep("Verify store is not changed for the item " + skuOption,
							"Store is not changed for " + skuOption
									+ " and remains same as the added items are different stores", StepResult.PASS);
					String refresh = driver.getCurrentUrl();
					driver.get(refresh);
					Thread.sleep(commonData.mediumWait);
				} else {
					report.addReportStep("Verify store is not changed for the item " + skuOption,
							"Store is changed to the new store as the localized store changed from header",
							StepResult.FAIL);
					String refresh = driver.getCurrentUrl();
					driver.get(refresh);
					Thread.sleep(commonData.mediumWait);
				}

			}
		} else {

			report.addReportStep("Verify the store is not changed for the items added as the localized store changed",
					"Items are not available in cart page", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to click Product Image
	 * 
	 * @author axb8034
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickProductImage() throws Exception {

		if (wh.isElementPresent(prodImageInCart, 2)) {

			wh.clickElement(prodImageInCart);

			report.addReportStep("Verify prodcut Image is clicked in cart Page",
					"Prodcut Image is clicked in cart Page", StepResult.PASS);

		} else {
			report.addReportStep("Verify prodcut Image is clicked in cart Page",
					"Prodcut Image is not clicked in cart Page", StepResult.FAIL);
		}

		String url = driver.getCurrentUrl();

		if (url.contains("?")) {
			driver.get(url + "&mcc=true");
		} else {
			driver.get(url + "?mcc=true");
		}
		Thread.sleep(commonData.littleWait);

		return this;
	}

	/**
	 * Method to remove item from cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage removeItemsFromCart() throws Exception {

		wh.waitForPageLoaded();

		int noOfItems = driver.findElements(removeLink).size();

		for (int i = 0; i < noOfItems; i++) {
			if (wh.isElementPresent(removeLink)) {
				wh.clickElement(removeLink);
				wh.waitForPageLoaded();
			}
		}

		return this;

	}

	public void clickPickUpInStoreRadioButton() throws Exception {

		if (wh.isElementPresent(eleOSPickUpInStore)) {
			driver.findElement(eleOSPickUpInStore).click();
			report.addReportStep("Click the Pick up in Store radio button cart page",
					"Pick up in Store radio button is clicked in cart page", StepResult.PASS);

		} else {
			report.addReportStep("Click the Pick up in Store radio button cart page",
					"Pick up in Store radio button is not clicked in cart page", StepResult.FAIL);
		}
		Thread.sleep(commonData.mediumWait);

	}

	public void clickShipToStoreRadioButton() throws Exception {

		if (wh.isElementPresent(eleOShipToStore)) {
			driver.findElement(eleOShipToStore).click();
			report.addReportStep("Click the Ship To Store radio button cart page",
					"Ship To Store radio button is clicked in cart page", StepResult.PASS);

		} else {
			report.addReportStep("Click the Ship To Store radio button cart page",
					"Ship To Store radio button is not clicked in cart page", StepResult.FAIL);
		}

	}

	public void getStrikeThroPriceCart(By strikeThroPrice, String unitPrice, String sku) throws Exception {
		String priceType = dataTable.getData("PriceType");

		if (priceType.contains("strikethro")) {
			String promoMsg = wh.getText(strikeThroPrice);
			promoMsg = promoMsg.replace("Save", "");
			promoMsg = promoMsg.trim();

			if (promoMsg.contains("%")) {
				promoMsg = promoMsg.replace("%", "");
				double currentPrice = Double.parseDouble(unitPrice);
				double updatedUnitPrice1 = currentPrice - ((Double.parseDouble(promoMsg) / 100) * currentPrice);
				DecimalFormat df = new DecimalFormat("#.##");
				commonData.strikeThroPriceDB = unitPrice;
				commonData.unitPriceDB = df.format(updatedUnitPrice1);
				commonData.unitPrice.put(sku, commonData.unitPriceDB);
				commonData.itemDescPrice.put(commonData.prodDescription, commonData.unitPriceDB);
				commonData.calcUnitPrice.put(sku, commonData.unitPriceDB);
			} else {
				commonData.calcUnitPrice.put(sku, unitPrice);
			}
		}

	}

	public void clickCopyCustomDetailBlinds() throws Exception {

		if (wh.isElementPresent(copyBlinds)) {
			driver.findElement(copyBlinds).click();
			report.addReportStep("Click Copy blinds link in cart page", "Copy blinds link is clicked in cart page",
					StepResult.PASS);

		} else {
			report.addReportStep("Click Copy blinds link in cart page", "Copy blinds link is not clicked in cart page",
					StepResult.FAIL);
		}

	}

	public void clickAddThisToCartBlinds() throws Exception {
		String strCurrentEnvironment = HelperClass.baseModel.runEnvironment;
		if (strCurrentEnvironment.contains("prod")) {
			strCurrentEnvironment = "homedepot.com";
		}

		else {
			strCurrentEnvironment = "hd-" + strCurrentEnvironment + ".homedepotdev.com";
		}

		if (wh.isElementPresent(addCartBlinds)) {
			driver.findElement(addCartBlinds).click();
			report.addReportStep("Click Add this to cart blinds in cart page",
					"Add this to cart blinds is clicked in cart page", StepResult.PASS);
			Thread.sleep(commonData.smallWait);

			driver.get("http://" + strCurrentEnvironment + "/MCCCheckout/Cart/ViewCart.do");
			Thread.sleep(commonData.mediumWait);

		} else {
			report.addReportStep("Click Add this to cart blinds in cart page",
					"Add this to cart blinds is not clicked in cart page", StepResult.FAIL);
		}

	}

	// ********************This section is for
	// HDPP********************************************

	/**
	 * Component to verify HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyHDPPItem() throws Exception {

		String msg_exp = dataTable.getData(DataColumn.PLAN_TXT_CART);
		// String PRC_exp= dataTable.getData(DataColumn.HDPP_PRICE);
		// String Prc_act=wh.getText(hddpPrc);
		if (wh.isElementPresent(hdppText_cart)) {
			System.out.println("present");
		}
		String MS = wh.getText(hdppText_cart);
		System.out.println(MS);

		String msg_act = wh.getText(hdppText_cart);

		if (msg_act.contains(msg_exp) && (msg_exp != "")) {
			report.addReportStep("Verify HDPP item is displayed  in Shopping cart Page",
					" HDPP item displayed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify HDPP item is displayed  in Shopping cart Page",
					"HDPP item is not displayed  in Shopping cart Page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify Add Plan option not present
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyNoAddPlan() throws Exception {

		wh.waitForPageLoaded();

		if (!wh.isElementPresent(addPlan_cart, 7)) {

			report.addReportStep("Verify Add Plan option is not displayed  in Shopping cart Page",
					" Add Plan option is not displayed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Add Plan option is not displayed  in Shopping cart Page",
					"Add Plan option is  displayed  in Shopping cart Page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify Add Plan option is present
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyAddPlan() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(addPlan_cart, 5)) {

			report.addReportStep("Verify Add Plan option is displayed  in Shopping cart Page",
					" Add Plan option displayed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Add Plan option is displayed  in Shopping cart Page",
					"Add Plan option is  not displayed  in Shopping cart Page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to click Add Plan option
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickAddPlan() throws Exception {
		wh.waitForPageLoaded();
		if (wh.isElementPresent(addPlan_cart, 7)) {

			wh.clickElement(addPlan_cart);
			Thread.sleep(5000l);
			report.addReportStep("Click Add Plan Option in cart", "Clicked Add Plan Option in cart", StepResult.PASS);
		}

		else {
			report.addReportStep("Click Add Plan Option in cart", "Add Plan Option is not clicked  in cart",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify HDPP is added
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyPlanAdded() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(hddp_added)) {

			report.addReportStep("Verify plan added  in cart", "Plan is added  in cart", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify plan added  in cart", "Plan is not added  in cart", StepResult.FAIL);
		}
		return this;
	}

	public ShoppingCartPage verifyMiniCart() throws Exception {

		wh.waitForPageLoaded();
		int exp_qt = commonData.qtyTotal;
		int act_qt = Integer.parseInt(driver.findElement(By.xpath("//*[@id='headerCart']/span")).getText());
		if (exp_qt == act_qt) {

			report.addReportStep("Verify quantity  in mini cart", "Mini cartquantity " + exp_qt + " is verified",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify quantity in mini cart", "Mini cart quantity is incorrect", StepResult.FAIL);
		}
		return this;
	}

	public ShoppingCartPage verifyMiniCartMerged() throws Exception {

		// wh.waitForPageLoaded();
		String qt = commonData.editCartCount;
		int exp_qt = Integer.parseInt(qt);
		int act_qt = Integer.parseInt(driver.findElement(By.xpath("//*[@id='headerCart']/span")).getText());
		if (exp_qt == act_qt) {

			report.addReportStep("Verify quantity  in mini cart", "Mini cartquantity " + exp_qt + " is verified",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify quantity in mini cart", "Mini cart quantity is incorrect", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Component to verify Add to list for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyAddtoList() throws Exception {

		wh.waitForPageLoaded();

		//String ID = dataTable.getData(DataColumn.PLAN_ID);
		//
		// div[@class='m-bottom-xsmall add-to-list dual-sign-in-pop-up
		// addToListFromCart' and @data-itemid='" + ID + "']
		// By addtoList = By.xpath("//a[contains(@href,'" + sku + "')]/h3");
		//By addtoList = By.xpath("//div[@class='m-bottom-xsmall add-to-list dual-sign-in-pop-up addToListFromCart' and @data-itemid='"+ ID + "']");

		if (wh.isElementPresent(addToListLink, 5)) {

			report.addReportStep("Verify Add to List option is displayed  in Shopping cart Page",
					" Add to List is displayed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Add to List option is displayed  in Shopping cart Page",
					"Add to List is not displayed  in Shopping cart Page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify remove links for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage verifyRemoveLinks() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(removeLinkPlanOption, 5)) {

			report.addReportStep("Verify Remove Link option is displayed  in Shopping cart Page",
					" Remove Link option is displayed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Remove Link  option is displayed  in Shopping cart Page",
					"Remove Link option is not displayed  in Shopping cart Page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to increase HDPP plan quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage increasePlanQuantity() throws Exception {

		String skupath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]");

		if (wh.isElementPresent(fulfilmentpath, 7)) {

			String strQTY = wh.getAttribute(fulfilmentpath, "value");
			System.out.println(strQTY);
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY + 1).toString();
			driver.findElement(fulfilmentpath).sendKeys(strNewQty);
			// wh.sendKeys(fulfilmentpath, strNewQty);
			Thread.sleep(3000l);
			driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			Thread.sleep(3000l);
			commonData.prodQuantityFulfilment = wh.getAttribute(fulfilmentpath, "value");

			if (wh.getAttribute(fulfilmentpath, "value").equals(commonData.prodQuantityFulfilment)) {

				report.addReportStep("Increase the plan quantity in shopping cart page",
						"New or Increased Quantity <b>" + commonData.prodQuantityFulfilment
								+ "</b> displayed in shopping cart page", StepResult.PASS);
				// wh.clickElement(fulfilmentpath);
				// driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Increase the plan quantity in shopping cart page",
						"New or Increased Quantity <b>" + commonData.prodQuantityFulfilment
								+ "</b> is not displayed in shopping cart page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Increase the plan quantity in shopping cart page",
					"QTY box not displayed in shopping cart page", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Component to decrease HDPP plan quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage decreasePlanQuantity() throws Exception {

		String skupath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]");

		if (wh.isElementPresent(fulfilmentpath, 7)) {

			String strQTY = wh.getAttribute(fulfilmentpath, "value");
			System.out.println(strQTY);
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY - 1).toString();
			// commonData.prodQuantityFulfilment=strNewQty;
			// wh.sendKeys(fulfilmentpath, strNewQty);
			driver.findElement(fulfilmentpath).sendKeys(strNewQty);
			Thread.sleep(2000l);
			driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			Thread.sleep(2000l);
			commonData.prodQuantityFulfilment = wh.getAttribute(fulfilmentpath, "value");
			if (wh.getAttribute(fulfilmentpath, "value").equals(commonData.prodQuantityFulfilment)) {

				// commonData.prodQuantityFulfilment=wh.getAttribute(fulfilmentpath,
				// "value");
				report.addReportStep("Decrease the plan quantity in shopping cart page",
						"New or Decreased Quantity <b>" + strNewQty + "</b> displayed in shopping cart page",
						StepResult.PASS);
				// wh.clickElement(fulfilmentpath);
				// driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Decrease the product quantity in shopping cart page",
						"New or Decreased Quantity <b>" + strNewQty + "</b> is not displayed in shopping cart page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Decrease the product quantity in shopping cart page",
					"QTY box not displayed in shopping cart page", StepResult.FAIL);
		}
		return this;

		/*
		 * String skupath = dataTable.getData(DataColumn.PlanPath);
		 * System.out.println(skupath); By fulfilmentpath =
		 * By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]");
		 * 
		 * if (wh.isElementPresent(fulfilmentpath, 7)) {
		 * 
		 * String strQTY = wh.getAttribute(fulfilmentpath, "value");
		 * System.out.println(strQTY); int iQTY = Integer.parseInt(strQTY);
		 * String strNewQty = new Integer(iQTY - 1).toString();
		 * driver.findElement(fulfilmentpath).sendKeys("0");
		 * driver.findElement(fulfilmentpath).sendKeys(strNewQty);
		 * //wh.sendKeys(fulfilmentpath, strNewQty); Thread.sleep(3000l);
		 * driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
		 * Thread.sleep(3000l);
		 * 
		 * if (wh.getAttribute(fulfilmentpath, "value").equals(strNewQty)) {
		 * 
		 * commonData.prodQuantityFulfilment=wh.getAttribute(fulfilmentpath,
		 * "value"); report.addReportStep(
		 * "Decrease the plan quantity in shopping cart page" ,
		 * "New or Decreased Quantity <b>" + commonData.prodQuantityFulfilment +
		 * "</b> displayed in shopping cart page", StepResult.PASS); //
		 * wh.clickElement(fulfilmentpath); //
		 * driver.findElement(fulfilmentpath).sendKeys(Keys.TAB); } else {
		 * report .addReportStep(
		 * "Decrease the plan quantity in shopping cart page",
		 * "New or Decreased Quantity <b>" + commonData.prodQuantityFulfilment +
		 * "</b> is not displayed in shopping cart page", StepResult.FAIL); }
		 * 
		 * } else { report.addReportStep(
		 * "Decrease the plan quantity in shopping cart page" ,
		 * "QTY box not displayed in shopping cart page", StepResult.FAIL); }
		 * return this;
		 */
	}

	/**
	 * Component to click remove link for HDPP plan item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickRemovePlanLink() throws Exception {

		if (wh.isElementPresent(removeLinkPlanOption, 5)) {

			wh.clickElement(removeLinkPlanOption);
			report.addReportStep("Click remove plan Option in cart", "Clicked remove plan Option in cart",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Click remove plan Option in cart", "Remove Plan Option is not clicked  in cart",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to click remove link for HDPP item in a mixed cart
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage clickRemovePlanLinkMixedCart() throws Exception {
		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		String strlineitemid = wh.getAttribute(planpath_mixed_cart, "data-lineitem-id");

		By planpath_mixed_cart_removeLink = By.xpath("//a[contains(@data-lineitem-id,'" + strlineitemid + "')]");

		if (wh.isElementPresent(planpath_mixed_cart_removeLink, 5)) {

			wh.clickElement(planpath_mixed_cart_removeLink);
			report.addReportStep("Click remove plan Option in cart", "Clicked remove plan Option in cart",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Click remove plan Option in cart", "Remove Plan Option is not clicked  in cart",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify HDPP item is removed
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyRemovePlanLink() throws Exception {
		wh.waitForPageLoaded();

		if (wh.isElementPresent(addPlan_cart, 5)) {

			report.addReportStep("Verify HDPP is removed  from Shopping cart Page",
					" HDPP is removed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify HDPP is removed  from Shopping cart Page",
					"HDPP is not removed  in Shopping cart Page ", StepResult.FAIL);
		}

		return this;

	}

	public ShoppingCartPage verifyRemoveItemLink() throws Exception {
		wh.waitForPageLoaded();

		if (!wh.isElementPresent(addPlan_cart, 5)) {

			report.addReportStep("Verify HDPP is removed  from Shopping cart Page",
					" HDPP is removed  in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify HDPP is removed  from Shopping cart Page",
					"HDPP is not removed  in Shopping cart Page ", StepResult.FAIL);
		}

		return this;

	}

	public void bodfstoSth() throws Exception {
		wh.waitForPageLoaded();
		List<WebElement> buttons = driver.findElements(OnlineProd);
		buttons.get(1).click();
		Thread.sleep(2000l);

		report.addReportStep("Verify HDPP is removed  from Shopping cart Page",
				" HDPP is removed  in Shopping cart Page ", StepResult.PASS);

	}

	/**
	 * Component to verify make HDPP item quantity to zero
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage zeroPlanQuantity() throws Exception {

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.isElementPresent(planpath_mixed_cart, 5)) {
			String strQtyinShoppingCart = wh.getAttribute(planpath_mixed_cart, "value");
			if (!strQtyinShoppingCart.isEmpty()) {
				driver.findElement(planpath_mixed_cart).sendKeys("\u0008");
				// driver.findElement(planpath_mixed_cart).sendKeys("0");
				driver.findElement(planpath_mixed_cart).sendKeys(Keys.TAB);
				Thread.sleep(2000l);

			}

		}
		return this;
	}

	/**
	 * Component to clear HDPP plan quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage clearPlanQuantity() throws Exception {

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.isElementPresent(planpath_mixed_cart, 5)) {
			String strQtyinShoppingCart = wh.getAttribute(planpath_mixed_cart, "value");
			if (!strQtyinShoppingCart.isEmpty()) {

				driver.findElement(planpath_mixed_cart).sendKeys("\u0008");
				Thread.sleep(5000l);
				driver.findElement(planpath_mixed_cart).sendKeys(Keys.TAB);
				Thread.sleep(5000l);

			}

		}
		return this;
	}

	/**
	 * Component to verify HDPP plan and item quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyItemAndPlanqty() throws Exception {

		String exp_quantity = commonData.prodQuantity;

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.getAttribute(planpath_mixed_cart, "value").equals(exp_quantity)) {

			report.addReportStep("Verify item and plan quantity Shopping cart Page",
					"Verified item and plan quantity Shopping cart Page  ", StepResult.PASS);
		} else {
			report.addReportStep("Verify item and plan quantity Shopping cart Page",
					"item and plan quantity are incorrect in Shopping cart Page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify plan quantity for bopis
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyPlanqtyBOPIS() throws Exception {

		String exp_quantity = commonData.prodQuantitybopis;

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.getAttribute(planpath_mixed_cart, "value").equals(exp_quantity)) {

			report.addReportStep("Verify plan quantity is increased in Shopping cart Page",
					"plan quantity is increased in Shopping cart Page  ", StepResult.PASS);
		} else {
			report.addReportStep("Verify plan quantity is increased in Shopping cart Page",
					"Plan quantity is incorrect in Shopping cart Page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify plan quantity and item quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyHDPPnItemQty() throws Exception {

		//String skupath = dataTable.getData(DataColumn.SKUPATH);
		//System.out.println(skupath);

		//String exp_quantity = driver.findElement(By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]"))
				//.getAttribute("value");
		String exp_quantity = driver.findElement(qtyTxtBox).getAttribute("value");

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.getAttribute(planpath_mixed_cart, "value").equals(exp_quantity)) {

			report.addReportStep("Verify plan quantity and item quantity are updated  in Shopping cart Page",
					"plan quantity and item quantity are updated   in Shopping cart Page  ", StepResult.PASS);
		} else {
			report.addReportStep("Verify plan quantity and item quantity are updated in Shopping cart Page",
					"plan quantity and item quantity are updated   in Shopping cart Page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify increase in plan quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyIncreasedPlanqty() throws Exception {
		wh.waitForPageLoaded();
		Thread.sleep(3000);
		String exp_quantity = commonData.prodQuantityFulfilment;

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.getAttribute(planpath_mixed_cart, "value").equals(exp_quantity)) {

			report.addReportStep("Verify plan quantity is increased in Shopping cart Page",
					"plan quantity is increased in Shopping cart Page  ", StepResult.PASS);
		} else {
			report.addReportStep("Verify plan quantity is increased in Shopping cart Page",
					"Plan quantity is incorrect in Shopping cart Page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify decrease in plan quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyDecreasedPlanqty() throws Exception {

		String exp_quantity = commonData.prodQuantityFulfilment;

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.getAttribute(planpath_mixed_cart, "value").equals(exp_quantity)) {

			report.addReportStep("Verify plan quantity is decreased in Shopping cart Page",
					"plan quantity is decreased in Shopping cart Page  ", StepResult.PASS);
		} else {
			report.addReportStep("Verify plan quantity is decreased in Shopping cart Page",
					"Plan quantity is incorrect in Shopping cart Page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify promotion for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyPromoforHDPP() throws Exception {
		String exp_plan = dataTable.getData(DataColumn.HDPP);
		String act_plan = wh.getText(hddp_added);
		if (exp_plan.equalsIgnoreCase(act_plan)) {
			report.addReportStep("Verify promotion is not applied on HDPP in Shopping Cart Page",
					"Promotion is not applied on HDPP in Shopping Cart Page", StepResult.PASS);
		} else {

			report.addReportStep("Verify promotion is not applied on HDPP in Shopping Cart Page",
					"Promotion is  applied on HDPP in Shopping Cart Page", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Component to click Learn More for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage clickLearnMore() throws Exception {

		if (wh.isElementPresent(learnMoreLinkcart, 5)) {

			wh.clickElement(learnMoreLinkcart);
			report.addReportStep("Click Learn More Link in cart", "Clicked Learn More Link in cart", StepResult.PASS);
		}

		else {
			report.addReportStep("Click Learn More Link in cart", "Learn More Link is not clicked  in cart",
					StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify Tool Tip for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyToolTip() throws Exception {

		if (wh.isElementPresent(toolTipcart, 5)) {

			report.addReportStep("Verify Tool Tip is displayed in Shopping cart Page",
					"Tool Tip is displayed in Shopping cart Page ", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Tool Tip is displayed in Shopping cart Page",
					"Tool Tip is not displayed in Shopping cart Page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify promotion is applied for HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyPromoApplyHDPP() throws Exception {

		String exp_plan = dataTable.getData(DataColumn.HDPP);
		String act_plan = wh.getText(hddp_added);
		if (exp_plan.equalsIgnoreCase(act_plan)) {
			report.addReportStep("Verify promotion is  applied on HDPP in Shopping Cart Page",
					"Promotion is  applied on HDPP in Shopping Cart Page", StepResult.PASS);
		} else {

			report.addReportStep("Verify promotion is  applied on HDPP in Shopping Cart Page",
					"Promotion is not applied on HDPP in Shopping Cart Page", StepResult.FAIL);

		}

		return this;
	}

	/**
	 * Component to decrease item quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage decreaseItemQtyCartPage() throws Exception {

		if (wh.isElementPresent(qtyTxtBox, 10)) {

			String strQTY = wh.getAttribute(qtyTxtBox, "value");
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY - 1).toString();
			commonData.prodQuantity = strNewQty;
			commonData.prodQuantityFulfilment = strNewQty;
			Thread.sleep(3000l);
			wh.sendKeys(qtyTxtBox, strNewQty);
			Thread.sleep(3000l);
			driver.findElement(qtyTxtBox).sendKeys(Keys.TAB);
			Thread.sleep(5000l);

			/*
			 * Click on cart button to refresh the page to get the QTY updated
			 */
			if (!commonData.desktopUserAgent) {
				if (wh.isElementPresent(By.xpath("//*[@id='thdTablet-nav-cart']"), 7)) {
					wh.clickElement(By.xpath("//*[@id='thdTablet-nav-cart']"));
					Thread.sleep(1000);
				}
			}

			if (wh.getAttribute(qtyTxtBox, "value").equals(strNewQty)) {

				commonData.prodQuantity = wh.getAttribute(qtyTxtBox, "value");
				report.addReportStep("Decrease the product quantity in shopping cart page",
						"New or decreased Quantity <b>" + strNewQty + "</b> displayed in shopping cart page",
						StepResult.PASS);
				// wh.clickElement(qtyTxtBox);
				// driver.findElement(qtyTxtBox).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Decrease the product quantity in shopping cart page",
						"New or Decreased Quantity <b>" + strNewQty + "</b> is not displayed in shopping cart page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Decrease the product quantity in shopping cart page",
					"QTY box not displayed in shopping cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to click Ship to Store radio button
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage clickBOSSRadiobutton() throws Exception {

		if (wh.isElementPresent(bossRadio, 2)) {
			wh.clickElement(bossRadio);

			report.addReportStep("Select Boss radio button on cart", "Boss radio button selected on cart",
					StepResult.PASS);

		} else {
			report.addReportStep("Select Boss radio button on cart", "Express Boss button not selected on cart",
					StepResult.FAIL);

		}
		return this;

	}

	/**
	 * Component to increase fulfillment quantity in mixed cart HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage increasefufilmentquantity() throws Exception {

		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//a[contains(@href,'" + skupath + "')]/../..//input[contains(@id,'quantity_')]");

		/*
		 * String
		 * x=driver.findElement(By.xpath("//input[contains(@data-unit-price,'" +
		 * skupath + "')]")).getAttribute("value"); System.out.println(x);
		 */
		if (wh.isElementPresent(fulfilmentpath, 7)) {

			String strQTY = wh.getAttribute(fulfilmentpath, "value");
			System.out.println(strQTY);
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY + 1).toString();
			driver.findElement(fulfilmentpath).clear();
			driver.findElement(fulfilmentpath).sendKeys(strNewQty);
			// wh.sendKeys(fulfilmentpath, strNewQty);
			// Thread.sleep(3000l);
			driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			Thread.sleep(3000l);
			commonData.prodQuantityFulfilment = wh.getAttribute(fulfilmentpath, "value");
			if (wh.getAttribute(fulfilmentpath, "value").equals(commonData.prodQuantityFulfilment)) {

				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + commonData.prodQuantityFulfilment
								+ "</b> displayed in shopping cart page", StepResult.PASS);
				// wh.clickElement(fulfilmentpath);
				// driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Increase the product quantity in shopping cart page",
						"New or Increased Quantity <b>" + commonData.prodQuantityFulfilment
								+ "</b> is not displayed in shopping cart page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Increase the product quantity in shopping cart page",
					"QTY box not displayed in shopping cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify decrease in fulfillment quantity in mixed cart
	 * 
	 * @author axb8034
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage decreasefufilmentquantity() throws Exception {

		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//a[contains(@href,'" + skupath + "')]/../..//input[contains(@id,'quantity_')]");

		if (wh.isElementPresent(fulfilmentpath, 7)) {

			String strQTY = wh.getAttribute(fulfilmentpath, "value");
			System.out.println(strQTY);
			int iQTY = Integer.parseInt(strQTY);
			String strNewQty = new Integer(iQTY - 1).toString();
			// commonData.prodQuantityFulfilment=strNewQty;
			// wh.sendKeys(fulfilmentpath, strNewQty);
			wh.clearElement(fulfilmentpath);
			driver.findElement(fulfilmentpath).sendKeys(strNewQty);
			Thread.sleep(2000);
			driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			Thread.sleep(2000);

			if (wh.getAttribute(fulfilmentpath, "value").equals(strNewQty)) {

				commonData.prodQuantityFulfilment = wh.getAttribute(fulfilmentpath, "value");
				report.addReportStep("Decrease the product quantity in shopping cart page",
						"New or Decreased Quantity <b>" + strNewQty + "</b> displayed in shopping cart page",
						StepResult.PASS);
				// wh.clickElement(fulfilmentpath);
				// driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			} else {
				report.addReportStep("Decrease the product quantity in shopping cart page",
						"New or Decreased Quantity <b>" + strNewQty + "</b> is not displayed in shopping cart page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Decrease the product quantity in shopping cart page",
					"QTY box not displayed in shopping cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to clear fulfillment quantity in mixed cart
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage clearfufilmentquantity() throws Exception {

		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//a[contains(@href,'" + skupath + "')]/../..//input[contains(@id,'quantity_')]");

		/*
		 * String
		 * x=driver.findElement(By.xpath("//input[contains(@data-unit-price,'" +
		 * skupath + "')]")).getAttribute("value"); System.out.println(x);
		 */
		if (wh.isElementPresent(fulfilmentpath, 7)) {

			driver.findElement(fulfilmentpath).sendKeys("\u0008");
			driver.findElement(fulfilmentpath).sendKeys("0");
			driver.findElement(fulfilmentpath).sendKeys(Keys.TAB);
			Thread.sleep(4000);
			report.addReportStep("Clear the product quantity in shopping cart page",
					" Quantity is cleared in shopping cart page", StepResult.PASS);

		} else {
			report.addReportStep("Clear the product quantity in shopping cart page",
					" Quantity is not cleared in shopping cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify fulfillment item present
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyfulfilmentquantity() throws Exception {

		String skupath = dataTable.getData(DataColumn.SKUPATH);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]");

		/*
		 * String
		 * x=driver.findElement(By.xpath("//input[contains(@data-unit-price,'" +
		 * skupath + "')]")).getAttribute("value"); System.out.println(x);
		 */
		if (wh.isElementPresent(fulfilmentpath, 7)) {

			report.addReportStep("Verify product is present in shopping cart page",
					" product is present in shopping cart page", StepResult.PASS);

		} else {
			report.addReportStep("Verify product is present in shopping cart page",
					"product is present in shopping cart page", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * Component to verify HDPP plan quantity in mixed cart
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void verifyPlanqtyMixedCart() throws Exception {

		String exp_fulfilment_quantity = commonData.prodQuantityFulfilment;

		String planpath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(planpath);
		By planpath_mixed_cart = By.xpath("//input[contains(@data-unit-price,'" + planpath + "')]");

		if (wh.getAttribute(planpath_mixed_cart, "value").equals(exp_fulfilment_quantity)) {

			report.addReportStep("Verify plan quantity in shopping cart page",
					"Verified plan quntity in shopping cart page", StepResult.PASS);

		} else {
			report.addReportStep("Verify plan quantity in shopping cart page",
					"Plan quntity is incorrect in shopping cart page", StepResult.FAIL);
		}

	}

	/**
	 * Component to change pick up store and increase quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void changePickupstoreNIncreaseQty() throws Exception {

		String sku = dataTable.getData(DataColumn.SKU);
		By changestoreBtn = By.xpath("//a[contains(@data-itemid,'" + sku + "')]");
		String strChangeStore = dataTable.getData(DataColumn.storeID);

		wh.clickElement(changestoreBtn);

		if (wh.isElementPresent(zipCodeOverlay)) {
			report.addReportStep("Check Inventory Overlay", "Check Inventory Overlay opened from Cart Page",
					StepResult.PASS);
			driver.findElement(zipCodeOverlay).clear();
			driver.findElement(zipCodeOverlay).sendKeys(strChangeStore);
			Thread.sleep(commonData.smallWait);
			if(wh.isElementPresent(SearchBtnoverlayFullSite, 2))
			{
				wh.clickElement(SearchBtnoverlayFullSite);
			}
			else
			{
				wh.clickElement(SearchBtnoverlayTabSite);	
			}
			Thread.sleep(commonData.smallWait);
			if(wh.isElementPresent(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"), 2))
			{
				driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
				.sendKeys("1");
				commonData.prodQuantitybopis = "1";
			}
			else{
				driver.findElement(By.xpath("//input[contains(@class,'quantity bopis-input bopis-qty sborder border-all border-secondary')]"))
				.sendKeys("1");
				commonData.prodQuantitybopis = "1";
			}

			if (wh.isElementPresent(updateBtn)) {
				wh.clickElement(updateBtn);
				Thread.sleep(3000l);

				report.addReportStep("Update quantity in shopping cart page",
						"Quantity is updated in shopping cart page", StepResult.PASS);
			} 
			else if(wh.isElementPresent(By.xpath("//*[@class='btn btn-primary bold btn-bopis icon-plus-symbol']"),4))
			{
				wh.clickElement(By.xpath("//*[@class='btn btn-primary bold btn-bopis icon-plus-symbol']"));
				Thread.sleep(3000l);

				report.addReportStep("Update quantity in shopping cart page",
						"Quantity is updated in shopping cart page", StepResult.PASS);
			}
			else {
				report.addReportStep("Update quantity in shopping cart page",
						"Quantity is updated  in shopping cart page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Check Inventory Overlay", "Check Inventory Overlay not opened from Cart Page",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to increase bopis quantity in overlay
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void IncreaseQtyOverlay() throws Exception {

		if (wh.isElementPresent(zipCodeOverlay)) {

			driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
					.sendKeys("2");
			commonData.prodQuantitybopis = "2";
		} else {

			report.addReportStep("Verify change store overlay", "Change store overlay is not displayed",
					StepResult.FAIL);

		}
		if (wh.isElementPresent(updateBtn)) {
			wh.clickElement(updateBtn);

			report.addReportStep("Update quantity in shopping cart page", "Quantity is updated in shopping cart page",
					StepResult.PASS);
		} else {
			report.addReportStep("Update quantity in shopping cart page",
					"Quantity is not updated  in shopping cart page", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify mini cart for HDPP removed qty
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage verifyMiniCartForHDPPRemovedQTY() throws Exception {

		wh.waitForPageLoaded();

		int iPipQty = commonData.pipQty;

		// if (wh.isElementPresent(miniCart)) {

		int miniCartQty = Integer.parseInt(wh.getText(miniCart));

		if (iPipQty == (miniCartQty - 1)) {

			report.addReportStep("Verify Cart Quantity '" + miniCartQty + "' should be displayed on Cart page",
					"Cart quantity '" + miniCartQty + "' displayed on Cart page", StepResult.PASS);

		} else {

			report.addReportStep("Verify Cart Quantity '" + miniCartQty + "' should be displayed on Cart page",
					"Cart quantity '" + miniCartQty + "' is not displayed on Cart page", StepResult.FAIL);

		}

		return this;

	}

	/**
	 * Component to verify mini cart for HDPP selected qty
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyMiniCartForHDPPSelectedQTY() throws Exception {

		wh.waitForPageLoaded();

		int iPipQty = commonData.pipQty;
		System.out.println();
		if (wh.isElementPresent(miniCart)) {

			int miniCartQty = Integer.parseInt(wh.getText(miniCart));

			if (iPipQty == (miniCartQty - 1)) {

				report.addReportStep("Verify Cart Quantity '" + miniCartQty + "' should be displayed on Cart page",
						"Cart quantity '" + miniCartQty + "' displayed on Cart page", StepResult.PASS);

			} else {

				report.addReportStep("Verify Cart Quantity '" + miniCartQty + "' should be displayed on Cart page",
						"Cart quantity '" + miniCartQty + "' is not displayed on Cart page", StepResult.FAIL);

			}

		}

		return this;

	}

	/**
	 * Component to verify guidance text before adding HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void verifyGuidanceTextBefore() throws Exception {

		if (wh.isElementPresent(guidanceTextbefore)) {

			String gdtxtBefore = wh.getText(guidanceTextbefore);

			if (gdtxtBefore.contains(dataTable.getData(DataColumn.PLAN_TXT_CART))) {

				report.addReportStep("Verify Guidance text before adding the plan on Cart page",
						"Verified Guidance text before adding the plan on Cart page", StepResult.PASS);

			} else {

				report.addReportStep("Verify Guidance text before adding the plan on Cart page",
						"Incorrect guidance text is  displayed on Cart page", StepResult.FAIL);

			}

		}
	}

	/**
	 * Component to click New List
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */
	public void clickNewList() throws Exception {

		if (wh.isElementPresent(newList)) {

			wh.clickElement(newList);
			report.addReportStep("Verify new list link is clicked", "New List  link is clicked", StepResult.PASS);
			wh.waitForPageLoaded();

		} else {

			report.addReportStep("Verify new list link is clicked", "New List  link is clicked", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify Guidance text after adding HDPP item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public void verifyGuidanceTextAfter() throws Exception {
		wh.waitForPageLoaded();
		if (wh.isElementPresent(guidanceTextafter)) {

			String gdtxtBefore = wh.getText(guidanceTextafter);

			if (gdtxtBefore.contains(dataTable.getData(DataColumn.Guidance_Txt))) {

				report.addReportStep("Verify Guidance text before adding the plan on Cart page",
						"Verified Guidance text before adding the plan on Cart page", StepResult.PASS);

			} else {

				report.addReportStep("Verify Guidance text before adding the plan on Cart page",
						"Incorrect guidance text is  displayed on Cart page", StepResult.FAIL);

			}

		}
	}

	/**
	 * Component to verify separate line item
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifySeparatelineitem() throws Exception {

		String sku = dataTable.getData(DataColumn.SKU);
		By prodDesc = By.xpath("//a[contains(@href,'" + sku + "')]/h3");

		if (wh.isElementPresent(prodDesc, 7)) {

			report.addReportStep("Verify plan as a separate line item in cart page",
					"plan is a separate line item in cart page", StepResult.PASS);
		} else {

			report.addReportStep("Verify plan as a separate line item in cart page",
					"plan is not a separate line item in cart page", StepResult.FAIL);

		}
		return this;
	}

	/**
	 * Component to verify persistent user session in shopping cart page
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage deleteUserSession() throws Exception {

		Thread.sleep(commonData.LongWait);

		Set cookies = driver.manage().getCookies();
		Iterator iter = cookies.iterator();
		while (iter.hasNext()) {
			Cookie cookie = (Cookie) iter.next();
			String strCookieName = cookie.toString();
			System.out.println(strCookieName);
			if (strCookieName.contains("WC_USERACTIVITY")) {
				System.out.println(strCookieName);
				strCookieName = strCookieName.substring(0, strCookieName.indexOf("="));
				System.out.println();
				driver.manage().deleteCookieNamed(strCookieName);
				report.addReportStep("Delete the <b>User Session cookie</b>",
						"Session cookie for the active user was <b>deleted</b>", StepResult.DONE);
			}
		}

		return this;

	}

	/**
	 * Component to verify no change in item quantity
	 * 
	 * @author nxp0367
	 * @return
	 * @throws Exception
	 */

	public ShoppingCartPage verifyNoChangeInProductQty() throws Exception {

		if (wh.isElementPresent(qtyTxtBox, 7)) {

			String strQTY = wh.getAttribute(qtyTxtBox, "value");
			// int strQTY_exp = Integer.parseInt(strQTY);

			String strQTY_act = commonData.prodQuantityFulfilment;

			if (strQTY.equals(strQTY_act)) {

				report.addReportStep("Verify Product quantity change on Cart page", "Product quantity is not changed",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify Product quantity change on Cart page", "Product quantity is  changed",
						StepResult.FAIL);
			}

		}
		return this;
	}

	public ShoppingCartPage verifyNoChangeInPlanQty() throws Exception {
		String skupath = dataTable.getData(DataColumn.PlanPath);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]");

		if (wh.isElementPresent(fulfilmentpath, 7)) {

			String strQTY = wh.getAttribute(fulfilmentpath, "value");

			// int strQTY_exp = Integer.parseInt(strQTY);

			String strQTY_act = commonData.prodQuantityFulfilment;

			if (strQTY.equals(commonData.prodQuantityFulfilment)) {

				report.addReportStep("Verify Plan quantity change on Cart page", "Product quantity is not changed",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify Plan quantity change on Cart page", "Product quantity is  changed",
						StepResult.FAIL);
			}

		}
		return this;
	}

	public ShoppingCartPage verifyEstimatedSubtotalbopis() throws Exception {
		// wh.waitForPageLoaded();
		double totalSumEstimatedPricebopis = 0;

		Thread.sleep(2000l);

		String actualEstimatedSubtotalbopis = wh.getText(estimatedSubtotalbopis).replace(",", "");

		if (wh.isElementPresent(orderTotalRightRail)) {

			WebElement ele = driver.findElement(orderTotalRightRail);

			List<WebElement> totalPrices = ele.findElements(By.tagName("h3"));

			for (WebElement element : totalPrices) {
				String priceTotal = wh.getText(element);
				if (priceTotal.contains("$")) {
					priceTotal = priceTotal.replace("$", "");
					priceTotal = priceTotal.replace(",", "");
					totalSumEstimatedPricebopis += Double.parseDouble(priceTotal);
				}
			}

			totalSumEstimatedPricebopis = Double.parseDouble(new DecimalFormat("##.##")
					.format(totalSumEstimatedPricebopis));
			String totalSumEstPricebopis = Double.toString(totalSumEstimatedPricebopis);

			if (actualEstimatedSubtotalbopis.contains(totalSumEstPricebopis)) {
				System.out.println(actualEstimatedSubtotalbopis);
				report.addReportStep("Verify Estimated subtotal is sum of all subtotals", "Estimated subtotal "
						+ actualEstimatedSubtotalbopis + " is equal to Sum of all subtotals " + totalSumEstPricebopis,
						StepResult.PASS);
			} else {
				report.addReportStep("Verify Estimated subtotal is sum of all subtotals", "Estimated subtotal "
						+ actualEstimatedSubtotalbopis + " is not equal to Sum of all subtotals "
						+ totalSumEstPricebopis, StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify order total price section", "Order Total price section not displayed",
					StepResult.FAIL);
		}
		return this;
	}

	public ShoppingCartPage verifyNoItemPlan() throws InterruptedException, Exception {
		// TODO Auto-generated method stub

		String skupath = dataTable.getData(DataColumn.SKUPATH);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//input[contains(@data-unit-price,'" + skupath + "')]");

		/*
		 * String
		 * x=driver.findElement(By.xpath("//input[contains(@data-unit-price,'" +
		 * skupath + "')]")).getAttribute("value"); System.out.println(x);
		 */
		if (wh.isElementPresent(fulfilmentpath, 7)) {

			report.addReportStep("Verfy item and plan in shopping cart page",
					" Item and plan are not cleared in shopping cart page", StepResult.FAIL);

		} else {
			report.addReportStep("Verfy item and plan in shopping cart page",
					" Item and plan are  cleared in shopping cart page", StepResult.PASS);
		}

		return this;

	}

	public ShoppingCartPage clickAddToListCartforPlan() throws Exception {
		String ID = dataTable.getData(DataColumn.PLAN_ID);
		//
		// div[@class='m-bottom-xsmall add-to-list dual-sign-in-pop-up
		// addToListFromCart' and @data-itemid='" + ID + "']
		// By addtoList = By.xpath("//a[contains(@href,'" + sku + "')]/h3");
		By addtoListPlan = By
				.xpath("//div[@class='m-bottom-xsmall add-to-list dual-sign-in-pop-up addToListFromCart' and @data-itemid='"
						+ ID + "']");

		if (wh.isElementPresent(addtoListPlan)) {

			wh.clickElement(addtoListPlan);
			report.addReportStep("Click Add to list option for plan in cart page",
					"Add to list option for plan is clciked", StepResult.PASS);

		} else {
			report.addReportStep("Verify Add to list option in cart page", "Add to list option is not present",
					StepResult.FAIL);
		}

		return this;

	}

	public void getPLCCPromoPrice() throws Exception {
		if (wh.isElementPresent(promoPrices)) {

			List<WebElement> promoPrice = driver.findElements(promoPrices);
			for (WebElement price : promoPrice) {

				if (wh.getText(price).contains("-")) {
					commonData.plccPrice = wh.getText(price);
					commonData.plccPrice = commonData.plccPrice.substring(1).replace(",", "");
					commonData.plccPrice = commonData.plccPrice.substring(1).replace(",", "");
					report.addReportStep("Verify PLCC promo price is displayed", "PLCC promo price is saved",
							StepResult.PASS);
				}

			}

		} else {
			report.addReportStep("Verify PLCC promo price is displayed", "PLCC promo price is not displayed",
					StepResult.FAIL);
		}
	}

	public void clickEditCustomDetailBlinds() throws Exception {

		if (wh.isElementPresent(editBlinds)) {
			driver.findElement(editBlinds).click();
			report.addReportStep("Click Edit blinds link in cart page", "Edit blinds link is clicked in cart page",
					StepResult.PASS);

		} else {
			report.addReportStep("Click Edit blinds link in cart page", "Edit blinds link is not clicked in cart page",
					StepResult.FAIL);
		}

	}

	public void updateRoomSelectorBlinds() throws Exception {

		if (wh.isElementPresent(roomSelectorUpdate)) {
			driver.findElement(roomSelectorUpdate).click();
			report.addReportStep("Click different room option", "Option selected", StepResult.PASS);

		} else {
			report.addReportStep("Click different room option", "Option not selected", StepResult.FAIL);
		}

	}

	public void clickUpdateCartBlinds() throws Exception {

		if (wh.isElementPresent(updateCartBlinds)) {
			driver.findElement(updateCartBlinds).click();
			report.addReportStep("Click Update Cart button", "Update Cart button clicked", StepResult.PASS);

		} else {
			report.addReportStep("Click Update Cart button", "Update Cart button not clicked", StepResult.FAIL);
		}

	}

	public ShoppingCartPage clickChangeLinkBODFSItem() throws Exception {

		if (wh.isElementPresent(changeZipCodeBODFS, 5)) {

			wh.clickElement(changeZipCodeBODFS);
			report.addReportStep("Click change zip code for BODFS item", "Change zip code clicked for BODFS item",
					StepResult.PASS);

		} else {
			wh.clickElement(zipCodeAvailArrow);
			if (wh.isElementPresent(changeZipCodeBODFS, 5)) {

				wh.clickElement(changeZipCodeBODFS);
				report.addReportStep("Click change zip code for BODFS item", "Change zip code clicked for BODFS item",
						StepResult.PASS);

			} else {
				report.addReportStep("Click change zip code for BODFS item",
						"Change zip code not clicked for BODFS item", StepResult.FAIL);
			}

		}
		return this;

	}

	public ShoppingCartPage verifyStoreUpdatedInCart() throws Exception {

		// String newStore = dataTable.getData(DataColumn.NewStore);
		String newStore = dataTable.getData(DataColumn.storeID);

		if (wh.isElementPresent(updatedStoretxt, 5)) {

			String updatedStr = wh.getText(updatedStoretxt);
			if (updatedStr.contains(newStore)) {

				report.addReportStep("Verify the localized store is updated in cart",
						"Localized store is updated in cart", StepResult.PASS);
			} else {
				report.addReportStep("Verify the localized store is updated in cart",
						"Localized store is not updated in cart", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify the localized store is updated in cart",
					"Store detail is not displayed in cart", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to verify page level error message item not in stock for BODFS
	 * item
	 * 
	 * @since April 22,2015
	 * @author RXP8655
	 * @throws InterruptedException
	 */
	public void verifyLimitedInStockErrMsg() throws Exception {

		if (wh.isElementPresent(pageLevelErrMsgCart, 10)) {
			String strErrMsg = wh.getText(pageLevelErrMsgCart);
			if (strErrMsg
					.contains("Sorry, some items in your order have limited availability for delivery in the selected ZIP code. Please update your quantity or select another fulfillment method.")) {
				report.addReportStep(
						"Verify Page level error message <b>'some items in your order are limited in stock for delivery'</b> displayed",
						"Page level error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify Page level error message: 'some items in your order are limited in stock for delivery' displayed",
						"Page level error message <b>'some items in your order are not in stock for delivery'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify Page level error message: 'item not in stock for delivery' displayed",
					"Page level error message <b>'some items in your order are not in stock for delivery'</b> is not displayed",
					StepResult.FAIL);
		}

	}

	public ShoppingCartPage verifyLimitedItemForSelectZipErr() throws Exception {
		if (wh.isElementPresent(bodfsQtyErr, 10)) {
			String strErrMsg = wh.getText(bodfsQtyErr);

			if (strErrMsg.contains("items are in stock in your area.")) {
				report.addReportStep(
						"Verify item level error message <b>'Only X items are in stock in your area.'</b> is displayed",
						"Item level error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify item level error message <b>'Only X items are in stock in your area.'</b> is displayed",
						"Item level error message <b>'Only X items are in stock in your area.'</b> is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify item level error message <b>'Only X items are in stock in your area.'</b> is displayed",
					"Item level error message <b>'Only X items are in stock in your area.'</b> is not displayed",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to verify Promo section for each item in cart page
	 * 
	 * @throws Exception
	 */
	public void verifyPromoForEachItem() throws Exception {
		if (wh.isElementPresent(By.xpath("//*[@class='promo-msg-wrap itemLevelPromoSection']"), 5)) {
			List<WebElement> strSKu = driver.findElements(By.xpath("//*[@class='bold break m-right-small']"));
			System.out.println(strSKu.size());
			List<WebElement> strPromo = driver
					.findElements(By.xpath("//*[@class='promo-txt-container m-right-small']"));
			System.out.println(strPromo.size());
			if (strSKu.size() == strPromo.size()) {
				report.addReportStep("Promo section displayed for each item",
						"Promo Section is displayed for each item", StepResult.PASS);
			} else {
				report.addReportStep("Promo section displayed for each item",
						"Promo Section is not displayed for each item", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Promo section displayed for each item", "Coupon not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Components to verify See details link in Promo section for each item in
	 * cart page
	 * 
	 * @throws Exception
	 */

	public void verifySeeDetailsInPromoSection() throws Exception {
		if (wh.isElementPresent(By.xpath("//*[@class='pod-promotion overflowHidden']"), 4)) {
			report.addReportStep("Verify Promotion section displayed in cart page",
					"Promotion section displayed in cart page", StepResult.PASS);

			// Verify See details link
			if (wh.isElementPresent(By.xpath("//*[@class='tip-opener-mcc text-primary bold']"), 5)) {
				if (driver.findElement(By.xpath("//*[@class='tip-opener-mcc text-primary bold']")).getText()
						.contains("see details")) {
					report.addReportStep("Verify see deails link displayed in promo section",

					"See deails link is displayed in promo section", StepResult.PASS);
				}
			} else {
				report.addReportStep("Verify see deails link displayed in promo section",
						"See deails link is displayed in promo section", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Promotion section displayed in cart page",
					"Promotion section not displayed in cart page", StepResult.FAIL);
		}

	}

	public void verifyYouSavedSection() throws Exception {
		if ((wh.isElementPresent(By.xpath("//*[contains(@class,'cartYouSave')]"), 5))
				|| (wh.isElementPresent(By.id("chk-you-saved-div"), 5))
				|| (wh.isElementPresent(
						By.xpath("//*[@class='order-summary  clear']//div[@class='bottom-pod']//*[contains(text(),'You Saved')]"),
						5))) {
			String strSavedAmt = driver.findElement(
					By.xpath("//*[@class='order-summary  clear']//div[@class='right']//h3[2]")).getText();
			System.out.println(strSavedAmt);

			report.addReportStep("Verify that You saved section is displayed",
					"The section <b> is displayed with amount :" + strSavedAmt + "</b>", StepResult.PASS);
		} else {
			report.addReportStep("Verify that You saved section is displayed", "The section <b> is not displayed</b>",
					StepResult.FAIL);
		}

	}

	/**
	 * To Verify the lowest cost is displayed under the delivery fulfillment in
	 * shopping cart page
	 * 
	 */
	public void verifySceduleDeliveryLabel() {
		String strtemp = driver
				.findElement(
						By.xpath("//label[contains(@for,'scheduleDelivery_')]|//*[contains(text(),'As Low as')]|//*[contains(text(),'Express Delivery from')]"))
				.getText();
		System.out.println(strtemp);
		if (strtemp.contains("As Low") || strtemp.contains("Express Delivery from Store")) {
			report.addReportStep(
					"Verify the lowest cost is displayed under the delivery fulfillment in shopping cart page ",
					"The lowest cost Text : " + strtemp
							+ " is displayed under the delivery fulfillment in shopping cart page ", StepResult.PASS);
		} else {
			report.addReportStep(
					"Verify the lowest cost is displayed under the delivery fulfillment in shopping cart page ",
					"The lowest cost Text : " + strtemp
							+ " is not displayed under the delivery fulfillment in shopping cart page ",
					StepResult.PASS);
		}
	}

	/**
	 * Component to verify express delivery from store label in how to get it
	 * section
	 * 
	 * @throws Exception
	 */
	public void verifyExpressDeliveryLabelInHowToGetSection() throws Exception {
		if (wh.isElementPresent(ExpressDeliveryFromStroreLabel, 5)) {
			if (wh.isElementPresent(ExpressDeliveryFromStroreLabel, 5)) {
				report.addReportStep("Express Delivery Label", "Express Delivery Label is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Express Delivery Label", "Express Delivery Label is not displayed",
						StepResult.FAIL);
			}
		} else if (wh.isElementPresent(By.xpath("(//*[@class='tpl-content overflowHidden']//h4)[3]"), 5)) {
			if (wh.isElementPresent(By.xpath("(//*[@class='tpl-content overflowHidden']//h4)[3]"))) {
				report.addReportStep("Express Delivery Label", "Express Delivery Label is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Express Delivery Label", "Express Delivery Label is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Express Delivery Label", "BODFS Item is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify express delivery from store label order total section
	 * 
	 * @throws Exception
	 */
	public void verifyExpressDeliveryLabelInOrderTotalSection() throws Exception {
		if (wh.isElementPresent(ExpressDeliveryLabelInOrderSummarySection, 10)) {
			if (wh.isElementPresent(ExpressDeliveryLabelInOrderSummarySection, 10)) {
				report.addReportStep("Estimated Express Delivery", "Estimated Express Delivery is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Estimated Express Delivery", "Estimated Express Delivery is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Express Delivery Label", "BODFS Item is not displayed", StepResult.FAIL);
		}
	}

	public void verifyBOPIS() throws Exception {
		if (wh.isElementPresent(itemInCart)) {
			List<WebElement> lst = driver.findElements((itemInCart));
			System.out.println(lst.size());
			for (WebElement ele1 : lst) {
				String strBOpis = wh.getText(ele1);
				if (strBOpis.contains("Pick Up In Store")) {
					report.addReportStep("verify BOPIS item in cart", "Only BOPIS item is added to cart",
							StepResult.PASS);
				} else {
					report.addReportStep("verify BOPIS item in cart", "Only BOPIS item is not added to cart",
							StepResult.FAIL);
				}
			}

			report.addReportStep("verify item in cart", "Item is added to cart", StepResult.PASS);
		} else {
			report.addReportStep("verify item in cart", "No item is added to cart", StepResult.FAIL);
		}
	}

	public void verifyBOSS() throws Exception {
		if (wh.isElementPresent(itemInCart)) {
			List<WebElement> lst = driver.findElements((itemInCart));
			System.out.println(lst.size());
			for (WebElement ele1 : lst) {
				String strBOpis = wh.getText(ele1);
				if (strBOpis.contains("Ship to Store")) {
					report.addReportStep("verify BOSS item in cart", "Only BOSS item is added to cart", StepResult.PASS);
				} else {
					report.addReportStep("verify BOSS item in cart", "Only BOSS item is not added to cart",
							StepResult.FAIL);
				}
			}

			report.addReportStep("verify item in cart", "Item is added to cart", StepResult.PASS);
		} else {
			report.addReportStep("verify item in cart", "No item is added to cart", StepResult.FAIL);
		}
	}

	public void verifySTH() throws Exception {
		if (wh.isElementPresent(itemInCart)) {
			List<WebElement> lst = driver.findElements((itemInCart));
			System.out.println(lst.size());
			for (WebElement ele1 : lst) {
				String strBOpis = wh.getText(ele1);
				if (strBOpis.contains("Ship to Home")) {
					report.addReportStep("verify STH item in cart", "Only STH item is added to cart", StepResult.PASS);
				} else {
					report.addReportStep("verify STH item in cart", "Only STH item is not added to cart",
							StepResult.FAIL);
				}
			}

			report.addReportStep("verify item in cart", "Item is added to cart", StepResult.PASS);
		} else {
			report.addReportStep("verify item in cart", "No item is added to cart", StepResult.FAIL);
		}
	}

	/**
	 * Verify that the custom attributes are displayed in the sequence--> Window
	 * name, Width, Height, color
	 * 
	 * @throws Exception
	 */
	public void verifyCustomProdIncartPg() throws Exception {
		if (wh.isElementPresent(CustomAttrName, 4)) {

			String[] strAttributes = { "window name", "width", "height", "color" };
			List<WebElement> webAttributes = driver.findElements(CustomAttrName);
			int intCount = 0;
			for (WebElement webAttribute : webAttributes) {
				String strTempValue = "No Value";
				try {
					strTempValue = webAttribute.findElement(By.xpath("//*[@class='blinds-config']//span[2]")).getText();
					System.out.println(strTempValue);
				} catch (Exception e) {
					System.out.println("Unable to find the Custom attribute value");
				}
				if (webAttribute.getText().toLowerCase().contains(strAttributes[intCount])) {
					report.addReportStep("Verify that <b>Attribute " + (intCount + 1) + "</b> is <b>"
							+ strAttributes[intCount] + "</b>", "Custom Attribute <b>" + strAttributes[intCount]
							+ "</b> is displayed with value <b>" + strTempValue + "</b>", StepResult.PASS);
				}

				else {
					report.addReportStep("Verify that <b>Attribute " + (intCount + 1) + "</b> is <b>"
							+ strAttributes[intCount] + "</b>", "Custom Attribute 1 is displayed as <b>"
							+ strAttributes[intCount] + "</b> with value <b>" + strTempValue + "</b>", StepResult.FAIL);
				}
				intCount++;
				break;

			}

		} else if (wh.isElementNotPresent(CustomAttrName)) {
			report.addReportStep("Non Blinds Items should be added to the cart page.",
					"Non Blinds Items are added in cart page", StepResult.PASS);
		} else {
			report.addReportStep("Verify that Custom Attributes are displayed in cart page",
					"<b>Custom Attributes are not displayed <b>", StepResult.FAIL);

		}

	}

	/**
	 * Component to click the 'ViewAllCustomdetails' link in cart page for
	 * blinds item
	 * 
	 * @throws Exception
	 * 
	 */
	public void clickViewAllCustomDetails() throws Exception {

		String strSubIteration = dataTable.getData(DataColumn.SubIteration);
		if (wh.isElementPresent(By.cssSelector("a[class='blinds-custom-details bold']"), 10)) {
			List<WebElement> webLinks = driver.findElements(By.cssSelector("a[class='blinds-custom-details bold']"));
			try {
				int intCount = 0;
				boolean blnClicked = false;
				for (WebElement webylinks : webLinks) {
					if (strSubIteration.contains("" + (intCount + 1))) {
						Thread.sleep(2000);
						wh.jsClick(By.cssSelector("a[class='blinds-custom-details bold']"));
						report.addReportStep("Click the 'View All Custom details' link for the Item " + strSubIteration
								+ "", "Link Clicked", StepResult.PASS);
						blnClicked = true;
						break;
					}
					intCount++;
				}
				if (!blnClicked) {
					report.addReportStep("Click the 'View All Custom details' link for the item " + strSubIteration
							+ "", "Link not Clicked", StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep("Click the 'View All Custom details' link", "Link not Clicked", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}

		}

		else {
			report.addReportStep("Click the 'View All Custom details' link", "Link not found", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * Component to verify copy link is clicked in cart page
	 * 
	 * @throws Exception
	 */
	public void CopyDesignLink() throws Exception {

		if (wh.isElementPresent(CopyDesignLink, 4)) {
			driver.findElement(CopyDesignLink).click();
			Thread.sleep(1000);
			report.addReportStep("Click the copy design link in cart page", "copy design link is clicked in cart page",
					StepResult.PASS);

		} else {
			report.addReportStep("Click the copy design link in cart page",
					"copy design link is not clicked in cart page", StepResult.FAIL);
		}

	}

	/**
	 * Component to click the order my blinds button in configurator page
	 * 
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public boolean clickOrderMyBlindsButton() throws Exception {
		if (wh.isElementPresent(OrderMyBlindsButton, 5)) {
			try {
				wh.jsClick(OrderMyBlindsButton);
				Thread.sleep(7000);

				try {
					driver.switchTo().alert().accept();
					report.addReportStep(
							"Verify that there is no alert displayed after 'order my blinds' button is clicked",
							"Alert is displayed. Quiting the Test case", StepResult.FAIL);
					commonData.blnGracefulExit = true;
					return false;
				} catch (Exception e) {
					report.addReportStep("Click 'Order My blinds' button", "Button  clicked", StepResult.PASS);
					return true;
				}

			} catch (Exception e) {
				report.addReportStep("Click 'Order My blinds' button", "Button not clicked", StepResult.FAIL);
				commonData.blnGracefulExit = true;
				return false;
			}
		} else {
			report.addReportStep("Click 'Order My blinds' button", "Button not Found", StepResult.FAIL);
			commonData.blnGracefulExit = true;
			return false;
		}

	}

	public void updateColorInConfiguratorPage() throws Exception {

		if (wh.isElementPresent(SwatchImage, 5)) {
			try {

				String strColor = driver.findElement(Color).getText();
				System.out.println(strColor);
				driver.findElement(Color).click();
				commonData.strCartColor = strColor;
				report.addReportStep("Click the  available Color option", "Color option: <b> " + strColor
						+ "</b> is updated", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Click the  available Color option", "Unable to click the button", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else if (wh.isElementPresent(By.xpath("//div[@id='colors']/div/div/div/div[2]"), 2)) {
			try {

				driver.findElement(By.xpath("//div[@id='colors']/div/div/div/div[2]")).click();
				String strColor = driver.findElement(By.xpath("//div[@id='colors']/div/div/div/div[2]")).getText();
				System.out.println(strColor);
				commonData.strCartColor = strColor;

				report.addReportStep("Click the  available Color option", "Color option: <b> " + strColor
						+ "</b> is updated", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Click the  available Color option", "Unable to click the button", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else {
			report.addReportStep("Click the  available Color option", "Unable to click the color", StepResult.FAIL);
		}
	}

	/**
	 * Method to update width in configurator page for blinds item
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public void updateWidthInConfiguratorPage() throws Exception {
		if (wh.isElementPresent(configwidth, 2)) {
			try {
				// driver.findElement(By.name("heightwhole")).click();
				Select selectBox = new Select(driver.findElement(configwidth));
				selectBox.selectByIndex(25);

				System.out.println(selectBox.getFirstSelectedOption().getText());

				commonData.strWidthWhole = selectBox.getFirstSelectedOption().getText();

				// driver.findElement(By.cssSelector("option[value="40"]")).click();
				report.addReportStep("Click the  available width option", "Width option "
						+ selectBox.getFirstSelectedOption().getText() + " is  updated", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Click the  available width option", "Unable to click the button", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else {
			report.addReportStep("Click the  available width option", "Unable to click the button", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * Component to displayed product details in cart page
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyCustomBlindProductsInCart() throws Exception {
		if (wh.isElementPresent(By.xpath("//div[contains(@class,'shopCartDescInfo')]"), 3)) {
			List<WebElement> lstProdDetails = driver.findElements(By
					.xpath("//div[contains(@class,'shopCartDescInfo')]"));

			for (WebElement prodDetails : lstProdDetails) {
				String strProdDetails = prodDetails.getText();
				report.addReportStep("Verify Items should be added to the cart page.", "<b>" + strProdDetails
						+ "</b> items are added to cart", StepResult.PASS);
			}

		} else {
			report.addReportStep("Verify Items should be added to the cart page.",
					"Items are not displayed in cart page", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify that the color seleted in config page is updated in
	 * the cart page
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public void verifyColorUpdatedInCart() throws Exception {
		if (wh.isElementPresent(By.xpath("//*[@class='blinds-custom-config']//h4[4]//span[2]"), 4)) {
			String strCartColor = driver.findElement(By.xpath("//*[@class='blinds-custom-config']//h4[4]//span[2]"))
					.getText();
			System.out.println(strCartColor);

			if (commonData.strCartColor.contains(strCartColor)) {

				report.addReportStep("Verify that the Color <b>" + commonData.strCartColor
						+ "</b> selected in config page is updated in cart page product section",
						"The value is displayed in cart page product description", StepResult.PASS);
			} else {
				report.addReportStep("Verify that the Color <b>" + commonData.strCartColor
						+ "</b> selected in config page is updated in cart page product section",
						"The value is not displayed in cart page product description", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify that the Color selected in config page is updated in cart page product section",
					"No previously saved value available to compare the value available in product description",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify that the width seleted in config page is updated in
	 * the cart page
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public void verifyWidthUpdatedInCart() throws Exception {
		if (wh.isElementPresent(width, 2)) {
			String strWidthWhole = driver.findElement(width).getText();
			System.out.println(strWidthWhole);

			if (strWidthWhole.contains(commonData.strWidthWhole)) {

				report.addReportStep("Verify that the Width whole <b>" + commonData.strWidthWhole
						+ "</b> selected in config page is updated in cart page product section",
						"The value is displayed in cart page product description", StepResult.PASS);
			} else {
				report.addReportStep("Verify that the Width whole <b>" + commonData.strWidthWhole
						+ "</b> selected in config page is updated in cart page product section",
						"The value is not displayed in cart page product description", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify that the Width selected in config page is updated in cart page product section",
					"No previously saved value available to compare the value available in product description",
					StepResult.FAIL);
		}

	}

	/**
	 * Verify that the custom attributes are displayed in the sequence--> Window
	 * name, Width, Height, color
	 * 
	 * @throws Exception
	 */
	public void verifyCustomAttrSequence() throws Exception {
		if (wh.isElementPresent(CustomAttrName, 3)) {

			String[] strAttributes = { "window name", "width", "height", "color" };
			List<WebElement> webAttributes = driver.findElements(By.xpath("//*[@class='blinds-config']"));

			int intCount = 0;

			for (WebElement webAttribute : webAttributes) {
				String strTempValue = "No Value";
				String strAtt = webAttributes.get(intCount).findElement(By.xpath(".//span[1]")).getText();
				if (strAtt.toLowerCase().contains(strAttributes[intCount])) {
					try {
						strTempValue = webAttributes.get(intCount).findElement(By.xpath(".//span[2]")).getText();
					} catch (Exception e) {
						System.out.println("Unable to find the Custom attribute value");
					}
					report.addReportStep("Verify that <b>Attribute " + (intCount + 1) + "</b> is <b>"
							+ strAttributes[intCount] + "</b>", "Custom Attribute <b>" + strAttributes[intCount]
							+ "</b> is displayed with value <b>" + strTempValue + "</b>", StepResult.PASS);
				} else {
					report.addReportStep("Verify that <b>Attribute " + (intCount + 1) + "</b> is <b>"
							+ strAttributes[intCount] + "</b>", "Custom Attribute 1 is displayed as <b>"
							+ strAttributes[intCount] + "</b> with value <b>" + strTempValue + "</b>", StepResult.FAIL);
				}
				intCount++;
			}

		} else {
			report.addReportStep("Verify that Custom attributes are displayed in sequence",
					"Unable to find the custom attributes", StepResult.FAIL);
		}

	}

	/**
	 * Method to calculate qty for all the items
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage calculateQtyAllItems() throws Exception {

		if (wh.isElementPresent(qtyTxtBox)) {

			List<WebElement> qtyBoxElement = driver.findElements(qtyTxtBox);

			if (qtyBoxElement.size() == 1) {
				String qty = wh.getAttribute(qtyTxtBox, "value");
				commonData.QuantityTotal = qty;
				int iQty = Integer.parseInt(qty);
				commonData.qtyTotal = iQty;
				report.addReportStep("Calculate Qty Total", "Qty total is calculated", StepResult.PASS);
			}

			else {
				int qtyTotal = 0;
				for (int i = 1; i <= qtyBoxElement.size(); i++) {
					String qty = wh.getAttribute(By
							.xpath("(//*[contains(@class,'qty-wrapper')]/input[contains(@id,'quantity')])[" + i + "]"),
							"value");
					int iQty = Integer.parseInt(qty);
					qtyTotal = iQty + qtyTotal;
				}
				commonData.qtyTotal = qtyTotal;
				String strNewQtyTotal = new Integer(qtyTotal).toString();
				commonData.QuantityTotal = strNewQtyTotal;
				report.addReportStep("Calculate Qty Total", "Qty total is calculated for all the items",
						StepResult.PASS);
			}

		}

		else {
			report.addReportStep("Calculate Qty Total", "Qty text box is not present in cart page", StepResult.PASS);
		}
		return this;

	}

	/**
	 * Method to update height in configurator page for blinds item
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public void updateheightInConfiguratorPage() throws Exception {
		if (wh.isElementPresent(configHeight, 2)) {
			try {
				// driver.findElement(By.name("heightwhole")).click();
				Select selectBox = new Select(driver.findElement(configHeight));
				selectBox.selectByIndex(25);

				System.out.println(selectBox.getFirstSelectedOption().getText());

				commonData.strHeightWhole = selectBox.getFirstSelectedOption().getText();

				// driver.findElement(By.cssSelector("option[value="40"]")).click();
				report.addReportStep("Click the  available Height option", "Height option "
						+ selectBox.getFirstSelectedOption().getText() + " is  updated", StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Click the  available Height option", "Unable to click the button",
						StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else {
			report.addReportStep("Click the  available Height option", "Unable to click the button", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * Component to verify that the height seleted in config page is updated in
	 * the cart page
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public void verifyHeightUpdatedInCart() throws Exception {
		if (wh.isElementPresent(height, 2)) {
			String strheightwhole = driver.findElement(height).getText();
			System.out.println(strheightwhole);

			if (strheightwhole.contains(commonData.strHeightWhole)) {

				report.addReportStep("Verify that the height whole <b>" + commonData.strHeightWhole
						+ "</b> selected in config page is updated in cart page product section",
						"The value is displayed in cart page product description", StepResult.PASS);
			} else {
				report.addReportStep("Verify that the height whole <b>" + commonData.strHeightWhole
						+ "</b> selected in config page is updated in cart page product section",
						"The value is not displayed in cart page product description", StepResult.FAIL);
			}

		} else {
			report.addReportStep(
					"Verify that the height selected in config page is updated in cart page product section",
					"No previously saved value available to compare the value available in product description",
					StepResult.FAIL);
		}

	}

	/**
	 * Method to update mount in configurator page for blinds item
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public void updateMountInConfiguratorPage() throws Exception {
		if (wh.isElementPresent(configMount, 2)) {

			try {

				driver.findElement(mountOpt2).click();

				if (wh.isElementPresent(mountOpt2, 2)) {

					String strConfigMount = driver.findElement(mountOpt2).getText();
					System.out.println(strConfigMount);
					commonData.strMount = strConfigMount;

					report.addReportStep("Click the  available Mount option", "Mount option " + strConfigMount
							+ " selected", StepResult.PASS);
				} else {
					report.addReportStep("Click the  available Mount option",
							"Unable to get the newly selected Mount option", StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep("Click the  available Mount option", "Unable to click the button", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else {
			report.addReportStep("Click the  available Mount option", "Unable to click the button", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * Component to verify that the mount seleted in config page is updated in
	 * the cart page
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public void verifyMountUpdatedInCart() throws Exception {
		if (wh.isElementPresent(mount, 2)) {
			String strMount = driver.findElement(mount).getText();
			System.out.println(strMount);

			System.out.println(commonData.strMount);

			if (strMount.toUpperCase().contains(commonData.strMount)) {
				report.addReportStep("Verify that mount <b>" + commonData.strMount
						+ "</b> selected in config page is updated in cart page product section",
						"The value is displayed in cart page product description", StepResult.PASS);
			} else {
				report.addReportStep("Verify that mount <b>" + commonData.strMount
						+ "</b> selected in config page is updated in cart page product section",
						"The value is not displayed in cart page product description", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that mount selected in config page is updated in cart page product section",
					"No previously saved value available to compare the value available in product description",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to click on custom details link in cart page for blinds item
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public void clickCustomDetailsLink() throws Exception {
		String strSubIteration = dataTable.getData("SubIteration");

		if (wh.isElementPresent(customDetails, 2)) {
			List<WebElement> webLinks = driver.findElements(customDetails);

			try {
				int intCount = 0;
				boolean blnClicked = false;

				for (WebElement webylinks : webLinks) {
					if (strSubIteration.contains("" + (intCount + 1))) {
						webylinks.click();
						Thread.sleep(2000);
						report.addReportStep("Click the 'View All Custom details' link for the Item " + strSubIteration
								+ "", "Link Clicked", StepResult.PASS);
						blnClicked = true;
						break;
					}
					intCount++;
				}

				if (!blnClicked) {
					report.addReportStep("Click the 'View All Custom details' link for the item " + strSubIteration
							+ "", "Link not Clicked", StepResult.FAIL);
				}

			} catch (Exception e) {
				report.addReportStep("Click the 'View All Custom details' link", "Link not Clicked", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}

		}

		else {
			report.addReportStep("Click the 'View All Custom details' link", "Link not found", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * Component to click close on custom details overlay
	 * 
	 * @since Oct 28, 2014
	 * @author PXM8043
	 * @throws Exception
	 */
	public void closeCustomDetailsOverlay() throws Exception {

		if (wh.isElementPresent(customDetailsClose, 2)) {
			try {
				wh.clickElement(customDetailsClose);
				report.addReportStep("Click the Close button in the Custom details overlay", "Button clicked",
						StepResult.PASS);
			} catch (Exception e) {
				report.addReportStep("Click the Close button in the Custom details overlay",
						"Unable to click the button", StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else {
			report.addReportStep("Click the Close button in the Custom details overlay", "Unable to Find the button",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	public ShoppingCartPage verifyShoppingCartEmpty() throws Exception {

		if (wh.isElementPresent(emptyCartText)) {

			report.addReportStep("Verify Shopping Cart Page", "Shopping Cart Page is empty", StepResult.PASS);
		} else {

			report.addReportStep("Verify Shopping Cart Page", "Shopping Cart Page is not empty", StepResult.FAIL);

			rc.terminateTestCase("Shopping Cart Page");
		}

		return this;
	}

	public ShoppingCartPage verifyInvalidPromoErrMsg() throws Exception {

		String pormoCode = dataTable.getData(DataColumn.PromoCode);
		By invalidPromoMsg = By.xpath("//span[contains(text(),'Promotion code " + pormoCode + " is invalid.')]");

		if (wh.isElementPresent(invalidPromoMsg)) {

			String promoTxt = wh.getText(invalidPromoMsg);
			if (promoTxt.contains("invalid")) {

				report.addReportStep("Verify invalid promotion error message",
						"Invalid promotion error message is displayed", StepResult.PASS);

			} else {

				report.addReportStep("Verify invalid promotion error message",
						"Invalid promotion error message is not displayed properly", StepResult.FAIL);

			}

		} else {

			report.addReportStep("Verify invalid promotion error message",
					"Invalid promotion error message is not displayed", StepResult.FAIL);

		}

		return this;

	}

	/**
	 * Component to displayed product details in cart page
	 * 
	 * @throws Exception
	 * 
	 * 
	 */
	public void verifyProductsInCart() throws Exception {
		if (wh.isElementPresent(ProdDesc, 5)) {
			List<WebElement> lstProdDetails = driver.findElements(ProdDesc);
			for (WebElement prodDetails : lstProdDetails) {
				String strProdDetails = prodDetails.getText();
				report.addReportStep("Product details should be displayed", "<b>" + strProdDetails
						+ "</b> are displayed", StepResult.PASS);
			}
		} else {
			report.addReportStep("Product details should be displayed", "Products are not displayed", StepResult.FAIL);
		}
	}

	public void verifyDisclaimerMsgCart() throws Exception {

		if (wh.isElementPresent(disclaimerMsg)) {

			String strMsg = wh.getText(disclaimerMsg);
			if (strMsg.contains("* Shipping and delivery charges are calculated")) {

				report.addReportStep("Verify disclaimer message is displayed", "Disclaimer message is displayed",
						StepResult.PASS);

			} else {

				report.addReportStep("Verify disclaimer message is displayed",
						"Disclaimer message is not displayed properly", StepResult.FAIL);

			}

		} else {

			report.addReportStep("Verify disclaimer message is displayed", "Disclaimer message is not displayed",
					StepResult.FAIL);

		}

	}

	public void verifyPickUpInstoreChecked() throws Exception {

		if (wh.isElementPresent(ProdDesc)) {

			String checkedValue = driver.findElement(bopisChecked).getAttribute("checked");
			if (checkedValue.contains("true")) {
				report.addReportStep(
						"Verify the Pick Up In Store radio button is selcted and value is true in cart page",
						"Pick Up In Store radio button is selcted and value is true in cart page", StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify the Pick Up In Store radio button is selcted and value is true in cart page",
						"Pick Up In Store radio button is not selcted and value is not true in cart page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Click the Pick Up In Store radio button cart page",
					"Pick Up In Store radio button is not clicked in cart page", StepResult.FAIL);
		}

	}

	public void verifyExpressDeliveryChecked() throws Exception {

		if (wh.isElementPresent(bodfsChecked)) {

			String checkedValue = driver.findElement(bodfsChecked).getAttribute("checked");
			if (checkedValue.contains("true")) {
				report.addReportStep(
						"Verify the ExpressDelivery radio button is selcted and value is true in cart page",
						"ExpressDelivery radio button is selcted and value is true in cart page", StepResult.PASS);

			} else {
				report.addReportStep(
						"Verify the ExpressDelivery radio button is selcted and value is true in cart page",
						"ExpressDelivery radio button is not selcted and value is not true in cart page",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Click the ExpressDelivery radio button cart page",
					"ExpressDelivery radio button is not clicked in cart page", StepResult.FAIL);
		}

	}

	public void verifyBulkPricingMsgCart() throws Exception {

		if (wh.isElementPresent(bulkPricingMsg)) {

			String strMsg = wh.getText(bulkPricingMsg);
			if (strMsg.contains("Get Bulk Pricing of")) {
				report.addReportStep("Verify the bulk pricing message in cart page", "Bulk pricing msg is displayed",
						StepResult.PASS);

			} else {
				report.addReportStep("Verify the bulk pricing message in cart page",
						"Bulk pricing msg is not displayed properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify the bulk pricing message in cart page", "Bulk pricing msg is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyAssemblyMsgNotDisplayed() throws Exception {

		if (wh.isElementNotPresent(verifyAssemblyOption)) {

			report.addReportStep("Verify assembly msg is not present", "Assembly msg not present", StepResult.PASS);

		} else {
			report.addReportStep("Verify assembly msg is not present", "Assembly msg is present", StepResult.FAIL);
		}

	}

	public void verifyAssemblyMsg() throws Exception {

		if (wh.isElementPresent(verifyAssemblyOption)) {

			report.addReportStep("Verify assembly msg is present", "Assembly msg present", StepResult.PASS);

		} else {
			report.addReportStep("Verify assembly msg is present", "Assembly msg is not present", StepResult.FAIL);
		}

	}

	public void verifyMoreQtyError() throws Exception {
		// TODO Auto-generated method stub
		if (wh.isElementPresent(qtyError, 3)) {
			// To verify cart page level error
			String strErrorMessage = wh.getText(qtyError);
			if (strErrorMessage != null)
				report.addReportStep("Verfy cart Page error message",
						"Cart Page level error message is displayed : <b>" + strErrorMessage + "</b>", StepResult.PASS);
			else
				report.addReportStep("Verfy cart Page error message",
						"Cart Page level error message is not displayed properly.", StepResult.WARNING);

		} else
			report.addReportStep("Verfy cart Page error message", "Cart Page level error message is not displayed.",
					StepResult.WARNING);
	}

	public void verifyMiniCartCountWithSamples() throws Exception {

		if (wh.isElementPresent(miniCartCount)) {

			List<WebElement> miniCart = driver.findElements(miniCartCount);

			int qtyTotal = 0;
			for (WebElement cartCount : miniCart) {
				String qty = wh.getText(cartCount).substring(0, 1);
				int iQty = Integer.parseInt(qty);
				qtyTotal = iQty + qtyTotal;
			}
			String strNewQtyTotal = new Integer(qtyTotal).toString();
			commonData.miniCartSampleCount = strNewQtyTotal;
			report.addReportStep("Calculate Qty Total", "Qty total is calculated for all the items", StepResult.PASS);

		} else {
			report.addReportStep("Calculate Qty Total", "Qty total is not calculated for all the items",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify that the added sku's are by default with STH
	 * 
	 * @throws Exception
	 *
	 *
	 */
	public void verifyDefaultFullfillmentForSTHItems() throws Exception {
		/*
		 * List<WebElement> webRadio =
		 * driver.findElements(STHFulfillmentActive); int intItems =
		 * webRadio.size(); System.out.println(intItems); String strSTH =
		 * driver.findElement(STHButton).getText(); System.out.println(strSTH);
		 * if (intItems >= 1) report.addReportStep(
		 * "Verify that 'STH' option is selected by default with the selected store."
		 * , "'STH' option " + strSTH +
		 * " is selected by default for the added items", StepResult.PASS); else
		 * report.addReportStep(
		 * "Verify that 'STH' option is selected by default with the selected store."
		 * , "'STH' option is not selected by default.", StepResult.FAIL);
		 */
		if (wh.isElementPresent(Buybox, 4)) {
			boolean blnIsSTHFound = false;
			try {

				blnIsSTHFound = driver.findElement(STHFulfillmentActive).isSelected();
				System.out.println(blnIsSTHFound);
				if (blnIsSTHFound) {
					report.addReportStep("Verify that STH radio button is selected for a product",
							"STH option is selected", StepResult.PASS);
				}
			} catch (Exception e) {
				blnIsSTHFound = false;
			}

		} else {
			report.addReportStep("Buy box should be displayed", "Buy box is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Verify the contents of the custom details overlay
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyCustomDetailOverlay() throws Exception {
		if (wh.isElementPresent(BlindsModal, 4)) {
			report.addReportStep("Verify that Custom Attributes Overlay is displayed", "The overlay is displayed",
					StepResult.PASS);
			if (wh.isElementPresent(ModalTitle, 1)) {
				String strTempTitle = driver.findElement(ModalTitle).getText();
				report.addReportStep("Verify that Title is displayed",
						"Title Displayed as <b>" + strTempTitle + "</b>", StepResult.PASS);

			} else {
				report.addReportStep("Verify that Title is displayed", "Title is not displayed", StepResult.FAIL);
			}
			if (wh.isElementPresent(BlindsModalHeading, 1)) {
				String strTempHeading = driver.findElement(BlindsModalHeading).getText();
				report.addReportStep("Verify that Heading is displayed", "Heading is displayed as " + strTempHeading
						+ "", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Heading is displayed", "Heading is not displayed", StepResult.FAIL);
			}
			if (wh.isElementPresent(BasePrice, 1)) {
				String strTempBasePrice = driver.findElement(BasePriceValue).getText();
				report.addReportStep("Verify that Base Price is displayed", "<b>" + strTempBasePrice
						+ "</b> is displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify that Base Price is displayed", "Base price is not displayed",
						StepResult.FAIL);
			}
			if (wh.isElementPresent(BlindsDetailsImage, 2)) {
				report.addReportStep("Verify that Blinds product image is displayed", "<b>Image</b> is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify that Blinds product image is displayed", "Image is not displayed",
						StepResult.FAIL);
			}
			if (wh.isElementPresent(BlindDetailAttributeValue, 2)) {
				String strTotalAttributes = "" + driver.findElements(BlindDetailAttributeValue).size();
				report.addReportStep("Verify that Blinds product's Custom attributes are displayed",
						"There are a total of <b>" + strTotalAttributes + "</b> attribute(s) displayed in the overlay",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify that Blinds product's Custom attributes are displayed",
						"Custom attributes are not displayed", StepResult.FAIL);
			}
			if (wh.isElementPresent(BlindTotal, 2)) {
				String strTempTotal = driver.findElement(BlindTotal).getText();
				report.addReportStep("Verify that Total is displayed in the overlay", "<b>" + strTempTotal
						+ "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Total is displayed in the overlay", "Total is not displayed",
						StepResult.FAIL);
			}

		} else if (wh.isElementNotPresent(BlindsModal)) {

			report.addReportStep("Verify that Custom Attributes Overlay  is not displayed for non blind item",
					"The overlay is not displayed for non blind item", StepResult.PASS);
		} else {
			report.addReportStep("Verify that Custom Attributes Overlay is displayed", "The overlay is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to clear cookie value
	 * 
	 */

	public void simulateSessionExpiryCart() {

		Set cookies = driver.manage().getCookies();
		Iterator iter = cookies.iterator();

		while (iter.hasNext()) {
			Cookie cookie = (Cookie) iter.next();

			String strCookieName = cookie.toString();

			System.out.println(strCookieName);

			if (strCookieName.contains("WC_USERACTIVITY")) {
				System.out.println(strCookieName);
				strCookieName = strCookieName.substring(0, strCookieName.indexOf("="));
				System.out.println();
				driver.manage().deleteCookieNamed(strCookieName);
				report.addReportStep("Delete the <b>User Session cookie</b>",
						"Session cookie for the active user was <b>deleted</b>", StepResult.DONE);

			}

		}

	}

	/**
	 * Component to verify that the width whole seleted in config page is
	 * updated in the cart page
	 * 
	 * @throws Exception
	 */
	public void verifyRoomUpdatedInCart() throws Exception {
		if (wh.isElementPresent(Room, 2)) {
			String strRoom = driver.findElement(Room).getText();
			System.out.println(strRoom);

			System.out.println(commonData.strRoom);

			if (strRoom.toUpperCase().contains(commonData.strRoom)) {
				report.addReportStep("Verify that Room <b>" + commonData.strRoom
						+ "</b> selected in config page is updated in cart page product section",
						"The value is displayed in cart page product description", StepResult.PASS);
			} else {
				report.addReportStep("Verify that Room <b>" + commonData.strRoom
						+ "</b> selected in config page is updated in cart page product section",
						"The value is not displayed in cart page product description", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that Room selected in config page is updated in cart page product section",
					"Unable to find the selected Room value in product description", StepResult.FAIL);
		}

	}

	/**
	 * Component tp Remove the last product from Shopping cart page
	 * 
	 * @throws Exception
	 * 
	 */
	public void removeLastProductInCart() throws Exception {

		if (wh.isElementPresent(removeLink, 2)) {
			List<WebElement> lstProductCount = driver.findElements(removeLink);
			int intInitialProdCount = lstProductCount.size();
			try {
				lstProductCount.get(lstProductCount.size() - 1).click();
				Thread.sleep(2000);
				try {
					List<WebElement> lstProductCount2 = driver.findElements(removeLink);
					if (intInitialProdCount > (lstProductCount2.size())) {
						report.addReportStep("Remove the last product displayed in cart page", "Remove link clicked",
								StepResult.PASS);
					} else {
						report.addReportStep("Remove the 1st product displayed in cart page", "Product not removed",
								StepResult.FAIL);
					}

				} catch (Exception e) {
					report.addReportStep("Remove the Last product displayed in cart page", "Remove link clicked",
							StepResult.PASS);
				}

			} catch (Exception e) {
				report.addReportStep("Remove the Last product displayed in cart page", "Remove link not clicked",
						StepResult.FAIL);
				commonData.blnGracefulExit = true;
			}
		} else {
			report.addReportStep("Remove the Last product displayed in cart page", "Unable to find Remove links",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * Component to get the grand total displayed
	 * 
	 * @throws Exception
	 */
	public void getCurrentOrderTotal() throws Exception {
		if (wh.isElementPresent(Total, 2)) {
			commonData.strtotal = driver.findElement(Total).getText();
			report.addReportStep("Get the current total from the summary table", "Total found as <b>"
					+ commonData.strtotal + "</b> and saved", StepResult.PASS);
		} else {
			report.addReportStep("Get the current total from the summary table", "Unable to get the total",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * Component to verify that the current total is greater than the previously
	 * saved total via component getCurrentOrderTotal() and saves the new total
	 * 
	 * * @throws Exception
	 */
	public void verifyNewTotalNotSameAsPrev() throws Exception {
		String strPreviousTotal = commonData.strtotal.trim();
		System.out.println(strPreviousTotal);

		if (wh.isElementPresent(Total, 2)) {
			commonData.strtotal = driver.findElement(Total).getText().trim();
			report.addReportStep("Get the current total from the summary table", "Total found as <b>"
					+ commonData.strtotal + "</b> and saved", StepResult.PASS);

			if (!commonData.strtotal.contains(strPreviousTotal)) {
				report.addReportStep("Verify that the Current total : <b>" + commonData.strtotal
						+ "</b> is not similar to the previous total", "The previous Total : <b>" + strPreviousTotal
						+ "</b> is not similar to the current total", StepResult.PASS);
			} else {
				report.addReportStep("Verify that the Current total : <b>" + commonData.strtotal
						+ "</b> is not similar to the previous total", "The previous Total : <b>" + strPreviousTotal
						+ "</b> is similar to the current total", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(Emptycart, 1)) {
			report.addReportStep("Verify that the Current total : " + commonData.strtotal
					+ " is not similar to the previous total",
					"There is no products displayed in cart. Order Total is not displayed", StepResult.PASS);

		} else {
			report.addReportStep("Get the current total from the summary table", "Unable to get the total",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	// ******This Section is for Checkout from ATC overlay screen Parent Story:
	// MLTC-1587/QA story 2591*****
	/**
	 * Method to verify shopping cart has major appliance in it
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyCartHasMajorApplianceInIt() throws Exception {

		if (wh.isElementPresent(partsandServicesText)) {
			report.addReportStep(
					"I verify cart has major appliance item in it",
					"I verified cart has major appliance item in it. So when you add another item, cart page should be not be skipped",
					StepResult.PASS);
		}

		else
			report.addReportStep("I verify cart has major appliance item in it",
					"I verified cart has no major appliance item in it", StepResult.FAIL);

		return this;

	}

	/**
	 * Method to verify shopping cart has no major appliance in it
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyCartHasNoMajorApplianceInIt() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementNotPresent(partsandServicesText)) {
			report.addReportStep("I verify cart has no major appliance item in it",
					"I verified cart has no major appliance item in it", StepResult.PASS);
		}

		else
			report.addReportStep(
					"I verify cart has no major appliance item in it",
					"I verified cart has major appliance item in it. So when you add another item, cart page should be not be skipped",
					StepResult.WARNING);

		return this;

	}

	/**
	 * Method to verify shopping cart has assembly options selected or not
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyAssemblyOptionSelectedOrNot() throws Exception {

		wh.waitForPageLoaded();
		String IsAsYes = wh.getAttribute(IsAssemblyRadioButtonChosen, "data-selected");
		String IsAsNo = wh.getAttribute(IsAssemblyRadioButtonChosen, "data-selected");

		if (IsAsYes.equals("Y")) {
			report.addReportStep("I verify cart has assembly option selected or not",
					"I verified cart has assembly option selected as Yes", StepResult.PASS);
		} else {

			if (IsAsNo.equals("N"))
				report.addReportStep("I verify cart has assembly option selected or not",
						"I verified cart has assembly option selected as No", StepResult.PASS);

			else {
				if (wh.isElementPresent(IsAssemblyRadioButtonChosen))
					report.addReportStep(
							"I verify cart has assembly option selected or not",
							"I verified cart has assembly item but no assembly option is selected. So when you add an another item, cart page should be not be skipped.",
							StepResult.WARNING);
				else
					report.addReportStep("I verify cart has assembly option selected or not",
							"I verified cart has no assembly item.", StepResult.DONE);
			}
		}
		return this;
	}

	/**
	 * Method to verify shopping cart has assembly option available or not
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyAssemblyOptionTextInCart() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(verifyAssemblyOption)) {

			report.addReportStep(
					"I verify cart has assembly item or not",
					"I verified cart has assembly item. If the assembly option is not selected then you cannot skip the cart page",
					StepResult.PASS);
		}

		else
			report.addReportStep("I verify cart has assembly item or not", "I verified cart has no assembly item.",
					StepResult.DONE);
		return this;

	}

	/**
	 * Method to verify shopping cart shows please choose assembly option error
	 * message
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public ShoppingCartPage verifyAssemblyErrorInCart() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(cartErrMsg)) {

			String errMsg = wh.getText(cartErrMsg);
			if (errMsg.contains("Please choose an assembly option")) {

				report.addReportStep("Verify Error messgae displayed in cart", "Error message <b>" + errMsg
						+ " </b> is displayed in cart", StepResult.PASS);

			} else {
				report.addReportStep("Verify Error messgae displayed in cart", "Error message <b>" + errMsg
						+ " </b> is displayed in cart", StepResult.FAIL);
			}

		}

		else
			report.addReportStep("Verify Error messgae displayed in cart", "Error message is not displayed in cart",
					StepResult.FAIL);
		return this;

	}

	/**
	 * To click on mini cart button in header
	 * 
	 * @return ShoppingCartPage
	 * @throws Exception
	 */
	public ShoppingCartPage clickMiniCartBtn() throws Exception {

		if (wh.isElementPresent(miniCartBtn)) {

			addMCCparamter();

			wh.clickElement(miniCartBtn);

			report.addReportStep("Click Mini cart button from header", "Mini cart button is clicked", StepResult.PASS);

		}

		else {

			report.addReportStep("Click Mini cart button from header", "Mini cart button is not clicked",
					StepResult.FAIL);
		}

		return new ShoppingCartPage(ic);

	}

	/**
	 * To get the order level promo value in shopping cart page shopping cart
	 * page
	 * 
	 */
	public ShoppingCartPage getOrderLevelPromo() throws Exception {

		Thread.sleep(commonData.smallWait);
		if (wh.isElementPresent(promoValue)) {
			report.addReportStep("Order level promo", "Order level promo is displayed", StepResult.PASS);

			String strpromo = wh.getText(promoValue);
			System.out.println(strpromo);
			commonData.promovalue = strpromo;
			report.addReportStep("Order level promo", "Promo value " + strpromo + "is saved", StepResult.PASS);

		} else {
			report.addReportStep("Order level promo", "Order level promo is not displayed", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Component to fetch subtotal,shipping charges , Merchandise subtotal from
	 * Shopping cart page
	 * 
	 * @since Aug 20, 2013
	 * @author PXM8043 modified by gdp8587
	 */

	public void getAllTotalsfromShoppingCartPage() {
		try {

			List<WebElement> lstleftsummary = driver
					.findElements(By
							.xpath("//*[@class='left text-left order-summary-leftwidth' or @class='left paddingZero cartEstimatedSubTotal']//h3"));
			System.out.println(lstleftsummary.size());
			List<WebElement> lstritesummary = driver.findElements(By
					.xpath("//*[@class='right text-right p-bottom-normal' or @class='right']//h3"));
			System.out.println(lstritesummary.size());
			ArrayList<String> strrite = new ArrayList();
			ArrayList<String> strleft = new ArrayList();
			for (WebElement leftsummary : lstleftsummary) {
				String strtemp = leftsummary.getText();

				strleft.add(strtemp);
			}
			for (WebElement ritesummary : lstritesummary) {
				String strtemp = ritesummary.getText();

				strrite.add(strtemp);
			}
			for (int i = 0, j = 0; i < strleft.size(); i++) {
				// subtotal
				if (strleft.get(i).contains("Subtotal")) {
					String strMerValue = strrite.get(i);
					if (strMerValue.contains("$")) {
						strMerValue = strMerValue.substring(strMerValue.indexOf("$") + 1, strMerValue.length()).trim();

						if (strMerValue.contains(",")) {
							strMerValue = strMerValue.replace(",", "");
						}
					}

					try {
						commonData.doubMerchandiseSubTotalCart = Double.parseDouble(strMerValue);
						report.addReportStep("Verify the Merchandise subtotal in Cart page", "Subtotal : "
								+ commonData.doubMerchandiseSubTotalCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the merchandise subtotal");
						commonData.doubMerchandiseSubTotalCart = 0;
						report.addReportStep("Verify the Merchandise subtotal in Cart page",
								"Subtotal is not displayed", StepResult.FAIL);
					}
				}

				// To verify Estimated subtotal
				if (strleft.get(i).contains("Estimated Subtotal")) {
					String strEstValue = strrite.get(i);
					if (strEstValue.contains("$")) {
						strEstValue = strEstValue.substring(strEstValue.indexOf("$") + 1, strEstValue.length()).trim();

						if (strEstValue.contains(",")) {
							strEstValue = strEstValue.replace(",", "");
						}
					}

					try {
						commonData.doubSubtTotalCart = Double.parseDouble(strEstValue);
						report.addReportStep("Verify the  Estimated subtotal in Cart page", "Subtotal : "
								+ commonData.doubSubtTotalCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the subtotal");
						commonData.doubSubtTotalCart = 0;
						report.addReportStep("Verify the subtotal in Cart page", "Subtotal is not displayed",
								StepResult.FAIL);
					}
				}

				// To fetch Appliance subtotal
				if (strleft.get(i).contains("Appliance Subtotal")) {
					String strAppSubtotalValue = strrite.get(i);
					if (strAppSubtotalValue.contains("$")) {
						strAppSubtotalValue = strAppSubtotalValue.substring(strAppSubtotalValue.indexOf("$") + 1,
								strAppSubtotalValue.length()).trim();

						if (strAppSubtotalValue.contains(",")) {
							strAppSubtotalValue = strAppSubtotalValue.replace(",", "");
						}
					}

					try {
						commonData.doubApplianceSubtotalCart = Double.parseDouble(strAppSubtotalValue);
						report.addReportStep("Verify the Appliance  subtotal in Cart page", "Subtotal : "
								+ commonData.doubSubtTotalCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the subtotal");
						commonData.doubApplianceSubtotalCart = 0;
						report.addReportStep("Verify the Appliance subtotal in Cart page", "Subtotal is not displayed",
								StepResult.FAIL);
					}
				}

				// To fetch Estimated Sales Tax
				if (strleft.get(i).contains("Sales Tax")) {
					String strEstimatedTax = strrite.get(i);
					if (strEstimatedTax.contains("$")) {
						strEstimatedTax = strEstimatedTax.substring(strEstimatedTax.indexOf("$") + 1,
								strEstimatedTax.length()).trim();

						if (strEstimatedTax.contains(",")) {
							strEstimatedTax = strEstimatedTax.replace(",", "");
						}
					}

					try {
						commonData.doubEstimatedTaxCart = Double.parseDouble(strEstimatedTax);
						report.addReportStep("Verify the Estimated tax in Cart page", "Estimated tax : "
								+ commonData.doubEstimatedTaxCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						if (strEstimatedTax.contains("FREE") || strEstimatedTax.contains("----")) {
							commonData.doubEstimatedTaxCart = 0;
							report.addReportStep("Verify the  sales tax in Cart page",
									"sales tax is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Estimated tax");
							commonData.doubEstimatedTaxCart = 0;
							report.addReportStep("Verify the Estimated tax in Cart page",
									"Estimated tax is not displayed", StepResult.FAIL);
						}

					}
				}

				// To fetch pickup in store value
				if (strleft.get(i).contains("Pick Up In Store")) {
					String strPickUpvalue = strrite.get(i);
					if (strPickUpvalue.contains("$")) {
						strPickUpvalue = strPickUpvalue.substring(strPickUpvalue.indexOf("$") + 1,
								strPickUpvalue.length()).trim();

						if (strPickUpvalue.contains(",")) {
							strPickUpvalue = strPickUpvalue.replace(",", "");
						}
					}

					try {
						commonData.doubPickupTotalCart = Double.parseDouble(strPickUpvalue);
						report.addReportStep("Verify the pick up in store total in Cart page",
								"Pick up in store total : " + commonData.doubPickupTotalCart + " is displayed",
								StepResult.PASS);
					} catch (Exception e) {
						if (strPickUpvalue.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the  Pick up in store total in Cart page",
									"Pick up in store total is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Estimated tax");
							commonData.doubPickupTotalCart = 0;
							report.addReportStep("Verify the pick up in store total in Cart page",
									"Pick up in store total is not displayed", StepResult.FAIL);
						}
					}
				}

				// To fetch Estimated Shipping Charge
				if (strleft.get(i).contains("Shipping")) {
					String strShippingChargeValue = strrite.get(i);
					if (strShippingChargeValue.contains("$")) {
						strShippingChargeValue = strShippingChargeValue.substring(
								strShippingChargeValue.indexOf("$") + 1, strShippingChargeValue.length()).trim();
						if (strShippingChargeValue.contains(",")) {
							strShippingChargeValue = strShippingChargeValue.replace(",", "");
						}
					}

					try {
						commonData.doubShipChargesCart = Double.parseDouble(strShippingChargeValue);
						report.addReportStep(
								"Verify the Estimated Shipping Charge in Cart page",
								"Estimated Shipping Charge : " + commonData.doubApplianceDeliveryCart + " is displayed",
								StepResult.PASS);

					} catch (Exception e) {
						if (strShippingChargeValue.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the Estimated Shipping Charge in Cart page",
									" Estimated Shipping Charge is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Appliance delivery");
							commonData.doubApplianceDeliveryCart = 0;
							report.addReportStep("Verify the Estimated Shipping Charge   in Cart page",
									" Estimated Shipping Charge is not displayed", StepResult.FAIL);
						}
					}
				}

				// To fetch Appliance delivery Value
				if (strleft.get(i).contains("Appliance Delivery")) {
					String strApplianceValue = strrite.get(i);
					if (strApplianceValue.contains("$")) {
						strApplianceValue = strApplianceValue.substring(strApplianceValue.indexOf("$") + 1,
								strApplianceValue.length()).trim();
						if (strApplianceValue.contains(",")) {
							strApplianceValue = strApplianceValue.replace(",", "");
						}
					}

					try {
						commonData.doubApplianceDeliveryCart = Double.parseDouble(strApplianceValue);
						report.addReportStep(
								"Verify the Appliance delivery Charge in Cart page",
								"Appliance delivery Charge : " + commonData.doubApplianceDeliveryCart + " is displayed",
								StepResult.PASS);

					} catch (Exception e) {
						if (strApplianceValue.contains("FREE")) {
							commonData.doubShipChargesCart = 0;
							report.addReportStep("Verify the  Appliance deliver charges in Cart page",
									" Appliance deliver charge is  displayed as FREE", StepResult.PASS);
						} else {
							System.out.println("Unable to fetch the Appliance delivery");
							commonData.doubApplianceDeliveryCart = 0;
							report.addReportStep("Verify the Appliance delivery Charge in Cart page",
									"Appliance delivery Charge is not displayed", StepResult.FAIL);
						}
					}
				}

				// To fetch You Saved value
				if (strleft.get(i).contains("You Saved ")) {
					String strYouSaved = strrite.get(i);
					if (strYouSaved.contains("$")) {
						strYouSaved = strYouSaved.substring(strYouSaved.indexOf("$") + 1, strYouSaved.length()).trim();

						if (strYouSaved.contains(",")) {
							strYouSaved = strYouSaved.replace(",", "");
						}
					}

					try {
						commonData.doubYouSavedCart = Double.parseDouble(strYouSaved);
						report.addReportStep("Verify the 'You saved' total in Cart page", "You saved : "
								+ commonData.doubYouSavedCart + " is displayed", StepResult.PASS);
					} catch (Exception e) {
						System.out.println("Unable to fetch the you save total");
						commonData.doubYouSavedCart = 0;
						report.addReportStep("Verify the 'You saved' total in Payment page",
								"'You saved' is not displayed", StepResult.FAIL);
					}
				}
			}
			System.out.println(commonData.doubMerchandiseSubTotalCart);
			System.out.println(commonData.doubSubtTotalCart);
			System.out.println(commonData.doubShipChargesCart);
			System.out.println(commonData.doubEstimatedTaxCart);
			System.out.println(commonData.doubPickupTotalCart);
			System.out.println(commonData.doubApplianceDeliveryCart);
			System.out.println(commonData.doubApplianceSubtotalCart);
			System.out.println(commonData.doubYouSavedCart);
			System.out.println(commonData.doubEstimatedTotalCart);
			System.out.println(commonData.doubtotalCart);
			System.out.println("Done'");

		}

		catch (Exception e) {
			System.out.println("Unable to get the totals from Shopping page");
			report.addReportStep("Verify that Items totals in Order summary table", "Unable to validate the Totals",
					StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}
	}

	/**
	 * Function to verify that discounted amount is displayed after applying
	 * promo code
	 * 
	 * 
	 * @since Aug 7, 2013
	 * @author PXM8043
	 * @throws Exception
	 */

	public void verifyPromotionDiscountForCartPg() throws Exception {

		if (wh.isElementPresent(verifyShoppingCartPage, 2)) {
			getAllTotalsfromShoppingCartPage();

			double doubMerchandiseSubTotalCart = commonData.doubMerchandiseSubTotalCart;
			double doubSubtTotalCart = commonData.doubSubtTotalCart;
			double doubShipChargesCart = commonData.doubShipChargesCart;
			double doubEstimatedTaxCart = commonData.doubEstimatedTaxCart;
			double doubPickupTotalCart = commonData.doubPickupTotalCart;
			double doubApplianceDeliveryCart = commonData.doubApplianceDeliveryCart;
			double doubApplianceSubtotalCart = commonData.doubApplianceSubtotalCart;

			double doubEstimatedTotalCart = commonData.doubEstimatedTotalCart;
			double doubtotalCart = commonData.doubtotalCart;

			double doubItemLevelTotal = (doubApplianceSubtotalCart + doubApplianceDeliveryCart + doubPickupTotalCart
					+ doubEstimatedTaxCart + doubMerchandiseSubTotalCart + doubShipChargesCart);
			System.out.println("Item level total : " + doubItemLevelTotal);
			double doubGrandTotal = (doubEstimatedTotalCart + doubtotalCart + doubSubtTotalCart);
			System.out.println("Grand Total : " + doubGrandTotal);

			if (doubItemLevelTotal == doubGrandTotal) {
				report.addReportStep("verify that Item level total and grand total are the same",
						"Both Totals are displayed equal as " + doubGrandTotal, StepResult.PASS);

			} else {
				report.addReportStep("verify that Item level total and grand total are the same",
						"Both Totals are not equal", StepResult.PASS);
			}

			double doubYouSaved = commonData.doubYouSavedCart;
			double doubEstimatedTotalCart1 = commonData.doubEstimatedTotalCart;
			double doubtotalCart1 = commonData.doubtotalCart;
			double doubSubTotalCart1 = commonData.doubSubtTotalCart;

			double doubGrandTotal1 = (doubEstimatedTotalCart1 + doubtotalCart1 + doubSubTotalCart1);
			commonData.finalDiscountTotalcart = doubGrandTotal1;
			System.out.println("Grand Total : " + doubEstimatedTotalCart1 + doubtotalCart1 + doubSubTotalCart1);
		} else {
			report.addReportStep("verify the discount offer after applying promotion code",
					"Unable to validate the shopping cart page", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * Component to check Qualifier discount amount after updated the Quantity
	 * 
	 */
	public void verifyQualifierDiscountSection() {
		try {
			if (driver.findElement(QualifierAmountSaved).isDisplayed()) {
				String strTemp = driver.findElement(QualifierAmountSavedvalue).getText();
				if (strTemp.contains("$")) {
					strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();
					if (strTemp.contains(",")) {
						strTemp = strTemp.replace(",", "");
					}
				}
				commonData.doubleQualifierDiscount = Double.parseDouble(strTemp);
				System.out.println(strTemp);
				report.addReportStep("verify that Qualifier Discount section after update the quantity",
						"Promocode was applied automatically and discount amount is " + strTemp + " displayed",
						StepResult.PASS);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			report.addReportStep("verify that Qualifier Discount section after update the quantity",
					"Promocode was not applied automatically ", StepResult.FAIL);
		}
	}

	/**
	 * Component to check Grand total for Qualifying purchase
	 * 
	 * @throws Exception
	 */
	public void verifyQualifierDiscountTotal() throws Exception {
		double doubSavedAmount = commonData.doubleQualifierDiscount;

		double doubItemPrice = 0.00;

		getAllTotalsfromShoppingCartPage();
		double doubMerchandiseSubTotalCart = commonData.doubMerchandiseSubTotalCart;
		double doubApplianceSubTotalCart = commonData.doubApplianceSubtotalCart;

		double doubEstimatedTotalCart = commonData.doubEstimatedTotalCart;
		double doubSubtTotalCart = commonData.doubSubtTotalCart;
		double doubtotalCart = commonData.doubtotalCart;
		if (wh.isElementPresent(QualifierPromoValue, 3)) {
			String strTemp = driver.findElement(QualifierPromoValue).getText();
			if (strTemp.contains("$")) {
				strTemp = strTemp.substring(strTemp.indexOf("$") + 1, strTemp.length()).trim();

				if (strTemp.contains(",")) {
					strTemp = strTemp.replace(",", "");
				}
			}
			doubItemPrice = (Double.parseDouble(strTemp)) + doubItemPrice;
		}
		System.out.println("sum of all product:" + doubItemPrice);
		double doubGrandTotalCart = doubMerchandiseSubTotalCart + doubApplianceSubTotalCart;
		commonData.finalDiscountTotalcart = doubEstimatedTotalCart + doubSubtTotalCart + doubtotalCart;
		System.out.println("total of all product:" + doubGrandTotalCart);
		double doubTotal = doubGrandTotalCart + doubSavedAmount;
		if (doubItemPrice == doubTotal) {
			report.addReportStep("verify the grand total after deducted the discount amount",
					"Grand total after discount is " + doubGrandTotalCart, StepResult.PASS);
			report.addReportStep("verify the grand total and saved amount are equal to the item price", "Grand total:"
					+ doubGrandTotalCart + "and saved amount:" + doubSavedAmount + " are equal to the Item price:"
					+ doubItemPrice, StepResult.PASS);

		} else {
			report.addReportStep("verify the grand total and saved amount are equal to the item price", "Grand total:"
					+ doubGrandTotalCart + "and saved amount:" + doubSavedAmount + " are not equal to the Item price:"
					+ doubItemPrice, StepResult.FAIL);
		}
	}

	/**
	 * Component to click see details tool tip
	 * 
	 * @throws Exception
	 */
	public void clickSeeDetailsToolTip() throws Exception {

		if (wh.isElementPresent(seeDetailsLink, 5)) {

			wh.clickElement(seeDetailsLink);

			report.addReportStep("Verify See Details link is clicked", "See Details link is clicked", StepResult.PASS);

		}

		else {
			report.addReportStep("Verify See Details link is present in the Shopping Cart",
					"See Details link is not Present in Shopping cart", StepResult.FAIL);

		}

	}

	/**
	 * Component to verify free haul away message removed
	 * 
	 * @throws Exception
	 */
	public ShoppingCartPage verifyFreeHaulAwayRemoved() throws Exception {

		if (wh.isElementPresent(FreeShippingToolTip, 5)) {

			String toolTipContent = driver.findElement(FreeShippingToolTip).getText().trim();

			report.addReportStep("Verify Free Shipping Tool Tip displayed",
					"Free Shipping Tool Tip is displayed with the below content </br>" + toolTipContent,
					StepResult.PASS);

			if (!(toolTipContent.contains("and haul away"))) {

				report.addReportStep("Verify Free Haulaway is not displayed", "Free haulaway is not displayed  ",
						StepResult.PASS);

			}

			else {
				report.addReportStep("Verify Free Haulaway is not displayed", "Free haulaway is displayed ",
						StepResult.FAIL);

			}

		} else {

			report.addReportStep("Verify Free Shipping Tool Tip displayed", "Free Shipping Tool Tip is not displayed",
					StepResult.FAIL);

		}

		return this;

	}

	/**
	 * Method to verify optional parts in cart page
	 * 
	 * @throws Exception
	 */
	public ShoppingCartPage verifyOptionlParts(String arg) throws Exception {
		int i = 0;
		String OptParts = arg;
		if (OptParts.contains("BOSS")) {
			List<WebElement> noOfItems = driver.findElements(itemInCart);

			String strTemp = noOfItems.get(0).getText().trim();
			String strboss = noOfItems.get(1).getText().trim();
			if (strTemp.contains("Home Delivery") && strboss.contains("Ship to Store") && noOfItems.size() == 2) {
				report.addReportStep("verify optional parts", "Optional Parts for BOSS is displayed", StepResult.PASS);

			} else {
				report.addReportStep("verify optional parts", "Optional Parts for BOSS is not displayed",
						StepResult.FAIL);
			}

		} else if (OptParts.contains("STH")) {
			List<WebElement> noOfItems = driver.findElements(itemInCart);

			String strTemp = noOfItems.get(0).getText().trim();
			String strSTH = noOfItems.get(1).getText().trim();
			if (strTemp.contains("Home Delivery") && strSTH.contains("Ship to Home") && noOfItems.size() == 2) {
				report.addReportStep("verify optional parts", "Optional Parts for STH is displayed", StepResult.PASS);

			} else {
				report.addReportStep("verify optional parts", "Optional Parts for STH is not displayed",
						StepResult.FAIL);
			}
		}
		return this;
	}

	/**
	 * Component to get the number of items in cart
	 * 
	 * @since Mar 15,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void getItemCountCart() throws Exception {
		if (wh.isElementPresent(itemInCart, 2)) {
			List<WebElement> noOfItems = driver.findElements(itemInCart);
			commonData.totalItems = noOfItems.size();

			report.addReportStep("Verify item total is taken from cart", "Item total is <b> " + commonData.totalItems
					+ " </b> in cart", StepResult.PASS);

		} else {
			report.addReportStep("Verify item total is taken from cart", "Item total is not taken from cart",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to compare item total is matching
	 * 
	 * @since Mar 15,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void compareItemTotalCart() throws Exception {
		if (wh.isElementPresent(itemInCart, 2)) {
			List<WebElement> noOfItems = driver.findElements(itemInCart);
			if (noOfItems.size() == commonData.totalItems) {
				report.addReportStep("Verify item total in cart", "Item total <b> " + commonData.totalItems
						+ " </b>is same in cart", StepResult.PASS);
			} else {
				report.addReportStep("Verify item total in cart", "Item total <b> " + commonData.totalItems
						+ " </b>is not same in cart", StepResult.PASS);
			}

		} else {
			report.addReportStep("Verify item total is taken from cart", "Item total is not taken from cart",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify Change store link in cart
	 * 
	 * @throws Exception
	 */
	public void clickChangePickUpStoreLink() throws Exception {
		if (wh.isElementPresent(By.xpath("//*[contains(text(),'change store')]"), 5)) {
			wh.jsClick(By.xpath("//*[contains(text(),'change store')]"));
			report.addReportStep("Change Store link should be displayed",
					"<b>Change Store link  </b>is clicked in PIP", StepResult.PASS);
		} else {
			report.addReportStep("Change Store link should be displayed", "Change Store link is not clicked in PIP",
					StepResult.PASS);
		}
	}

	/**
	 * component to verify store present in cart page
	 * 
	 * @throws InterruptedException
	 */
	public void verifyStorePresentIncart() throws InterruptedException {
		try {
			Thread.sleep(10000);
			String StrcartStore = driver
					.findElement(
							By.xpath("//*[@class='reveal bb-inline buy-box-message show-on-select ']//span[3]|//*[@class='reveal bb-inline buy-box-message']//span"))
					.getText().split("\\#")[1].trim();
			System.out.println(StrcartStore);
			commonData.cartStoreName = StrcartStore;
			report.addReportStep("verify the Store details are Cart Page", "<b>Store details</b> " + StrcartStore
					+ " displayed in cart page", StepResult.PASS);
		} catch (Exception e) {
			report.addReportStep("verify the Store details are Cart Page", "<b>Store details</b> are not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * 
	 * Description : get the item price in cart page
	 * 
	 * @throws Exception
	 */
	public void verifyPriceInCartPage() throws Exception {
		String strUnitPrice = "";
		if (wh.isElementPresent(By.cssSelector("h3[class='bold price-section']"), 10)) {
			strUnitPrice = driver.findElement(By.cssSelector("h3[class='bold price-section']")).getText().trim();

			commonData.strPrice = strUnitPrice;
			System.out.println(commonData.strPrice);

			report.addReportStep("Verify that product unit price is displayed in cart page", "Unit price <b> "
					+ commonData.strPrice + "</b> is displayed in cart page", StepResult.PASS);
		}

		if (!(strUnitPrice.length() > 0)) {

			try {
				strUnitPrice = driver.findElement(By.cssSelector("h3[class='bold price-section']")).getText().trim();
				commonData.strPrice = strUnitPrice;
			} catch (Exception e) {
				report.addReportStep("Verify that product unit price is displayed",
						"Unable to find the unit price section", StepResult.FAIL);
			}

		}

	}

	/**
	 * clickchangeStoreAndUpdateCart
	 * 
	 * @throws Exception
	 */
	public void MultiplePickupStore() throws Exception {
		String sku = dataTable.getData(DataColumn.SKU);
		By changestoreBtn = By.xpath("//a[contains(@data-itemid,'" + sku + "')]");

		String strChangeStore = dataTable.getData(DataColumn.LocalizeStore);
		commonData.StoreList.add(strChangeStore);
		String strChangeStore1 = dataTable.getData(DataColumn.storeID);
		commonData.StoreList.add(strChangeStore1);

		String zipcode = dataTable.getData(DataColumn.ChangeZipCode);

		// wh.ignorePopup(driver);
		if (commonData.desktopUserAgent) {
			if (wh.isElementPresent(changestoreBtn)) {

				wh.clickElement(changestoreBtn);
				if (wh.isElementPresent(zipCodeOverlay)) {
					report.addReportStep("Check Inventory Overlay", "Check Inventory Overlay opened from Cart Page",
							StepResult.PASS);
					driver.findElement(zipCodeOverlay).clear();
					driver.findElement(zipCodeOverlay).sendKeys(dataTable.getData(DataColumn.multistoreID));
					Thread.sleep(commonData.smallWait);
					wh.clickElement(SearchBtnoverlayFullSite);
					Thread.sleep(commonData.smallWait);
					Thread.sleep(2000l);

					int itemcount = commonData.StoreList.size();

					for (int i = 0; i < itemcount; i++) {

						String store = commonData.StoreList.get(i);

						driver.findElement(
								By.xpath(".//*[@id='bssStores']/../descendant::input[@name='smrtOvQnt_" + store + "']"))
								.sendKeys("1");
						;

					}

					if (wh.isElementPresent(updateCartBtn)) {
						wh.clickElement(updateCartBtn);
					}

					else {
						wh.clickElement(updateCartBtnFullSite);
					}
					Thread.sleep(commonData.smallWait);

				} else {
					report.addReportStep("Check Inventory Overlay",
							"Check Inventory Overlay is not opened from Cart Page", StepResult.FAIL);
				}
			}
		} else {

			if (wh.isElementPresent(changestoreBtn)) {

				wh.clickElement(changestoreBtn);
				if (wh.isElementPresent(zipCodeOverlay)) {
					report.addReportStep("Check Inventory Overlay", "Check Inventory Overlay opened from Cart Page",
							StepResult.PASS);
					driver.findElement(zipCodeOverlay).clear();
					driver.findElement(zipCodeOverlay).sendKeys(zipcode);
					wh.clickElement(SearchBtnoverlay);
					Thread.sleep(2000);

					int itemcount = commonData.StoreList.size();

					for (int i = 0; i < itemcount; i++) {

						String store = commonData.StoreList.get(i);

						driver.findElement(
								By.xpath(".//*[@id='bssStores']/../descendant::input[name='smrtOvQnt_" + store + "']"))
								.sendKeys("1");
						;

					}

					if (wh.isElementPresent(updateCartBtn)) {
						wh.clickElement(updateCartBtn);
					}

					else {
						wh.clickElement(updateCartBtnFullSite);
					}

				} else {
					report.addReportStep("Check Inventory Overlay",
							"Check Inventory Overlay is not opened from Cart Page", StepResult.FAIL);
				}
			}
		}
	}

	public void verifyPromocodeErrMsg() throws Exception {
		if (wh.isElementPresent(txtPromoCode, 2)) {
			// promoCodeText();
			String strPromoCode = dataTable.getData(DataColumn.PromoCode);
			wh.sendKeys(txtPromoCode, strPromoCode);
			System.out.println(strPromoCode);
			wh.clickElement(btnApplyPromo);
			String strPromoErrMsg_1 = driver.findElement(PromoerrorMsg1).getText();
			String strPromoErrMsg_2 = driver.findElement(PromoerrorMsg2).getText();
			if (strPromoErrMsg_1.trim().contains("invalid") && strPromoErrMsg_2.trim().contains("case sensitive")) {
				report.addReportStep(
						"Verify that </b>Promotion code "
								+ strPromoCode
								+ " is invalid.Promotion codes are case sensitive </b>should be displayed on entering wrong Promocode",
						"Verify that </b>Promotion code "
								+ strPromoCode
								+ " is invalid.Promotion codes are case sensitive </b>is displayed on entering wrong Promocode",
						StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify that </b>Promotion code "
								+ strPromoCode
								+ " is invalid.Promotion codes are case sensitive </b>should be displayed on entering wrong Promocode",
						"Verify that </b>Promotion code "
								+ strPromoCode
								+ " is invalid.Promotion codes are case sensitive </b>is displayed on entering wrong Promocode",
						StepResult.FAIL);
			}
		}
	}

	// *************************Instant Rebates
	// **************************************//

	/**
	 * Instant Rebate Method to verify the IR message in cart when FM is changed
	 * 
	 * @author vxr8682 & u93wcs
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public ShoppingCartPage verifyIRmessageinCart() throws Exception {

		String IREligMsg1 = "";
		String IREligMsg3 = "";
		String IREligMsg4 = "";
		String IRInEligMsg1 = "";

		IREligMsg1 = commonData.InstantRebateEligMsg1_CC;
		IREligMsg3 = commonData.InstantRebateEligMsg3_CC;
		IRInEligMsg1 = commonData.InstantRebateIneligMsg1_CC;
		IREligMsg4 = commonData.InstantRebateEligMsg4_CC;

		int itemcount = commonData.skuList.size();

		for (int i = 0; i < itemcount; i++) {

			String sku = commonData.skuList.get(i);

			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);

			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);

			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));

			By InstantRebateMsg = By.xpath(".//*[@value='" + sku + "']/../descendant::div[@class='cart-item-message']");

			if ((val2 < val1)) {

				if (wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IREligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg1, StepResult.FAIL);

					}

				}

				else if (wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IREligMsg3)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg3, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg3, StepResult.FAIL);

					}

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && (!(StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);

					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);

					}

				} else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}

			}

			else if ((val2 > val1))

			{
				if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && (!(StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);

					}

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);

					}

				}

				else if ((wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);

					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);

					}

				}

				else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}

			} else if ((val2 == val1)) {

				if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				} else if ((wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is displayed", StepResult.FAIL);
				}
			}
			continue;
		}
		return this;
	}

	/**
	 * Instant Rebate Method to change the localized store in header
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public ShoppingCartPage Fulfilmenttype() throws Exception {

		int itemcount = commonData.skuList.size();

		for (int i = 0; i < itemcount; i++) {

			String sku = commonData.skuList.get(i);
			By CheckedValue = By.xpath(".//*[@value='" + sku + "']/../descendant::input[@checked='true']");

			String Fulfilment = driver.findElement(CheckedValue).getAttribute("value");

			if ((!(Fulfilment == null)) && (Fulfilment.contains("ShipToHome"))) {
				commonData.STHSKUList.add(sku);

			}

			else if ((!(Fulfilment == null)) && (Fulfilment.contains("BOPIS")) || (Fulfilment.contains("BOSS"))) {
				commonData.BOPISSKUList.add(sku);
			}

			continue;
		}

		int STHCount = commonData.STHSKUList.size();
		int BOPISCount = commonData.BOPISSKUList.size();

		if ((STHCount > 1) && (BOPISCount > 1))

		{
			commonData.mixedcart = true;

		}

		return this;

	}

	/**
	 * To verify page level error in shopping cart page
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */
	public void verifyPageLevelError() throws Exception {
		// TODO Auto-generated method stub
		if (wh.isElementPresent(qtyError, 3)) {
			// To verify cart page level error
			String strErrorMessage = wh.getText(qtyError);
			if (strErrorMessage.contains("Your local store has been changed"))
				report.addReportStep("Verfy cart Page error message",
						"Cart Page level error message is displayed : <b>" + strErrorMessage + "</b>", StepResult.PASS);
			else
				report.addReportStep("Verfy cart Page error message",
						"Cart Page level error message is not displayed properly.", StepResult.FAIL);

		} else
			report.addReportStep("Verfy cart Page error message", "Cart Page level error message is not displayed.",
					StepResult.FAIL);
	}

	/**
	 * Instant Rebate Method to change the localized store in header
	 * 
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public ShoppingCartPage headerlocalization() throws Exception {

		By wElm;

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-550)", "");
		Thread.sleep(commonData.littleWait);
		wh.clickElement(lnkStoreFinder);
		Thread.sleep(commonData.littleWait);

		wElm = changeStoreLink;

		if (wh.isElementPresent(wElm)) {
			wh.waitForPageLoaded();
			wh.clickElement(wElm);

			report.addReportStep("Click on (change) link in the header", "Change link clicked", StepResult.PASS);
		} else {
			report.addReportStep("Click on (change ) link in the header", "Change link not present on header",
					StepResult.FAIL);

			rc.terminateTestCase("Change Link on header");
		}

		driver.switchTo().defaultContent();

		String localStore = commonData.localizestore;

		if (wh.isElementPresent(changeStoreOverlay)) {
			wh.clearElement(storeFinderBox);
			wh.sendKeys(storeFinderBox, localStore);
			wh.clickElement(storeFinderBtn);
			Thread.sleep(commonData.littleWait);
			wh.clickElement(makeThisYourStoreLink);
			Thread.sleep(commonData.smallWait);

			report.addReportStep("Change Localization store", "Localization store changed", StepResult.PASS);
		} else {
			report.addReportStep("Change Localization store",
					"Localization store not changed, Change store overlay not closed", StepResult.FAIL);

			rc.terminateTestCase("Change Local Store");
		}

		return this;
	}

	public void pickupStore() throws Exception {
		String sku = dataTable.getData(DataColumn.SKU);

		By Fullfilment = By.xpath("//a[contains(@href,'" + sku + "')]/../../div[2]//label[contains(@for,'BOPIS_')]");

		if (wh.isElementPresent(Fullfilment)) {

			driver.findElement(Fullfilment).click();
			report.addReportStep("Click the Pick up in Store radio button cart page",
					"Pick up in Store radio button is clicked in cart page", StepResult.PASS);

		} else {
			report.addReportStep("Click the Pick up in Store radio button cart page",
					"Pick up in Store radio button is not clicked in cart page", StepResult.FAIL);
		}
		Thread.sleep(commonData.mediumWait);
	}

	/**
	 * Method to select STH radio button
	 * 
	 * @author vxr8682
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public void sthradiobtn() throws Exception {
		String sku = dataTable.getData(DataColumn.SKU);

		By Fullfilment = By.xpath("//a[contains(@href,'" + sku
				+ "')]/../../div[2]//label[contains(@for,'ShipToHome_')]");

		if (wh.isElementPresent(Fullfilment)) {

			driver.findElement(Fullfilment).click();

			report.addReportStep("Click the Ship to home radio button cart page",
					"Ship to Home radio button is clicked in cart page", StepResult.PASS);

		} else {
			report.addReportStep("Click the Ship to home radio button cart page",
					"Ship to Home radio button is not clicked in cart page", StepResult.FAIL);
		}
		Thread.sleep(commonData.mediumWait);
	}

	public ShoppingCartPage signInreguser() throws Exception {

		wh.clickElement(lnkSignIn);
		wh.clickElement(signInLink);

		if (wh.isElementPresent(emailTxtBox, 5)) {

			String Emailid = dataTable.getData("Regusername");
			String pswd = dataTable.getData("Regpwd");

			wh.sendKeys(emailTxtBox, Emailid);

			wh.sendKeys(passwordTxtBox, pswd);

			wh.clickElement(signInBtn);

			wh.waitForPageLoaded();

			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Selected register user, entered email password and clicked on continue", StepResult.PASS);
		} else {
			report.addReportStep("Select Register user, enter email, password and click on continue",
					"Not Selected register user, not entered email password and clicked on continue", StepResult.FAIL);
			rc.terminateTestCase("Checkout Sign in page");
		}

		return this;
	}

	/**
	 * Method to remove item from cart
	 * 
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage removeallitems() throws Exception {

		wh.waitForPageLoaded();

		List<WebElement> removeLnk = wh.getElements(removeLink);

		int noOfItems = removeLnk.size();

		for (int i = 0; i < noOfItems; i++) {

			if (wh.isElementPresent(removeLink)) {

				wh.clickElement(removeLink);

				report.addReportStep("Remove item from cart", "Item is removed from cart", StepResult.PASS);

			} else {
				report.addReportStep("Remove item from cart", "Item is not removed from cart", StepResult.FAIL);
			}

		}

		return this;

	}

	/**
	 * Method to get the price and store promotion from Pricing API
	 * 
	 * @author u93wcs
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public String getpricedetails(DataBase database) throws Exception {

		int noOfItems = commonData.skuList.size();
		int storecount = commonData.StoreList.size();
		String store = null;
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.skuList.get(i);

			if (storecount > 1) {

			//store = commonData.StoreList.get(i);
			store = dataTable.getData(DataColumn.storeID);
			}

			else {
				store = dataTable.getData(DataColumn.storeID);
			}

			database.getUnitPriceFromPricingService(sku, store);

		}
		commonData.IRList1.add(commonData.shortdesc);
		commonData.PriceList1.add(commonData.unitPriceDB);

		return null;

	}

	/**
	 * Method to click checkoutnow button
	 * 
	 * @author vxr8682
	 * @return Shopping cart page
	 * @throws Exception
	 */

	public ShippingPage clickCheckoutNowBtn() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementNotPresent(checkoutNowBtn)) {

			wh.waitForElementPresent(checkoutNowBtn, 30);
		}

		wh.clickElement(checkoutNowBtn);

		report.addReportStep("Click checkout now button in Shopping Cart Page",
				"Clicked check out now button in Shopping Cart Page", StepResult.PASS);

		return new ShippingPage(ic);
	}

	// **********************Instant Rebates***************************//

	/**
	 * To verify qty update is disabled in cart for appliance items
	 * 
	 * @throws Exception
	 */
	public void verifyQtyBoxDisabled() throws Exception {
		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//a[contains(@href,'" + skupath + "')]/../..//input[contains(@id,'quantity_')]");
		if (wh.isElementPresent(fulfilmentpath)) {
			boolean QtyinShoppingCart = driver.findElement(fulfilmentpath).isEnabled();

			if (QtyinShoppingCart == false) {
				report.addReportStep("Verify that quantity field is disabled for appliance item ",
						"Quantity field is disabled in cart page", StepResult.PASS);
			} else {
				report.addReportStep("Verify that quantity field is disabled for appliance item ",
						"Quantity field is not disabled in cart page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify that quantity field is disabled for appliance item ",
					"Quantity field is not displayed in Cart Page", StepResult.FAIL);
		}
	}

	public ShoppingCartPage clickRemoveLinkMixedCart() throws Exception {

		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//a[contains(@href,'" + skupath
				+ "')]/../../../../..//a[@class='delete-cart-item']");
		if (wh.isElementPresent(fulfilmentpath, 5)) {

			wh.clickElement(fulfilmentpath);

			report.addReportStep("Click remove link in cart", "Item removed from cart", StepResult.PASS);

		} else {
			report.addReportStep("Click remove link in cart", "Item not removed from cart", StepResult.FAIL);
		}
		Thread.sleep(commonData.mediumWait);
		return this;

	}

	public void clickATCCertonaCart() throws Exception {
		if (wh.isElementPresent(certonaAddToCartBtnCart, 5)) {

			wh.clickElement(certonaAddToCartBtnCart);

			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is clicked in certona section", StepResult.PASS);

		} else {
			report.addReportStep("Click Add to cart button in certona section",
					"Add to cart button is not clicked in certona section", StepResult.FAIL);
		}
		Thread.sleep(commonData.mediumWait);

	}

	public ShoppingCartPage clickAddToListItemCart() throws Exception {

		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		By fulfilmentpath = By.xpath("//a[contains(@href,'" + skupath
				+ "')]/../../..//div[contains(@id,'add-to-list')]");
		if (wh.isElementPresent(fulfilmentpath, 5)) {

			wh.clickElement(fulfilmentpath);

			report.addReportStep("Click Add to List link in cart", "Add to List link is clicked in cart",
					StepResult.PASS);

		} else {
			report.addReportStep("Click Add to List link in cart", "Add to List link is not displayed in cart",
					StepResult.FAIL);
		}
		Thread.sleep(commonData.mediumWait);
		return this;

	}

	public void verifyLimitPerOrderErrMsg() throws Exception {

		if (wh.isElementPresent(limPerOrderErrMsg, 2)) {
			String errMsg = driver.findElement(limPerOrderErrMsg).getText();
			if (errMsg
					.contains("Quantity requested exceeds purchase limit for this order. Please reduce your selected quantity.")) {
				report.addReportStep("Verify the limited per order error message is displayed", "Error message<b>"
						+ errMsg + "</b>is displayed", StepResult.PASS);
				System.out.println(errMsg);
			} else {
				report.addReportStep("Verify the limited per order error message is displayed", "Error message<b>"
						+ errMsg + "</b>is not  displayed properly", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify the  limited per order error message is displayed",
					"Error message page is not displayed", StepResult.FAIL);
		}

	}

	public void increaseQtyMoreThanStockInOverlay() throws Exception {

		if (wh.isElementPresent(zipCodeOverlay)) {
			String inStock = driver.findElement(By.xpath("//div[@class='smrtOvNumInStock b']/span")).getText().trim();
			if (!inStock.isEmpty()) {
				int qty = Integer.parseInt(inStock);

				driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
						.sendKeys(Integer.toString(qty + 1));
				report.addReportStep("Verify quantity is increased than stock", "Quantity is increased than stock",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify quantity is increased than stock", "Quantity is not increased than stock",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify change store overlay is displayed", "Change store overlay is not displayed",
					StepResult.FAIL);
		}

	}

	public ShoppingCartPage verifyInvalidPromo() throws Exception {

		Thread.sleep(commonData.smallWait);
		if (wh.isElementNotPresent(promoSection)) {
			report.addReportStep("Check for Invalid or Removed promo",
					"Invalid or Removed promo is not displayed in order summary", StepResult.PASS);
		} else {
			report.addReportStep("Check for Invalid or Removed promo",
					"Invalid or Removed promo is displayed in order summary", StepResult.FAIL);
		}
		return this;
	}

	public ShoppingCartPage verifyPartAndServices() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(partsAndServices, 5) && wh.isElementPresent(partsAndServicesOverlay, 5)) {

			report.addReportStep("Verify parts and services overlay",
					"Parts and services overlay is displayed on click of checkout now", StepResult.PASS);

		} else {
			report.addReportStep("Verify parts and services overlay",
					"Parts and services overlay is not displayed on click of checkout now", StepResult.FAIL);
		}

		return this;

	}

	public void verifyQtyExceedsErrorMsg() throws Exception {

		if (wh.isElementPresent(zipCodeOverlay)) {
			String errMsg = driver.findElement(By.xpath("//div[@class='smrtOv-PgLevlErr btn-clear b']/span")).getText()
					.trim();
			if (errMsg.contains("Quantity requested exceeds available amount at your local store")) {
				report.addReportStep("Verify quantity exceeded error message is displayed", "Error message<b>" + errMsg
						+ "</b>is  displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify quantity exceeded error message is displayed", "Error message<b>" + errMsg
						+ "</b>is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify quantity exceeded error message is displayed",
					"Change store overlay is not displayed", StepResult.FAIL);
		}

	}

	public void increaseQtyLimitPerOrder() throws Exception {

		if (wh.isElementPresent(limPerOrderCount)) {
			String limitCount = driver.findElement(limPerOrderCount).getText().trim();
			System.out.println(limitCount);
			if (limitCount.contains("Limit")) {
				String limitQty = limitCount.replaceAll("Limit", "").trim();
				String limitCnt = limitQty.replaceAll("per Order", "").trim();

				report.addReportStep("Verify limit per order count is taken from cart",
						"Limit per order count is taken from cart", StepResult.PASS);
				clickChangePickUpStoreLink();
				if (wh.isElementPresent(zipCodeOverlay)) {
					if (!limitCnt.isEmpty()) {
						int limitOrder = Integer.parseInt(limitCnt);
						driver.findElement(By.xpath("//input[contains(@class,'input-mini localStr-Qnt smrtQtyInp')]"))
								.sendKeys(Integer.toString(limitOrder + 1));
						report.addReportStep("Verify quantity is increased than stock",
								"Quantity is increased than stock", StepResult.PASS);
					} else {
						report.addReportStep("Verify quantity is increased than stock",
								"Quantity is not increased than stock", StepResult.FAIL);
					}
				} else {
					report.addReportStep("Verify change store overlay is displayed",
							"Change store overlay is not displayed", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify limit per order count is taken from cart",
						"Limit per order count is not taken from cart", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify limit per order count is displayed", "Limit per order count is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyWarningMsgOnZipCdChangeBODFS() throws Exception {

		if (wh.isElementPresent(itemUpdMsg1)) {
			String errMsg = driver.findElement(itemUpdMsg1).getText().trim();
			if (errMsg.contains("Pricing was updated based on your delivery ZIP code")) {
				report.addReportStep("Verify warning message is displayed on change of zipcode in cart for BODFS",
						"Warning message<b> " + errMsg + " </b> is  displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify warning message is displayed on change of zipcode in cart for BODFS",
						"Warning message<b> " + errMsg + " </b> is  not displayed properly", StepResult.FAIL);

			}
		} else {
			report.addReportStep("Verify warning message is displayed on change of zipcode in cart for BODFS",
					"Warning message is not displayed", StepResult.FAIL);
		}

	}

	public ShoppingCartPage signInAddToList(String email, String password) throws Exception {

		if (wh.isElementPresentAfterWait(verifySignInPage)) {

			report.addReportStep("Click on 'Sign in' link present on the top right side of the page",
					"Sign In page displayed successfully", StepResult.PASS);

			wh.sendKeys(emailTxtBox, email);
			wh.sendKeys(passwordTxtBox, password);
			wh.clickElement(signInBtn);
			Thread.sleep(commonData.smallWait);
			wh.waitForPageLoaded();

		} else {
			report.addReportStep("Click on Sign In link", "Sign In page did not get displayed", StepResult.FAIL);
		}

		return this;
	}

	public ShoppingCartPage verifyAddToListOverlay() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(addToListOverlay, 5)) {

			report.addReportStep("Verify add to list overlay", "Add to list overlay is displayed", StepResult.PASS);

		} else {
			report.addReportStep("Verify add to list overlay", "Add to list overlay is displayed", StepResult.FAIL);
		}

		return this;

	}

	public void verifyErrMsgInvalidZipAppliance() throws Exception {

		if (wh.isElementPresent(errMsgZipcd)) {
			String errMsg = driver.findElement(errMsgZipcd).getText().trim();
			if (errMsg.contains("Please enter a valid ZIP code")) {
				report.addReportStep("Verify invalid zip code error message is displayed", "Error message<b>" + errMsg
						+ "</b>is  displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify invalid zip code error message is displayed", "Error message<b>" + errMsg
						+ "</b>is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify invalid zip code error message is displayed",
					"Invalid zip code error message is not displayed", StepResult.FAIL);
		}

	}

	public void verifyDeliveryUnavailAppliance() throws Exception {

		if (wh.isElementPresent(errMsgDelUnavail)) {
			String errMsg = driver.findElement(errMsgDelUnavail).getText().trim();
			if (errMsg.contains("Please contact your local store to order and arrange delivery")) {
				report.addReportStep("Verify delivery unavailable error message is displayed", "Error message<b> "
						+ errMsg + " </b>is  displayed", StepResult.PASS);

			} else {
				report.addReportStep("Verify delivery unavailable error message is displayed", "Error message<b> "
						+ errMsg + " </b>is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify delivery unavailable error message is displayed",
					"Delivery unavailable error message is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify the count down timer displayed for parcel sth sku
	 * 
	 * @throws Exception
	 */
	public void verifyCountDownTimer() throws Exception {
		if (wh.isElementPresent(CountDownTimer, 5)) {
			String strcountdown = driver.findElement(CountDownTimer).getText();
			System.out.println(strcountdown);
			if (strcountdown.contains("Order within") && strcountdown.contains("get it by")) {
				report.addReportStep("verify the count down timer", "count down time:'<b>" + strcountdown
						+ "</b>' is displayed", StepResult.PASS);
			} else {
				report.addReportStep("verify the count down timer", "count down time is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("verify the count down timer", "DETA sku is not displayed in cart page",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the estimated arrival text in cart page for STH
	 * 
	 * @throws Exception
	 */
	public void verifyEstimatedArrival() throws Exception {
		if (wh.isElementPresent(ETA, 3)) {
			String strETASTH = driver.findElement(ETA).getText();
			System.out.println("STH ETA" + strETASTH);
			if (strETASTH.contains("Estimated Arrival:")) {
				report.addReportStep("Estimated Arrival date should be displayed", "<b>" + strETASTH
						+ "</b> date is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Estimated Arrival date should be displayed",
						"Estimated Arrival date is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Estimated Arrival date should be displayed",
					"Estimated Arrival date is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the from $xx.xx value in cart page for STH
	 * 
	 * @throws Exception
	 */
	public void verifyFromValueSTH() throws Exception {
		if (wh.isElementPresent(FromValue, 2)) {
			String strFromValue = driver.findElement(FromValue).getText();
			System.out.println(strFromValue);
			commonData.strFromPrice = strFromValue;
			if (strFromValue.contains("from")) {
				report.addReportStep("verify the from value for STH", "Shipping value:'<b>" + strFromValue
						+ "</b>' is displayed", StepResult.PASS);
			} else {
				report.addReportStep("verify the from value for STH", "Shipping value is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("verify the from value for STH", "DETA sku is not displayed in cart page",
					StepResult.FAIL);
		}

	}

	public void enterQtyMoreThanAvailable() throws Exception {
		int availQty = 0;

		if (wh.isElementPresent(availableqty)) {
			report.addReportStep("Verify available Qty", "Available Qty is displayed", StepResult.PASS);
			String str = wh.getText(availableqty);
			availQty = Integer.parseInt(str);

		} else {
			report.addReportStep("Verify available Qty", "Available Qty is not displayed", StepResult.FAIL);
		}
		wh.sendKeys(Quantity, "\u0008");
		wh.sendKeys(Quantity, String.valueOf(availQty + 1));
		driver.findElement(Quantity).sendKeys(Keys.TAB);
		report.addReportStep("Enter Qty more than available", "Qty more than available is entered", StepResult.PASS);
	}

	public void verifyQuantityExceedsErrMsgonOverlay() throws Exception {
		if (wh.isElementPresent(overlayErrMsg, 10)) {
			String strErrMsg = wh.getText(overlayErrMsg);

			if (strErrMsg
					.contains("Quantity requested exceeds available amount at your local store. Please select remaining quantity from other store(s).")) {
				report.addReportStep(
						"Verify error message <b>'some items in your order are not in stock is'</b> displayed",
						"error message <b>" + strErrMsg + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify error message: 'Quantity requested exceeds available amount at your local store. Please select remaining quantity from other store(s).' displayed",
						"error message <b>" + strErrMsg + "</b> is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify error message: 'Quantity requested exceeds available amount at your local store. Please select remaining quantity from other store(s).' displayed",
					"Page level error message <b>'Quantity requested exceeds available amount at your local store. Please select remaining quantity from other store(s).'</b> is not displayed",
					StepResult.FAIL);
		}
	}

	public ShoppingCartPage verifyBackorderMsg() throws Exception {

		wh.waitForPageLoaded();
		String errorMsg = driver.findElement(backorderMsg).getText();
		if (wh.isElementPresent(backorderMsg, 20)) {
			if (errorMsg.contains("Backorder")) {

				report.addReportStep("Verify Backorder error message", "Backorder error message is displayed",
						StepResult.PASS);
			}
		} else {

			report.addReportStep("Verify Backorder error message", "Backorder error message is not displayed",
					StepResult.FAIL);

			rc.terminateTestCase("Shopping Cart Page");
		}

		return this;
	}

	/**
	 * Component to get the subtotal with promo
	 * 
	 * @throws InterruptedException
	 */
	public void getTotalWithPromo() throws InterruptedException {
		String strTotalwithPro = driver.findElement(By.xpath("//*[@class='bold text-right orCharges']")).getText();
		commonData.strTotalWithPromo = strTotalwithPro;

		report.addReportStep("Get the total with promo", "<b>" + commonData.strTotalWithPromo
				+ "</b> Subtotal is displayed", StepResult.DONE);
	}

	/**
	 * Component to get the subtotal without promo
	 * 
	 * @throws InterruptedException
	 */
	public void getTotalWithoutPromo() throws InterruptedException {
		String strTotalwithoutPro = driver.findElement(By.xpath("//*[@class='bold text-right orCharges']")).getText();
		commonData.strTotalWithoutPromo = strTotalwithoutPro;

		report.addReportStep("Get the total with out promo", "<b>" + commonData.strTotalWithoutPromo
				+ "</b> Subtotal is displayed", StepResult.DONE);
	}

	/**
	 * Component to verify that the order total is recalculated in cart page
	 * 
	 * @throws InterruptedException
	 */
	public void verifyTotalRecalculated() throws InterruptedException {
		System.out.println(commonData.strTotalWithPromo);
		System.out.println(commonData.strTotalWithoutPromo);
		if (!commonData.strTotalWithPromo.contains(commonData.strTotalWithoutPromo)) {
			report.addReportStep("verify total recalculated", "Total is recalculated", StepResult.PASS);
		} else {
			report.addReportStep("verify total recalculated", "Total is not recalculated", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify You saved Section not displayed in cart page
	 * 
	 * @return
	 * @throws Exception
	 */
	public void verifyYouSavedNotDisplayed() throws Exception {
		if (!(wh.isElementPresent(By.className("orItemList youSaved"), 2))) {
			report.addReportStep("Verify <b>you saved</b> text is not displayed in the shopping cart page",
					"<b>You saved is NOT displayed </b> in the shopping cart page", StepResult.PASS);

		} else {

			report.addReportStep("Verify <b>you saved</b> text is not displayed in the shopping cart page",
					"<b>You saved</b> button is displayed in the shopping cart page", StepResult.FAIL);
		}

	}

	public void verifyLimitperOrderMsg() throws Exception {
		String qty = dataTable.getData(DataColumn.Quantity);

		wh.waitForPageLoaded();

		Thread.sleep(commonData.smallWait);
		if (wh.isElementPresent(Quantity, 5)) {
			String strQtyinShoppingCart = driver.findElement(Quantity).getAttribute("value");
			if (!strQtyinShoppingCart.isEmpty()) {
				report.addReportStep("Verify that quantity displayed in Cart Page", "quantity value is <b> "
						+ strQtyinShoppingCart + " </b>in cart page", StepResult.PASS);

				driver.findElement(Quantity).sendKeys("\u0008");
				wh.sendKeys(Quantity, qty);
				if (wh.isElementPresent(limitperorder, 3)) {
					String Msg = driver.findElement(limitperorder).getText();
					if (Msg.contains("limited")) {

						report.addReportStep("Verfy limit per order message below qty field",
								"limit per order message is displayed below qty field : <b>" + Msg + "</b>",
								StepResult.PASS);
					}
				} else {
					report.addReportStep("Verfy limit per order message below qty field",
							"limit per order message is not displayed below qty field : <b>", StepResult.WARNING);
				}

				Thread.sleep(commonData.smallWait);

				report.addReportStep("Verify that quantity entered is " + qty, "Quantity is entered as " + qty
						+ " in cart page", StepResult.PASS);

			}
		} else {
			report.addReportStep("Verify that quantity entered is " + qty, "Quantity is not displayed in Cart Page",
					StepResult.FAIL);
		}

	}

	public ShoppingCartPage verifyWarningMsgPromo() throws Exception {
		if (wh.isElementPresent(warningPromo)) {
			String strErrMsg = wh.getText(warningPromo);

			if (strErrMsg.contains("Your order must meet the minimum purchase")) {
				report.addReportStep("Verify warning message for wrong promo", "Error message <b>" + strErrMsg
						+ "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify warning message for wrong promo", "Error message <b>" + strErrMsg
						+ "</b> is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify warning message for wrong promo", "Error message is not displayed",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Update the quantity above threshold
	 * 
	 * @throws Exception
	 */

	public void updateQtyAbvThreshold() throws Exception {
		String strQuantity = null;
		String skupath = dataTable.getData(DataColumn.SKU);
		System.out.println(skupath);
		wh.isElementPresent(bulkPricingMsg, 3);

		// Fetch threshold limit
		String strThresholdLimit = driver.findElement(bulkPricingMsg).getText();
		System.out.println(strThresholdLimit);

		strThresholdLimit = strThresholdLimit.substring(strThresholdLimit.indexOf("least") + 6,
				strThresholdLimit.indexOf("units") - 3);
		System.out.println(strThresholdLimit);

		int intThresholdLimit = Integer.parseInt(strThresholdLimit);
		String strAboveThresholdLimit = new Integer(intThresholdLimit + 1).toString();
		System.out.println(strAboveThresholdLimit);
		driver.findElement(By.xpath("//*[contains(@id,'quantity_')]")).clear();
		driver.findElement(By.xpath("//*[contains(@id,'quantity_')]")).sendKeys(strAboveThresholdLimit);

		Thread.sleep(1000);

		// Get the Quantity after updating and verify
		Thread.sleep(1000);
		if (wh.isElementPresent(By.cssSelector("#quantity_1"), 4)) {
			strQuantity = driver.findElement(By.cssSelector("#quantity_1")).getAttribute("value");
		} else if (wh.isElementPresent(By.cssSelector(".qty-wrapper.quantity-section input"), 2)) {
			strQuantity = driver.findElement(By.cssSelector(".qty-wrapper.quantity-section input")).getAttribute(
					"value");
		}
		if (strAboveThresholdLimit.equals(strQuantity)) {
			report.addReportStep("Increase the quantity to greater than threshold limit <b>" + intThresholdLimit
					+ " </b>and click on the Update link below the quantity field", "Increased quantity "
					+ intThresholdLimit + "  is  displayed in the quantity field", StepResult.PASS);
		} else {
			report.addReportStep("Increase the quantity to greater than threshold limit " + intThresholdLimit
					+ "  and click on the Update link below the quantity field", "Increased quantity "
					+ intThresholdLimit + " is not displayed in the quantity field", StepResult.FAIL);
		}
	}

	public ShoppingCartPage verifyNoErrorCartPage() throws Exception {
		if (wh.isElementNotPresent(cartErrMsg)) {

			report.addReportStep("Verify No Error message is displayed in cart", "No Error message is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify No Error message is displayed in cart", "Error message is displayed in cart",
					StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Component to update the quantity based on the
	 * 
	 * @throws Exception
	 */
	public void quantUpdateEqualThresh() throws Exception {
		if (wh.isElementPresent(qtyTxtBox, 5)) {
			try {
				driver.findElement(By.xpath("//*[contains(@id,'quantity_')]")).clear();

				report.addReportStep("Clear the quantity field", "quantity field cleared", StepResult.PASS);
				if (wh.isElementPresent(By.xpath("//span[contains(@class,'message-txt-container m-right-small')]"), 2)) {
					String thres1 = driver.findElement(
							By.xpath("//span[contains(@class,'message-txt-container m-right-small')]")).getText();
					System.out.println(thres1);
					String thres = "";

					if (thres1.contains("units")) {
						String threshold = thres1.split("at least ")[1];
						thres = threshold.split("\\.")[0];
						int intThresholdLimit = Integer.parseInt(thres);
						String strAboveThresholdLimit = new Integer(intThresholdLimit + 1).toString();
						System.out.println(strAboveThresholdLimit);
						wh.waitForElementPresent(By.cssSelector(".qty-wrapper.quantity-section input"), 5);
						/*
						 * JavascriptExecutor js = (JavascriptExecutor) driver;
						 * js.executeScript(
						 * "arguments[0].setAttribute('value', " +
						 * strAboveThresholdLimit + ");", driver.findElement(By
						 * .
						 * cssSelector(".qty-wrapper.quantity-section input")));
						 */
						driver.findElement(By.xpath("//*[contains(@id,'quantity_')]")).sendKeys(strAboveThresholdLimit);
						driver.navigate().refresh();
						if (wh.isElementPresent(qtyTxtBox, 5)) {
							String qty = driver.findElement(qtyTxtBox).getAttribute("value");

							System.out.println(qty);
							if (qty.equals(thres)) {
								report.addReportStep(
										"Enter the Quantity in the quantity field and click on update button",
										"The quantity is updated on page refresh", StepResult.PASS);
							} else {
								report.addReportStep(
										"Enter the Quantity in the quantity field and click on update button",
										"The quantity is not updated on page refresh", StepResult.WARNING);
							}

							if (wh.isElementPresent(
									By.xpath("//span[contains(@class,'message-txt-container m-right-small')]"), 2)) {
								String thresholdprice1 = driver.findElement(
										By.xpath("//span[contains(@class,'message-txt-container m-right-small')]"))
										.getText();

								String thresholdprice = "";
								if (thresholdprice1.contains("$")) {
									thresholdprice = thresholdprice1.split("\\$")[1].split(" ")[0];
								} else {
									thresholdprice = thresholdprice1;
								}
								if (wh.isElementPresent(UnitPrice, 2)) {

									String updatedUnitprice = driver.findElement(UnitPrice).getText();
									String arrprice = "$" + thresholdprice;
									if (arrprice.equals(updatedUnitprice))
										report.addReportStep(
												"The New unit price in Shopping Cart page when the entered quantity is equal to threshold limit",
												"The New Unit price is displayed", StepResult.PASS);
									else
										report.addReportStep(
												"The New unit price in Shopping Cart page when the entered quantity is equal to threshold limit",
												"The New Unit price is not displayed", StepResult.FAIL);

								} else {
									report.addReportStep(
											"The New unit price in Shopping Cart page when the entered quantity is equal to threshold limit",
											"The New Unit price is not displayed", StepResult.FAIL);
									commonData.blnGracefulExit = true;
								}

							} else {
								report.addReportStep(
										"Verify that the Bulk pricing promo message is displayed in the Cart page after refresh",
										"The Promo message is not displayed", StepResult.FAIL);
								commonData.blnGracefulExit = true;

							}

						} else {
							report.addReportStep("Verify that Quantity field is displayed after page refresh",
									"The Quantity field is not displayed", StepResult.FAIL);
							commonData.blnGracefulExit = true;
						}

					} else {
						report.addReportStep("Verify that the bulk pricing message is displayed in the right format",
								"The message is not in proper format", StepResult.FAIL);
						commonData.blnGracefulExit = true;
					}

				} else {
					report.addReportStep("Verify that Bulk pricing promotion message is displayed",
							"The Promotion message is not displayed", StepResult.FAIL);
					commonData.blnGracefulExit = true;
				}

			} catch (Exception e) {
				report.addReportStep("Clear the quantity field", "quantity field not cleared", StepResult.WARNING);
			}

		} else {
			report.addReportStep("Clear the quantity field", "quantity field not found", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	public ShoppingCartPage verifyWarningBOSSInOverlay() throws Exception {
		if (wh.isElementPresent(warninMsgSTS)) {
			String strErrMsg = wh.getText(warninMsgSTS);

			if (strErrMsg.contains("Choose Ship to Store to pick up this item")) {
				report.addReportStep("Verify warning message for BOSS", "Error message <b>" + strErrMsg
						+ "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify warning message for BOSS", "Error message <b>" + strErrMsg
						+ "</b> is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify warning message for BOSS", "Error message is not displayed", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Component to compare the Estimate Toatl in Cart Page Before and
	 * afterremoving the Line item from the cart page
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void checkEstimatedTotAftrRmvingItem() throws Exception {
		if (wh.isElementPresent(estimatedSubtotalValue)) {
			String strEstimatedTotalAfter = wh.getText(estimatedSubtotalValue).split("\\$")[1];
			String strEstimatedTotalBefore = commonData.strEstTotal;

			if (strEstimatedTotalAfter != strEstimatedTotalBefore) {
				report.addReportStep(
						"Verify the <b>'Estimated Total' </b>amount in shopping cart after removing the line item",
						"'Shopping cart' line item  <b> 'Estimated Total' is updated with " + strEstimatedTotalAfter
								+ " </b>after the item line has been removed", StepResult.PASS);
			} else {
				report.addReportStep(
						"Verify the <b>'Estimated Total' </b>amount in shopping cart after removing the line item",
						"'Shopping cart' line item  <b> 'Estimated Total' is not updated </b>after the item line has been removed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify the <b>'Estimated Total' </b> in shopping cart page",
					"Estimated subtotal is not displayed in cart page", StepResult.FAIL);
		}
	}

	/**
	 * Function to validate free shipping eligible message for online SKU
	 * 
	 * @throws Exception
	 * @InputParameters None
	 * @Author RXP8655
	 */
	public void freeShippingEligibleMsg() throws Exception {
		if (wh.isElementPresent(freeShipMsg)) {
			String strFreeShip = wh.getText(freeShipMsg);
			String strExpeted = "to your cart to receive FREE Shipping on eligible items.";
			if (strFreeShip.contains(strExpeted))
				report.addReportStep("Verify the free shipping  text is displayed in Cart page", "<b>" + strFreeShip
						+ " </b> Free Shipping eligible Message is displayed </b>", StepResult.PASS);
			else
				report.addReportStep("Verify the free shipping  text is displayed in Cart page",
						"Free shipping eligible message is not displayed", StepResult.FAIL);

		} else {
			report.addReportStep("Verify that the free shipping  text is displayed in Shopping Cart page ",
					"Unable to analyse the message", StepResult.FAIL);
		}
	}

	/**
	 * Function to validate free shipping message for online SKU
	 * 
	 * @throws Exception
	 * @InputParameters None
	 * @Author RXP8655
	 */
	public void freeShippingMsg() throws Exception {
		if (wh.isElementPresent(freeShipMsg)) {
			String strFreeShip = wh.getText(freeShipMsg);
			String strExpeted = "FREE Shipping on eligible items.";
			if (strFreeShip.contains(strExpeted)
					&& !strFreeShip.contains("to your cart to receive FREE Shipping on eligible items."))
				report.addReportStep("Verify the free shipping is displayed in Cart page", "<b>" + strFreeShip
						+ " </b> Free Shipping Message is displayed </b>", StepResult.PASS);
			else
				report.addReportStep("Verify the free shipping is displayed in Cart page",
						"Free shipping message is not displayed", StepResult.FAIL);

		} else {
			report.addReportStep("Verify that the free shipping is displayed in Shopping Cart page ",
					"Unable to analyse the message", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify there is a text box to enter the Promotion code and
	 * apply button in Shopping cart page
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifyPromoSection() throws Exception {
		boolean blnpromo = false;
		if (wh.isElementPresent(txtPromoCode)) {
			blnpromo = wh.isElementPresent(txtPromoCode);
			String strPromoUpdate = wh.getText(btnApplyPromo);
			System.out.println(strPromoUpdate);
			if ((blnpromo) && (strPromoUpdate.contains("APPLY"))) {
				report.addReportStep(
						"Validate that there is a textbox to enter a Promotion code with 'APPLY' button beside it",
						"A textbox is displayed with <b>'APPLY' </b>button under the 'Promotion Code' section.",
						StepResult.PASS);

			} else {
				report.addReportStep(
						"Validate that there is a textbox to enter a Promotion code with 'APPLYs' button beside it",
						"A textbox is not displayed with <b>'APPLY' </b>button under the 'Promotion Code' section.",
						StepResult.FAIL);

			}
		} else {
			report.addReportStep("verify promo section in cart page", "Promo section is not displayed in cart page",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to click on the product 'Description' from 'Shopping cart' and
	 * verify it is navigated to PIP page
	 * @author RXP8655
	 * @throws Exception
	 */
	public void shoppingCartItemDesc() throws Exception {
		if (wh.isElementPresent(ProdDesc)) {
			wh.clickElement(ProdDesc);
			Thread.sleep(10000);
			PIPPage pipPage = new PIPPage(ic);
			pipPage.verifyPIPPage();
			report.addReportStep("verify prod desc is clicked in cart page", "prod desc is clicked and navigated to PIP page",
					StepResult.PASS);
		} else {
			report.addReportStep("verify prod desc in cart page", "prod desc is not available",
					StepResult.FAIL);
		}
	}
	
	/**
	 * Method to remove second item from cart
	 * @return
	 * @throws Exception
	 */
	public ShoppingCartPage removeSecondItem() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(removesecondLink)) {

			wh.clickElement(removesecondLink);

			report.addReportStep("Remove item from cart", "Second Item is removed from cart", StepResult.PASS);
			Thread.sleep(commonData.mediumWait);

		} else {
			report.addReportStep("Remove item from cart", "Second Item is not removed from cart", StepResult.FAIL);
		}

		return this;

	}
	
	/**
	 * 
	 * @throws Exception
	 */
	public void updatemulitemQtyCartPg() throws Exception {
		int noOfItems = commonData.skuList.size();
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.skuList.get(i);

			By prodQty = By.xpath("//a[contains(@href,'" + sku
					+ "')]/../..//*[contains(@class,'qty-wrapper')]/input[contains(@id,'quantity')]");

			String qty = dataTable.getData(DataColumn.Quantity);

			wh.waitForPageLoaded();

			Thread.sleep(commonData.smallWait);
			if (wh.isElementPresent(prodQty, 5)) {
				String strQtyinShoppingCart = driver.findElement(prodQty).getAttribute("value");
				if (!strQtyinShoppingCart.isEmpty()) {
					report.addReportStep("Verify that quantity displayed in Cart Page",
							"quantity value is <b> " + strQtyinShoppingCart + " </b>in cart page", StepResult.PASS);

					driver.findElement(prodQty).sendKeys("\u0008");
					wh.sendKeys(prodQty, qty);
					driver.findElement(By.xpath("//h1[contains(text(),'Questions? We can help')]")).click();
					Thread.sleep(commonData.smallWait);

					report.addReportStep("Verify that quantity entered is " + qty,
							"Quantity is entered as " + qty + " in cart page", StepResult.PASS);

				}
			} else {
				report.addReportStep("Verify that quantity entered is " + qty, "Quantity is not displayed in Cart Page",
						StepResult.FAIL);
			}

		}
	}
	
	/**
	 * Component to verify Summary Section details in Cart page for only merchandise
	 * product
	 * 
	 */
	public void verifySummarySecMerch() {
		String strSum = driver.findElement(SummarySec)
				.getText();
		System.out.println(strSum);
		String strEsti = driver.findElement(OrderSummarySec).getText();
		System.out.println(strEsti);
		if (strEsti.contains("Subtotal")
				&& strEsti.contains("*Estimated Shipping")
				&& strEsti.contains("Estimated Sales Tax")
				&& strEsti.contains("Estimated Subtotal")) {
			report.addReportStep(
					"Verify Summary section in Shopping cart page only for Merchandise product",
					"Summary Section <b>"
							+ strSum
							+ "</b> and <b>"
							+ strEsti
							+ "</b> is displayed in shopping cart page only for merchandise product",
					StepResult.PASS);
		} else

		{
			report.addReportStep(
					"Verify Summary section in Shopping cart page only for Merchandise product",
					"Summary Section <b>"
							+ strSum
							+ "</b> and <b>"
							+ strEsti
							+ "</b> is not displayed in shopping cart page only for merchandise product",
					StepResult.PASS);
		}
	}
	
	/**
	 * To verify Summary Section details in Cart page while adding merchandise &
	 * Bopis product
	 * 
	 */

	public void verifySummarySecMerchbopis() {
		String strSum = driver.findElement(SummarySec).getText();
		System.out.println(strSum);
		String strEsti = driver.findElement(OrderSummarySec).getText();
		System.out.println(strEsti);
		if (strEsti.contains("Subtotal")
				&& strEsti.contains("Pick Up In Store")
				&& strEsti.contains("Estimated Shipping")
				&& strEsti.contains("Sales Tax")
				&& strEsti.contains("Estimated Subtotal")) {
			report.addReportStep(
					"Verify Summary section in Shopping cart page while adding two Products of opis and Merchandise",
					"Summary Section <b>"
							+ strSum
							+ "</b> and <b>"
							+ strEsti
							+ "</b> is displayed in shopping cart page while adding two Products of opis and Merchandise",
					StepResult.PASS);
		} else

		{
			report.addReportStep(
					"Verify Summary section in Shopping cart page while adding two Products of opis and Merchandise",
					"Summary Section <b>"
							+ strSum
							+ "</b> and <b>"
							+ strEsti
							+ "</b> is not displayed in shopping cart page while adding two Products of opis and Merchandise",
					StepResult.PASS);
		}
	}

	/**
	 * Component to verify cart merge in cart page
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifyCartMerge() throws Exception {
		if (wh.isElementPresent(itemInCart, 2)) {
			List<WebElement> noOfItems = driver.findElements(itemInCart);
			if (noOfItems.size() == commonData.totalItems) {
				report.addReportStep("Verify cart merge in cart", "Cart items:<b> " + noOfItems.size()
						+ " </b>is displayed in cart as there is no item to merge", StepResult.PASS);
			} else {
				report.addReportStep("Verify cart merge in cart", "Cart items:<b> " + noOfItems.size()
						+ " </b>is displayed in cart as cart is merged", StepResult.PASS);
			}

		} else {
			report.addReportStep("Verify item total is taken from cart", "Item total is not taken from cart",
					StepResult.FAIL);
		}
	}

}
