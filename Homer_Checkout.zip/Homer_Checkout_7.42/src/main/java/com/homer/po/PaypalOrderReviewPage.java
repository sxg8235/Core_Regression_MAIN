package com.homer.po;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

import java.util.List;

public class PaypalOrderReviewPage extends PageBase<HomePage> {

	static final By verifyPaypalOrderReviewPage = By
			.xpath("//h3[@class='title m-bottom-small'][text()='PayPal Express Order Review']");
	static final By errorMsg = By.id("checkout-error-message");
	static final By paypalOrderSubmitbutton = By.xpath("(//a[contains(.,'SUBMIT ORDER')])[2]");
	static final By AttributeName = By.cssSelector(".custom-attr-name");
	static final By editThisAddrLink = By.xpath("//a[@class='text-primary bold js-modal edit-address-link']");
	static final By editAddrOverlay = By.id("edit-address-overlay-content");
	static final By shipZipcode = By.xpath("(//input[@name='zipcode'])[1]");
	static final By UpdateButtonInOverlay = By.xpath("//*[@class='btn btn-gray edit-address-button md-submit']");
	static final By addAddrLink = By.xpath("//a[@class='text-primary bold js-modal add-address-link']");
	static final By addAddrOverlay = By.id("add-address-overlay-content");
	static final By saveAddrBtn = By.xpath("//a[@class='btn btn-gray add-address-button md-submit']");
	static final By firstName = By.xpath("//*[@id='add-address-overlay-content']//input[@name='firstName']");

	static final By lastName = By.xpath("//*[@id='add-address-overlay-content']//input[@name='lastName']");
	static final By phoneNo = By.xpath("//div[@id='add-address-overlay-content']//input[@name='phone']");
	static final By address1 = By.xpath("//div[@id='add-address-overlay-content']//input[@name='address1']");
	static final By zipcode = By
			.xpath("//*[@id='add-address-overlay-content']//input[@class='zipcode-lookup zipcode zipcode-lookup-us-mexico']");
	static final By addrInEditAddrOverlay = By.xpath("(//input[@name='address1'])[1]");
	static final By editAddrError = By.xpath("//*[@id='edit-address-overlay']//span[@class='md-error-message']");

	static final By InstantRebateMsg = By.xpath(".//*[@id='irContent']/div[1]/p");
	static final By pickupOptionPageTitle = By.xpath("//h1[text()='Pick Up In Store']");
	static final By fNameErr = By.xpath("//div[@for='firstName']");
	static final By editAddrFirstName = By.xpath("//div[@id='edit-address-overlay-content']//input[@name='firstName']");

	public PaypalOrderReviewPage(InstanceContainer ic) {
		super(ic);

	}

	/**
	 * Method to verify Shipping Page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaypalOrderReviewPage verifyPaypalOrderReviewPage() throws Exception {


		if (wh.isElementPresent(verifyPaypalOrderReviewPage, 2)||wh.isElementPresent(pickupOptionPageTitle, 2)) {

			report.addReportStep("Verify Paypal Order Review page is displayed",
					"Paypal Order Review page is displayed", StepResult.PASS);
		} else {

			report.addReportStep("Verify Paypal Order Review page is displayed",
					"Paypal Order Review page is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Paypal Order Review Page");
		}

		return this;
	}

	/**
	 * Method to submit order
	 * 
	 * @return
	 * @throws Exception
	 */
	public ThankYouPage submitOrderPaypal() throws Exception {

		ThankYouPage thankYouPage;

		if (rc.isProdEnvironment()) {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"We do not place Orders on Production", StepResult.WARNING);
			rc.terminateTestCase();

			thankYouPage = new ThankYouPage(ic);
			thankYouPage.isProdEnv = true;

			return thankYouPage;

		} else {

			if (wh.isElementPresent(paypalOrderSubmitbutton, 10)) {
				wh.clickElement(paypalOrderSubmitbutton);
				Thread.sleep(commonData.LongWait);
			}

			else {
				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
						"Submit order button not identified", StepResult.FAIL);
				rc.terminateTestCase("Thank You for Your Order");
			}

			if (wh.noWaitElementPresent(errorMsg)) {

				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
						"'Error mesage is displayed after clicking submit button", StepResult.FAIL);
				rc.terminateTestCase("Thank You for Your Order");
			}

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details",
					"Submitted order for sku : " + commonData.sku, StepResult.PASS);

			thankYouPage = new ThankYouPage(ic);

			return thankYouPage;
		}
	}

	/**
	 * Component to verify custom product details in Papal express page
	 * 
	 * @throws InterruptedException
	 */
	public void verifyCustomBlindProductsNotPresentInPPalExp() throws InterruptedException {
		try {

			if (wh.isElementPresent(By.xpath("//div[@class='custom-attr-div']/div"), 5)) {
				report.addReportStep("Verify Custom Attributes should not be displayed in the Paypal Express page",
						"Custom Attributes are not  displayed in the Paypal Express page", StepResult.PASS);
			} else {
				report.addReportStep("Verify Custom Attributes should not be displayed in the Paypal Express page",
						"Custom Attributes are displayed in the Paypal Express page", StepResult.FAIL);
			}
		} catch (Exception e) {
			report.addReportStep("Verify Custom Attributes should not be displayed in the Paypal Express page",
					"Custom Attributes are displayed in the Paypal Express page", StepResult.FAIL);
		}

		try {
			if (wh.isElementPresent(By.xpath("//div[@class='blinds-sku-img']"), 5)) {

				report.addReportStep("Verify Custom Image should not be displayed in the Paypal Express page",
						"Custom Image is not  displayed in the Paypal Express page", StepResult.PASS);
			}

			else {
				report.addReportStep("Verify Custom Image should not be displayed in the Paypal Express page",
						"Custom Image is displayed in the Paypal Express page", StepResult.FAIL);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			report.addReportStep("Verify Custom Attributes should not be displayed in the Paypal Express page",
					"Custom Image is displayed in the Paypal Express page", StepResult.FAIL);
		}
	}

	public void clickEditThisAddress() throws Exception {
		if (wh.isElementPresent(editThisAddrLink, 2)) {

			wh.clickElement(editThisAddrLink);
			report.addReportStep("Click Edit this Address link in order review page",
					"Edit this Address link is clicked in order review page", StepResult.PASS);
		} else {
			report.addReportStep("Click Edit this Address link in order review page",
					"Edit this Address link is not clicked in order review page", StepResult.FAIL);
		}

	}

	public void EditAddressOverlay() throws Exception {
		String ChangeZipcode = dataTable.getData("ChangeZipCode");
		if (wh.isElementPresent(editAddrOverlay, 3)) {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is displayed",
					StepResult.PASS);
			wh.sendKeys(shipZipcode, ChangeZipcode);
			Thread.sleep(commonData.littleWait);

			report.addReportStep("Verify zipcode is changed in edit address overlay",
					"zipcode is changed in Edit Address overlay", StepResult.PASS);
			if (wh.isElementPresent(UpdateButtonInOverlay, 5)) {
				wh.clickElement(UpdateButtonInOverlay);
				Thread.sleep(commonData.smallWait);
				report.addReportStep("verify Update is clicked", "address is updated", StepResult.PASS);
			} else {
				report.addReportStep("verify Update is clicked", "address is not updated", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is not displayed",
					StepResult.FAIL);
		}
	}

	public void clickaddNewAddress() throws Exception {
		if (wh.isElementPresent(addAddrLink, 2)) {

			wh.clickElement(addAddrLink);
			report.addReportStep("Click add new Address link in order review page",
					"Add new Address link is clicked in order review page", StepResult.PASS);
		} else {
			report.addReportStep("Click add new Address link in order review page",
					"Add new Address link is not clicked in order review page", StepResult.FAIL);
		}

	}

	public void NewAddressOverlay() throws Exception {
		String ChangeZipcode = dataTable.getData("ChangeZipCode");
		if (wh.isElementPresent(addAddrOverlay, 3)) {
			report.addReportStep("Verify Add Address overlay is displayed", "Add Address overlay is displayed",
					StepResult.PASS);
			wh.sendKeys(firstName, "Thomas");
			wh.sendKeys(lastName, "James");
			wh.sendKeys(phoneNo, "1234567896");
			wh.sendKeys(address1, "London");
			wh.sendKeys(zipcode, ChangeZipcode);
			Thread.sleep(commonData.littleWait);

			report.addReportStep("Verify zipcode is changed in edit address overlay",
					"zipcode is changed in Edit Address overlay", StepResult.PASS);
			if (wh.isElementPresent(saveAddrBtn, 5)) {
				wh.clickElement(saveAddrBtn);
				Thread.sleep(commonData.smallWait);
				report.addReportStep("verify Save is clicked", "New address is added", StepResult.PASS);
			} else {
				report.addReportStep("verify Save is clicked", "New address is added", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify Edit Address overlay is displayed", "Edit Address overlay is not displayed",
					StepResult.FAIL);
		}

	}

	public PaypalOrderReviewPage verifyIRmessage() throws Exception {
		String IREligMsg1 = "";
		String IREligMsg3 = "";
		String IREligMsg4 = "";
		String IRInEligMsg1 = "";
		IREligMsg1 = commonData.InstantRebateEligMsg1_CC;
		IREligMsg3 = commonData.InstantRebateEligMsg3_CC;
		IRInEligMsg1 = commonData.InstantRebateIneligMsg1_CC;
		IREligMsg4 = commonData.InstantRebateEligMsg4_CC;
		int itemcount = commonData.skuList.size();
		if ((itemcount > 1)) {
			IREligMsg1 = commonData.InstantRebateEligMsg2_CC;
			IRInEligMsg1 = commonData.InstantRebateIneligMsg2_CC;
		}

		for (int i = 0; i < itemcount; i++) {
			String sku = commonData.skuList.get(i);

			String StorePromo1 = "";
			StorePromo1 = commonData.IRList.get(i);
			String StorePromo2 = "";
			StorePromo2 = commonData.IRList1.get(i);
			double val1 = Double.parseDouble(commonData.PriceList.get(i));
			double val2 = Double.parseDouble(commonData.PriceList1.get(i));
			System.out.println(val1);
			System.out.println(val2);
			if ((val2 < val1)) {
				if (wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg1, StepResult.PASS);
					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg1, StepResult.FAIL);
					}
				} else if (wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES"))
						&& ((StorePromo2).contains("INSTANT_REBATES"))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg3)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg3, StepResult.PASS);
					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg3, StepResult.FAIL);
					}
				} else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && (!(StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);
					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);
					}
				} else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}
			} else if ((val2 > val1)) {
				if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && (!(StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IRInEligMsg1)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IRInEligMsg1, StepResult.PASS);
					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IRInEligMsg1, StepResult.FAIL);
					}
				} else if ((wh.isElementPresent(InstantRebateMsg, 5) && ((StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);
					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);
					}
				} else if ((wh.isElementPresent(InstantRebateMsg, 5) && (!(StorePromo1).contains("INSTANT_REBATES")) && ((StorePromo2)
						.contains("INSTANT_REBATES")))) {
					String Msg = wh.getText(InstantRebateMsg);
					if (Msg.contains(IREligMsg4)) {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is equal to Expected Msg" + IREligMsg4, StepResult.PASS);
					} else {
						report.addReportStep("Verify IR Msg is equal to Expected Msg", "IR Msg" + Msg
								+ "is not equal to Expected Msg" + IREligMsg4, StepResult.FAIL);
					}
				} else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
					report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed",
							StepResult.PASS);
				}
			} else if (!(wh.isElementPresent(InstantRebateMsg, 5))) {
				report.addReportStep("Verify IR Msg will not be displayed", "IR Msg is not displayed", StepResult.PASS);
			}
			continue;
		}
		try {
			By Msgclose = By.xpath(".//a[contains(@class,'md-close')]");
			wh.clickElement(Msgclose);
		} catch (Exception e) {
		}
		return this;
	}

	/**
	 * Method to get price & store promotion from pricing API
	 * 
	 * @author u93wcs
	 * @return
	 * @throws Exception
	 */
	public String getpricedetails(DataBase database) throws Exception {
		int noOfItems = commonData.skuList.size();
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.skuList.get(i);
			String store = dataTable.getData(DataColumn.storeID);
			database.getUnitPriceFromPricingService(sku, store);
			commonData.IRList1.add(commonData.shortdesc);
			System.out.println(commonData.shortdesc);
			commonData.PriceList1.add(commonData.unitPriceDB);
			System.out.println(commonData.unitPriceDB);
		}
		return null;
	}

	public void enterInvalidPoBoxInPPOrderReview() throws Exception {

		int i = 0;
		int j = 0;

		if (wh.isElementPresent(addrInEditAddrOverlay, 3)) {
			for (i = 0; i < commonData.addrPOBOX.length; i++) {
				String addr = commonData.addrPOBOX[i];
				wh.clearElement(addrInEditAddrOverlay);
				wh.sendKeys(addrInEditAddrOverlay, addr);
				report.addReportStep("Verify <b>" + addr + "</b> is entered", "<b>" + addr + "</b> is entered",
						StepResult.PASS);
				wh.clickElement(UpdateButtonInOverlay);
				Thread.sleep(1000);
				if (wh.isElementPresent(editAddrError, 5)) {
					String err = wh.getText(editAddrError);
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify error message is displayed for <b>" + addr + "</b> entered",
							"Error message is not displayed", StepResult.FAIL);
				}
			}
				wh.clearElement(addrInEditAddrOverlay);
				wh.sendKeys(addrInEditAddrOverlay, dataTable.getCommonData(CommonDataColumn.ShippingAddr) + j++);
				wh.clickElement(UpdateButtonInOverlay);
				report.addReportStep("Verify <b>" + CommonDataColumn.ShippingAddr + "</b> is entered", "<b>"
						+ CommonDataColumn.ShippingAddr + "</b> is entered", StepResult.PASS);
			

		} else {
			report.addReportStep("Verify Address is entered with invalid PoBox", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyFNErrorSplChar() throws Exception {
		if (wh.isElementPresent(editAddrOverlay, 2)) {
			wh.clickElement(editAddrFirstName);
			wh.clearElement(editAddrFirstName);
			wh.sendKeys(editAddrFirstName, commonData.zipcdSymbol);
			report.addReportStep("verify First name with spl char", "First name with spl char is entered",
					StepResult.PASS);
			wh.clickElement(UpdateButtonInOverlay);
			String strFN = wh.getText(fNameErr);
			if (strFN.contains("We are sorry, but the system does not recognize special characters")) {
				report.addReportStep("verify First name error", "First name error " + strFN + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("verify First name error", "First name error is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify First name error", "First name error field is not displayed", StepResult.FAIL);
		}
	}

	public void verifyFNErrorSplCharwithSpaces() throws Exception {
		if (wh.isElementPresent(editAddrOverlay, 2)) {
			wh.clickElement(editAddrFirstName);
			wh.clearElement(editAddrFirstName);
			wh.sendKeys(editAddrFirstName, commonData.zipcdSymbol + "  " + commonData.zipcdSymbol);
			wh.clickElement(UpdateButtonInOverlay);
			report.addReportStep("verify First name with spl char and spaces",
					"First name with spl char and spaces is entered", StepResult.PASS);
			String strFN = wh.getText(fNameErr);
			if (strFN.contains("We are sorry, but the system does not recognize special characters")) {
				report.addReportStep("verify First name error", "First name error " + strFN + "is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("verify First name error", "First name error is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("verify First name error", "First name error field is not displayed", StepResult.FAIL);
		}
	}
}
