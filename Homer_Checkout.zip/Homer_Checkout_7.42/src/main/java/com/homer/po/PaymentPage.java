package com.homer.po;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataColumn;
import com.homer.dao.InstanceContainer;
import com.homer.enums.EnumClass.StepResult;

public class PaymentPage extends PageBase<PaymentPage> {

	static final By verifyPaymentPage = By
			.xpath("//div[@class='title-wrapper m-bottom-normal']/h1 [contains(text(),'Payment')]");
	static final By verifyPaymentAndBillingPage = By
			.xpath("//div[@class='title-wrapper m-bottom-normal']/h1[contains(text(),'Payment & Billing')]");
	static final By cardNumber = By.id("newCardNumber");
	static final By nameOnCard = By.id("cardHolderName");
	static final By buyerNameSavedCard = By.cssSelector("div.buyer-name > input#savedCardName");
	static final By buyerNameNewCard = By.cssSelector("div.buyer-name > input#cardHolderName");
	static final By expirationMonth = By.id("expiration-month");
	static final By expirationYear = By.id("expiration-year");
	static final By cardSecurityID = By.id("cvv");
	static final By poJobCode = By.id("POJobCode");
	static final By firstName = By.xpath("(//input[@name='firstName'])[1]");
	static final By lastName = By.xpath("(//input[@name='lastName'])[1]");
	static final By address1 = By.xpath("(//input[@name='address1'])[1]");
	static final By zipCode = By.xpath("(//input[@name='zipcode'])[1]");
	static final By phoneNumber = By.xpath("(//input[@name='phone'])[2]");
	static final By emailAddress = By.id("payment_email");
	static final By submitOrderBtn = By
			.xpath("//*[@class='tablet-checkout-right-rail']/descendant::span[contains(.,'SUBMIT ORDER')]");
	static final By submitOrderBtn2 = By.xpath("(//span[contains(.,'SUBMIT ORDER')])[1]");
	static final By errorMsg = By.className("checkout-error-message");
	static final By btnGoToPaypal = By.xpath("//*[@class='pod-buttons flex-box']//a[2]");
	static final By rdoPaypal = By.className("paymentPaypalLogo");
	static final By savedAddr = By.xpath("(//div[@class='address-module m-bottom-normal'])[2]");
	static final By cartBreadCrumb = By.xpath("//div[@class='pod-progress-bar']//span[contains(text(),'CART')]");
	static final By regPwd = By.xpath("(//input[@id='newPasswordField'])[2]");
	static final By regConfirmPwd = By.xpath("(//input[@id='confirm-password-field'])[2]");
	static final By RegisteredMsg = By.xpath("(//*[@id='payment-existingUser-registration'])[2]");
	static final By estimatedSalesTaxlabel = By.xpath("//span[contains(text(),'Estimated Sales Tax :')]");
	static final By estimatedSalesTax = By.xpath("*//h4[@id='sales-tax']");
	static final By cvvError = By.xpath("//div[@for='cvv']");
	static final By savedTaxExempt = By.id("taxExemptNo");
	static final By salesTax = By.id("sales-tax");
	static final By loadingIcon = By.cssSelector("div.containerLoading.loader-image");
	static final By btnBack = By.xpath("(//*[@id='slider_panel_1']//a[text()='Back'])[1]");
	static final By shippingChargeRightRail = By.id("shippingCharge");
	static final By subTot = By.xpath("//h3[contains(text(),'Subtotal')]/../h3[2]");
	static final By rightRail = By.xpath("//div[@class='checkout-summary clear']");
	static final By savedCard = By.id("savedCards");
	static final By savedCardCvv = By.id("savedCardCVV");
	static final By cvvCleared = By.cssSelector("input.more-info.saved-card-cvv.pymt-fld-hghlgt");
	static final By savedCreditCardRadioGrp = By.cssSelector("div.credit-cards-saved > div.radio-set.m-bottom-normal");
	static final By newCardRadioGrp = By.cssSelector("div.newCard-cntr.m-top-normal > div.radio-set.m-bottom-normal");
	static final By payPalRadio = By.cssSelector("div.radio-set.m-bottom-normal > label.tab11.paypal-label");
	static final By savedCardDropDown = By.cssSelector("div.select-card.select-expiredate");
	static final By gcSection = By.cssSelector("div.payment-gc-sec");
	static final By billingSection = By.xpath("//h4[contains(text(),'Billing Address')]");
	static final By newCardSection = By.cssSelector("div.newCard-cntr.m-top-normal");
	static final By expirationMonthYear = By.cssSelector("div.newcards-expiredate.select-expiredate");
	static final By newCardRadio = By.xpath("//label[contains(text(),'New Card')]");
	static final By creditCardRadio = By.xpath("//h4[contains(text(),'Credit card')]");
	static final By totalRightRail = By.xpath("//h3[contains(text(),'Total')]/span");
	static final By EditLinkInPayment = By.xpath("//*[contains(text(),'Modify')]");
	static final By orderSummary = By.xpath("//div[@class='display-table fullWidth layout-fixed']/div/h3[2]");
	static final By orderSummaryExtras = By.xpath("//div[@class='display-table fullWidth layout-fixed']/div/h4[2]");

	static final By discoverCardIconEnabled = By.xpath("//li[@class='icon-payment-discover']");
	static final By amexCardIconEnabled = By.xpath("//li[@class='icon-payment-amex']");
	static final By visaCardIconEnabled = By.xpath("//li[@class='icon-payment-visa']");
	static final By masterCardIconEnabled = By.xpath("//li[@class='icon-payment-mastercard']");
	static final By hdCommericialCardIconEnabled = By.xpath("//li[@class='icon-payment-hdcom']");
	static final By hdConsumerCardIconEnabled = By.xpath("//li[@class='icon-payment-hdcon']");
	static final By hdProxCardIconEnabled = By.xpath("//li[@class='icon-payment-hdmc js-hdcom']");

	static final By discoverCardIconDisabled = By.xpath("//li[@class='icon-payment-discover ccOff']");
	static final By amexCardIconPresenceDisabled = By.xpath("//li[@class='icon-payment-amex ccOff']");
	static final By visaCardIconPresenceDisabled = By.xpath("//li[@class='icon-payment-visa ccOff']");
	static final By masterCardIconPresenceDisabled = By.xpath("//li[@class='icon-payment-mastercard ccOff']");
	static final By hdCommericialCardIconPresenceDisabled = By.xpath("//li[@class='icon-payment-hdcom ccOff']");
	static final By hdConsumerCardIconPresenceDisabled = By.xpath("//li[@class='icon-payment-hdcon ccOff']");
	static final By hdProxCardIconPresenceDisabled = By.xpath("//li[@class='icon-payment-hdmc js-hdcom ccOff']");

	static final By TaxToolTip = By.xpath("//*[@data-modal-content='#estimated-sales-tax-tip-content']");
	static final By taxToolClose = By.xpath("//*[@class='quick-tip-mcc add-shadow-mcc']//a[1]");
	static final By taxToolImage = By.xpath("//*[@class='quick-tip-mcc add-shadow-mcc']");
	static final By CVVToolTip = By.xpath("//*[contains(@class,'card-info update-cvv-info')]");
	static final By CVVOverlay = By.xpath("//*[contains(@class,'quick-tip-mcc add-shadow-mcc cvv')]");
	static final By editThisTax = By.xpath("//*[@class='tax-exempt-wrapper m-bottom-large']//*[contains(text(),'edit this tax exempt ID')]");
	static final By applyTaxLink = By.xpath("//*[@class='tax-exempt-wrapper m-bottom-large']//h3//a[1]");
	static final By applyTaxlink = By.xpath("//*[contains(text(),'apply a tax Exempt ID')]");
	static final By taxExemptOverlay = By.cssSelector("div[class='md-modal md-effect-1 md-show']");
	static final By taxExemptText = By.xpath("//*[@id='apply-tax-id']//p");
	static final By taxApplyOne = By.xpath("//*[@id='apply-tax-id']//p//a");
	static final By taxId = By.cssSelector("#tax-id");
	static final By applyTax = By.cssSelector("#applyTaxExemptId");
	static final By firstNameErr = By
			.xpath("//*[@class='billing-address-wrapper']//div[contains(@class,'error-container')]");
	static final By lastNameErr = By.xpath("//*[@for='lastName']");
	static final By AddressErr = By.xpath("//*[@for='address1']");
	static final By zipcodeErr = By.xpath("//*[@for='zipcode']");
	static final By PhErr = By.xpath("//*[@for='phone']");
	static final By emailErr = By.xpath("//*[@class='error-container']//div[@for='payment_email']");
	static final By CardErr = By.xpath("//*[@for='newCardNumber']");
	static final By CvvErr = By.xpath("//*[@for='cvv']");
	static final By BuyerNameErr = By.xpath("//*[@for='cardHolderName']");
	static final By giftCardSection = By.xpath("//*[@class='gift-cards-wrapper clear']");
	static final By taxExemptErr = By.xpath("//*[@class='checkout-error-message tax-serv-error']");
	static final By paymentAddrPhone = By
			.xpath("//div[@class='billing-address-wrapper']//label[contains(text(),'Last Name')]/../following-sibling::div[2]");
	static final By newBillingAddrLink = By.xpath("//a[contains(text(),'use a new billing address')]");
	static final By newBillingAddrOverlay = By.id("add-address-overlay");
	static final By shipValue = By.xpath("(//*[@class='p-custom-inner-block']//h4[2])[1]");
	static final By weakPwdMsg = By
			.xpath("//div[@class='weak-password-info error-container m-top-closer p-bottom-small']");
	static final By pwdMismatchMsg = By.xpath("(//div[@class='error-in-container error-message'])[2]");
	static final By weakPwdStrengthMeter = By
			.xpath("//div[@class='weak-password-info error-container m-top-closer p-bottom-small']/following-sibling::div[1]/ul/li[1]");
	static final By pwdStrengthRules = By.xpath("(//input[@id='newPasswordField'])[2]/..//i");
	static final By pwdStrengthTips = By.xpath("//div[@class='tip-content-mcc']/div");
	static final By pwdStrengthMeter = By.xpath("(//div[@id='newPasswordField_strength'])[2]//ul/li");
	static final By POMust = By.xpath("//*[@class='checkout-error-message']");
	static final By chkSaveCard = By.xpath("//*[@name='savecard']");
	static final By canadaMexicoLink = By
			.xpath("//a[@class='text-primary bold js-modal add-address-link new-canada-or-mexico-address-link']");
	static final By internationalBillingFirstName = By
			.xpath("//*[@id='add-address-overlay']//input[@name='firstName']");
	static final By internationalBillingLastName = By.xpath("//*[@id='add-address-overlay']//input[@name='lastName']");
	static final By internationalBillingAddress1 = By.xpath("//*[@id='add-address-overlay']//input[@name='address1']");
	static final By internationalBillingZipCode = By
			.xpath("//*[@id='add-address-overlay']//input[@class='zipcode-lookup zipcode zipcode-international-canada']");
	static final By internationalBillingPhoneNumber = By.xpath("//*[@id='add-address-overlay']//input[@name='phone']");
	static final By internationalBillingSaveBtn = By
			.xpath("//*[@id='add-address-overlay']//a[contains(text(),'SAVE')]");
	static final By cityErrMsg = By.xpath("//div[@for='add-address-overlay-content_city_input']");
	static final By stateErrMsg = By.xpath("//div[@for='add-address-overlay-content_state_input']");
	static final By mexicoRadioBtn = By.xpath("//label[@for='mexico_billing_address']");
	static final By internationalBillingZipCodeMexico = By
			.xpath("//*[@id='add-address-overlay']//input[@class='zipcode-lookup zipcode zipcode-lookup-us-mexico']");
	static final By city = By.id("add-address-overlay-content_city_input");
	static final By state = By.id("add-address-overlay-content_state_input");
	static final By cityPopulated = By.id("add-address-overlay-content_city_label");
	static final By promoRightRail = By.xpath("//p[contains(text(),'Have a Promocode')]");
	static final By promoPlusBtn = By.cssSelector("i.accordion.icon-plus-orange");
	static final By promoTextBox = By.xpath("//div[@id='checkout-promo-code-box']/input");
	static final By applyPromoCode = By.xpath("//div[@id='checkout-promo-code-box']//a[contains(text(),'Apply')]");

	static final By expYearErr = By.xpath("//*[@for='expiration-year']");
	static final By expMnthErr = By.xpath("//*[@for='expiration-month']");
	static final By taxError = By.xpath("//*[@for='tax-id' and @class='error error-in-container']");
	static final By taxClose = By.xpath("//*[@id='apply-tax-id']//*[@class='md-close']");
	static final By giftCardText = By.xpath("//div[@class='gift-cards-wrapper clear']/h3");
	static final By giftCardLink = By.xpath("//a[@class='text-primary bold js-modal add-gift-card-link']");
	static final By giftCardOverlay = By.id("apply-gift-card");
	static final By giftCardOverlayTitle = By.xpath("//div[@id='apply-gift-card']//div[@class='md-content']/h3");
	static final By savedAddrOptions = By
			.xpath("//div[@class='m-top-large billing-address-info']//select[@class='address-select']");
	static final By savedAddrOptions1 = By.xpath("//select[@class='address-select']");
	static final By fNameErrMsg = By.xpath("//div[@for='firstName']");
	static final By lNameErrMsg = By.xpath("//div[@for='lastName']");
	static final By phoneErrMsg = By.xpath("//div[@for='phone']");
	static final By addr1ErrMsg = By.xpath("//div[@for='address1']");
	static final By zipErrMsg = By.xpath("//div[@for='add-address-overlay-content']");
	static final By SavedcardRadio = By.xpath("//*[@id='newCardNumber']|//select[@id='savedCards']");
	static final By newCardNum = By.xpath("//*[@id='newCardNumber']");
	static final By NewCardNum = By.xpath("//*[@class='newCard-cntr m-top-normal']//input[@id='newCardNumber']");
	static final By SavedcardNum = By.id("saved-cards-display");

	static final By ApplyAgiftCardText = By.xpath("//*[contains(text(),'apply a gift card')]");
	static final By GiftCardNumber = By.id("gift-card");
	static final By GiftCardPinNumber = By.id("pin-number");
	static final By GiftCardCaptcha = By.id("capcha");
	static final By GcChangeVerfImg = By.id("changeImg");
	static final By CancelBtnGiftCard = By.xpath("//*[@class='btn btn-flat-lightGray m-right-small md-cancel']");
	static final By ApplyBtnGiftCard = By.id("giftCardSave");
	static final By verifyGiftCardAndStoreCreditText = By.xpath("//*[contains(text(),'Gift Card & Store Credit')]");
	static final By verifyGiftCard = By.xpath("//*[contains(text(),'Gift Card')]");
	static final By verifyStoreCreditAdvisoryMsg = By.xpath("//*[@id='apply-gift-card']/form/div/div/div[2]/div[2]");
	static final By verifyGiftCardOverlayHeaderText = By.xpath("//*[contains(text(),'Apply Gift Cards')]");
	// MLTC-2798 Gift card and Store credit FAQ
	static final By verifyonlineFAQsText = By.xpath("//*[@class='text-primary bold ofaq-checkout']");
	static final By verifyCustomerSupportFAQPage = By
			.xpath("//div[@class='pod alpha omega']/h1[contains(text(),'Products and Services FAQ')]");
	static final By verifyGiftCardFAQPage = By
			.xpath("//div[@class='pod alpha omega']/h1[contains(text(),'Gift Card Frequently Asked Questions')]");
	static final By verifyGCUsageQuestionInCFAQ = By
			.xpath("//*[contains(text(),'Can I use a Gift Card to purchase my online order?')]");
	static final By verifyGCUsageAnswerInCFAQ = By
			.xpath("//*[@id='container']/div[2]/div/div[3]/div/div[2]/div/div[1]/div/div/div[30]/div/div/div/p");
	static final By verifySCUsageQuestionInCFAQ = By
			.xpath("//*[contains(text(),'Can I use Store Credit to purchase my online order?')]");
	static final By verifySCUsageAnswerInCFAQ = By
			.xpath("//*[@id='container']/div[2]/div/div[3]/div/div[2]/div/div[1]/div/div/div[32]/div/div/div/p");
	static final By verifyGCUsageQuestionInGCFAQ = By
			.xpath("//*[contains(text(),'Can I use a Gift Card to purchase my online order?')]");
	static final By verifyGCUsageAnswerInGCFAQ = By
			.xpath("//*[@id='container']/div[2]/div/div[3]/div/div[2]/div/div[2]/div/div/div[20]/div/div/div/p");
	static final By verifySCUsageQuestionInGCFAQ = By.xpath("//*[contains(text(),'Can I use Store Credits online?')]");
	static final By verifySCUsageAnswerInGCFAQ = By
			.xpath("//*[@id='container']/div[2]/div/div[3]/div/div[2]/div/div[5]/div/div/div[2]/div/div/div/p");
	static final By verifyFormOfPaymentQuestion = By
			.xpath("//*[@id='container']/div[2]/div/div[3]/div/div[2]/div/div[12]/div/div/h3");
	static final By verifyFormOfPaymentExcludeSC = By
			.xpath("//*[@id='container']/div[2]/div/div[3]/div/div[2]/div/div[12]/div/div/ul[2]/li[3]");
	static final By verifyPayment = By.xpath("//*[contains(text(),'Payments')]");
	static final By verifyPaymentMethods = By.xpath("//*[contains(text(),'Payment Methods')]");
	static final By verifyGCSCInGCFAQ = By.xpath("//*[contains(text(),'Gift Cards and Store Credits')]");
	static final By verifyGCFAQLink = By.xpath("//*[contains(text(),'Gift Card FAQs')]");
	static final By addAddrBillingZipCode = By.xpath("//*[@id='add-address-overlay']//input[@name='zipcode']");
	static final By poJobCodeIn = By.id("POJobCode");
	static final By poError = By.xpath("//*[@for='POJobCode']");
	static final By modifyLinkRR = By.xpath("//span[@class='right text-primary m-right-small pointer modify']");
	static final By plccWarningMessage = By.xpath("//*[@id='plccNewCardMessage']/h3");
	// Gift card:
	static final By GCZeroErr = By.xpath("//*[@class='error-text']");
	static final By GCCaptchaErr = By.id("captchaError");
	static final By lstBread = By.xpath("//*[@id='progressBar']//li");
	static final By contactinfoheading = By.xpath("//*[@class='pod-contact-info']//h1");
	static final By contactinfolist = By.xpath("//*[@class='pod-contact-info']//h3");
	static final By giftCardErrMsg = By.xpath("//div[@for='gift-card']");
	static final By gcPinErrMsg = By.xpath("//div[@for='pin-number']");
	static final By gcCaptchaErrMsg = By.xpath("//div[@for='capcha']");
	static final By gcApplied = By.xpath("//*[@class='payment-gc-sec']//ul//li[1]");
	static final By gcAnothercard = By.xpath("//*[contains(text(),'apply another gift card')]");
	static final By gcremove = By.xpath("//*[@class='payment-gc-sec']//ul//a");

	static final By TaxExemptlnk = By.xpath("//*[@id='slider_panel_1']/div[1]/div[2]/div[7]/div[1]/h3[3]/a[1]");
	static final By EditTaxExemptlnk = By.xpath("//a[contains(text(),'edit this tax exempt ID')]");
	static final By InvalidTaxExempt = By.xpath("//*[@id='tax-id']");
	static final By TaxExempt1 = By.xpath("//*[@id='tax-id']");
	static final By InvalidTaxExemptErrormsg = By.xpath("//*[@id='error_msg']");
	static final By InvalidTaxExemptErrormsg1 = By.xpath("//span[@class='checkout-error-message tax-serv-error']");
	static final By InvalidTaxExemptLengthErrormsg = By.xpath("//div[@for='tax-id']");
	static final By TXEApplybtn = By.xpath("//a[@id='applyTaxExemptId']");
	static final By TXECancelbtn = By.xpath("//*[contains(text(),'CANCEL')]");
	static final By NoTaxExemptId = By.xpath("//*[@id='taxExemptNo']");
	static final By CreditCardSection = By.xpath("//*[@id='credit-card-fields']");
	static final By AlertMessage = By.xpath("//*[@class='alert-message']");
	static final By address1AddOverlay = By.xpath("(//input[@name='address1'])[2]");

	public PaymentPage(InstanceContainer ic) {
		super(ic);
	}

	/**
	 * Method to verify payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyPaymentPage() throws Exception {

		wh.waitForPageLoaded();

		if (wh.isElementPresent(verifyPaymentPage, 5)) {

			report.addReportStep("Enter Details and click 'Continue'", "'Payment' page is displayed", StepResult.PASS);

		} else {

			report.addReportStep("Enter Details and click 'Continue'", "'Payment' page is not displayed",
					StepResult.FAIL);

			rc.terminateTestCase("Payment");
		}

		return this;
	}

	/**
	 * Method to verify Payment & Billing Page
	 * 
	 * @return
	 * @throws Exception
	 *             kxn8362
	 */

	public PaymentPage verifyPaymentAndBillingPage() throws Exception {

		if (wh.isElementPresent(verifyPaymentAndBillingPage, 5)) {

			report.addReportStep("Enter Details and click 'Continue'", "'Payment & Billing' page is  displayed",
					StepResult.PASS);

		} else {

			report.addReportStep("Enter Details and click 'Continue'", "'Payment & Billing' page is not displayed",
					StepResult.FAIL);

			rc.terminateTestCase("Payment & Billing");
		}
		return this;

	}

	/**
	 * Method to fill payment page details
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage fillPaymentPageDetails() throws Exception {

		wh.sendKeys(cardNumber, dataTable.getCommonData(CommonDataColumn.CardNumber));
		driver.findElement(cardNumber).sendKeys(Keys.TAB);
		if (wh.isElementPresent(buyerNameNewCard, 5)) {
			wh.sendKeys(buyerNameNewCard, dataTable.getCommonData(CommonDataColumn.BuyerName));
		} else {
			wh.selectValue(expirationMonth, dataTable.getCommonData(CommonDataColumn.ExpirationMonth));
			wh.selectValue(expirationYear, dataTable.getCommonData(CommonDataColumn.ExpirationYear));
		}
		wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CardSecurityID));

		if (wh.isElementPresent(firstName, 2)) {

			wh.sendKeys(firstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
			wh.sendKeys(lastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.sendKeys(address1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(zipCode, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			wh.sendKeys(phoneNumber, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			wh.sendKeys(emailAddress, dataTable.getCommonData(CommonDataColumn.GuestEmail));
			Thread.sleep(commonData.littleWait);

		}

		report.addReportStep("Enter payment page details", "Payment page details entered", StepResult.PASS);

		return this;
	}

	/**
	 * Method to submit order
	 * 
	 * @return
	 * @throws Exception
	 */
	public ThankYouPage submitOrder() throws Exception {

		ThankYouPage thankYouPage;

		if (rc.isProdEnvironment()) {

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
					"We do not place Orders on Production", StepResult.WARNING);
			rc.terminateTestCase();

			thankYouPage = new ThankYouPage(ic);
			thankYouPage.isProdEnv = true;

			return thankYouPage;

		} else {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,-550)", "");
			// Thread.sleep(commonData.smallWait);

			wh.clickElement(submitOrderBtn);

			Thread.sleep(commonData.LongWait);

			if (wh.isElementPresent(submitOrderBtn)) {
				wh.jsClick(submitOrderBtn);
			} else if (wh.isElementPresent(submitOrderBtn2)) {
				wh.jsClick(submitOrderBtn);
			}

			if (wh.noWaitElementPresent(errorMsg)) {

				report.addReportStep("Click on 'Submit Order' button in payment after filling all the details.",
						"'Error mesage is displayed after clicking submit button", StepResult.FAIL);
				rc.terminateTestCase("Thank You for Your Order");
			}

			report.addReportStep("Click on 'Submit Order' button in payment after filling all the details",
					"Submitted order for sku : " + commonData.sku, StepResult.PASS);

			thankYouPage = new ThankYouPage(ic);

			return thankYouPage;
		}
	}

	/**
	 * To select Paypal Radio option in payment page
	 * 
	 * @throws Exception
	 * 
	 * @FunctionName taxExemptNum
	 * @InputParameters None
	 * @Author autotest
	 * @DateCreated Jan 2nd, 2013
	 */

	public void selectRadioPaypal() throws Exception {
		if (wh.isElementPresent(rdoPaypal, 4)) {

			wh.clickElement(rdoPaypal);

			report.addReportStep("Verify <b>'Paypal'</b> Option is selected under payment option section",
					" <b>Paypal</b> option is selected", StepResult.PASS);
		} else

		{
			report.addReportStep("Verify <b>'Paypal'</b> Option is selected under payment option section",
					" <b>Paypal</b> option is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Paypal radio button");
		}
	}

	/**
	 * Click Go to paypal button
	 * 
	 * @throws @author YXG8356
	 * @since Aug 27,2015
	 */

	public PaypalPage clickGoToPaypal() throws Exception {

		if (wh.isElementPresent(btnGoToPaypal, 10)) {
			wh.clickElement(btnGoToPaypal);
		} else {
			report.addReportStep("Verify <b>'Go To Paypal'</b> button is selected under payment option section",
					" <b>Go To Paypal</b> button is not displayed", StepResult.FAIL);
			rc.terminateTestCase("Go To Paypal  button");
		}

		return new PaypalPage(ic);

	}

	/**
	 * Method to verify saved address
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifySavedAddress() throws Exception {

		if (wh.isElementPresent(savedAddr, 0)) {
			String savedAddress = driver.findElement(savedAddr).getText();
			if (savedAddress.contains(dataTable.getCommonData(CommonDataColumn.ShippingFirstName))
					&& savedAddress.contains(dataTable.getCommonData(CommonDataColumn.ShippingLastName))
					&& savedAddress.contains(dataTable.getCommonData(CommonDataColumn.ShippingAddr))
					&& savedAddress.contains(dataTable.getCommonData(CommonDataColumn.ShippingZipCode))) {
				report.addReportStep("Verify that saved address is retained in payment page",
						"Saved address is retained in payment page", StepResult.PASS);

			} else {
				report.addReportStep("Verify that saved address is retained in payment page",
						"Saved address is not retained in payment page properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that saved address is retained in payment page",
					"Saved address is not retained in payment page", StepResult.FAIL);
		}

		return this;
	}

	/**
	 * Click CART breadcrumb button
	 * 
	 * @throws @author AXB8034
	 * @since Oct 09,2015
	 */

	public ShoppingCartPage clickCartBreadCrumb() throws Exception {

		if (wh.isElementPresent(cartBreadCrumb, 10)) {
			wh.clickElement(cartBreadCrumb);
			report.addReportStep("Verify <b>'CART'</b> breadcrumb is clicked", "<b>'CART'</b> breadcrumb is clicked",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify <b>'CART'</b> breadcrumb is clicked",
					"<b>'CART'</b> breadcrumb is not clicked", StepResult.FAIL);
			rc.terminateTestCase("Go To Paypal  button");
		}

		return new ShoppingCartPage(ic);

	}

	/**
	 * Method to Register in Payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage registerInPaymentPg() throws Exception {

		driver.findElement(By.id("POJobCode")).sendKeys(Keys.PAGE_DOWN);

		String strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, strPassword);

			report.addReportStep("Enter password for registration", "Password entered for registration",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter password for registration", "Password field is not present in payment page",
					StepResult.FAIL);

			rc.terminateTestCase("Payment page registration");
		}

		return this;
	}

	/**
	 * Method to Register in Payment page with Strong pwd
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage registerInPaymentPgWithStrongPwd(String strPassword) throws Exception {

		driver.findElement(By.id("POJobCode")).sendKeys(Keys.PAGE_DOWN);

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, strPassword);

			report.addReportStep("Enter password for registration", "Password entered for registration",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter password for registration", "Password field is not present in payment page",
					StepResult.FAIL);

			rc.terminateTestCase("Payment page registration");
		}

		return this;
	}

	/**
	 * Method to Register in Payment page with Weak Pwd
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage registerInPaymentPgWithWeakPwd(String strPassword) throws Exception {

		driver.findElement(By.id("POJobCode")).sendKeys(Keys.PAGE_DOWN);

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, strPassword);

			report.addReportStep("Enter password for registration", "Password entered for registration",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter password for registration", "Password field is not present in payment page",
					StepResult.FAIL);

			rc.terminateTestCase("Payment page registration");
		}

		return this;
	}

	/**
	 * Method to verify the Estimated tax label and amount in payment and
	 * billing page
	 * 
	 * @kxn8362
	 * @throws Exception
	 * 
	 */

	public PaymentPage verifyEstimatedTaxAmountAndLabel() throws Exception {

		String taxAmount = wh.getText(estimatedSalesTax);
		commonData.taxAmount = taxAmount;
		if (wh.isElementPresent(estimatedSalesTaxlabel)) {

			System.out.println("Inside IF");
			report.addReportStep("The Estimated Sales Tax label ", "is displayed. And the value is : " + taxAmount,
					StepResult.PASS);
		}

		else {
			report.addReportStep("Estimated Sales Tax Label", "Is not displayed in the Payment & Billing page",
					StepResult.FAIL);
		}
		return this;
	}

	public void compareEstimatedTaxInPaymentAndShipping() {
		String TaxValueInpayment = commonData.taxAmount;
		String TaxValueInShipping = commonData.strEstimatedSalesTaxValue;
		if (TaxValueInpayment.equals(TaxValueInShipping)) {
			report.addReportStep("Verify EstimatedTax mismatch in payment and Shipping page",
					"Estimated Tax not mismatches in Payment and Shipping page", StepResult.PASS);
		} else {
			report.addReportStep("Verify EstimatedTax mismatch in payment and Shipping page",
					"Estimated Tax mismatches in Payment and Shipping page", StepResult.FAIL);
		}

	}

	/**
	 * Method to enter card details
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage enterCardDetails() throws Exception {
		String CardNumber = null;
		String CardType = dataTable.getData("CardType");

		if (CardType.toLowerCase().contains("visa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.VISA_card);
		}

		else if (CardType.toLowerCase().contains("master")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.MASTER_card);
		}

		else if (CardType.toLowerCase().contains("amex")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.AMEX_card);
		}

		else if (CardType.toLowerCase().contains("discover")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.DISCOVER_card);
		}

		else if (CardType.toLowerCase().contains("consumer")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCONSUMER_card);
		}

		else if (CardType.toLowerCase().contains("commercial")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCOMMERCIAL_card);
		}

		else if (CardType.toLowerCase().contains("pojobmandatory")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.HDCOMMERCIAL_POMandat);
		}

		else if (CardType.toLowerCase().contains("gsa")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.GSA_card);
		}

		else if (CardType.toLowerCase().contains("proxy")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.PROXY_card);
		}

		else if (CardType.toLowerCase().contains("testcard")) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.TEST_card);
		}

		else if (CardType.isEmpty()) {
			CardNumber = dataTable.getCommonData(CommonDataColumn.CardNumber);
		}

		wh.sendKeys(cardNumber, CardNumber);
		driver.findElement(cardNumber).sendKeys(Keys.TAB);

		if (CardType.toLowerCase().contains("commercial") || CardType.toLowerCase().contains("pojobmandatory")
				|| CardType.toLowerCase().contains("proxy")) {
			wh.sendKeys(buyerNameNewCard, dataTable.getCommonData(CommonDataColumn.BuyerName));
		}

		else if (CardType.toLowerCase().contains("consumer")) {

		}

		else {
			wh.selectValue(expirationMonth, dataTable.getCommonData(CommonDataColumn.ExpirationMonth));
			wh.selectValue(expirationYear, dataTable.getCommonData(CommonDataColumn.ExpirationYear));
		}

		if (CardType.toLowerCase().contains("amex")) {
			wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CVV_Amex));
		} else {
			wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CardSecurityID));
		}

		// To Verify PO Job Code
		if (CardType.toLowerCase().contains("consumer") || CardType.toLowerCase().contains("amex")) {
			if (verifyPOforCreditCards()) {
				report.addReportStep("Verifying PO number", "PO field is Displayed", StepResult.FAIL);
			} else {
				report.addReportStep("Verifying PO number", "PO field is not Displayed", StepResult.PASS);
			}

		}

		else {
			if (verifyPOforCreditCards()) {
				// String strPOField = dataTable.getData("POJobCode");
				String strPOField = dataTable.getCommonData(CommonDataColumn.POJobCode);
				commonData.strPO = strPOField;
				wh.sendKeys(poJobCode, strPOField);
				report.addReportStep("Entering PO number <b>" + strPOField
						+ " </b>in the PO number Field in payment method page",
						"PO field is Displayed and PO Number <b>" + strPOField + " </b>is entered", StepResult.PASS);
			} else {
				report.addReportStep(" Verify whether the PO # field should displayed", "PO # field is not displayed.",
						StepResult.FAIL);
			}
		}

		if (wh.isElementPresent(firstName, 0)) {

			wh.sendKeys(firstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
			wh.sendKeys(lastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.sendKeys(address1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(zipCode, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			wh.sendKeys(phoneNumber, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			wh.sendKeys(emailAddress, dataTable.getCommonData(CommonDataColumn.GuestEmail));

		}

		report.addReportStep("Enter payment page details", "Payment page details entered", StepResult.PASS);

		return this;
	}

	/**
	 * Method to clear card details
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage clearCardDetails() throws Exception {

		driver.findElement(cardNumber).clear();
		driver.findElement(nameOnCard).clear();
		driver.findElement(cardSecurityID).clear();

		report.addReportStep("Clear card details", "Card details cleared", StepResult.PASS);

		return this;
	}

	/**
	 * Method verify cvv error in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyCvvErrorInPaymentPg() throws Exception {

		if (wh.isElementPresent(cvvError)) {
			String cvvErr = driver.findElement(cvvError).getText();
			if (cvvErr.contains("Enter the credit card security ID number or CVV.")) {
				report.addReportStep("Verify the CVV error displayed", "CVV error " + cvvErr + " is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify the CVV error displayed", "CVV error " + cvvErr
						+ " is not displayed properly", StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify the CVV error displayed", "CVV error is not displayed", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Method to verify saved tax id in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifySavedTaxIdInPaymentPg() throws Exception {

		String taxId = dataTable.getData("TaxExcemptId");

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");

		if (wh.isElementPresent(savedTaxExempt)) {
			String taxExecmptNo = driver.findElement(savedTaxExempt).getText();
			if (taxExecmptNo.trim().equals(taxId)) {
				report.addReportStep("Verify saved tax exempt id is displayed", "Saved tax exempt id " + taxId
						+ " is displayed properly", StepResult.PASS);
			} else {
				report.addReportStep("Verify saved tax exempt id is displayed", "Saved tax exempt id " + taxExecmptNo
						+ " is not displayed properly", StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify saved tax exempt id is displayed", "Saved tax exempt id is not displayed",
					StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Method to verify tax is zero
	 * 
	 * @return Payment page
	 * @throws Exception
	 */
	public PaymentPage verifyTaxIsZero() throws Exception {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");

		if (wh.isElementPresent(salesTax)) {
			String saleTax = driver.findElement(salesTax).getText();
			String tax = saleTax.substring(1);
			if (tax.trim().equals("0.00")) {
				report.addReportStep("Verify Tax calculated is Zero", "Tax calculated is " + tax, StepResult.PASS);
			} else {
				report.addReportStep("Verify Tax calculated is Zero", "Tax calculated is " + tax, StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify Tax calculated is Zero", "Sales Tax is not displayed", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Method to verify tax is not zero
	 * 
	 * @return Paymentpage
	 * @throws Exception
	 */
	public PaymentPage verifyTaxIsNotZero() throws Exception {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-250)", "");

		if (wh.isElementPresent(salesTax)) {
			String saleTax = driver.findElement(salesTax).getText();
			String tax = saleTax.substring(1);
			if (!tax.trim().equals("0.00")) {
				report.addReportStep("Verify Tax calculated is not Zero", "Tax calculated is " + tax, StepResult.PASS);
			} else {
				report.addReportStep("Verify Tax calculated is not Zero", "Tax calculatesd is " + tax, StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify Tax calculated is not Zero", "Sales Tax is not displayed", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * verify unit price right rail
	 * 
	 * @throws Exception
	 */
	public void verifyUnitPriceRightRail() throws Exception {

		if (wh.isElementPresent(rightRail, 7)) {
			for (Entry<String, String> entry : commonData.itemDescPrice.entrySet()) {
				By unitPrice = By.xpath("//h3[contains(text(),'" + entry.getKey() + "')]/../h3[2]");
				By prodDesc = By.xpath("//h3[contains(text(),'" + entry.getKey() + "')]");
				By viewItems = By.xpath("//*[contains(text(),'View Items')]");

				if (wh.isElementPresent(viewItems)) {
					wh.clickElement(viewItems);
				}

				String prodDescr = wh.getText(prodDesc);
				String itemPrice = wh.getText(unitPrice);
				if (itemPrice.contains("$")) {
					itemPrice = itemPrice.substring(1).trim();
				}
				if (itemPrice.contains(",")) {
					itemPrice = itemPrice.replaceAll(",", "");
				}

				if (prodDescr.contains(entry.getKey())) {
					if (itemPrice.contains(entry.getValue())) {
						report.addReportStep(
								"Verify whether unit price in right rail is equivalent to Expected Price",
								"Unit price in right rail " + itemPrice + " is equivalent to Expected Price"
										+ entry.getValue(), StepResult.PASS);

					} else {
						report.addReportStep("Verify whether unit price in right rail is equivalent to Expected Price",
								"Unit price in right rail " + itemPrice + " is not equivalent to Expected Price"
										+ entry.getValue(), StepResult.FAIL);

					}
				} else {
					report.addReportStep("Verify whether unit price in right rail is equivalent to Expected Price",
							"Product description mismatch", StepResult.FAIL);
				}
				System.out.println(entry.getKey() + " - " + entry.getValue());
			}

		} else {
			report.addReportStep("Verify whether unit price in right rail is equivalent to Expected Price",
					"Unit price in right rail is not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * verify subtotal right rail
	 * 
	 * @throws Exception
	 */
	public void verifysubTotalRightRail() throws Exception {

		if (wh.isElementPresent(subTot, 7)) {
			String subTotal = wh.getText(subTot);
			String subTotVal = subTotal.substring(1);
			if (subTotVal.contains(",")) {
				subTotVal = subTotVal.replaceAll(",", "");
			}
			if (subTotVal.contains(commonData.subTotal)) {
				report.addReportStep("Verify whether subtotal in order summary POD is equivalent to cart page value",
						"Subtotal is equivalent to cart page", StepResult.PASS);
			} else {
				report.addReportStep("Verify whether subtotal in order summary POD is equivalent to cart page value",
						"Subtotal is not equivalent to cart page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify whether subtotal in order summary POD is equivalent to cart page value",
					"Subtotal is not dispalyed properly", StepResult.FAIL);
		}
		if (wh.isElementPresent(totalRightRail)) {
			String total = wh.getText(totalRightRail);
			commonData.total = total.substring(1);
		}
	}

	/**
	 * Description-click back button on Payment & Billing page
	 * 
	 * @throws Exception
	 * @author RSM8521
	 */
	public PaymentPage clickBackButton() throws Exception {

		if (wh.isElementPresent(btnBack, 5)) {
			wh.clickElement(btnBack);

			report.addReportStep("Verify Back button is clicked in Payment & Billing page",
					"Back button is clicked in Payment & Billing page", StepResult.PASS);
		} else {

			report.addReportStep("Verify Back button is clicked in Payment & Billing page",
					"Back button is not clicked in Payment & Billing page", StepResult.FAIL);
			rc.terminateTestCase("Back Button on Payment & Billing page");
		}

		return this;
	}

	/**
	 * Method to verify Name on card field is not present in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyNameOnCardFieldNotPresent() throws Exception {

		if (wh.isElementNotPresent(buyerNameSavedCard) && wh.isElementNotPresent(buyerNameNewCard)) {
			report.addReportStep("Verify Name on card field is not present in payment page",
					"Name on card field is not present in payment page", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Name on card field is not present in payment page",
					"Name on card field is present in payment page", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Verify Shipping Charges on the Right Rail in Payment Page
	 * 
	 * @throws @author SXV6002
	 * @since Nov 16,2015
	 */

	public void verifyRightRailShippingCharge() throws Exception {

		String test = wh.getText(shippingChargeRightRail);
		System.out.println("Charge" + test);

		/*
		 * Checking for element Present if
		 * (wh.isElementPresent(shippingChargeRightRail,10) &&
		 * wh.getText(shippingChargeRightRail).contains(DataColumn.
		 * ShippingCharge)){ report.addReportStep(
		 * "Verify <b>'Shipping Charge on Right Rail'</b> under payment section"
		 * , " <b>'Shipping Charge on Right Rail'</b> is displayed",
		 * StepResult.PASS); } else{ report.addReportStep(
		 * "Verify <b>'Go To Paypal'</b> button is selected under payment option section"
		 * , " <b>Go To Paypal</b> button is not displayed", StepResult.FAIL);
		 * rc.terminateTestCase(
		 * "Verify on Shipping Charge on Right Rail in Payment Page"); }
		 * 
		 * 
		 * if (wh.isElementPresent(shippingChargeRightRail,10)){
		 * 
		 * }
		 */
	}

	/**
	 * Method to verify Name on card field is present in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyNameOnCardFieldPresent() throws Exception {

		if (wh.isElementPresent(buyerNameSavedCard) || wh.isElementPresent(buyerNameNewCard)) {
			report.addReportStep("Verify Buyer Name field is present in payment page",
					"Buyer Name field is present in payment page", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Buyer Name field is present in payment page",
					"Buyer Name field is not present in payment page", StepResult.FAIL);
		}
		return this;
	}

	public void calculateShippingSurCharge() throws Exception {

		@SuppressWarnings("unused")
		String shippingUIValue;
		if (wh.isElementPresent(shippingChargeRightRail, 10)) {

			shippingUIValue = wh.getAttribute(shippingChargeRightRail, "$");

			// Formula for shipping charge calculation from DB
			// 1.Connect to DB
			// 2.Use Formula for Shipping value
			// 3. Compare with UI value
			// 4. add report step for validation

		}

	}

	/**
	 * Method to verify Name on card field is present in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage selectSavedCardDropDown() throws Exception {

		Thread.sleep(commonData.littleWait);
		if (wh.isElementPresent(savedCard)) {

			new Select(driver.findElement(savedCard)).selectByIndex(1);
			Thread.sleep(commonData.littleWait);
			report.addReportStep("Select card from saved card drop down", "Card is selected from saved card drop down",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Select card from saved card drop down", "saved card drop down is not present",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to enter CVV for saved cards in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage enterCvvSavedCards() throws Exception {

		// String cvv = dataTable.getData(DataColumn.CardSecurityId);
		String cvv = dataTable.getData("CardSecurityId");

		if (wh.isElementPresent(savedCardCvv)) {

			wh.sendKeys(savedCardCvv, cvv);

			report.addReportStep("Enter CVV in payment page", "CVV is entered in payment page", StepResult.PASS);
		}

		else {
			report.addReportStep("Enter CVV in payment page", "CVV is not present in payment page", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify CVV cleared for saved cards in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyCvvCleared() throws Exception {

		if (wh.isElementPresent(cvvCleared)) {

			report.addReportStep("Verify CVV is cleared in payment page", "CVV is cleared in payment page",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify CVV is cleared in payment page", "CVV is not cleared in payment page",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify saved credit card option as radio button
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifySavedCreditCardRadio() throws Exception {

		if (wh.isElementPresent(savedCreditCardRadioGrp)) {

			report.addReportStep("Verify Saved Credit card displayed as Radio Buttons",
					"Saved Credit card displayed as Radio Buttons", StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Saved Credit card displayed as Radio Buttons",
					"Saved Credit card is not displayed as Radio Buttons", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify new card as radio button
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyNewCardRadio() throws Exception {

		if (wh.isElementPresent(newCardRadioGrp)) {

			report.addReportStep("Verify New card displayed as Radio Buttons", "New card displayed as Radio Buttons",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify New card displayed as Radio Buttons",
					"New card is not displayed as Radio Buttons", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * Method to verify Paypal as radio button
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyPaypalRadio() throws Exception {

		if (wh.isElementPresent(payPalRadio)) {

			report.addReportStep("Verify Paypal displayed as Radio Buttons", "Paypal displayed as Radio Buttons",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Verify Paypal displayed as Radio Buttons",
					"Paypal is not displayed as Radio Buttons", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * To select new card Radio option in payment page
	 * 
	 * @throws Exception
	 * 
	 * @InputParameters None
	 */

	public void selectNewCardRadio() throws Exception {
		if (wh.isElementPresent(newCardRadio, 4)) {

			wh.clickElement(newCardRadio);

			report.addReportStep("Verify <b>'New Card'</b> Option is selected under payment option section",
					" <b>New Card</b> option is selected", StepResult.PASS);
		} else

		{
			report.addReportStep("Verify <b>'New Card'</b> Option is selected under payment option section",
					" <b>New Card</b> option is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * To select new card Radio option in payment page
	 * 
	 * @throws Exception
	 * 
	 * @InputParameters None
	 */

	public void selectCreditCardRadio() throws Exception {
		if (wh.isElementPresent(creditCardRadio, 4)) {

			wh.clickElement(creditCardRadio);

			report.addReportStep("Verify <b>'Credit Card'</b> Option is selected under payment option section",
					" <b>Credit Card</b> option is selected", StepResult.PASS);
		} else

		{
			report.addReportStep("Verify <b>'Credit Card'</b> Option is selected under payment option section",
					" <b>Credit Card</b> option is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Method to verify Name on card field is present in payment page
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifySavedCardRadio() throws Exception {

		Thread.sleep(commonData.littleWait);

		if (wh.isElementPresent(savedCard)) {

			new Select(driver.findElement(savedCard)).selectByIndex(1);
			Thread.sleep(commonData.littleWait);
			report.addReportStep("Select card from saved card drop down", "Card is selected from saved card drop down",
					StepResult.PASS);
		}

		else {
			report.addReportStep("Select card from saved card drop down", "saved card drop down is not present",
					StepResult.FAIL);
		}
		return this;
	}

	/**
	 * To verify saved card section collapsed
	 * 
	 * @throws Exception
	 * 
	 * @InputParameters None
	 */

	public void verifySavedCardCollapsed() throws Exception {
		if (wh.isElementNotPresent(savedCardDropDown)) {

			report.addReportStep("Verify Saved card section is collapsed and hidden",
					"<b>Saved card</b> section is collapsed and hidden", StepResult.PASS);
		} else

		{
			report.addReportStep("Verify Saved card section is collapsed and hidden",
					"<b>Saved card</b> section is not collapsed and not hidden", StepResult.FAIL);
		}
	}

	/**
	 * To verify new card section and fields
	 * 
	 * @throws Exception
	 * 
	 * @InputParameters None
	 */

	public void verifyNewCardSection() throws Exception {
		if (wh.isElementPresent(newCardSection, 4)) {

			report.addReportStep("Verify New card section is displayed", "<b>New card</b> section is displayed",
					StepResult.PASS);

			if (wh.isElementPresent(cardNumber, 4)) {

				report.addReportStep("Verify Card Number text box is displayed",
						"<b>Card Number</b> text box is displayed", StepResult.PASS);
			} else

			{
				report.addReportStep("Verify Card Number text box is displayed",
						"<b>Card Number</b> text box is not displayed", StepResult.FAIL);
			}

			if (wh.isElementPresent(expirationMonthYear, 4)) {

				report.addReportStep("Verify Expiration month and Expiration year dropdown are displayed",
						"<b>Expiration month and Expiration year</b> dropdown are displayed", StepResult.PASS);
			} else

			{
				report.addReportStep("Verify Expiration month and Expiration year dropdown are displayed",
						"<b>Expiration month and Expiration year</b> dropdown are not displayed", StepResult.FAIL);
			}

			if (wh.isElementPresent(cardSecurityID, 4)) {

				report.addReportStep("Verify Security code text box is displayed",
						"<b>Security code</b> text box is displayed", StepResult.PASS);
			} else

			{
				report.addReportStep("Verify Security code text box is displayed",
						"<b>Security code</b> text box is not displayed", StepResult.FAIL);
			}

			if (wh.isElementPresent(poJobCode, 4)) {

				report.addReportStep("Verify PO/Job Code text box is displayed",
						"<b>PO/Job Code</b> text box is displayed", StepResult.PASS);
			} else

			{
				report.addReportStep("Verify PO/Job Code text box is displayed",
						"<b>PO/Job Code</b> text box is not displayed", StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify New card section is displayed", "<b>New card</b> section is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * To verify Gift card section hidden
	 * 
	 * @throws Exception
	 * 
	 * @InputParameters None
	 */

	public void verifyGiftCardSecHidden() throws Exception {
		if (wh.isElementNotPresent(gcSection)) {

			report.addReportStep("Verify Gift card section is hidden", "<b>Gift card</b> section is hidden",
					StepResult.PASS);
		} else

		{
			report.addReportStep("Verify Gift card section is hidden", "<b>Gift card</b> section is not hidden",
					StepResult.FAIL);
		}
	}

	/**
	 * To verify Billing section hidden
	 * 
	 * @throws Exception
	 * 
	 * @InputParameters None
	 */

	public void verifyBillingSecHidden() throws Exception {
		if (wh.isElementNotPresent(billingSection)) {

			report.addReportStep("Verify Billing section is hidden", "<b>Billing</b> section is hidden",
					StepResult.PASS);
		} else

		{
			report.addReportStep("Verify Billing section is hidden", "<b>Billing</b> section is not hidden",
					StepResult.FAIL);
		}
	}

	public void verifyTotalForPLCCNonHDCard() throws Exception {

		if (wh.isElementPresent(orderSummary)) {

			List<WebElement> priceDet = driver.findElements(orderSummary);
			double finalTotal = 0;
			String total;
			for (WebElement price : priceDet) {

				if (wh.getText(price).contains("$")) {
					total = wh.getText(price);
					total = total.replace("$", "");
					total = total.replace(",", "");
					finalTotal = finalTotal + Double.parseDouble(total);

				} else if (wh.getText(price).contains("NOT APPLIED")) {
					report.addReportStep("Verify PLCC promo price is not applied", "PLCC promo price is not applied",
							StepResult.PASS);
				}

			}
			if (wh.isElementPresent(orderSummaryExtras)) {
				List<WebElement> priceDetail = driver.findElements(orderSummaryExtras);
				String tot;
				for (WebElement price : priceDetail) {

					if (wh.getText(price).contains("$")) {
						tot = wh.getText(price);
						tot = tot.replace("$", "");
						tot = tot.replace(",", "");
						finalTotal = finalTotal + Double.parseDouble(tot);

					}
				}

			}
			if (wh.isElementPresent(totalRightRail)) {
				String tot = wh.getText(totalRightRail);
				if (tot.contains(Double.toString(finalTotal))) {
					report.addReportStep("Verify whether PLCC promo discount is reduced from total in payment page",
							"Total in payment page<b> " + tot + "</b> is equivalent to sum of all the prices<b>"
									+ finalTotal + "</b>", StepResult.PASS);
				} else {
					report.addReportStep("Verify whether PLCC promo discount is reduced from total in payment page",
							"Total in payment page<b> " + tot + "</b> is not equivalent to sum of all the prices<b>"
									+ finalTotal + "</b>", StepResult.FAIL);
				}

			}

		} else {
			report.addReportStep("Verify PLCC promo price is reduced", "PLCC promo price is not reduced",
					StepResult.FAIL);
		}
		// if ((commonData.total != null)&&(!commonData.total.isEmpty())) {
		// String total = null;
		// double finalTot = Double.parseDouble(commonData.total) -
		// Double.parseDouble(commonData.plccPrice);
		// if (wh.isElementPresent(totalRightRail)) {
		// total = wh.getText(totalRightRail);
		// total = total.substring(1);
		// }
		// if (Math.abs(finalTot - Double.parseDouble(total)) == 0) {
		// report.addReportStep("Verify whether PLCC promo discount is reduced
		// from total in payment page",
		// "Total in payment page<b> " + total + "</b> is equivalent to sum of
		// all the prices<b>"
		// + finalTot + "</b>",
		// StepResult.PASS);
		//
		// } else {
		// report.addReportStep("Verify whether PLCC promo discount is reduced
		// from total in payment page",
		// "Total in cart page<b> " + total + "</b> is not equivalent to sum of
		// all the prices<b>"
		// + finalTot + "</b>",
		// StepResult.FAIL);
		// }
		// } else
		//
		// {
		// report.addReportStep("Verify whether PLCC promo discount is reduced
		// from total in payment page",
		// "PLCC promo discount is not reduced from total in payment page",
		// StepResult.FAIL);
		// }
	}

	public boolean verifyPOforCreditCards() throws InterruptedException {

		try {
			new WebDriverWait(driver, 4).until(ExpectedConditions.presenceOfElementLocated(By.id("POJobCode"))).click();
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public void clickEditLink() throws Exception {
		Thread.sleep(2000);
		boolean blnIsDialogDisplayed = false;
		int intCount = 0;
		if (wh.isElementPresent(EditLinkInPayment)) {
			List<WebElement> lstNoShopCart = driver.findElements(EditLinkInPayment);
			// List lstNoShopCart = (List)
			// driver.findElements(EditLinkInPayment);
			System.out.println(lstNoShopCart.size());
			for (WebElement removeItem : lstNoShopCart) {
				JavascriptExecutor js = null;
				if (driver instanceof JavascriptExecutor) {
					js = (JavascriptExecutor) driver;
				}
				wh.jsClick(EditLinkInPayment);
				report.addReportStep("click on modify link", "Modify link is clicked", StepResult.PASS);
			}
		}
	}

	public PaymentPage verifyNewSavedAddress() throws Exception {
		if (wh.isElementPresent(savedAddr, 0)) {
			String newZipcode = commonData.NewZipcode;
			String previousZipcode = dataTable.getCommonData(CommonDataColumn.ShippingZipCode);
			if (newZipcode != previousZipcode) {
				report.addReportStep("previous and New address should not match", "Both address are not matched",
						StepResult.PASS);

			} else {
				report.addReportStep("previous and New address should not match", "Both address are matched",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify that saved address is retained in payment page",
					"Saved address is not retained in payment page", StepResult.FAIL);
		}
		return this;
	}

	/*
	 * Method to enter card details from test data sheet
	 * 
	 * @return
	 * 
	 * @throws Exception
	 */
	public PaymentPage enterDiffCardDetails() throws Exception {
		String CardNumber = dataTable.getData("CardNumber");
		String CardType = dataTable.getData("CardType");
		wh.sendKeys(cardNumber, CardNumber);
		driver.findElement(cardNumber).sendKeys(Keys.TAB);

		Thread.sleep(1000);
		verifyCardTypeIconEnabled(CardType);

		if (CardType.toLowerCase().contains("commercial") || CardType.toLowerCase().contains("prox")) {
			wh.sendKeys(buyerNameNewCard, dataTable.getCommonData(CommonDataColumn.BuyerName));
		}

		else if (CardType.toLowerCase().contains("consumer")) {

		}

		else {
			wh.selectValue(expirationMonth, dataTable.getCommonData(CommonDataColumn.ExpirationMonth));
			wh.selectValue(expirationYear, dataTable.getCommonData(CommonDataColumn.ExpirationYear));
		}

		if (CardType.toLowerCase().contains("amex")) {
			wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CVV_Amex));
		} else {
			wh.sendKeys(cardSecurityID, dataTable.getCommonData(CommonDataColumn.CardSecurityID));
		}

		verifyCVVMasked();

		// To Verify PO Job Code
		if (CardType.toLowerCase().contains("consumer") || CardType.toLowerCase().contains("amex")) {
			if (verifyPOforCreditCards()) {
				report.addReportStep("Verifying PO number", "PO field is Displayed", StepResult.FAIL);
			} else {
				report.addReportStep("Verifying PO number", "PO field is not Displayed", StepResult.PASS);
			}
		}

		else {
			if (verifyPOforCreditCards()) {
				// String strPOField = dataTable.getData("POJobCode");
				String strPOField = dataTable.getCommonData(CommonDataColumn.POJobCode);
				wh.sendKeys(poJobCode, strPOField);
				report.addReportStep("Entering PO number <b>" + strPOField
						+ " </b>in the PO number Field in payment method page",
						"PO field is Displayed and PO Number <b>" + strPOField + " </b>is entered", StepResult.PASS);
			} else {
				report.addReportStep(" Verify whether the PO # field should displayed", "PO # field is not displayed.",
						StepResult.FAIL);
			}
		}

		if (wh.isElementPresent(firstName, 0)) {

			wh.sendKeys(firstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
			wh.sendKeys(lastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.sendKeys(address1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			wh.sendKeys(zipCode, dataTable.getCommonData(CommonDataColumn.ShippingZipCode));
			wh.sendKeys(phoneNumber, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			wh.sendKeys(emailAddress, dataTable.getCommonData(CommonDataColumn.GuestEmail));

		}

		report.addReportStep("Enter payment page details", "Payment page details entered", StepResult.PASS);

		return this;
	}

	public void verifyCVVMasked() throws Exception {

		if (wh.getAttribute(cardSecurityID, "type").equalsIgnoreCase("tel"))
			report.addReportStep(" Verify is Masked", "CVV is Not masked", StepResult.PASS);
		else if (wh.getAttribute(cardSecurityID, "type").equalsIgnoreCase("password"))
			report.addReportStep(" Verify is Masked", "CVV is Not masked", StepResult.PASS);
		else
			report.addReportStep(" Verify is Masked", "CVV is Not masked", StepResult.FAIL);

	}

	public void verifyCardTypeIconEnabled(String CardType) throws Exception {

		if (CardType.toLowerCase().contains("discover")) {
			creditCardIconPresence(discoverCardIconEnabled, CardType);

			creditCardIconAbsence(visaCardIconPresenceDisabled, "Visa");
			creditCardIconAbsence(amexCardIconPresenceDisabled, "Amex");
			creditCardIconAbsence(masterCardIconPresenceDisabled, "Master");
			creditCardIconAbsence(hdConsumerCardIconPresenceDisabled, "hdconsumer");
			creditCardIconAbsence(hdCommericialCardIconPresenceDisabled, "hdcommercial");
			creditCardIconAbsence(hdProxCardIconPresenceDisabled, "hdProx");

		} else if (CardType.toLowerCase().contains("visa")) {
			creditCardIconPresence(visaCardIconEnabled, CardType);

			creditCardIconAbsence(discoverCardIconDisabled, "Discover");
			creditCardIconAbsence(amexCardIconPresenceDisabled, "Amex");
			creditCardIconAbsence(masterCardIconPresenceDisabled, "Master");
			creditCardIconAbsence(hdConsumerCardIconPresenceDisabled, "hdconsumer");
			creditCardIconAbsence(hdCommericialCardIconPresenceDisabled, "hdcommercial");
			creditCardIconAbsence(hdProxCardIconPresenceDisabled, "hdProx");

		} else if (CardType.toLowerCase().contains("amex")) {
			creditCardIconPresence(amexCardIconEnabled, CardType);

			creditCardIconAbsence(discoverCardIconDisabled, "Discover");
			creditCardIconAbsence(visaCardIconPresenceDisabled, "Visa");
			creditCardIconAbsence(masterCardIconPresenceDisabled, "Master");
			creditCardIconAbsence(hdConsumerCardIconPresenceDisabled, "hdconsumer");
			creditCardIconAbsence(hdCommericialCardIconPresenceDisabled, "hdcommercial");
			creditCardIconAbsence(hdProxCardIconPresenceDisabled, "hdProx");

		} else if (CardType.toLowerCase().contains("master")) {
			creditCardIconPresence(masterCardIconEnabled, CardType);

			creditCardIconAbsence(discoverCardIconDisabled, "Discover");
			creditCardIconAbsence(visaCardIconPresenceDisabled, "Visa");
			creditCardIconAbsence(amexCardIconPresenceDisabled, "Amex");
			creditCardIconAbsence(hdConsumerCardIconPresenceDisabled, "consumer");
			creditCardIconAbsence(hdCommericialCardIconPresenceDisabled, "commercial");
			creditCardIconAbsence(hdProxCardIconPresenceDisabled, "hdProx");

		} else if (CardType.toLowerCase().contains("consumer")) {
			creditCardIconPresence(hdConsumerCardIconEnabled, CardType);

			creditCardIconAbsence(discoverCardIconDisabled, "Discover");
			creditCardIconAbsence(visaCardIconPresenceDisabled, "Visa");
			creditCardIconAbsence(amexCardIconPresenceDisabled, "Amex");
			creditCardIconAbsence(masterCardIconPresenceDisabled, "MasterCard");
			creditCardIconAbsence(hdCommericialCardIconPresenceDisabled, "commercial");
			creditCardIconAbsence(hdProxCardIconPresenceDisabled, "hdProx");

		} else if (CardType.toLowerCase().contains("commercial")) {
			creditCardIconPresence(hdCommericialCardIconEnabled, CardType);
			creditCardIconPresence(hdProxCardIconEnabled, "prox");

			creditCardIconAbsence(discoverCardIconDisabled, "Discover");
			creditCardIconAbsence(visaCardIconPresenceDisabled, "Visa");
			creditCardIconAbsence(amexCardIconPresenceDisabled, "Amex");
			creditCardIconAbsence(masterCardIconPresenceDisabled, "MasterCard");
			creditCardIconAbsence(hdConsumerCardIconPresenceDisabled, "consumer");
			// creditCardIconAbsence(hdProxCardIconPresenceDisabled, "hdProx");

		} else if (CardType.toLowerCase().contains("prox")) {
			creditCardIconPresence(hdProxCardIconEnabled, CardType);
			creditCardIconPresence(hdCommericialCardIconEnabled, "commercial");

			creditCardIconAbsence(discoverCardIconDisabled, "Discover");
			creditCardIconAbsence(visaCardIconPresenceDisabled, "Visa");
			creditCardIconAbsence(amexCardIconPresenceDisabled, "Amex");
			creditCardIconAbsence(masterCardIconPresenceDisabled, "MasterCard");
			creditCardIconAbsence(hdConsumerCardIconPresenceDisabled, "consumer");
			// creditCardIconAbsence(hdCommericialCardIconPresenceDisabled,
			// "commercial");
		}
	}

	public void creditCardIconPresence(By Icon, String cardType) throws Exception {

		if (wh.isElementPresent(Icon))
			report.addReportStep("Verify " + cardType + " is Enabled", cardType + " Icon is enabled", StepResult.PASS);
		else
			report.addReportStep("Verify " + cardType + " is Enabled", cardType + " Icon is not enabled",
					StepResult.FAIL);
	}

	public void creditCardIconAbsence(By Icon, String cardType) throws Exception {

		if (wh.isElementPresent(Icon))
			report.addReportStep("Verify " + cardType + " is displayed in Disabled mode", cardType
					+ " Icon is Disabled", StepResult.PASS);
		else
			report.addReportStep("Verify " + cardType + " is displayed in Disabled mode", cardType
					+ " Icon is not Disabled", StepResult.FAIL);
	}

	/**
	 * 
	 * Description : Verify the CVV field tool tip image
	 * 
	 * @since Jan 8,2015
	 * @author yxg8356
	 * @throws Exception
	 */

	public void verifyCVVTooltipImage() throws Exception {

		if (wh.isElementPresent(CVVToolTip, 2)) {

			report.addReportStep("Verify CVV Filed tooltip icon is displayed", "CVV field tooltip icon is displayed",
					StepResult.PASS);

			// Click tooltip icon
			wh.clickElement(CVVToolTip);
		}
		if (wh.isElementPresent(CVVOverlay, 2)) {
			report.addReportStep("Verify CVV Filed tooltip icon is clicked", "CVV field tooltip overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify CVV Filed tooltip icon is not clicked",
					"CVV field tooltip overlay is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * To Check the option 'Apply my Home Depot Tax Exempt ID' and enter the tax
	 * exempt
	 * 
	 * @throws Exception
	 * @Author Cognizant
	 * @DateCreated Jan 2nd, 2013
	 */
	public void taxExemptNum() throws Exception {
		// if(cf.waitForElement(driver,
		// By.xpath("//*[contains(text(),'edit this tax exempt ID')]"), 5))
		if (wh.isElementPresent(editThisTax, 2)) {
			report.addReportStep(
					"Verify the <b>Home Depot Tax Exempt ID'</b> field is already present in payment page",
					"Home Depot Tax Exempt Id label is already displayed in payment page ", StepResult.PASS);
		} else {
			String strTaxExemptNum = dataTable.getData("TaxExemptNum");
			commonData.strTaxNum = strTaxExemptNum;
			verifyTaxExemptNum();
			wh.sendKeys(taxId, dataTable.getData(DataColumn.TaxExemptNum));
			driver.findElement(By.cssSelector("#tax-id")).sendKeys(Keys.TAB);
			report.addReportStep("Enter a valid Tax Exempt ID in the text box",
					" Valid Tax Exempt Id is entered in the text box ", StepResult.DONE);
			clickOnApplyBtnOnApplyTaxExemptOverly();
		}
	}

	public boolean verifyTaxExemptNum() throws Exception {

		if (wh.isElementPresent(taxExemptOverlay, 2)) {
			report.addReportStep("Tax section overlay opened", "Tax section overlay is opened ", StepResult.PASS);
		} else if (wh.isElementPresent(applyTaxLink, 2)) {

			wh.jsClick(applyTaxLink);
			report.addReportStep(
					"Apply a tax Exempt ID should be clicked and Apply Tax Exempt Id overly should be opened",
					"Apply a tax Exempt ID is clicked and Apply Tax Exempt Id overly is opend ", StepResult.PASS);
		} else if (wh.isElementPresent(applyTaxlink, 2)) {
			wh.jsClick(applyTaxlink);
			report.addReportStep(
					"Apply a tax Exempt ID should be clicked and Apply Tax Exempt Id overly should be opened",
					"Apply a tax Exempt ID is clicked and Apply Tax Exempt Id overly is opend ", StepResult.PASS);
		}

		else {
			report.addReportStep(
					"Apply a tax Exempt ID should be clicked and Apply Tax Exempt Id overly should be opened",
					"Apply a tax Exempt ID is not clicked", StepResult.FAIL);
		}
		if (wh.isElementPresent(taxId, 2)) {
			report.addReportStep("Verify the <b>Home Depot Tax Exempt ID'</b> field is present in payment page",
					"Home Depot Tax Exempt Id label is displayed with a text box to enter the value", StepResult.PASS);
			return true;
		} else {
			report.addReportStep("Verify the <b>Home Depot Tax Exempt ID'</b> field is present in payment page",
					"Home Depot Tax Exempt Id label is not displayed with a text box to enter the value",
					StepResult.FAIL);
			return false;
		}
	}

	public void clickOnApplyBtnOnApplyTaxExemptOverly() throws Exception {
		if (wh.isElementPresent(applyTax, 2)) {
			wh.jsClick(applyTax);
			report.addReportStep("Click on apply button on tax exempt overlay",
					"Clicked on apply button on tax exempt overlay", StepResult.PASS);
		} else {
			report.addReportStep("Click on apply button on tax exempt overlay",
					"not Clicked on apply button on tax exempt overlay", StepResult.FAIL);
		}
	}

	/**
	 * To verify mandatory field error msg by leaving fields empty
	 * 
	 * @throws Exception
	 * @Author Cognizant
	 * @DateCreated Jan 2nd, 2013
	 */
	public void verifyMandatoryFieldsErrMsg() throws Exception {
		// Card Number
		driver.findElement(cardNumber).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strCardErr = wh.getText(CardErr);
		System.out.println(strCardErr);

		// CVV field
		driver.findElement(cardSecurityID).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strCvvErr = wh.getText(CvvErr);
		System.out.println(strCvvErr);

		// Buyer's Name
		if (wh.isElementPresent(buyerNameNewCard, 2)) {
			driver.findElement(buyerNameNewCard).clear();
			if (wh.isElementPresent(submitOrderBtn)) {
				wh.jsClick(submitOrderBtn);
			} else if (wh.isElementPresent(submitOrderBtn2)) {
				wh.jsClick(submitOrderBtn);
			}
			String strBuyerNameErr = wh.getText(BuyerNameErr);
			System.out.println(strBuyerNameErr);
		} else {
			report.addReportStep("Mandatory field error", "Buyer Name is not availabel for this cart type",
					StepResult.DONE);

		}
		if (strCardErr.contains("Card number is required. Please enter a valid credit card number.")
				&& strCvvErr.contains("Enter the credit card security ID number or CVV.")) {

			report.addReportStep("Mandatory field error", "Mandatory Card section field error is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Mandatory field error", "Mandatory card section field error is not displayed",
					StepResult.FAIL);
		}

		enterCardDetails();
		// First Name
		driver.findElement(firstName).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strFirstNameErr = wh.getText(firstNameErr);
		System.out.println(strFirstNameErr);

		// Last Name
		driver.findElement(lastName).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strLastNameErr = wh.getText(lastNameErr);
		System.out.println(strLastNameErr);

		// Address1
		driver.findElement(address1).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strAddrErr = wh.getText(AddressErr);
		System.out.println(strAddrErr);

		// Zipcode
		driver.findElement(zipCode).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strzipErr = wh.getText(zipcodeErr);
		System.out.println(strzipErr);

		// Phone Number
		driver.findElement(phoneNumber).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strPhErr = wh.getText(PhErr);
		System.out.println(strPhErr);

		// Email Address
		driver.findElement(emailAddress).clear();
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		String strEmailErr = wh.getText(emailErr);
		System.out.println(strEmailErr);

		if (strFirstNameErr.contains("First name is required. Please enter your first name")
				&& strLastNameErr.contains("Last name is required. Please enter your last name")
				&& strAddrErr.contains("Address Line 1 required. Please enter your address")
				&& strzipErr.contains("This field is required.")
				&& strPhErr.contains("Phone is required. Please enter your phone number")
				&& strEmailErr.contains("Enter an email address such as name@domain.com")) {
			report.addReportStep("Mandatory field error", "Mandatory field error is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Mandatory field error", "Mandatory field error is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * To verify credit card, gift card, paypal and billing section in payment
	 * page
	 * 
	 * @throws Exception
	 * @Author Cognizant
	 * @DateCreated Jan 2nd, 2013
	 */
	public void verifyPaymentTypeSection() throws Exception {
		if (wh.isElementPresent(giftCardSection, 2) && wh.isElementPresent(rdoPaypal, 2)
				&& wh.isElementPresent(creditCardRadio, 2) && wh.isElementPresent(billingSection, 2)) {
			report.addReportStep("Payment Type section", "Payment Type section is displayed", StepResult.PASS);
		} else {
			report.addReportStep("Payment Type section", "Payment Type section is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Method to verify No Saved address
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyNoSavedAddress() throws Exception {

		if (wh.isElementPresent(savedAddr, 0)) {
			report.addReportStep("Verify that no saved address is retained in payment page",
					"Saved address is not retained in payment page properly", StepResult.PASS);
		} else {
			report.addReportStep("Verify that saved address is retained in payment page",
					"Saved address is retained in payment page", StepResult.FAIL);
		}
		return this;
	}

	/**
	 * To verify tax exempt error
	 * 
	 * @throws Exception
	 * @Author Cognizant
	 * @DateCreated Jan 2nd, 2013
	 */
	public PaymentPage verifyTaxExemptError() throws Exception {
		// To click on submit order
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		Thread.sleep(1000);
		if (wh.isElementPresent(taxExemptErr, 2)) {
			String strTaxErr = wh.getText(taxExemptErr);
			System.out.println(strTaxErr);
			if (strTaxErr.contains("The tax-exempt number you have entered is not valid")
					|| strTaxErr
							.contains("We're sorry. Your tax exempt ID is not authorized in the shipping state entered.")) {
				report.addReportStep("Verify tax exempt error in payment page", "Invalid tax exempt error" + strTaxErr
						+ "is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify tax exempt error in payment page",
						"Invalid tax exempt error is not displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify tax exempt error in payment page", "Tax exempt error is not displayed",
					StepResult.FAIL);
		}
		return this;
	}

	public void enterInvalidCreditCard() throws Exception {

		wh.waitForPageLoaded();
		if (wh.isElementPresent(cardNumber, 5)) {
			wh.sendKeys(cardNumber, dataTable.getData("CardNumber"));
			driver.findElement(cardNumber).sendKeys(Keys.TAB);
			if (wh.isElementPresent(CardErr, 5)) {
				String err = wh.getText(CardErr);
				if (err.contains("Please enter a valid credit card number."))
					report.addReportStep("Verify error message is displayed for invalid credit card",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed for invalid credit card",
							"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
				}

			} else {
				report.addReportStep("Verify error message is displayed for invalid credit card",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify error message is displayed for invalid credit card",
					"Card number field is not displayed", StepResult.FAIL);

		}

	}

	public void enterInvalidEmailId() throws Exception {

		wh.waitForPageLoaded();
		if (wh.isElementPresent(emailAddress, 5)) {
			wh.sendKeys(emailAddress, "abcd");
			driver.findElement(emailAddress).sendKeys(Keys.TAB);
			if (wh.isElementPresent(emailErr, 5)) {
				String err = wh.getText(emailErr);
				if (err.contains("Please enter a valid email address."))
					report.addReportStep("Verify error message is displayed for invalid Email Id", "Error message <b>"
							+ err + "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed for invalid Email Id", "Error message <b>"
							+ err + "</b> is not displayed properly", StepResult.PASS);
				}

			} else {
				report.addReportStep("Verify error message is displayed for invalid Email Id",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify error message is displayed for invalid Email Id",
					"Card number field is not displayed", StepResult.FAIL);

		}

	}

	public void clearFirstLastNameClickSubmitOrder() throws Exception {

		if (wh.isElementPresent(firstName, 3)) {
			wh.clearElement(firstName);
			wh.clearElement(lastName);

			wh.clickElement(submitOrderBtn);
			if (wh.isElementPresent(firstNameErr, 5)) {
				String fnameErr = wh.getText(firstNameErr);
				String lnameErr = wh.getText(lastNameErr);
				if (fnameErr.contains("First name is required. Please enter your first name")
						&& lnameErr.contains("Last name is required. Please enter your last name"))
					report.addReportStep("Verify error message is displayed", "Error message <b>" + fnameErr
							+ "</b> <b>" + lnameErr + "</b>is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed", "Error message <b>" + fnameErr
							+ "</b> <b>" + lnameErr + "</b>is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify error message is displayed", "FirstName text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void clearEmailClickSubmitOrder() throws Exception {

		if (wh.isElementPresent(emailAddress, 3)) {
			wh.clearElement(emailAddress);

			wh.clickElement(submitOrderBtn);
			if (wh.isElementPresent(emailErr, 5)) {
				String stremail = wh.getText(emailErr);
				if (stremail.contains("Enter an email address such as name@domain.com")) {

					report.addReportStep("Verify Email error message is displayed", "Error message <b>" + stremail
							+ "</b>is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify Email error message is displayed", "Error message <b>" + stremail
							+ "</b>is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error message is displayed", "Eamil text box is not displayed",
					StepResult.FAIL);
		}
		// Enter email again
		wh.sendKeys(emailAddress, dataTable.getCommonData(CommonDataColumn.GuestEmail));

	}

	public void enterInvalidSymbolsPhonePaymentPg() throws Exception {

		int i = 0;

		if (wh.isElementPresent(phoneNumber, 3)) {
			for (i = 0; i < commonData.phSymbols.length; i++) {
				String phNum = commonData.phSymbols[i];
				wh.clearElement(phoneNumber);
				wh.sendKeys(phoneNumber, phNum);
				report.addReportStep("Verify " + phNum + " is entered", phNum + " is entered", StepResult.PASS);
				wh.clickElement(address1);
				if (wh.isElementPresent(PhErr, 5)) {
					String err = wh.getText(PhErr);
					if (err.contains("Invalid format."))
						report.addReportStep("Verify error message is displayed for " + phNum + " entered",
								"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + phNum + " entered",
								"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + phNum + " entered",
							"Error message is not displayed", StepResult.FAIL);
				}
				wh.clearElement(phoneNumber);
				wh.sendKeys(phoneNumber, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
				wh.clickElement(address1);
			}

		} else

		{
			report.addReportStep("Verify Phone Number is entered with invalid symbol",
					"Phone Number text box is not displayed", StepResult.FAIL);
		}

	}

	public void enterZeroesPhoneNoPaymentPg() throws Exception {

		if (wh.isElementPresent(phoneNumber, 3)) {
			String phNo = dataTable.getCommonData(CommonDataColumn.InvalidPhoneNumber);
			wh.clearElement(phoneNumber);
			wh.sendKeys(phoneNumber, phNo);

			report.addReportStep("Verify " + phNo + " is entered", phNo + " is entered", StepResult.PASS);
			wh.clickElement(address1);
			if (wh.isElementPresent(PhErr, 5)) {
				String err = wh.getText(PhErr);
				if (err.contains("Please enter a valid phone number"))
					report.addReportStep("Verify error message is displayed for " + phNo + " entered",
							"Error message <b>" + err + "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed for " + phNo + " entered",
							"Error message <b>" + err + "</b> is not displayed properly", StepResult.PASS);
				}

			} else {
				report.addReportStep("Verify error message is displayed for " + phNo + " entered",
						"Error message is not displayed", StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify phone number is entered with zeroes", "Zipcode text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void clearAddressClickSumbitOrder() throws Exception {

		if (wh.isElementPresent(address1, 3)) {
			wh.clearElement(address1);

			wh.clickElement(submitOrderBtn);
			if (wh.isElementPresent(AddressErr, 5)) {
				String err = wh.getText(AddressErr);
				if (err.contains("Address Line 1 required. Please enter your address"))
					report.addReportStep("Verify error message is displayed", "Error message <b>" + err
							+ "</b> is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed", "Error message <b>" + err
							+ "</b> is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify error message is displayed", "Address text box is not displayed",
					StepResult.FAIL);
		}

	}

	public void clearZipcodeAndPhoneClickSubmitOrder() throws Exception {

		if (wh.isElementPresent(zipCode, 3)) {
			wh.clearElement(zipCode);
			wh.clearElement(phoneNumber);

			wh.clickElement(submitOrderBtn);
			if (wh.isElementPresent(zipcodeErr, 5)) {
				String zipErr = wh.getText(zipcodeErr);
				String phoneErr = wh.getText(PhErr);
				if (zipErr.contains("This field is required.")
						&& phoneErr.contains("Phone is required. Please enter your phone number"))
					report.addReportStep("Verify error message is displayed", "Error message <b>" + zipErr + "</b> <b>"
							+ phoneErr + "</b>is displayed", StepResult.PASS);
				else {
					report.addReportStep("Verify error message is displayed", "Error message <b>" + zipErr + "</b> <b>"
							+ phoneErr + "</b>is not displayed properly", StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify error message is displayed", "Error message is not displayed",
						StepResult.FAIL);
			}

		} else

		{
			report.addReportStep("Verify error message is displayed", "FirstName text box is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify the Phone field is moved up AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyPhoneFieldMovedUp() throws Exception {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,550)", "");
		Thread.sleep(commonData.mediumWait);
		if (wh.isElementPresent(paymentAddrPhone, 3)) {
			String phone = wh.getText(paymentAddrPhone);
			if (phone.contains("Phone")) {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is moved up and displayed below Last Name field", StepResult.PASS);
			} else {
				report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
						"Phone field is not moved up and not displayed below Last Name field", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Phone field is moved up and displayed below Last Name field",
					"Shipping address fields are not displayed properly", StepResult.FAIL);
		}
	}

	/**
	 * Component to click use new billing address link in payment page AXB8034
	 * 
	 * @throws Exception
	 */
	public void clickNewBillingAddress() throws Exception {
		if (wh.isElementPresent(newBillingAddrLink, 3)) {
			wh.clickElement(newBillingAddrLink);
			report.addReportStep("Click use new billing Address link in payment page",
					"use new billing Address link is clicked in payment page", StepResult.PASS);
		} else {
			report.addReportStep("Click use new billing Address link in payment page",
					"use new billing Address link is not clicked in payment page", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify new billing address overlay in payment page AXB8034
	 * 
	 * @throws Exception
	 */
	public void verifyNewBillingAddressOverlay() throws Exception {
		if (wh.isElementPresent(newBillingAddrOverlay, 3)) {
			report.addReportStep("Verify New billing Address overlay is displayed in payment page",
					"New billing Address overlay is displayed in payment page", StepResult.PASS);
		} else {
			report.addReportStep("Verify New billing Address overlay is displayed in payment page",
					"New billing Address overlay is not displayed in payment page", StepResult.FAIL);
		}
	}

	public void verifyShippingCharge() throws Exception {
		if (wh.isElementPresent(shipValue)) {

			String strShipCharge = wh.getText(shipValue);
			System.out.println(strShipCharge);
			System.out.println(commonData.strshipvalue);
			if (strShipCharge.contains(commonData.strshipvalue)) {
				report.addReportStep("Verify Shipping charge is displayed", "Shipping charge <b>" + strShipCharge
						+ "</b> <b>" + commonData.strshipvalue + "</b>is same in payment and shipping page",
						StepResult.PASS);
			} else {
				report.addReportStep("verify shipping charge", "Shipping charge is not same" + strShipCharge
						+ "as in payment page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("verify shipping charge", "Shipping charge is not displayed", StepResult.FAIL);
		}

	}

	public void enterNewRegPassword() throws Exception {

		driver.findElement(By.id("POJobCode")).sendKeys(Keys.PAGE_DOWN);

		String strPassword = dataTable.getData("NewRegPwd");

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, strPassword);

			report.addReportStep("Enter password for registration", "Password entered for registration",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter password for registration", "Password field is not present in payment page",
					StepResult.FAIL);

			rc.terminateTestCase("Payment page registration");
		}

	}

	public void verifyWeakPwdMsg() throws Exception {

		if (wh.isElementPresent(weakPwdMsg, 7)) {
			String strMsg = driver.findElement(weakPwdMsg).getText();
			if (strMsg
					.contains("Weak passwords won't be saved. You can submit your order now and you'll have the chance to enter a stronger password later.")) {
				report.addReportStep("Verify the Weak password msg is displayed", " Weak password msg " + strMsg
						+ " is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify the  Weak password msg is displayed", "Weak password msg " + strMsg
						+ " is not displayed properly", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify the Weak password msg is displayed", "Weak password msg is not displayed",
					StepResult.FAIL);

		}

	}

	public void verifyWeakPwdStrengthMeter() throws Exception {

		if (wh.isElementPresent(weakPwdStrengthMeter, 7)) {
			String strMsg = driver.findElement(weakPwdStrengthMeter).getCssValue("background-color");
			System.out.println(strMsg);
			if (strMsg.contains("rgba(255, 8, 0, 1)")) {
				report.addReportStep("Verify the Weak password strength meter is displayed",
						" Weak password msg is displayed in red color", StepResult.PASS);
			} else {
				report.addReportStep("Verify the  Weak password strength meter is displayed",
						"Weak password strength meter is not displayed properly", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify the Weak password strength meter is displayed",
					"Weak password strength meter is not displayed", StepResult.FAIL);

		}

	}

	public void verifyGoodPwdStrengthMeter() throws Exception {

		if (wh.isElementPresent(pwdStrengthMeter, 7)) {
			String strMsg = driver.findElement(pwdStrengthMeter).getCssValue("background-color");
			System.out.println(strMsg);
			if (strMsg.contains("rgba(255, 195, 21, 1)")) {
				report.addReportStep("Verify the Good password strength meter is displayed",
						" Good password msg is displayed in yellow color", StepResult.PASS);
			} else {
				report.addReportStep("Verify the  Good password strength meter is displayed",
						"Good password strength meter is not displayed properly", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify the Good password strength meter is displayed",
					"Good password strength meter is not displayed", StepResult.FAIL);

		}

	}

	public void verifyStrongPwdStrengthMeter() throws Exception {

		if (wh.isElementPresent(pwdStrengthMeter, 7)) {
			String strMsg = driver.findElement(pwdStrengthMeter).getCssValue("background-color");
			System.out.println(strMsg);
			if (strMsg.contains("rgba(42, 142, 0, 1)")) {
				report.addReportStep("Verify the Strong password strength meter is displayed",
						" Strong password msg is displayed in green color", StepResult.PASS);
			} else {
				report.addReportStep("Verify the  Strong password strength meter is displayed",
						"Strong password strength meter is not displayed properly", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify the Good password strength meter is displayed",
					"Strong password strength meter is not displayed", StepResult.FAIL);

		}

	}

	public void verifyPwdMismatchErrMsg() throws Exception {

		if (wh.isElementPresent(pwdMismatchMsg, 7)) {
			String strMsg = driver.findElement(pwdMismatchMsg).getText();
			if (strMsg.contains("Your passwords don't match")) {
				report.addReportStep("Verify the password mismatch err msg is displayed",
						"  Password mismatch err msg " + strMsg + " is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify the   password mismatch err msg is displayed",
						" password mismatch err msg " + strMsg + " is not displayed properly", StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify the password mismatch err msg is displayed",
					"Password mismatch err msg is not displayed", StepResult.FAIL);

		}

	}

	public void verifyPwdStrengthCriteria() throws Exception {

		if (wh.isElementPresent(pwdStrengthRules, 7)) {
			wh.clickElement(pwdStrengthRules);
			if (wh.isElementPresent(pwdStrengthTips)) {
				String pwdStrMsg = driver.findElement(pwdStrengthTips).getText();
				if (pwdStrMsg.contains("Your password:")) {
					report.addReportStep("Verify Password tips is displayed", "Password tips " + pwdStrMsg
							+ " is displayed", StepResult.PASS);
				} else {
					report.addReportStep("Verify Password tips is displayed", "Password tips " + pwdStrMsg
							+ " is not displayed properly", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify Password tips is displayed", "Password tips is not displayed",
						StepResult.FAIL);
			}

		} else {

			report.addReportStep("Verify the password tips section is displayed",
					"Password tips section is not displayed", StepResult.FAIL);

		}

	}

	public void enterMismatchPwd() throws Exception {

		String strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);
		String mismatchPwd = dataTable.getData("NewRegPwd");

		if (wh.isElementPresent(regPwd)) {

			wh.sendKeys(regPwd, strPassword);

			wh.sendKeys(regConfirmPwd, mismatchPwd);
			driver.findElement(regConfirmPwd).sendKeys(Keys.TAB);

			report.addReportStep("Enter mismatch password in confirm pwd field", "Mismatch password entered",
					StepResult.PASS);
		} else {

			report.addReportStep("Enter mismatch password in confirm pwd field", "Mismatch password not entered",
					StepResult.FAIL);

		}

	}

	/**
	 * Component to verify message as "You already have a homedepot.com account"
	 * for existing E-mail id in payment page
	 * 
	 * @throws Exception
	 */
	public void verifyYouAlreadyRegistredAccount() throws Exception {
		if (wh.isElementPresent(RegisteredMsg, 5)) {
			report.addReportStep("You already have a homedepot.com account should be displayed",
					"You already have a homedepot.com account message is displayed", StepResult.PASS);
		} else {
			report.addReportStep("You already have a homedepot.com account should be displayed",
					"You already have a homedepot.com account message is not displayed", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify PO JOB CODE Mandatory error message in payment page
	 * RXP8655
	 * 
	 * @throws Exception
	 */

	public void verifyPOMandatoryErrMsg() throws Exception {

		if (wh.isElementPresent(poJobCode, 7)) {
			String strPO = wh.getAttribute(poJobCode, "value");
			if (strPO.contains(" ")) {
				report.addReportStep("verify PO Field", "PO Job field is empty", StepResult.DONE);
			} else {
				wh.clearElement(poJobCode);
				wh.clickElement(submitOrderBtn);
				Thread.sleep(1000);
			}
			String strPOErr = wh.getText(POMust);
			if (strPOErr
					.contains("A PO/Job code is required for this Home Depot Commercial Card. Please enter a valid PO/Job Code.")) {
				report.addReportStep("Verify PO Must error message", "PO JOB is must" + strPOErr
						+ " error is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify PO Must error message", "PO JOB is must error is not displayed",
						StepResult.FAIL);
			}
		} else {

			report.addReportStep("Verify PO field", "PO field is not displayed", StepResult.FAIL);

		}

	}

	/**
	 * Component to click on save my credit card checkbox
	 * 
	 * @since Oct 19,2015
	 * @author RXP8655
	 * @throws Exception
	 */
	public void clickSaveCardChkBox() throws Exception {
		if (wh.isElementPresent(chkSaveCard)) {
			report.addReportStep("Verify credit card section displayed in payment page",
					"Save credit card checkbox is displayed in payment page", StepResult.PASS);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].click()", driver.findElement(chkSaveCard));
			Thread.sleep(1000);
			report.addReportStep("Verify credit card section displayed in payment page",
					"Save credit card checkbox is selected in payment page", StepResult.PASS);
		} else {
			report.addReportStep("Verify credit card section displayed in payment page",
					"Save credit card checkbox is not displayed in payment page", StepResult.FAIL);
		}

	}

	/**
	 * Component to Verify From Canada or Mexico link in billing address
	 * 
	 * @since Mar 04,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyCanadaMexicoBillingLink() throws Exception {
		if (wh.isElementPresent(canadaMexicoLink)) {
			report.addReportStep("Verify From Canada or Mexico? link is displayed in Billing section",
					"From Canada or Mexico? link is displayed in Billing section", StepResult.PASS);
		} else {
			report.addReportStep("Verify From Canada or Mexico? link is displayed in Billing section",
					"From Canada or Mexico? link is not displayed in Billing section", StepResult.FAIL);
		}

	}

	/**
	 * Component to Verify From Canada or Mexico link is not displayed in
	 * billing address
	 * 
	 * @since Mar 04,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyNoCanadaMexicoBillingLink() throws Exception {
		if (wh.isElementNotPresent(canadaMexicoLink)) {
			report.addReportStep("Verify From Canada or Mexico? link is not displayed in Billing section",
					"From Canada or Mexico? link is not displayed in Billing section", StepResult.PASS);
		} else {
			report.addReportStep("Verify From Canada or Mexico? link is not displayed in Billing section",
					"From Canada or Mexico? link is displayed in Billing section", StepResult.FAIL);
		}

	}

	/**
	 * Component to enter Canada or Mexico in billing address
	 * 
	 * @since Mar 04,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void enterCanadaMexicoBillingAddr() throws Exception {
		String phoneNumber = dataTable.getData("International_PhoneNumber");

		if (wh.isElementPresent(newBillingAddrOverlay)) {
			wh.sendKeys(internationalBillingFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName));
			wh.sendKeys(internationalBillingLastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName));
			wh.sendKeys(internationalBillingAddress1, dataTable.getCommonData(CommonDataColumn.ShippingAddr));
			if (wh.isElementPresent(internationalBillingZipCode)) {
				wh.sendKeys(internationalBillingZipCode, dataTable.getData("International_ZipCode"));
			} else {
				wh.sendKeys(internationalBillingZipCodeMexico, dataTable.getData("International_ZipCode"));
			}
			if (!phoneNumber.isEmpty()) {

				wh.sendKeys(internationalBillingPhoneNumber, phoneNumber);

			} else {
				wh.sendKeys(internationalBillingPhoneNumber, dataTable.getCommonData(CommonDataColumn.ShippingPhNo));
			}
			report.addReportStep("Verify billing details entered for Canada/Mexico",
					"Billing details entered for Canada/Mexico", StepResult.PASS);
		} else {
			report.addReportStep("Verify billing details entered for Canada/Mexico",
					"Billing details not entered for Canada/Mexico", StepResult.FAIL);
		}

	}

	/**
	 * Component to Click From Canada or Mexico link in billing address
	 * 
	 * @since Mar 04,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void clickCanadaMexicoBillingLink() throws Exception {
		if (wh.isElementPresent(canadaMexicoLink)) {
			wh.clickElement(canadaMexicoLink);
			report.addReportStep("Verify From Canada or Mexico? link is clicked in Billing section",
					"From Canada or Mexico? link is clicked in Billing section", StepResult.PASS);
		} else {
			report.addReportStep("Verify From Canada or Mexico? link is clicked in Billing section",
					"From Canada or Mexico? link is not displayed in Billing section", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify error message for city and state in international
	 * billing address overlay
	 * 
	 * @since Mar 04,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyErrMsgForCityStateBillingAddrOverlay() throws Exception {
		if (wh.isElementPresent(cityErrMsg)) {
			String strCityMsg = wh.getText(cityErrMsg);
			if (strCityMsg.contains("City required. Please enter your City")) {
				report.addReportStep("Verify error message for City in international billing address overlay",
						"Error message <b> " + strCityMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for City in international billing address overlay",
						"Error message <b> " + strCityMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for City in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}
		if (wh.isElementPresent(stateErrMsg)) {
			String strStateMsg = wh.getText(stateErrMsg);
			if (strStateMsg.contains("State required. Please enter your State")) {
				report.addReportStep("Verify error message for State in international billing address overlay",
						"Error message <b> " + strStateMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for State in international billing address overlay",
						"Error message <b> " + strStateMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for State in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to Click Mexico radio button in billing address
	 * 
	 * @since Mar 04,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void clickMexicoRadioButton() throws Exception {
		if (wh.isElementPresent(mexicoRadioBtn)) {
			wh.clickElement(mexicoRadioBtn);
			report.addReportStep("Verify Mexico radio button is clicked in Billing section",
					"Mexico radio button is clicked in Billing section", StepResult.PASS);
		} else {
			report.addReportStep("Verify Mexico radio button is clicked in Billing section",
					"Mexico radio button is not clicked in Billing section", StepResult.FAIL);
		}

	}

	/**
	 * Component to Verify city and state fields for mexico and canada are
	 * editable when not auto populated
	 * 
	 * @since Mar 07,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyCityStateEditable() throws Exception {

		if (wh.isElementPresent(city)) {
			wh.sendKeys(city, dataTable.getData("International_City"));
			wh.sendKeys(state, dataTable.getData("International_State"));
			driver.findElement(state).sendKeys(Keys.TAB);
			report.addReportStep(
					"Verify City and state fields are editable manually when City and State not auto populated on entering ZipCode",
					"City and state fields are editable manually when City and State not auto populated on entering ZipCode",
					StepResult.PASS);
		} else if (wh.isElementPresent(cityPopulated)) {
			String value = wh.getText(cityPopulated);
			if (value != "" && value != null) {
				report.addReportStep("Verify City and state fields are auto populated on entering ZipCode",
						"City and state fields are auto populated on entering ZipCode", StepResult.PASS);
			} else {
				report.addReportStep("Verify City and state fields are auto populated on entering ZipCode",
						"City and state fields are auto populated with empty value on entering ZipCode",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify City and state fields are editable manually when City and State not auto populated on entering ZipCode",
					"City and state fields are not editable manually when City and State not auto populated on entering ZipCode",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to save Canada or Mexico in billing address
	 * 
	 * @since Mar 07,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void saveCanadaMexicoBillingAddr() throws Exception {

		if (wh.isElementPresent(newBillingAddrOverlay)) {

			wh.clickElement(internationalBillingSaveBtn);
			report.addReportStep("Verify billing details entered for Canada/Mexico and click save button",
					"Save button is clicked for Canada/Mexico", StepResult.PASS);
		} else {
			report.addReportStep("Verify billing details entered for Canada/Mexico and click save button",
					"Save button is not clicked for Canada/Mexico", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify phone number format for Canada or Mexico in billing
	 * address
	 * 
	 * @since Mar 07,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyPhoneNumberFormat() throws Exception {

		if (wh.isElementPresent(newBillingAddrOverlay)) {
			driver.findElement(internationalBillingPhoneNumber).sendKeys(Keys.TAB);
			Thread.sleep(commonData.littleWait);
			String phNo = wh.getAttribute(internationalBillingPhoneNumber, "value");
			System.out.println(phNo.length());
			if (phNo.contains("(") && phNo.contains(")") && phNo.contains("-")) {
				report.addReportStep("Verify phone number is in the format (###)###-####",
						"Phone number is in the format of <b> " + phNo + " </b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify phone number is in the format (###)###-####",
						"Phone number is not in the format of (###)###-####", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify phone number is in the format (###)###-####", "Phone number is not dispalyed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify digits of phone number for Canada or Mexico in
	 * billing address
	 * 
	 * @since Mar 07,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyPhoneNumberDigits() throws Exception {
		String internationalPhNo = dataTable.getData("International_PhoneNumber");
		String phNo = dataTable.getCommonData(CommonDataColumn.ShippingPhNo);
		int inputPhoneLen;

		if (!internationalPhNo.isEmpty()) {
			inputPhoneLen = internationalPhNo.length();
		} else {
			inputPhoneLen = phNo.length();
		}
		if (wh.isElementPresent(newBillingAddrOverlay)) {
			driver.findElement(internationalBillingPhoneNumber).sendKeys(Keys.TAB);
			Thread.sleep(commonData.littleWait);
			String strPhNo = wh.getAttribute(internationalBillingPhoneNumber, "value");
			if (strPhNo.contains("(")) {
				strPhNo = strPhNo.replaceAll("\\(", "");
			}
			if (strPhNo.contains(")")) {
				strPhNo = strPhNo.replaceAll("\\)", "");
			}
			if (strPhNo.contains("-")) {
				strPhNo = strPhNo.replaceAll("-", "");
			}
			if (strPhNo.contains(" ")) {
				strPhNo = strPhNo.replaceAll(" ", "");
			}
			System.out.println(strPhNo.length());
			if (strPhNo.length() == inputPhoneLen) {
				report.addReportStep("Verify user is able to enter " + inputPhoneLen + " digit phone number",
						"User is able to enter " + inputPhoneLen + " digit phone number", StepResult.PASS);
			} else {
				report.addReportStep("Verify user is able to enter " + inputPhoneLen + " digit phone number",
						"User is not able to enter " + inputPhoneLen + " digit phone number", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify user is able to enter " + inputPhoneLen + " digit phone number",
					"User is not able to enter phone number", StepResult.FAIL);
		}

	}

	/**
	 * 
	 * Description : Verify the sales tax field tool tip image
	 * 
	 * @since Jan 8,2015
	 * @author yxg8356
	 * @throws Exception
	 */

	public void verifySalesTaxTooltipImage() throws Exception {

		if (wh.isElementPresent(TaxToolTip, 2)) {

			report.addReportStep("Verify Sales tax tooltip icon is displayed",
					"sales tax field tooltip icon is displayed", StepResult.PASS);

			// Click tooltip icon
			wh.clickElement(TaxToolTip);
		}
		if (wh.isElementPresent(taxToolImage, 2)) {
			report.addReportStep("Verify tax tooltip icon is clicked", "tax tooltip overlay is displayed",
					StepResult.PASS);
		} else {
			report.addReportStep("Verify tax tooltip icon is not clicked", "tax tooltip overlay is not displayed",
					StepResult.FAIL);
		}
		// verify tool tip text
		if (wh.isElementPresent(taxToolImage, 2)) {
			String strTemp = wh.getText(taxToolImage);
			if (strTemp.contains("Why Am I Being Charged Sales Tax?")) {
				report.addReportStep("Verify tax tooltip", "Tax message " + strTemp + "is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify tax tooltip", "Tax message " + strTemp + "is not displayed",
						StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify tax tooltip icon is not clicked", "tax tooltip overlay is not displayed",
					StepResult.FAIL);
		}
		// Close sales tool tip overlay
		wh.clickElement(taxToolClose);

	}

	/**
	 * Component to verify promo code section right rail
	 * 
	 * @since Mar 08,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifyPromoCodeRightRail() throws Exception {

		if (wh.isElementPresent(promoRightRail)) {
			report.addReportStep("Verify promo section is displayed in right rail",
					"Promo section is displayed in right rail", StepResult.PASS);
			if (wh.isElementPresent(promoPlusBtn)) {
				wh.clickElement(promoPlusBtn);
				report.addReportStep("Verify promo section is expanded on click of plus symbol",
						"Promo section is expanded", StepResult.PASS);
			} else {
				report.addReportStep("Verify promo section is expanded on click of plus symbol",
						"Promo section is not expanded", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify promo section is displayed in right rail",
					"Promo section is not displayed in right rail", StepResult.FAIL);
		}

	}

	/**
	 * Component to enter promo code section right rail
	 * 
	 * @since Mar 08,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void enterPromoCodeRightRail() throws Exception {
		String promoCode = dataTable.getData("PromoCode");

		if (wh.isElementPresent(promoTextBox)) {
			wh.sendKeys(promoTextBox, promoCode);
			wh.clickElement(applyPromoCode);
			report.addReportStep("Verify promo code " + promoCode
					+ " is entered in right rail and apply button is clicked", "Promo code " + promoCode
					+ " is entered in right rail and apply button is clicked", StepResult.PASS);

		} else {
			report.addReportStep("Verify promo code " + promoCode
					+ " is entered in right rail and apply button is clicked", "Promo code " + promoCode
					+ " is not entered in right rail", StepResult.FAIL);
		}

	}

	public void verifyInvalidCCErros() throws Exception {
		int i = 0;
		if (wh.isElementPresent(cardNumber, 3)) {
			for (i = 0; i < commonData.invalidCCNo.length; i++) {
				wh.clearElement(cardNumber);
				wh.sendKeys(cardNumber, commonData.invalidCCNo[i]);

				report.addReportStep("Verify " + commonData.invalidCCNo[i] + " is entered", commonData.invalidCCNo[i]
						+ " is entered", StepResult.PASS);
				wh.clickElement(cardSecurityID);
				if (wh.isElementPresent(CardErr, 5)) {
					String err = wh.getText(CardErr);
					if (err.contains("Please enter a valid credit card number."))
						report.addReportStep("Verify error message is displayed for " + commonData.invalidCCNo[i]
								+ " entered", "Error message <b>" + err + "</b> is displayed", StepResult.PASS);
					else {
						report.addReportStep("Verify error message is displayed for " + commonData.invalidCCNo[i]
								+ " entered", "Error message <b>" + err + "</b> is not displayed properly",
								StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error message is displayed for " + commonData.invalidCCNo[i]
							+ " entered", "Error message is not displayed", StepResult.FAIL);
				}
			}
		} else {
			report.addReportStep("Verify credit card filed", "credit card text box is not displayed", StepResult.FAIL);
		}
		// Clear field
		wh.clearElement(cardNumber);

	}

	public void verifyExpiryMonthYearError() throws Exception {

		if (wh.isElementPresent(cardSecurityID, 3)) {
			report.addReportStep("Verify expiration field", "Expiry field is displayed", StepResult.PASS);

			wh.selectValue(expirationMonth, "Month");
			wh.selectValue(expirationYear, "Year");
			wh.clickElement(submitOrderBtn);
			Thread.sleep(1000);
			String strmonth = wh.getText(expMnthErr);
			String stryear = wh.getText(expYearErr);
			if (strmonth.contains("Expiration month required.") && stryear.contains("Expiration year required.")) {
				report.addReportStep("Verify expiration error", "Expiry error " + strmonth + stryear + " is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify expiration error", "Expiry error is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify expiration field", "Expiry field is not displayed", StepResult.FAIL);
		}
		// Back to default value
		wh.selectValue(expirationMonth, dataTable.getCommonData(CommonDataColumn.ExpirationMonth));
		wh.selectValue(expirationYear, dataTable.getCommonData(CommonDataColumn.ExpirationYear));
	}

	public void clearCVV() throws Exception {

		if (wh.isElementPresent(cardSecurityID, 3)) {
			report.addReportStep("Verify CVV field", "CVV field is displayed", StepResult.PASS);

			wh.clearElement(cardSecurityID);

		}
	}

	public void clearPO() throws Exception {

		if (wh.isElementPresent(poJobCode, 3)) {
			report.addReportStep("Verify PO Job field", "PO Job field is displayed", StepResult.PASS);

			wh.clearElement(poJobCode);
			report.addReportStep("clear PO Job field", "PO Job field is cleared", StepResult.PASS);
		}
	}

	public void verifyInvalidTaxExempt() throws Exception {
		int i = 0;
		if (wh.isElementPresent(applyTaxLink, 2)) {
			report.addReportStep("Verify the <b>Home Depot Tax Exempt ID'</b> link is already present in payment page",
					"Home Depot Tax Exempt link is displayed in payment page ", StepResult.PASS);

			wh.clickElement(applyTaxLink);
			Thread.sleep(100);
			if (wh.isElementPresent(taxExemptOverlay)) {
				for (i = 0; i < commonData.invalidTax.length; i++) {
					wh.clearElement(taxId);
					wh.sendKeys(taxId, commonData.invalidTax[i]);

					report.addReportStep("Verify " + commonData.invalidTax[i] + " is entered", commonData.invalidTax[i]
							+ " is entered", StepResult.PASS);
					wh.clickElement(applyTax);
					if (wh.isElementPresent(taxError, 5)) {
						String err = wh.getText(taxError);
						if (err.contains("Enter a valid 6-10 digit tax exempt ID."))
							report.addReportStep("Verify error message is displayed for " + commonData.invalidTax[i]
									+ " entered", "Error message <b>" + err + "</b> is displayed", StepResult.PASS);
						else {
							report.addReportStep("Verify error message is displayed for " + commonData.invalidTax[i]
									+ " entered", "Error message <b>" + err + "</b> is not displayed properly",
									StepResult.FAIL);
						}

					} else {
						report.addReportStep("Verify error message is displayed for " + commonData.invalidPhNo[i]
								+ " entered", "Error message is not displayed", StepResult.FAIL);
					}
				}
			} else {

				report.addReportStep("Tax exempt overlay", "Tax exempt overlay is not displayed", StepResult.FAIL);

			}
		} else {

			report.addReportStep("Tax exempt", "Tax exempt link is not displayed", StepResult.FAIL);

		}
		// Back to default value
		wh.clearElement(taxId);
		wh.clickElement(taxClose);
		Thread.sleep(1000);
	}

	/**
	 * Component to verify Gift Card text and overlay Title
	 * 
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyGiftCardText() throws Exception {

		if (wh.isElementPresent(giftCardText)) {
			String gcTxt = wh.getText(giftCardText);
			if ((!gcTxt.contains("Gift Card & Store Credit")) && gcTxt.equals("Gift Card")) {
				report.addReportStep("Verify Gift card Text in Payment and Billing Section", "Gift Card text <b>"
						+ gcTxt + " </b>is displayed properly in Payment and Billing Section", StepResult.PASS);
			} else {
				report.addReportStep("Verify Gift card Text in Payment and Billing Section", "Gift Card text <b>"
						+ gcTxt + " </b>is not displayed properly in Payment and Billing Section", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Gift card Text in Payment and Billing Section",
					"Gift Card text is not displayed in Payment and Billing Section", StepResult.FAIL);
		}

	}

	/**
	 * Component to click Apply Gift Card link
	 * 
	 * @author AXB8034
	 * @throws Exception
	 */
	public void clickApplyGiftCardLink() throws Exception {

		if (wh.isElementPresent(giftCardLink)) {
			wh.clickElement(giftCardLink);
			Thread.sleep(commonData.smallWait);
			if (wh.isElementPresent(giftCardOverlay)) {
				report.addReportStep("Click Apply Gift Card link and verify gift card overlay is displayed",
						"Apply Gift Card link is clicked and gift card overlay is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Click Apply Gift Card link and verify gift card overlay is displayed",
						"Apply Gift Card link is clicked and gift card overlay is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Click Apply Gift Card link and verify gift card overlay is displayed",
					"Apply Gift Card link is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to click Apply Gift Card link
	 * 
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyGiftCardOverlayTitle() throws Exception {

		if (wh.isElementPresent(giftCardOverlayTitle)) {
			String gcOverlayTxt = wh.getText(giftCardOverlayTitle);
			if ((!gcOverlayTxt.contains("Apply Gift Cards or Store Credit"))
					&& gcOverlayTxt.contains("Apply Gift Cards")) {
				report.addReportStep("Verify Gift card overlay title", "Gift Card overlay title <b>" + gcOverlayTxt
						+ " </b>is displayed properly", StepResult.PASS);
			} else {
				report.addReportStep("Verify Gift card overlay title", "Gift Card overlay title <b>" + gcOverlayTxt
						+ " </b>is not displayed properly", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify Gift card overlay title", "Gift Card overlay title is not displayed",
					StepResult.FAIL);
		}

	}

	/**
	 * Component to verify type ahead address selected in shipping pg is saved
	 * in payment page
	 * 
	 * @since Mar 10,2016
	 * @author DXP8263
	 * @throws Exception
	 */
	public void verifySavedAddressTypeAheads() throws Exception {

		if (wh.isElementPresent(savedAddrOptions, 7)) {
			String savedAddress = driver.findElement(savedAddrOptions).getText();
			System.out.println(savedAddress);
			if (savedAddress.contains(commonData.typeAheadZipCd) && savedAddress.contains(commonData.typeAheadCity)
					&& savedAddress.contains(commonData.typeAheadState)) {
				report.addReportStep("Verify that saved address is retained in payment page",
						"Saved address is retained in payment page", StepResult.PASS);

			} else {
				report.addReportStep("Verify that saved address is retained in payment page",
						"Saved address is not retained in payment page properly", StepResult.FAIL);
			}

		} else if (wh.isElementPresent(savedAddrOptions1, 7)) {
			String savedAddress = driver.findElement(savedAddrOptions1).getText();
			System.out.println(savedAddress);
			if (savedAddress.contains(commonData.typeAheadZipCd) && savedAddress.contains(commonData.typeAheadCity)
					&& savedAddress.contains(commonData.typeAheadState)) {
				report.addReportStep("Verify that saved address is retained in payment page",
						"Saved address is retained in payment page", StepResult.PASS);

			} else {
				report.addReportStep("Verify that saved address is retained in payment page",
						"Saved address is not retained in payment page properly", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that saved address is retained in payment page",
					"Saved address is not retained in payment page", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify error message for first name, last name, phone,
	 * addr1, zipcode Canada billing address overlay
	 * 
	 * @since Mar 11,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyErrMsgBillingAddrOverlay() throws Exception {
		if (wh.isElementPresent(fNameErrMsg)) {
			String strfNameMsg = wh.getText(fNameErrMsg);
			if (strfNameMsg.contains("First name is required. Please enter your first name")) {
				report.addReportStep("Verify error message for First Name in international billing address overlay",
						"Error message <b> " + strfNameMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for First Name in international billing address overlay",
						"Error message <b> " + strfNameMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for First Name in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}
		if (wh.isElementPresent(lNameErrMsg)) {
			String strlNameMsg = wh.getText(lNameErrMsg);
			if (strlNameMsg.contains("Last name is required. Please enter your last name")) {
				report.addReportStep("Verify error message for Last Name in international billing address overlay",
						"Error message <b> " + strlNameMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for Last Name in international billing address overlay",
						"Error message <b> " + strlNameMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for Last Name in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}
		if (wh.isElementPresent(phoneErrMsg)) {
			String strlNameMsg = wh.getText(phoneErrMsg);
			if (strlNameMsg.contains("Phone is required. Please enter your phone number")) {
				report.addReportStep("Verify error message for Phone in international billing address overlay",
						"Error message <b> " + strlNameMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for Phone in international billing address overlay",
						"Error message <b> " + strlNameMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for Phone in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}
		if (wh.isElementPresent(addr1ErrMsg)) {
			String strAddrMsg = wh.getText(addr1ErrMsg);
			if (strAddrMsg.contains("Address Line 1 required. Please enter your address")) {
				report.addReportStep("Verify error message for Address1 in international billing address overlay",
						"Error message <b> " + strAddrMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for Address1 in international billing address overlay",
						"Error message <b> " + strAddrMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for Address1 in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}
		if (wh.isElementPresent(zipErrMsg)) {
			String strZipMsg = wh.getText(zipErrMsg);
			if (strZipMsg.contains("This field is required.")) {
				report.addReportStep("Verify error message for ZipCode in international billing address overlay",
						"Error message <b> " + strZipMsg + " is displayed", StepResult.PASS);
			} else {

				report.addReportStep("Verify error message for ZipCode in international billing address overlay",
						"Error message <b> " + strZipMsg + " is not displayed properly", StepResult.FAIL);

			}

		} else {
			report.addReportStep("Verify error message for ZipCode in international billing address overlay",
					"Error message is not displayed", StepResult.FAIL);
		}

	}

	/**
	 * Component to enter special characters in Canada or Mexico in billing
	 * address
	 * 
	 * @since Mar 11,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void enterSpecialCharCanadaMexicoBillingAddr() throws Exception {

		if (wh.isElementPresent(internationalBillingFirstName)) {
			wh.sendKeys(internationalBillingFirstName, dataTable.getCommonData(CommonDataColumn.ShippingFirstName)
					+ "$%^");
			driver.findElement(internationalBillingFirstName).sendKeys(Keys.TAB);
			Thread.sleep(commonData.littleWait);
			if (wh.isElementPresent(fNameErrMsg)) {
				String fNameMsg = wh.getText(fNameErrMsg);
				if (fNameMsg.contains("We are sorry, but the system does not recognize special characters")) {
					report.addReportStep("Verify Special characters error message for First Name",
							"Special characters error message <b>" + fNameMsg + "</b> for First Name is displayed",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify Special characters error message for First Name",
							"Special characters error message <b>" + fNameMsg
									+ "</b> for First Name is not displayed properly", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify Special characters error message for First Name",
						"Special characters error message for First Name is not displayed", StepResult.FAIL);
			}
		}

		if (wh.isElementPresent(internationalBillingLastName)) {
			wh.sendKeys(internationalBillingLastName, dataTable.getCommonData(CommonDataColumn.ShippingLastName)
					+ "$%^");
			driver.findElement(internationalBillingLastName).sendKeys(Keys.TAB);
			Thread.sleep(commonData.littleWait);
			if (wh.isElementPresent(lNameErrMsg)) {
				String lNameMsg = wh.getText(lNameErrMsg);
				if (lNameMsg.contains("We are sorry, but the system does not recognize special characters")) {
					report.addReportStep("Verify Special characters error message for Last Name",
							"Special characters error message <b>" + lNameMsg + "</b> for Last Name is displayed",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify Special characters error message for Last Name",
							"Special characters error message <b>" + lNameMsg
									+ "</b> for Last Name is not displayed properly", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify Special characters error message for Last Name",
						"Special characters error message for Last Name is not displayed", StepResult.FAIL);
			}
		}

		if (wh.isElementPresent(internationalBillingAddress1)) {
			wh.sendKeys(internationalBillingAddress1, dataTable.getCommonData(CommonDataColumn.ShippingAddr) + "$%^");
			driver.findElement(internationalBillingAddress1).sendKeys(Keys.TAB);
			Thread.sleep(commonData.littleWait);
			if (wh.isElementPresent(addr1ErrMsg)) {
				String addrMsg = wh.getText(addr1ErrMsg);
				if (addrMsg.contains("Please enter a valid address")) {
					report.addReportStep("Verify Special characters error message for Address1",
							"Special characters error message <b>" + addrMsg + "</b> for Address1 is displayed",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify Special characters error message for Address1",
							"Special characters error message <b>" + addrMsg
									+ "</b> for Address1 is not displayed properly", StepResult.FAIL);
				}
			} else {
				report.addReportStep("Verify Special characters error message for Address1",
						"Special characters error message for Address1 is not displayed", StepResult.FAIL);
			}
		}
	}

	/**
	 * Component to verify the PIE encryption of the card number is not happened
	 * 
	 * @throws Exception
	 */
	public void verifyNoPIEValueOfCC() throws Exception {
		if (wh.isElementPresent(newCardNum, 4)) {
			report.addReportStep("Verify credit card section displayed in payment page",
					"saved credit card section is displayed in payment page", StepResult.PASS);
			String strSavedCard = driver.findElement(newCardNum).getAttribute("value");
			System.out.println(strSavedCard);
			if (!strSavedCard.contains("****")) {
				report.addReportStep("Verify saved credit card section displayed in payment page", "credit card '<br> "
						+ strSavedCard + "</br>'  is  not encrypted in payment page", StepResult.PASS);
			} else {
				report.addReportStep("Verify saved credit card section displayed in payment page",
						"credit card is encrypted in payment page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify credit card section displayed in payment page",
					"credit card section is not displayed in payment page", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify the PIE encryption of the New card number
	 *
	 * @throws Exception
	 */

	public void verifyPIEValueforNewCard() throws Exception {
		if (wh.isElementPresent(NewCardNum, 5)) {
			report.addReportStep("Verify credit card section displayed in payment page",
					"saved credit card section is displayed in payment page", StepResult.PASS);
			String strSavedCard = driver.findElement(NewCardNum).getAttribute("value");
			System.out.println(strSavedCard);
			if (strSavedCard.contains("****")) {
				report.addReportStep("Verify credit card section is encrypted in payment page", "credit card '<br> "
						+ strSavedCard + "</br>'  is encrypted in payment page", StepResult.PASS);
			} else {
				report.addReportStep("Verify credit card section is encrypted in payment page",
						"credit card is not encrypted in payment page", StepResult.FAIL);
			}
		}
	}

	/**
	 * Component to verify the PIE encryption of the New card number
	 *
	 * @throws Exception
	 */

	public void verifyPIEValueforSavedCard() throws Exception {
		if (wh.isElementPresent(SavedcardRadio, 2)) {
			if (wh.isElementPresent(SavedcardNum, 5)) {
				report.addReportStep("Verify credit card section displayed in payment page",
						"saved credit card section is displayed in payment page", StepResult.PASS);
				String strSavedCard = driver.findElement(SavedcardNum).getAttribute("value");
				System.out.println(strSavedCard);
				if (strSavedCard.contains("****")) {
					report.addReportStep("Verify saved credit card section displayed in payment page",
							"credit card '<br> " + strSavedCard + "</br>'  is encrypted in payment page",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify saved credit card section displayed in payment page",
							"credit card is not encrypted in payment page", StepResult.FAIL);
				}

			}
		} else {
			report.addReportStep("Verify credit card section displayed in payment page",
					"credit card section is not displayed in payment page", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify digits of phone number for Canada or Mexico in
	 * billing address
	 * 
	 * @since Mar 15,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyZipCodeDigits() throws Exception {
		String zipCode = dataTable.getData("International_ZipCode");
		int inputZipCodeLen = zipCode.length();
		if (wh.isElementPresent(newBillingAddrOverlay)) {
			driver.findElement(internationalBillingPhoneNumber).sendKeys(Keys.TAB);
			Thread.sleep(commonData.littleWait);
			String strZipCode = wh.getAttribute(internationalBillingPhoneNumber, "value");
			System.out.println(strZipCode.length());
			if (strZipCode.length() == inputZipCodeLen) {
				report.addReportStep("Verify user is able to enter " + inputZipCodeLen + " digit ZipCode",
						"User is able to enter " + inputZipCodeLen + " digit ZipCode", StepResult.PASS);
			} else {
				report.addReportStep("Verify user is able to enter " + inputZipCodeLen + " digit ZipCode",
						"User is not able to enter " + inputZipCodeLen + " digit ZipCode", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify user is able to enter " + inputZipCodeLen + " digit ZipCode",
					"User is not able to enter ZipCode", StepResult.FAIL);
		}

	}

	/**
	 * Component to verify error message for less than 10 digit in phone no
	 * field
	 * 
	 * @since Mar 15,2016
	 * @author AXB8034
	 * @throws Exception
	 */
	public void verifyPhoneErrLessThanTenDigit() throws Exception {
		String phone = dataTable.getData("International_PhoneNumber");
		int inputPhoneLen = phone.length();
		if (inputPhoneLen < 10) {
			if (wh.isElementPresent(internationalBillingPhoneNumber)) {
				wh.clearElement(internationalBillingPhoneNumber);
				driver.findElement(internationalBillingPhoneNumber).sendKeys(Keys.TAB);
				Thread.sleep(commonData.littleWait);
				if (wh.isElementPresent(phoneErrMsg)) {
					String err = wh.getText(phoneErrMsg);
					report.addReportStep(
							"Verify Error message is displayed on entering less than 10 digit phone no in billing adddress",
							"Error message <b>" + err
									+ "</b> is displayed on entering less than 10 digit phone no in billing adddress",
							StepResult.PASS);
				} else {
					report.addReportStep(
							"Verify Error message is displayed on entering less than 10 digit phone no in billing adddress",
							"Error message is not displayed on entering less than 10 digit phone no in billing adddress",
							StepResult.FAIL);
				}

			} else {
				report.addReportStep(
						"Verify Error message is displayed on entering less than 10 digit phone no in billing adddress",
						"Phone no field is not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Verify Error message is displayed on entering less than 10 digit phone no in billing adddress",
					"Input phone no is not less than 10 digit", StepResult.FAIL);
		}
	}

	/**
	 * Component to verify 'Password' & 'Confirm Password' field
	 * 
	 * @throws Exception
	 */
	public void verifyRegistrationSecPresentInPaymentPg() throws Exception {
		if ((wh.isElementPresent(regPwd, 2)) && (wh.isElementPresent(regConfirmPwd, 2))) {
			report.addReportStep("'Password' & 'Confirm Password' fields should be displayed",
					"'Password' & 'Confirm Password' fields are displayed", StepResult.PASS);

		} else {
			report.addReportStep("'Password' & 'Confirm Password' fields should be displayed",
					"'Password' & 'Confirm Password' fields are not displayed", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * Component to verify 'Password' & 'Confirm Password' field not present
	 * 
	 * @throws Exception
	 */
	public void verifyRegistrationSecNotPresentInPaymentPg() throws Exception {
		if (!(wh.isElementPresent(regPwd, 2)) && !(wh.isElementPresent(regConfirmPwd, 2))) {
			report.addReportStep("'Password' & 'Confirm Password' fields should be displayed",
					"'Password' & 'Confirm Password' fields are not displayed", StepResult.PASS);

		} else {
			report.addReportStep("'Password' & 'Confirm Password' fields should be displayed",
					"'Password' & 'Confirm Password' fields are displayed", StepResult.FAIL);
			commonData.blnGracefulExit = true;
		}

	}

	/**
	 * Method to enter Store Credit card details in Gift card overlay
	 * section.MLTC-2797
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage enterStoreCreditCardDetails() throws Exception {
		String CardNumber = null;
		String CardType = dataTable.getData("CardType");
		// wh.sendKeys(GiftCardNumber, CardNumber);
		// driver.findElement(GiftCardNumber).sendKeys(Keys.TAB);

		if (CardType.toLowerCase().contains("storecredit")) {
			wh.sendKeys(GiftCardNumber, dataTable.getCommonData(CommonDataColumn.STORECREDIT_card));
			driver.findElement(GiftCardNumber).sendKeys(Keys.TAB);
			wh.waitForPageLoaded();
			verifyStoreCreditNotAllowedAdvisoryMsg();
			wh.sendKeys(GiftCardPinNumber, dataTable.getCommonData(CommonDataColumn.STORECREDIT_card_PIN));
		}
		return this;

	}

	/**
	 * Method to verify store credit not allowed advisory message in Gift card
	 * overlay page MLTC-2797
	 * 
	 * @return
	 * @throws Exception
	 */

	public PaymentPage verifyStoreCreditNotAllowedAdvisoryMsg() throws Exception {

		String verifyStoreCreditAdvisoryMsgCompare = wh.getText(verifyStoreCreditAdvisoryMsg);
		String verifyStoreCreditAdvisoryMsgCompare1 = "We're sorry, we do not accept store credit online. Please use another method of payment and visit any Home Depot store to use your store credit.";

		if (verifyStoreCreditAdvisoryMsgCompare.contentEquals(verifyStoreCreditAdvisoryMsgCompare1)) {

			report.addReportStep("Enter Store Credit details, tab out and verify the advisory message",
					"Enter Store Credit details, tab out and verified the advisory message", StepResult.PASS);
		} else
			report.addReportStep("Enter Store Credit details, tab out and verify the advisory message",
					"Enter Store Credit details, tab out and verified that no advisory message", StepResult.FAIL);
		return this;

	}

	/**
	 * Method to select onlineFAQsText in payment page MLTC-2798
	 * 
	 * @return
	 * @throws Exception
	 */

	public PaymentPage selectOnlineFAQsInPayment() throws Exception {

		if (wh.isElementPresent(verifyonlineFAQsText, 5)) {
			wh.clickElement(verifyonlineFAQsText);
			report.addReportStep("Click on Online FAQs in Payment page", "Online FAQs is clicked in Payment page",
					StepResult.PASS);
		} else
			report.addReportStep("Click on Online FAQs in Payment page", "Online FAQs is clicked in Payment page",
					StepResult.FAIL);
		return this;

	}

	/**
	 * Method to verify FAQ questions MLTC-2798 Can I use Gift card to purchase
	 * my online order? Can I use Store Credit to purchase my online order?
	 * 
	 * @return
	 * @throws Exception
	 */

	public PaymentPage verifyCFAQquestions() throws Exception {

		final String paymentPage = driver.getWindowHandle(); // get the current
																// window
																// paymentPage
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle); // switch focus of WebDriver to
													// the next newly opened
													// window)
		}

		if (wh.isElementPresent(verifyGCUsageQuestionInCFAQ) && wh.isElementPresent(verifySCUsageQuestionInCFAQ)) {
			wh.clickElement(verifyGCUsageQuestionInCFAQ);
			String verifyGCUsageAnswerFromSite = wh.getText(verifyGCUsageAnswerInCFAQ);
			String verifyGCUsageAnswerExpected = "Yes, The Home Depot accepts Gift Cards as payment online.";
			if (verifyGCUsageAnswerFromSite.equals(verifyGCUsageAnswerExpected))
				report.addReportStep(
						"Verify answer of 'Can I use Gift card online to purchase my online order?'",
						"Yes. The Home Depot Gift Card may be used to make purchases online at homedepot.com. The Home Depot Gift Cards may also be used to make purchases at any Home Depot store. You cannot, however, use store credit to make a purchase online. Please visit any Home Depot store to purchase items using store credit.",
						StepResult.PASS);
			else
				report.addReportStep("Verify answer of 'Can I use Gift card online to purchase my online order?'",
						"Gift card usage in online is not displayed as expected", StepResult.FAIL);

			wh.clickElement(verifySCUsageQuestionInCFAQ);
			String verifySCUsageAnswerFromSite = wh.getText(verifySCUsageAnswerInCFAQ);
			String verifySCUsageAnswerExpected = "Yes, The Home Depot accepts Store Credits with PINs as payment online.";
			if (verifySCUsageAnswerFromSite.equals(verifySCUsageAnswerExpected))
				report.addReportStep(
						"Verify answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order'",
						"Answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order' are verified",
						StepResult.PASS);
			else
				report.addReportStep(
						"Verify answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order'",
						"Store credit usage in online is not displayed as expected", StepResult.FAIL);
		} else
			report.addReportStep(
					"Verify answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order'",
					"These questions are not available", StepResult.FAIL);
		driver.close(); // close newly opened window when done with it
		driver.switchTo().window(paymentPage); // switch back to the payment
												// page window
		return this;

	}

	/**
	 * Method to verify GiftCard FAQ questions MLTC-2798 Can I use a Gift Card
	 * to purchase my online order? Can I use Store Credits online?
	 * 
	 * @return
	 * @throws Exception
	 */

	public PaymentPage verifyGiftCardFAQquestions() throws Exception {

		final String paymentPage = driver.getWindowHandle(); // get the current
																// window
																// paymentPage
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle); // switch focus of WebDriver to
													// the next newly opened
													// window)
		}
		clickPaymentGCSCInGCFAQ();

		if (wh.isElementPresent(verifyGCUsageQuestionInGCFAQ) && wh.isElementPresent(verifySCUsageQuestionInGCFAQ)) {
			wh.clickElement(verifyGCUsageQuestionInGCFAQ);
			String verifyGCUsageAnswerFromSite = wh.getText(verifyGCUsageAnswerInGCFAQ);
			String verifyGCUsageAnswerExpected = "Yes. The Home Depot Gift Card may be used to make purchases online at homedepot.com. The Home Depot Gift Cards may also be used to make purchases at any Home Depot store. You cannot, however, use store credit to make a purchase online. Please visit any Home Depot store to purchase items using store credit.";
			if (verifyGCUsageAnswerFromSite.equals(verifyGCUsageAnswerExpected))
				report.addReportStep(
						"Verify answer of 'Can I use Gift card online to purchase my online order?'",
						"Yes. The Home Depot Gift Card may be used to make purchases online at homedepot.com. The Home Depot Gift Cards may also be used to make purchases at any Home Depot store. You cannot, however, use store credit to make a purchase online. Please visit any Home Depot store to purchase items using store credit.",
						StepResult.PASS);
			else
				report.addReportStep("Verify answer of 'Can I use Gift card online to purchase my online order?'",
						"Gift card usage in online is not displayed as expected", StepResult.FAIL);

			wh.clickElement(verifySCUsageQuestionInGCFAQ);
			String verifySCUsageAnswerFromSite = wh.getText(verifySCUsageAnswerInGCFAQ);
			String verifySCUsageAnswerExpected = "No, The Home Depot does not accept store credit online. Please visit any Home Depot store to purchase items using store credit.";
			if (verifySCUsageAnswerFromSite.equals(verifySCUsageAnswerExpected))
				report.addReportStep(
						"Verify answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order'",
						"Answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order' are verified",
						StepResult.PASS);
			else
				report.addReportStep(
						"Verify answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order'",
						"Store credit usage in online is not displayed as expected", StepResult.FAIL);
		} else
			report.addReportStep(
					"Verify answers of 'Can I use Store Credit online and Can I use Store Credit to purchase my online order'",
					"These questions are not available", StepResult.FAIL);
		driver.close(); // close newly opened window when done with it
		driver.switchTo().window(paymentPage); // switch back to the payment
												// page window
		return this;

	}

	/**
	 * Method to verify Customer support answer MLTC-2798 What forms of payment
	 * can be used online? * @return
	 * 
	 * @throws Exception
	 */

	public PaymentPage verifyCustomerSupportAnswer() throws Exception {

		final String paymentPage = driver.getWindowHandle(); // get the current
																// window
																// paymentPage
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle); // switch focus of WebDriver to
													// the next newly opened
													// window)
		}
		clickPaymentMethodsInCFAQ();
		String verifyFormOfPaymentQuestionFromSite = wh.getText(verifyFormOfPaymentQuestion);
		String verifyFormOfPaymentQuestionExpected = "What forms of payment can be used online?";

		if (wh.isElementPresent(verifyFormOfPaymentQuestion)
				&& verifyFormOfPaymentQuestionFromSite.equals(verifyFormOfPaymentQuestionExpected)) {
			String verifyFormOfPaymentAnswerFromSite = wh.getText(verifyFormOfPaymentExcludeSC);

			if (wh.isElementNotPresent(verifyFormOfPaymentExcludeSC))
				report.addReportStep("Verify answer of 'What forms of payment can be used online?'",
						"Verified that store credit payment is removed from form of payment section", StepResult.PASS);
			else
				report.addReportStep("Verify answer of 'What forms of payment can be used online?'",
						"Verified that store credit payment is not removed from form of payment section",
						StepResult.FAIL);

		} else
			report.addReportStep("Verify form of payment question in Customer support answer page",
					"Form of payment question is not available in Customer support answer page", StepResult.FAIL);
		driver.close(); // close newly opened window when done with it
		driver.switchTo().window(paymentPage); // switch back to the payment
												// page window
		return this;

	}

	/**
	 * Method to verify click Payment link and then access GC FAQ page MLTC-2798
	 * What forms of payment can be used online? * @return
	 * 
	 * @throws Exception
	 */

	public PaymentPage clickPaymentGCSCInGCFAQ() throws Exception {

		if (wh.isElementPresent(verifyPayment)) {
			wh.clickElement(verifyPayment);
			wh.clickElement(verifyGCSCInGCFAQ);
			wh.clickElement(verifyGCFAQLink);
			report.addReportStep("Verify Gift card FAQ is accessed from Payment section of CFAQ ",
					"Gift card FAQ is accessed from Payment section of CFAQ", StepResult.PASS);
		} else
			report.addReportStep("Verify Gift card FAQ is accessed from Payment section of CFAQ ",
					"Gift card FAQ is accessed from Payment section of CFAQ", StepResult.FAIL);
		return this;

	}

	/**
	 * Method to verify click Payment link and then click Payment methods
	 * MLTC-2798 What forms of payment can be used online? * @return
	 * 
	 * @throws Exception
	 */

	public PaymentPage clickPaymentMethodsInCFAQ() throws Exception {

		if (wh.isElementPresent(verifyPayment)) {
			wh.clickElement(verifyPayment);
			wh.clickElement(verifyPaymentMethods);
			report.addReportStep("Verify Payment methods is acceses from Payments section",
					"Verified Payment methods is acceses from Payments section", StepResult.PASS);
		} else
			report.addReportStep("Verify Payment methods is acceses from Payments section",
					"Verified Payment methods is not available in Payments section", StepResult.FAIL);
		return this;

	}

	/**
	 * Method to enter security ID for Existing User
	 * 
	 * @return
	 * 
	 * @throws Exception
	 */

	public PaymentPage enterSecurityIdforExistingUser() throws Exception {

		if (wh.isElementPresent(savedCardCvv)) {
			wh.sendKeys(savedCardCvv, dataTable.getCommonData(CommonDataColumn.CardSecurityID));
			report.addReportStep("Verify Security Id value entered", "Verified Security ID is entered successfully",
					StepResult.PASS);
		} else
			report.addReportStep("Verify Security Id value entered",
					"Verified Security ID is NOT entered successfully", StepResult.FAIL);
		return this;

	}

	/**
	 * 
	 * Description : verify invalid card name is accepted in payment page
	 * 
	 */
	public void verifyCardNameIsInvalid() {
		try {
			String strInputFromExcel = dataTable.getCommonData(CommonDataColumn.InvalidCard);
			String strInvalidCardValue = driver.findElement(By.id("cardHolderName")).getAttribute("value");
			if (strInputFromExcel.contains(strInvalidCardValue)) {
				report.addReportStep("Verify that invalid card name is not accepted in the card Name Field",
						"Invalid card name is accepted in the field", StepResult.WARNING);
			} else {
				report.addReportStep("Verify that invalid card name is not accepted in the card Name Field",
						"Invalid card name is not accepted in the field", StepResult.PASS);
			}
		} catch (Exception e) {
			report.addReportStep("Verify that invalid card name is not accepted in the card Name Field",
					"Unable to find the card name field", StepResult.FAIL);
		}
	}

	/**
	 * 
	 * Description : verify the card field value length in payment page
	 * 
	 * @since May 23, 2013
	 * @author SXD8901
	 */

	public int getCardFieldLength() {
		JavascriptExecutor js = (JavascriptExecutor) driver;

		Object strCardNo = js

		.executeScript("return document.getElementById('newCardNumber').value;");

		int strCard = strCardNo.toString().length();
		System.out.println(strCard);
		return strCard;
	}

	/**
	 * 
	 * Description : verify card name field accepts a max of 16 characters in
	 * payment page
	 *
	 */
	public void verifyCardNameLength() {
		try {
			if (getCardFieldLength() > 16) {
				report.addReportStep("verify that card name field accepts a max of 16 chars",
						"The field accepts more than 16 characters", StepResult.WARNING);
			} else {
				report.addReportStep("verify that card name field accepts a max of 16 chars",
						"The field does not accept more than 16 characters", StepResult.PASS);
			}
		} catch (Exception e) {
			report.addReportStep("verify that card name field accepts a max of 16 chars",
					"Unable to find the card name field", StepResult.FAIL);
		}
	}

	/**
	 * 
	 * Description : verify card security field accepts a max of 4 characters in
	 * payment page
	 *
	 */
	public void verifyCardSecurityFieldLength() {

		try {
			String strValueLength = driver.findElement(By.id("cvv")).getAttribute("maxlength").trim();
			if (Integer.parseInt(strValueLength) > 4) {
				report.addReportStep("verify that card security # accepts a max of 4 chars",
						"The field accepts more than 4 characters", StepResult.FAIL);
			} else {
				report.addReportStep("verify that card security # field accepts a max of 4 chars",
						"The field does not accept more than 4 characters", StepResult.PASS);
			}
		} catch (Exception e) {
			report.addReportStep("verify that card security # d accepts a max of 4 chars",
					"Unable to find the card security # field", StepResult.FAIL);
		}
	}

	public void enterInvalidCardDetails() throws Exception {
		String InvalidCard = dataTable.getCommonData(CommonDataColumn.InvalidCard);
		String InvalidCvv = dataTable.getCommonData(CommonDataColumn.InvalidCvv);
		wh.clickElement(cardNumber);
		wh.clearElement(cardNumber);
		wh.clickElement(cardSecurityID);
		wh.clearElement(cardSecurityID);
		if (wh.isElementPresent(cardNumber)) {
			wh.sendKeys(cardNumber, InvalidCard);
			wh.sendKeys(cardSecurityID, InvalidCvv);
			report.addReportStep("verify Invalid card Number and CVV is entered",
					"Invalid card Number and CVV is entered", StepResult.PASS);
		} else {
			report.addReportStep("verify Invalid card Number and CVV is entered",
					"Invalid card Number and CVV is not entered", StepResult.FAIL);
		}
	}

	/**
	 * Component to enter gift card details
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void enterGiftCard() throws Exception {

		String GcNumber = dataTable.getData("GiftCardNumber");
		String GcPin = dataTable.getData("GiftCardPin");
		String GcCaptcha = dataTable.getData("GiftCardCaptcha");
		if (wh.isElementPresent(giftCardOverlay)) {
			// 1.Gift Card Number
			wh.sendKeys(GiftCardNumber, GcNumber);
			report.addReportStep("Gift Card Number", "Gift Card " + GcNumber + " is entered", StepResult.DONE);
			// 2.PIN Number
			wh.sendKeys(GiftCardPinNumber, GcPin);
			report.addReportStep("Gift Card Pin", "Gift Card pin " + GcPin + " is entered", StepResult.DONE);
			// 4.Verification Codefields
			wh.sendKeys(GiftCardCaptcha, GcCaptcha);
			report.addReportStep("Gift Card captcha", "Gift Card captcha " + GcCaptcha + " is entered", StepResult.DONE);
			// 5.Change It link
			if (wh.isElementPresent(GcChangeVerfImg)) {

				report.addReportStep("Captcha Change link", "Captcha Change link", StepResult.PASS);
			} else {
				report.addReportStep("Captcha Change link", "Change Change link is not displayed", StepResult.FAIL);
			}

			// 6.APPLY CARD
			if (wh.isElementPresent(ApplyBtnGiftCard)) {
				wh.jsClick(ApplyBtnGiftCard);
				Thread.sleep(10000);
				report.addReportStep("Verify APPLY CARD button is displayed",
						".APPLY CARD button is displayed and clicked", StepResult.PASS);
			} else {
				report.addReportStep("Verify APPLY CARD button is displayed", ".APPLY CARD button is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify gift card overlay", "Gift Card section is not displayed", StepResult.FAIL);

		}
	}

	/**
	 * Component to verify You saved Section in payment page
	 * 
	 * @throws Exception
	 */
	public void verifyYouSavedZeroInPaymentPage() throws Exception {

		if ((wh.isElementPresent(By.xpath("//*[contains(@class,'cartYouSave')]"), 2))
				|| (wh.isElementPresent(By.id("chk-you-saved-div"), 2))
				|| (wh.isElementPresent(By.className("you-saved"), 2))) {
			report.addReportStep("Verify You saved section is displayed in Payment Page",
					"You saved section is displayed in Payment Page", StepResult.PASS);
			String strSavedAmt = driver.findElement(By.id("chk-you-saved-amt")).getText();
			System.out.println(strSavedAmt);
			if (strSavedAmt.contains("0.00")) {
				report.addReportStep("Verify that You saved section is displayed",
						"Zero value is displayed in payment page" + strSavedAmt + "</b>", StepResult.PASS);
			} else {
				report.addReportStep("Verify that You saved section is displayed",
						"Zero value is not displayed in payment page", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify You saved section is displayed in Payment Page",
					"You saved section is not displayed in Payment Page", StepResult.WARNING);
		}
	}

	public void enterNewBillingAddressOverlay() throws Exception {
		if (wh.isElementPresent(internationalBillingFirstName, 2)) {

			wh.sendKeys(internationalBillingFirstName, dataTable.getCommonData(CommonDataColumn.BillingFirstName1));

			wh.sendKeys(internationalBillingLastName, dataTable.getCommonData(CommonDataColumn.BillingLastName1));

			wh.sendKeys(internationalBillingPhoneNumber, dataTable.getCommonData(CommonDataColumn.BillingPh1));
			wh.sendKeys(internationalBillingAddress1, dataTable.getCommonData(CommonDataColumn.BillingAddr1));
			wh.sendKeys(addAddrBillingZipCode, dataTable.getCommonData(CommonDataColumn.BillingZipCode1));

			report.addReportStep("Enter new billing address in add address overlay",
					"New billing address entered in add address overlay", StepResult.PASS);

		} else {
			report.addReportStep("Enter new billing address in add address overlay",
					"New billing address not entered in add address overlay", StepResult.FAIL);
		}

		if (wh.isElementPresent(internationalBillingSaveBtn, 5)) {
			wh.jsClick(internationalBillingSaveBtn);
			report.addReportStep("verify saveBtn is clicked", "address is updated", StepResult.PASS);
		} else {
			report.addReportStep("verify saveBtn is clicked", "address is not updated", StepResult.FAIL);
		}
	}

	public PaymentPage enterPOJob() throws Exception {

		if (wh.isElementPresent(poJobCodeIn)) {
			String pojob = dataTable.getCommonData(CommonDataColumn.InvaildPO);
			commonData.strPO = pojob;
			wh.sendKeys(poJobCodeIn, pojob);

			report.addReportStep("Enter POJOB in payment page", "POJOB is entered in payment page", StepResult.PASS);
		}

		else {
			report.addReportStep("Enter POJOB in payment page", "POJOB is not present in payment page", StepResult.FAIL);
		}
		return this;
	}

	public PaymentPage verifyPOJOBErrorInPaymentPg() throws Exception {
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
		}
		Thread.sleep(15000);
		if (wh.isElementPresent(poError)) {
			String poErr = driver.findElement(poError).getText();
			if (poErr.contains("Invalid PO/Job code. Please enter only alpha numeric characters.")) {
				report.addReportStep("Verify the POJOB error displayed", "POJOB error " + poErr + " is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify the POJOB error displayed", "POJOB error " + poErr
						+ " is not displayed properly", StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify the POJOB error displayed", "POJOB error is not displayed", StepResult.FAIL);
		}
		return this;

	}

	public void checkPlccWarningMessage() throws Exception {

		if (wh.isElementPresent(plccWarningMessage)) {

			String plccWarningMsg = wh.getText(plccWarningMessage);

			report.addReportStep("Verify PLCC warning message id displayed in payment page", "Warning message "
					+ plccWarningMsg + " is displayed", StepResult.PASS);
		}

		else
			report.addReportStep("Verify PLCC warning message id displayed in payment page",
					"Waring message is not displayed", StepResult.FAIL);

	}

	public void clickModifyLinkInRightRailPayment() throws Exception {
		if (wh.isElementPresent(modifyLinkRR)) {

			wh.jsClick(modifyLinkRR);
			report.addReportStep(
					"Verify modify link is clicked in payment pg in Pick up Today at column in right rail",
					"Modify link is clicked in payment pg in Pick up Today at column in right rail", StepResult.PASS);
		}

		else {
			report.addReportStep(
					"Verify modify link is clicked in payment pg in Pick up Today at column in right rail",
					"Modify link is not click in payment pg in Pick up Today at column in right rail", StepResult.FAIL);
		}
	}

	/*
	 * Component to verify the gift card zero balance error in payment page
	 * 
	 * @Author: RXP8655
	 */
	public void verifyGCZeroBalanceError() throws Exception {

		if (wh.isElementPresent(GCZeroErr)) {

			String strerr = wh.getText(GCZeroErr);
			if (strerr.contains("This gift card has a zero balance.")) {
				report.addReportStep("GC zero balance error", "<b>" + strerr + "</b> is displayed", StepResult.PASS);

			} else {
				report.addReportStep("GC zero balance error", "Zero balance error is not displayed", StepResult.FAIL);
			}
		}

		else
			report.addReportStep("Verify Gfit card error message", "GC error is not displayed", StepResult.FAIL);

	}

	/*
	 * Component to verify the gift card wrong pin error in payment page
	 * 
	 * @Author: RXP8655
	 */
	public void verifyGCWrongPinError() throws Exception {

		if (wh.isElementPresent(GCZeroErr)) {

			String strerr = wh.getText(GCZeroErr);
			if (strerr.contains("Please enter valid card number/Pin number")) {
				report.addReportStep("GC wrong pin error", "<b>" + strerr + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("GC wrong pin error", "wrong pin error is not displayed", StepResult.FAIL);
			}
		} else
			report.addReportStep("Verify Gfit card error message", "GC error is not displayed", StepResult.FAIL);
	}

	/*
	 * Component to verify the gift card wrong captcha error in payment page
	 * 
	 * @Author: RXP8655
	 */
	public void verifyGCWrongCaptchaError() throws Exception {

		if (wh.isElementPresent(GCCaptchaErr)) {

			String strerr = wh.getText(GCCaptchaErr);
			if (strerr.contains("The characters you entered do not match the image. Please try again")) {
				report.addReportStep("GC wrong captcha error", "<b>" + strerr + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("GC wrong captcha error", "wrong captcha error is not displayed", StepResult.FAIL);
			}
		} else
			report.addReportStep("Verify Gfit card error message", "GC error is not displayed", StepResult.FAIL);
	}

	/*
	 * Component to verify the bread crumbs (cart, shipping and payment) in
	 * payment page
	 * 
	 * @Author: RXP8655
	 */
	public void verifyBreadCrums() throws Exception {

		if (wh.isElementPresent(lstBread)) {
			List<WebElement> lstbread = driver.findElements(By.xpath("//*[@id='progressBar']//li"));
			ArrayList<String> lstbread1 = new ArrayList();
			for (WebElement ele1 : lstbread) {
				String strtemp = ele1.getText();
				lstbread1.add(strtemp);
			}
			System.out.println(lstbread1.get(0));
			System.out.println(lstbread1.get(1));
			System.out.println(lstbread1.get(2));
			if (lstbread1.get(0).contains("CART") && lstbread1.get(1).contains("SHIPPING")
					|| lstbread1.get(1).contains("PICKUP OPTIONS") && lstbread1.get(2).contains("PAYMENT & BILLING")) {
				report.addReportStep("Breadcrumbs in payment page", "<b>" + lstbread1.get(0) + lstbread1.get(1)
						+ lstbread1.get(2) + "   </b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Breadcrumbs in payment page", "Breadcrumbs is not displayed", StepResult.FAIL);
			}
		} else
			report.addReportStep("Verify breadcrumbs in payment page", "Breadcrumbs is not displayed", StepResult.FAIL);
	}

	/*
	 * Component to verify the contact info in payment page
	 * 
	 * @Author: RXP8655
	 */
	public void verifyContactInfo() throws Exception {

		if (wh.isElementPresent(contactinfoheading)) {

			String strinfo = wh.getText(contactinfoheading);
			List<WebElement> lstinfo = driver.findElements(By.xpath("//*[@class='pod-contact-info']//h3"));
			ArrayList<String> lstInfo1 = new ArrayList();
			for (WebElement ele1 : lstinfo) {
				String strtemp = ele1.getText();
				lstInfo1.add(strtemp);
			}
			if (strinfo.contains("Questions? We Can Help.") && lstInfo1.get(0).contains("online FAQs")
					&& lstInfo1.get(1).contains("Online Customer Support")
					&& lstInfo1.get(2).contains("1-800-430-3376") && lstInfo1.get(3).contains("Custom Blinds")
					&& lstInfo1.get(4).contains("1-800-921-2119") && lstInfo1.get(5).contains("Major Appliances")
					&& lstInfo1.get(6).contains("1-877-946-9843")
					&& lstInfo1.get(7).contains("Call 7 days a week - 6 a.m. to 2 a.m. EST")) {
				report.addReportStep("Verify contact info", "<b>" + strinfo + "</b> contact info is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify contact info", "contact info is not displayed", StepResult.FAIL);
			}
		} else
			report.addReportStep("Verify contact info", "contact info section is not displayed", StepResult.FAIL);
	}

	/*
	 * Component to verify the color of buttons in payment page
	 * 
	 * @Author: RXP8655
	 */
	public void verifyButtonColor() throws Exception {

		if (wh.isElementPresent(submitOrderBtn)) {
			String stredit = wh.getCssValue(EditLinkInPayment, "color");
			System.out.println(stredit);
			String strsubmit = wh.getCssValue(submitOrderBtn, "color");
			System.out.println(strsubmit);
			String strback = driver.findElement(btnBack).getAttribute("value");

			String strerr = wh.getText(GCCaptchaErr);
			if (strerr.contains("The characters you entered do not match the image. Please try again")) {
				report.addReportStep("GC wrong captcha error", "<b>" + strerr + "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("GC wrong captcha error", "wrong captcha error is not displayed", StepResult.FAIL);
			}
		} else
			report.addReportStep("Verify Gfit card error message", "GC error is not displayed", StepResult.FAIL);
	}

	public void verifyErrMsgStylingCardNumber() throws Exception {
		wh.clickElement(cardNumber);
		wh.clearElement(cardNumber);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(CardErr, 5)) {
			String strCardErr = wh.getCssValue(CardErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for card number", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for card number",
						"Err msg is not displayed in red color", StepResult.PASS);
			}

		} else {
			report.addReportStep("Verify error msg styling for card number", "Err msg is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingExpiryYear() throws Exception {
		wh.selectValue(expirationYear, "Year");
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(expYearErr, 5)) {
			String strCardErr = wh.getCssValue(expYearErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for Expiry Year", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for Expiry Year",
						"Err msg is not displayed in red color", StepResult.PASS);
			}

		} else {
			report.addReportStep("Verify error msg styling for Expiry Year", "Err msg is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingSecurityCode() throws Exception {
		wh.clickElement(cardSecurityID);
		wh.clearElement(cardSecurityID);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(CvvErr, 5)) {
			String strCardErr = wh.getCssValue(CvvErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for CVV", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for CVV", "Err msg is not displayed in red color",
						StepResult.PASS);
			}

		} else {
			report.addReportStep("Verify error msg styling for CVV", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingPOJobCode() throws Exception {
		wh.clickElement(poJobCode);
		wh.clearElement(poJobCode);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(POMust, 5)) {
			String strCardErr = wh.getCssValue(POMust, "color");
			System.out.println(strCardErr);
			if (strCardErr.contains("rgba(0, 0, 0, 1)")) {
				report.addReportStep("Verify error msg styling for PO", "Err msg is displayed in grey color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for PO", "Err msg is not displayed in grey color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for PO", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingFirstName() throws Exception {
		wh.clickElement(firstName);
		wh.clearElement(firstName);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(firstNameErr, 5)) {
			String strCardErr = wh.getCssValue(firstNameErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for first name", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for first name",
						"Err msg is not displayed in red color", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for first name", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingLastName() throws Exception {
		wh.clickElement(lastName);
		wh.clearElement(lastName);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(lastNameErr, 5)) {
			String strCardErr = wh.getCssValue(lastNameErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for first name", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for first name",
						"Err msg is not displayed in red color", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for first name", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingAddress1() throws Exception {
		wh.clickElement(address1);
		wh.clearElement(address1);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(AddressErr, 5)) {
			String strCardErr = wh.getCssValue(AddressErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for address", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for address", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for address", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingZipCd() throws Exception {
		wh.clickElement(zipCode);
		wh.clearElement(zipCode);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(zipcodeErr, 5)) {
			String strCardErr = wh.getCssValue(zipcodeErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for zipcode", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for zipcode", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for zipcode", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingPhone() throws Exception {
		wh.clickElement(phoneNumber);
		wh.clearElement(phoneNumber);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(PhErr, 5)) {
			String strCardErr = wh.getCssValue(PhErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for phone", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for phone", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for phone", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingInvalidPhone() throws Exception {
		wh.clickElement(phoneNumber);
		wh.clearElement(phoneNumber);
		wh.sendKeys(phoneNumber, dataTable.getCommonData(CommonDataColumn.InvalidPhoneNumber));
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(PhErr, 5)) {
			String strCardErr = wh.getCssValue(PhErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for invalid phone", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for invalid phone",
						"Err msg is not displayed in red color", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for invalid phone", "Err msg is not displayed",
					StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingEmailId() throws Exception {
		wh.clickElement(emailAddress);
		wh.clearElement(emailAddress);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(emailErr, 5)) {
			String strCardErr = wh.getCssValue(emailErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for email id", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for email id", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for email id", "Err msg is not displayed", StepResult.FAIL);
		}

	}

	public void verifyErrMsgStylingGiftCard() throws Exception {

		if (wh.isElementPresent(giftCardOverlay)) {

			if (wh.isElementPresent(ApplyBtnGiftCard)) {
				wh.jsClick(ApplyBtnGiftCard);
				Thread.sleep(10000);
				report.addReportStep("Verify APPLY CARD button is displayed",
						".APPLY CARD button is displayed and clicked", StepResult.PASS);
				if (wh.isElementPresent(giftCardErrMsg, 5)) {
					String strCardErr = wh.getCssValue(giftCardErrMsg, "color");
					if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
						report.addReportStep("Verify error msg styling for gift card number",
								"Err msg is displayed in red color", StepResult.PASS);
					} else {
						report.addReportStep("Verify error msg styling for gift card number",
								"Err msg is not displayed in red color", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error msg styling for gift card number", "Err msg is not displayed",
							StepResult.FAIL);
				}
				if (wh.isElementPresent(gcPinErrMsg, 5)) {
					String strCardErr = wh.getCssValue(gcPinErrMsg, "color");
					if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
						report.addReportStep("Verify error msg styling for gift card pin number",
								"Err msg is displayed in red color", StepResult.PASS);
					} else {
						report.addReportStep("Verify error msg styling for gift card pin number",
								"Err msg is not displayed in red color", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error msg styling for gift card pin number",
							"Err msg is not displayed", StepResult.FAIL);
				}
				if (wh.isElementPresent(gcCaptchaErrMsg, 5)) {
					String strCardErr = wh.getCssValue(gcCaptchaErrMsg, "color");
					if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
						report.addReportStep("Verify error msg styling for gift card captcha",
								"Err msg is displayed in red color", StepResult.PASS);
					} else {
						report.addReportStep("Verify error msg styling for gift card captcha",
								"Err msg is not displayed in red color", StepResult.FAIL);
					}

				} else {
					report.addReportStep("Verify error msg styling for gift card captcha", "Err msg is not displayed",
							StepResult.FAIL);
				}

			} else {
				report.addReportStep("Verify APPLY CARD button is displayed", ".APPLY CARD button is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify gift card overlay", "Gift Card section is not displayed", StepResult.FAIL);

		}
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyInvalidTXExemptIdGU() throws Exception {

		wh.clickElement(TaxExemptlnk);
		wh.jsClick(TaxExemptlnk);

		report.addReportStep("Click Tax Exempt link in Payment section",
				"Tax Exempt link in Payment section is clicked", StepResult.PASS);

		String InvalidTxExpt = "34589034";

		if (wh.isElementPresent(InvalidTaxExempt, 3)) {

			wh.sendKeys(InvalidTaxExempt, InvalidTxExpt);

			driver.findElement(InvalidTaxExempt).sendKeys(Keys.TAB);
			Thread.sleep(3000);

			wh.clickElement(TXEApplybtn);
			Thread.sleep(commonData.smallWait);

			if (wh.isElementPresent(submitOrderBtn)) {
				wh.jsClick(submitOrderBtn);

			} else if (wh.isElementPresent(submitOrderBtn2)) {
				wh.jsClick(submitOrderBtn);
			}

			if (wh.isElementPresent(InvalidTaxExemptErrormsg1)) {
				String TXE = driver.findElement(InvalidTaxExemptErrormsg1).getText();
				if (TXE.contains("The tax-exempt number you have entered")) {
					report.addReportStep("Verify the error displayed", "Error message - " + TXE + " is displayed",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify the error displayed", "Error message - " + TXE
							+ " is not displayed properly", StepResult.FAIL);
				}
			}

			else {
				report.addReportStep("Verify TaxExempt field element is present",
						"TaxExempt field element is not present ", StepResult.FAIL);
			}

		}

		return this;

	}

	/**
	 * To verify error message displayed for Invalid Tax Exempt Id - Registered
	 * User
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyInvalidTXExemptIdRU() throws Exception {

		wh.clickElement(submitOrderBtn);
		wh.waitForLoaderImage();

		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
		}

		if (wh.isElementPresent(InvalidTaxExemptErrormsg1)) {
			String TXE = driver.findElement(InvalidTaxExemptErrormsg1).getText();
			if (TXE.contains("The tax-exempt number you have entered")) {
				report.addReportStep("Verify the error displayed", "Error message - " + TXE + " is displayed",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify the error displayed", "Error message - " + TXE
						+ " is not displayed properly", StepResult.FAIL);
			}
		}

		else {
			report.addReportStep("Verify TaxExempt field element is present",
					"TaxExempt field element is not present ", StepResult.FAIL);
		}

		return this;

	}

	/**
	 * To verify error message displayed for Invalid length Tax Exempt Id -
	 * Guest User
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyInvalidTaxExemptIdLengthGU() throws Exception {

		wh.clickElement(TaxExemptlnk);
		wh.jsClick(TaxExemptlnk);

		report.addReportStep("Click Tax Exempt link in Payment section",
				"Tax Exempt link in Payment section is clicked", StepResult.PASS);
		Thread.sleep(commonData.smallWait);

		String InvalidTxExpt = "000";

		if (wh.isElementPresent(InvalidTaxExempt, 3)) {

			wh.sendKeys(InvalidTaxExempt, InvalidTxExpt);

			driver.findElement(InvalidTaxExempt).sendKeys(Keys.TAB);
			Thread.sleep(3000l);

			if (wh.isElementPresent(InvalidTaxExemptLengthErrormsg)) {
				String TXE = driver.findElement(InvalidTaxExemptLengthErrormsg).getText();
				if (TXE.contains("Enter a valid 6-10 digit")) {
					report.addReportStep("Verify the error displayed", "Error message - " + TXE + " is displayed",
							StepResult.PASS);
				} else {
					report.addReportStep("Verify the error displayed", "Error message - " + TXE
							+ " is not displayed properly", StepResult.FAIL);
				}
			}

			else {
				report.addReportStep("Verify it tabs out to next field with no error message",
						"Error message not displayed and tabs to next field", StepResult.FAIL);
			}

		}

		return this;

	}

	
	/**
	 * To verify Tax Exempt Id is entered in Payment page - Guest User
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyEnterTaxExemptId() throws Exception {

		wh.clickElement(TaxExemptlnk);
		wh.jsClick(TaxExemptlnk);
		wh.waitForLoaderImage();

		String TxExpt = dataTable.getCommonData(CommonDataColumn.TaxExempt1);

		if (wh.isElementPresent(TaxExempt1, 5)) {

			wh.sendKeys(TaxExempt1, TxExpt);
			wh.clickElement(TXEApplybtn);

			report.addReportStep("Click Tax Exempt link in Payment section",
					"Tax Exempt link in Payment section is clicked", StepResult.PASS);
			Thread.sleep(commonData.smallWait);

		}

		return this;

	}

	/**
	 * To verify Tax Exempt Id is Edited in Payment page -Guest User
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyEditTaxExemptId() throws Exception {

		wh.clickElement(EditTaxExemptlnk);
		wh.jsClick(EditTaxExemptlnk);
		report.addReportStep("Click on Edit this Tax Exempt Id link in Payment page",
				"Edit this Tax Exempt Id link in Payment page is clicked", StepResult.PASS);
		wh.waitForLoaderImage();

		wh.clearElement(TaxExempt1);

		report.addReportStep("Clear Tax Exempt Number", "Tax Exempt number cleared", StepResult.PASS);

		String EditedTxExpt = "378998787";
		if (wh.isElementPresent(InvalidTaxExempt, 3)) {
			wh.sendKeys(InvalidTaxExempt, EditedTxExpt);

			wh.clickElement(TXEApplybtn);
			report.addReportStep("Verify Tax Exempt Id is edited", "Tax Exempt Id is edited", StepResult.PASS);
			wh.waitForLoaderImage();

		}

		return this;

	}

	/**
	 * To verify Cancel Tax Exempt Id in Payment page - Guest User
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyCancelTaxExemptId() throws Exception {

		wh.clickElement(TaxExemptlnk);
		wh.jsClick(TaxExemptlnk);
		wh.waitForLoaderImage();

		String TxExpt = dataTable.getCommonData(CommonDataColumn.TaxExempt1);

		if (wh.isElementPresent(TaxExempt1, 5)) {
			wh.sendKeys(TaxExempt1, TxExpt);
			wh.clickElement(TXECancelbtn);

			report.addReportStep("Click Cancel in Tax Exempt Overlay", "Cancel in Tax Exempt overlay is clicked",
					StepResult.PASS);
			Thread.sleep(commonData.smallWait);

		}

		return this;

	}

	/**
	 * verifyNoTaxExemptId
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyNoTaxExemptId() throws Exception {

		if (wh.isElementPresent(NoTaxExemptId)) {
			report.addReportStep("Verify tax exempt id is present", "Tax Exempt Id is displayed", StepResult.FAIL);
		}

		else {
			report.addReportStep("Verify tax exempt id is present", "Tax Exempt id is not present", StepResult.PASS);
		}
		return this;

	}

	/**
	 * 
	 * Description : verify the proxy card error message in payment page
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void verifySameCardholdernameAsCommercialMsg() throws Exception {
		if (wh.getText(buyerNameNewCard).contains(" ")) {
			report.addReportStep("verify buyer name field", "Buyer name field is empty", StepResult.DONE);
			wh.clickElement(submitOrderBtn);
		} else {
			wh.clearElement(buyerNameNewCard);
			wh.clickElement(submitOrderBtn);
		}
		if (wh.isElementPresent(BuyerNameErr)) {

			String strcardnamer = wh.getText(BuyerNameErr);
			String strErrorMessage = "Enter the name on the credit card.";

			if (strcardnamer.contains(strErrorMessage)) {
				report.addReportStep("Verify card name error message <b>" + strcardnamer + "</b>",
						"Error message is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify that HD card name verification error message <b>" + strErrorMessage
						+ "</b> is displayed", "Unable to valid the Error message displayed", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify that HD card name verification error message is displayed",
					"Error message is not displayed", StepResult.FAIL);
		}

	}

	public void verfiyBuyerNameStyling() throws Exception {

		if (wh.getText(buyerNameNewCard).contains(" ")) {
			report.addReportStep("verify buyer name field", "Buyer name field is empty", StepResult.DONE);
			wh.clickElement(submitOrderBtn);
		} else {
			wh.clearElement(buyerNameNewCard);
			wh.clickElement(submitOrderBtn);
		}
		if (wh.isElementPresent(BuyerNameErr)) {
			String strCardErr = wh.getCssValue(BuyerNameErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for buyer name", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for buyer name",
						"Err msg is not displayed in red color", StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for buyer name", "Error message is not displayed",
					StepResult.FAIL);
		}
	}

	/**
	 * Component to verify error when we place order using cards other than HD
	 * card
	 * 
	 * @throws Exception
	 */
	public void verifyErrorHDCards() throws Exception {
		if (wh.isElementPresent(CreditCardSection, 4)) {
			report.addReportStep("Verify credit card section displayed in payment page",
					"credit card section displayed in payment page", StepResult.PASS);

			// Verify other cards error
			String strcarderror = driver.findElement(AlertMessage).getText();
			if (strcarderror.contains("You must pay using a Home Depot Credit Card with this promotion.")) {
				report.addReportStep("Verify credit card error displayed in payment page", "Error: <b>" + strcarderror
						+ "</b> is displayed", StepResult.PASS);
			} else {
				report.addReportStep("Verify credit card error displayed in payment page",
						"Verify credit card error is not displayed in payment page", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Verify credit card section displayed in payment page",
					"credit card section is not displayed in payment page", StepResult.FAIL);
		}
	}

	/**
	 * Component: to verify the gift card applied
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage verifyGiftCardApplied() throws Exception {

		if (wh.isElementPresent(gcApplied)) {
			String strgc = wh.getText(gcApplied);
			if (strgc.contains("****") && strgc.contains("remove")) {
				report.addReportStep("Verify gift card applied", "<b>" + strgc + "</b> gift card is applied",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify gift card applied", "Gift card is not applied", StepResult.FAIL);
			}

		}

		else {
			report.addReportStep("Verify gift card applied", "Gift card is not applied", StepResult.FAIL);
		}
		return this;

	}

	/**
	 * Component to enter another gift card details
	 * 
	 * @author RXP8655
	 * @throws Exception
	 */
	public void enterAnotherGiftCard() throws Exception {

		String GcNumber = dataTable.getData("AnotherGiftCardNumber");
		String GcPin = dataTable.getData("AnotherGiftCardPin");
		String GcCaptcha = dataTable.getData("AnotherGiftCardCaptcha");
		if (wh.isElementPresent(gcAnothercard)) {
			wh.clickElement(gcAnothercard);
		}
		if (wh.isElementPresent(giftCardOverlay)) {
			// 1.Gift Card Number
			wh.sendKeys(GiftCardNumber, GcNumber);
			report.addReportStep("Gift Card Number", "Gift Card " + GcNumber + " is entered", StepResult.DONE);
			// 2.PIN Number
			wh.sendKeys(GiftCardPinNumber, GcPin);
			report.addReportStep("Gift Card Pin", "Gift Card pin " + GcPin + " is entered", StepResult.DONE);
			// 4.Verification Codefields
			wh.sendKeys(GiftCardCaptcha, GcCaptcha);
			report.addReportStep("Gift Card captcha", "Gift Card captcha " + GcCaptcha + " is entered", StepResult.DONE);
			// 5.Change It link
			if (wh.isElementPresent(GcChangeVerfImg)) {

				report.addReportStep("Captcha Change link", "Captcha Change link", StepResult.PASS);
			} else {
				report.addReportStep("Captcha Change link", "Change Change link is not displayed", StepResult.FAIL);
			}

			// 6.APPLY CARD
			if (wh.isElementPresent(ApplyBtnGiftCard)) {
				wh.jsClick(ApplyBtnGiftCard);
				Thread.sleep(10000);
				report.addReportStep("Verify APPLY CARD button is displayed",
						".APPLY CARD button is displayed and clicked", StepResult.PASS);
			} else {
				report.addReportStep("Verify APPLY CARD button is displayed", ".APPLY CARD button is not displayed",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify gift card overlay", "Gift Card section is not displayed", StepResult.FAIL);

		}
	}

	/**
	 * Component: To remove all gift cards applied Author: RXP8655
	 * 
	 * @return
	 * @throws Exception
	 */
	public PaymentPage removeAllGiftCards() throws Exception {

		if (wh.isElementPresent(gcApplied)) {
			List<WebElement> lstRemove = wh.getElements(gcremove);
			System.out.println(lstRemove.size());
			for (WebElement ele1 : lstRemove) {
				ele1.click();
			}
			if (wh.isElementNotPresent(gcApplied)) {
				report.addReportStep("Verify gift card removed", "Gift cards are removed", StepResult.PASS);

			} else {
				report.addReportStep("Verify gift card removed", "Gift cards are not removed", StepResult.FAIL);
			}

		}

		else {
			report.addReportStep("Verify gift card applied", "Gift card is not applied", StepResult.FAIL);
		}
		return this;

	}
	
	/**
	 * Component to verify all item pods in all(shipping,pickup,delivery,schedule
	 * delivery,payment) checkout pages
	 * @throws Exception 
	 *
	 * @throws IntterruptedException
	 */
	public void verifyAllItemsPodsInAllPages() throws Exception {
		if(wh.isElementPresent(By.xpath("//*[@class='checkout-summary clear']"),3))
		{
			report.addReportStep("Pods should be displayed",
					"Pods are displayed", StepResult.PASS);
			try {
				List<WebElement> lstPods = driver.findElements(By
						.xpath("//*[@class='bold m-bottom-xsmall']//span[1]"));
				System.out.println(lstPods.size());
				// System.out.println(lstPods);

				for (WebElement pods : lstPods) {
					System.out.println(pods.getText());
					if (pods.getText().contains("Ship To Home:")) {
						report.addReportStep(
								"Ship to Home pod should be displayed",
								"<b>Ship to Home</b> pod is displayed",
								StepResult.PASS);
					} else if (pods.getText().contains("Pick Up After")) {
						report.addReportStep(
								"Pick Up In Store pod should be displayed",
								"<b>Pick Up In Store</b> pod is displayed",
								StepResult.PASS);
					} 
					else if (pods.getText().contains("Pick Up TODAY")) {
						report.addReportStep(
								"Pick Up In Store pod should be displayed",
								"<b>Pick Up In Store</b> pod is displayed",
								StepResult.PASS);
					}
					else if (pods.getText().contains(
							"Express Delivery from Store:")) {
						report.addReportStep(
								"Express Delivery From Store pod should be displayed",
								"<b>Express Delivery From Store</b> pod is displayed",
								StepResult.PASS);
					} else if (pods.getText()
							.contains("Appliance Delivery:")) {
						report.addReportStep(
								"Appliance Delivery pod should be displayed",
								"<b>Appliance Delivery</b> pod is displayed",
								StepResult.PASS);
					} else {
						report.addReportStep("Pods should be displayed",
								"Pods are not displayed", StepResult.FAIL);
					}
				}
			} catch (Exception e) {
				report.addReportStep("Pods should be displayed",
						"Pods are not displayed", StepResult.FAIL);
			}
		} else {
			report.addReportStep("Pods should be displayed",
					"Pods are not displayed", StepResult.FAIL);
		}
	}

	public void verifyErrMsgStylingAddress1Overlay() throws Exception {
		wh.clickElement(address1AddOverlay);
		wh.clearElement(address1AddOverlay);
		if (wh.isElementPresent(submitOrderBtn)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		} else if (wh.isElementPresent(submitOrderBtn2)) {
			wh.jsClick(submitOrderBtn);
			report.addReportStep("Click submit order", "Submit order button clicked", StepResult.PASS);
		}
		if (wh.isElementPresent(AddressErr, 5)) {
			String strCardErr = wh.getCssValue(AddressErr, "color");
			if (strCardErr.contains("rgba(237, 28, 36, 1)")) {
				report.addReportStep("Verify error msg styling for address", "Err msg is displayed in red color",
						StepResult.PASS);
			} else {
				report.addReportStep("Verify error msg styling for address", "Err msg is not displayed in red color",
						StepResult.FAIL);
			}

		} else {
			report.addReportStep("Verify error msg styling for address", "Err msg is not displayed", StepResult.FAIL);
		}

	}
	/*Component to verify the text field and link in apply tax exempt overlay
	 * @throws Exception 
	 */
	public void verifyTaxExemptOverlay() throws Exception {

		if (wh.isElementPresent(editThisTax, 2)) {
			wh.clickElement(editThisTax);
			report.addReportStep(
					"Verify the <b>Home Depot Tax Exempt ID'</b> field is already present in payment page",
					"Home Depot Tax Exempt Id label is already displayed in payment page ", StepResult.PASS);
		} else {
		verifyTaxExemptNum();
		}
		
		if (wh.isElementPresent(taxExemptText, 2)) {
			report.addReportStep("Tax section overlay opened", "Tax section overlay is opened ", StepResult.PASS);
			String strtext = wh.getText(taxExemptText);
			String strapply = wh.getText(taxApplyOne);
			if(strtext.contains("If you don't have a Tax Exempt ID, you can")
					&& strapply.contains("apply for one.")
					&& wh.isElementPresent(taxId)) {
				report.addReportStep(
						"Verify Tax exempt overlay","<b>" + strtext + "</b> is displayed with tax input field", StepResult.PASS);	
			} else {
				report.addReportStep(
						"Verify Tax exempt overlay","<b>" + strtext + "</b> is not displayed with tax input field", StepResult.FAIL);
			}
		} else {
			report.addReportStep(
					"Apply a tax Exempt ID should be clicked and Apply Tax Exempt Id overly should be opened",
					"Apply a tax Exempt ID is not clicked", StepResult.FAIL);
		}
		//close tax overlay
		wh.clickElement(taxClose);
		
	}

}
