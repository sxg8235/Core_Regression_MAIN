package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class MyAccountPageStepDefn extends BaseStepDefn {
	
	public MyAccountPageStepDefn(DataClass data) {
		super(data);
	}
	
	@And("^I see My Account page$")
	public void i_see_My_Account_page() throws Throwable { 
		myAccountPage.verifyMyAccountPage();
	}
	
	@Then("^I click Add to cart from My list$")
	public void i_click_Add_to_cart_from_My_list() throws Throwable { 
		myAccountPage.clickAddToCartFromList();	  
	}
	
	@And("^I check appliance availability from My list$")
	public void i_check_appliance_availability_from_My_list() throws Throwable { 
		applianceOverlay.enterZipCodeCheckAvailabilityMyList(); 	  
	}
	
	@And("^I verify protection plan tab My list$")
	public void i_verify_protection_plan_tab_My_list() throws Throwable { 
		shoppingCartPage = applianceOverlay.partsAndServicesProtectionPlanMyList(true);	 	  
	}
	
	@And("^I verify free delivery message My list$")
	public void i_verify_free_delivery_message_My_list() throws Throwable { 
		applianceOverlay.verifyFreeDeliveryMessageMyList();	  
	}

	@And("^I verify \\$(\\d+) or more message My list$")
	public void i_verify_396_or_more_message_My_list() throws Throwable { 
		applianceOverlay.verifyFreeDeliveryMessageMyList();	  
	}

	@And("^I verify no free delivery message My list$")
	public void i_verify_no_free_delivery_message_My_list() throws Throwable {
		applianceOverlay.verifyNoFreeDeliveryMessageMyList();	
	}
	
	@When("^I save tax exempt id in My Account page$")
	public void i_save_tax_exempt_id_in_My_Account_page() throws Throwable { 
		myAccountPage.saveTaxExcemptId();
	}
	
	@Then("^I click on Remove Tax Exempt Id link$")
	public void i_click_on_remove_tax_exempt_id_link() throws Throwable { 
		myAccountPage.verifyRemoveTaxExempt();
	}
	@Then("^I edit account information in My Account page$")
	public void i_edit_account_information_in_My_Account_page() throws Throwable { 
		myAccountPage.editAccountInfo();	  
	}
	
	@Then("^I see Confirmation popup for the items added$")
	public void i_see_Confirmation_popup_for_the_items_added() throws Throwable { 
		myAccountPage.verifyItemAddedOverlay();
	}
	
	@And("^I change store details in my account page$")
	public void i_change_store_details_in_my_account_page() throws Throwable { 
		myAccountPage.changeStoreDetailsMyAccount();	  
	}
	
	@When("^I signin for persistent user in My Account page$")
	public void i_signin_for_persistent_user_in_My_Account_page() throws Throwable { 
		myAccountPage.persistentUserSignIn();	  
	}

	@And("^I save credit card in My Account page$")
	public void i_save_credit_card_in_My_Account_page() throws Throwable { 
		myAccountPage.saveCreditCard();	  
	}
	
	@And("^I save different credit card in My Account page$")
	public void i_save_different_credit_card_in_My_Account_page() throws Throwable { 
		myAccountPage.saveCreditCardInMyAcct();	  
	}

	@And("^I click checkout now in My list popup$")
	public void i_click_checkout_now_in_My_list_popup() throws Throwable { 
		myAccountPage.clickCheckoutNowOverlay();
	}
	
	@And("^I save another credit card in My Account page$")
	public void i_save_another_credit_card_in_My_Account_page() throws Throwable { 
		myAccountPage.saveAnotherCreditCard();	  
	}
	
	@And("^I click My account Link$")
	public void i_click_My_Account_link_in_My_Account_page() throws Throwable { 
		myAccountPage.clickMyAccount();	  
	}
	
	
	@And("^I select address book Link$")
	public void i_select_address_book_Link_in_My_Account_page() throws Exception
	{
		myAccountPage.selectAddressBook();
	}
	
	@And("^I click Add address in address book$")
	public void  i_click_add_address_in_address_book() throws Exception
	{
		myAccountPage.clickAddAddressInAddressBook();
	}
	
	@And("I click My account Link in ThankYou page$")
	public void i_click_my_account_link_in_Thankyou_page() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		myAccountPage.verifyMyaccountLink();
		}
	}
	
	@And("^I verify order number in Order Details Page$")
	public void i_verify_order_num_in_order_details_page() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		myAccountPage.verifyOrderNumInOrderDetails();
		}
	}
	
	@And("^I click Order Number$")
	public void i_click_order_number() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		myAccountPage.clickOrderNumber();
		}
	}
	
	@Then("^I verify Order Details Page for Bopis item$")
	public void i_verify_Order_Details_Page_for_Bopis_item() throws Exception
	{
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
		myAccountPage.verifyOrderDetaisPageforBopisItem();
		}
	}
	
	
//  This section is for HDPP*****************************************************
	@And("^I verify plan from My list$")
	public void I_verify_plan_from_My_list() throws Throwable { 
		myAccountPage.verifyPlan();	  
	}
	//I verify product from My list
	@And("^I verify product from My list$")
	public void I_verify_product_from_My_list() throws Throwable { 
		myAccountPage.verifyProduct();	  
	}
	@And("^I verify certona section in My List Page$")
	public void i_verify_certona_section_in_List_Certona() throws Throwable { 
		myAccountPage.verifyListCertona();	  
	}
	
	@When("^I click on AddToCart in My List Certona$")
	public void i_click_on_AddToCart_in_List_Certona() throws Throwable { 
		myAccountPage.clickListCertona();
	}
	

	@Then("^I do not see Add Plan Option in Confirmation pop up$")
	public void I_do_not_see_Add_Plan_Option_in_Confirmation_pop_up() throws Throwable { 
		myAccountPage.verifyPlannotadded();
	}
	
	@And("^I save credit card in My Account page as a reg user$")
	public void i_save_credit_card_in_My_Account_page_as_a_reg_user() throws Throwable { 
		myAccountPage.registerUser();
		homePage.clickYourAccountInHomePg();
		myAccountPage.saveCreditCardInMyAcct();
	}
	
	@And("^I verify credit card saved from payment page$")
	public void i_verify_credit_card_saved_from_payment_page() throws Throwable { 
		myAccountPage.verifyCCSavedFromPaymentPage();
		
	}
	
	@And("^I verify order status in order details page$")
	public void i_verify_order_status_in_order_details_page() throws Throwable { 
		myAccountPage.verifyOrderInformationInMyacc();
		
	}
	
	
	@And("^I verify order status in order details page for appliance item$")
	public void i_verify_order_status_in_order_details_page_for_appliance_item() throws Throwable { 
		myAccountPage.verifyApplianceOrderInfoInMyacc();
		
	}

	@Then("^I see address is not added in my account$")
	public void i_see_address_is_not_added_in_my_account() throws Throwable {
		myAccountPage.verifyInternatioanlAddressNotSaved();
	}
	
	
	@Then("^I click norton logo in my account$")
	public void i_click_norton_logo_in_my_account() throws Throwable {
		myAccountPage.clickVeriSignLInkInMyacc();
	}
	
	@And("^I verify verisgin page$")
	public void i_verify_verisgin_page() throws Throwable {
		myAccountPage.verifyVeriSignPage();
	}
	
	@And("^I click online Order Link in my account$")
	public void i_click_online_order_Link_in_my_account() throws Exception
	{
		myAccountPage.clickOnlineOrdersInMyAccPg();
	}
	
	@And("^I verify store order history in my account page$")
	public void i_verify_store_history_in_my_account_page()
	{
		myAccountPage.verifyInStoreOrderHistory();
	}
	
	
	//***********************************Instant Rebates******************************//
	
	
	@And("^I register and add new address$")
	public void i_register_and_add_new_address$() throws Throwable { 
		
		myAccountPage.registerUser();
		myAccountPage.clickMyAccount();
		myAccountPage.selectAddressBook();
		myAccountPage.clickAddAddressInAddressBook() ;
	
		
	}
	
	
	@And("^I create a user with multiple address$")
		public void I_create_a_user_with_multiple_address() throws Throwable {
			myAccountPage.registerUser();
			myAccountPage.clickMyAccount();
			myAccountPage.selectAddressBook();
			myAccountPage.addaddresstoaddressbook();

			}

	//***********************************Instant Rebates****************************
	
    @And("^I verify error message for Registered Invalid Length Tax Exempt Id$")
    public void i_verify_error_message_for_registered_invalid_lenght_tax_exempt_id() throws Throwable { 
                    
                    myAccountPage.verifyInvalidTaxExemptIdLengthRU();
    }
    
    @When("^I save Invalid four digit tax exempt id in My Account page$")
    public void i_save_invalid_four_digit_tax_exempt_id_in_My_Account_page() throws Throwable { 
                    myAccountPage.fourdigitInvalidsaveTaxExcemptId();
    }
    
	@And("^I verify guest user order ID and address are not listed in reg user profile$")
	public void i_register_and_add_new_address1$() throws Throwable { 
		
		myAccountPage.verifyGuestUserOrderNumberInMyAcctPg();
		myAccountPage.clickMyAccount();
		myAccountPage.selectAddressBook();
		myAccountPage.verifyGuestUserAddressInMyAcctPg();	
	}


}
