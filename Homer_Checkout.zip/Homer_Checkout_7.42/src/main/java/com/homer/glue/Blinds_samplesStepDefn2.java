package com.homer.glue;

import com.homer.dao.*;

public class Blinds_samplesStepDefn2 extends BaseStepDefn {

	public Blinds_samplesStepDefn2(DataClass ic) {
		super(ic);
		// TODO Auto-generated constructor stub
	}


  @And("^I click on request samples form PIP page$")
  public void I_click_on_few_request_samples_form_PIP_page() throws Exception{
	  pipPage.addblindssamples();
  }
  
  @Then("^I see sample Item should be added to the cart page$")
  public void I_see_sample_Item_should_be_added_to_the_cart_page() throws Exception{
	  pipPage.verifyblindsaddedtocart(); 
  }
  
  @When("^I navigate to home page and click on cart icon$")
  public void I_navigate_to_home_page_and_click_on_cart_icon() throws Exception{
	 pipPage.clickhomepageicon();
  }
   
  
  @Then("^I see blinds samples added in cart$")
  public void I_see_blinds_samples_added_in_cart() throws Exception{
	pipPage.verifyproductincart(); 
  }
  
  
  
  
  
  
  
  
  
  
  
}