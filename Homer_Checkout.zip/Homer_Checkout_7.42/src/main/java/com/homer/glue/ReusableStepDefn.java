package com.homer.glue;

import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataClass;
import com.homer.dao.Given;
import com.homer.enums.EnumClass.StepResult;

public class ReusableStepDefn extends BaseStepDefn {

	public ReusableStepDefn(DataClass ih) {
		super(ih);
	}
	
	@Given("^I am \"(.*?)\" user on cart page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_cart_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
		
		//Steps till ATC Overlay
		i_am_arg1_user_on_ATC_overlay_with_arg2_item(arg1, arg2);
		
		//Verify ATC Overlay
		atcOverlay.verifyAddedToCartInATCOverlay();
		
		//Clear User session cookie if persistant
		if(arg1.toLowerCase().contains("persist")){
			homePage.deleteUserSessionCookie();
		}
				
		//Click checkout now
		if(arg2.toLowerCase().contains("appliance")){
			if(arg2.toLowerCase().contains("no")){
				shoppingCartPage = applianceOverlay.selectPartsAndServices(false);
			}
			else{
				shoppingCartPage = applianceOverlay.selectPartsAndServices(true);
			}
		}
		else{
			atcOverlay.clickCheckoutNow();
		}
		
		//Verify Shopping Cart
		shoppingCartPage.verifyShoppingCartPage();
		shoppingCartPage.verifyShoppingCartNotEmpty();
		
		
	}

	@Given("^I am \"(.*?)\" user on ATC overlay with \"(.*?)\" item$")
	public void i_am_arg1_user_on_ATC_overlay_with_arg2_item(String arg1, String arg2) throws Throwable { 
			
		//New User Registration
		if(arg1.toLowerCase().contains("reg") || arg1.toLowerCase().contains("persist")){
			myAccountPage.registerUser();
		}
		//Already registered user Sign in
		else if(arg1.toLowerCase().contains("sign")){
			homePage.signInUser(dataTable.getCommonData(CommonDataColumn.RegUserEmail),dataTable.getCommonData(CommonDataColumn.RegUserPwd));
			homePage.navigateMCCCart();
			shoppingCartPage.removeItemsFromCart();
		}
		
		//To search an Item
		HomePageStepDefn homeDefn = new HomePageStepDefn(ih);
		homeDefn.i_search_for_arg1_fulfillment_item(arg2);
		
		//Verify PIP Page
		pipPage.verifyPIPPage();
		
		//To get the price from api
		if(rc.isProdEnvironment()){
			commonData.unitPriceDB = commonData.pipPrice;
			commonData.unitPrice.put(commonData.sku, commonData.unitPriceDB);
		}
		else{
			//database.getUnitPriceFromPricingService(commonData.sku, "");
		}
		
		//Clear User session cookie if persistant
		if(arg1.toLowerCase().contains("persist")){
			homePage.deleteUserSessionCookie();
		}
		
		//To add item to cart
		if(arg2.toLowerCase().contains("appliance")){
			pipPage.CapturePipPageInfo();
			pipPage.clickAddToCartButton();
			applianceOverlay.enterZipCodeCheckAvailability();
		}
		else{
			PIPStepDefn pipDefn = new PIPStepDefn(ih);
			pipDefn.i_add_arg1_item_to_cart(arg2);
		}
		
			  
	}

	@Given("^I am \"(.*?)\" user on shipping page$")
	public void i_am_arg1_user_on_shipping_page(String arg1) throws Throwable { 
	 
		//Flow till cart page
		i_am_arg1_user_on_cart_page_with_arg2_item(arg1,"sth");
		
		//Click Checkout Now from Cart Page
		shoppingCartPage.clickCheckoutNow();
		
		//Checkout as guest user
		if(arg1.toLowerCase().contains("guest")){
			checkoutSignInPage.guestSignInAndContinue();
		}
		else if(arg1.toLowerCase().contains("persist")){
			checkoutSignInPage.enterPwdForPersistentUser();
		}
				
		//Verify Shipping page
		shippingPage.verifyShippingPage();
	  
	}

	@Given("^I am \"(.*?)\" user on pickup option page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_pickup_option_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
		
		//Flow till cart page
		i_am_arg1_user_on_cart_page_with_arg2_item(arg1,arg2);
		
		//Click Checkout Now from Cart Page
		shoppingCartPage.clickCheckoutNow();
		
		//Checkout as guest user
		if(arg1.toLowerCase().contains("guest")){
			checkoutSignInPage.guestSignInAndContinue();
		}
				
		//Verify Shipping page
		pickupPage.verifyPickupOptionPage();
  
	}

	@Given("^I am \"(.*?)\" user on appliance delivery page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_appliance_delivery_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
		
		//Flow till cart page
		i_am_arg1_user_on_cart_page_with_arg2_item(arg1,arg2);
		
		//Click Checkout Now from Cart Page
		shoppingCartPage.clickCheckoutNow();
		
		//Checkout as guest user
		if(arg1.toLowerCase().contains("guest")){
			checkoutSignInPage.guestSignInAndContinue();
		}
				
		//Verify Shipping page
		applianceDelivery.verifyApplianceDeliveryPage();
	  
	}

	@Given("^I am \"(.*?)\" user on express delivery page$")
	public void i_am_arg1_user_on_express_delivery_page(String arg1) throws Throwable { 
		//Flow till cart page
		i_am_arg1_user_on_cart_page_with_arg2_item(arg1,"bodfs");
		
		//Click Checkout Now from Cart Page
		shoppingCartPage.clickCheckoutNow();
		
		//Checkout as guest user
		if(arg1.toLowerCase().contains("guest")){
			checkoutSignInPage.guestSignInAndContinue();
		}
				
		//Verify Delivery page
		scheduleDeliveryPage.verifyScheduleDeliveryPage();
	  
	}

	@Given("^I am \"(.*?)\" user on paypal review page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_paypal_review_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
		//Flow till cart page
		i_am_arg1_user_on_cart_page_with_arg2_item(arg1,"bodfs");
		
		//Checkout as paypal
		shoppingCartPage.verifyPayPalBtnCartPg();
		shoppingCartPage.clickPaypalbuttonInCartPage();
		
		//Verify Paypal page is displayed
		paypal.verifyPayPalPgDisplayed();
		
		//Login to paypal
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);
			rc.terminateTestCase();

		} else {
		paypal.payPalLogin();
		paypal.clickPayNowPaypal();
		
		//Verify paypal order review page
		paypalreview.verifyPaypalOrderReviewPage();
		}
	  
	}

	@Given("^I am \"(.*?)\" user on payment page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_payment_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
	 
		//Flow till checkout page.
		if(arg2.toLowerCase().contains("sth")){
			i_am_arg1_user_on_shipping_page(arg1);
			
			//enter shipping address and continue
			shippingPage.enterShippingDetails();
			
		}
		else if(arg2.toLowerCase().contains("boss") || arg2.toLowerCase().contains("bopis")){
			i_am_arg1_user_on_pickup_option_page_with_arg2_item(arg1, arg2);
		}
		else if(arg2.toLowerCase().contains("appliance")){
			i_am_arg1_user_on_appliance_delivery_page_with_arg2_item(arg1, arg2);
			
			applianceDelivery.enterDeliveryAddress();
			applianceDelivery.selectDeliveryDate();
		}
		else if(arg2.toLowerCase().contains("bodfs")){
			i_am_arg1_user_on_express_delivery_page(arg1);
			
			scheduleDeliveryPage.enterScheduledDeliveryAddressMCC();
		}
		
		shippingPage.clickContinueBtn();
		
		//verify payment page
		paymentPage.verifyPaymentPage();
	  
	}

	@Given("^I am \"(.*?)\" user on order confirmation page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_order_confirmation_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
	
		//Flow till payment page
		i_am_arg1_user_on_payment_page_with_arg2_item(arg1, arg2);
		
		//enter card details
		paymentPage.enterCardDetails();
		
		//Click Submit order button
		paymentPage.submitOrder();
		
		//Verify Order Confirmation page
		thankYouPage.verifyThankYouPage();
	  
	}

	@Given("^I am \"(.*?)\" user on secure sign page with \"(.*?)\" item$")
	public void i_am_arg1_user_on_secure_sign_page_with_arg2_item(String arg1, String arg2) throws Throwable { 
		
		//Steps till Cart page
		i_am_arg1_user_on_cart_page_with_arg2_item(arg1, arg2);
		
		//Click Checkout Now from Cart Page
		shoppingCartPage.clickCheckoutNow();
		
		//Verify Secure Sign in page
		checkoutSignInPage.verifySecurePage();
	}
	
}
