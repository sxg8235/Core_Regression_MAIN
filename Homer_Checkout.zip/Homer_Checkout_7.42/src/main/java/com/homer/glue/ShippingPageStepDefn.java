package com.homer.glue;

import org.openqa.selenium.By;

import com.homer.dao.And;
import com.homer.dao.CommonData;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class ShippingPageStepDefn extends BaseStepDefn {

	public ShippingPageStepDefn(DataClass data) {
		super(data);
	}

	@Then("^I see Shipping Details page$")
	public void i_see_Shipping_Details_page() throws Throwable {

		shippingPage.verifyShippingPage();
	}

	@When("^I enter Shipping Details$")
	public void i_enter_Shipping_Details() throws Throwable {
		shippingPage.verifyAllFields();
		shippingPage.enterShippingDetails();
		shippingPage.closePriceChangeOverlay();
	}

	@And("^I click continue button in checkout page$")
	public void i_click_continue_button_in_Shipping_page() throws Throwable {

		paymentPage = shippingPage.clickContinueBtn();
	}

	@And("^ShippingPrice displayed in order pods is equivalent to the Shipping method$")
	public void shippingPrice_displayed_in_order_pods_is_equivalent_to_the_Shipping_method() throws Throwable {
		shippingPage.verifyStandardShippingCharge();
	}

	@And("^I see price details in Shipping Page$")
	public void i_see_price_details_in_Shipping_Page() throws Throwable {
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();

	}

	@And("^I enter zip code for restricted area$")
	public void i_enter_zip_code_for_restricted_area() throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
			shippingPage.enterShippingDetailsWithRestrictedState();
		}
	}

	@Then("^I see error message for restricted zip$")
	public void i_see_error_message_for_restricted_zip() throws Throwable {
		if (rc.isProdEnvironment()) {

			report.addReportStep("Place order and verify 'Thank You' page", "We do not place order on Production",
					StepResult.WARNING);

		} else {
			shippingPage.verifyErrorMsgForRestrictedState();
		}

	}
	
	@Then("^I enter store address and verify error message$")
	public void i_enter_store_address_and_verify_error_message() throws Exception
	{
		shippingPage.enterStoreAddAndVerifyErr();
	}

	@And("^I see Persisted address in Shipping Page$")
	public void i_see_Persisted_address_in_Shipping_Page() throws Throwable {
		shippingPage.verifyPersistAddress();

	}

	@And("^I see the SKU is DETA eligible$")
	public void i_see_the_SKU_is_DETA_eligible() throws Throwable {
		shippingPage.verifyDETAShipmode();
	}

	@Then("^I verify Apply button is displayed$")
	public void i_verify_Apply_button_is_displayed() throws Throwable {
		shippingPage.verifyApplyBtnDisplay();

	}

	@And("^I see the SKU is Not DETA eligible$")
	public void i_see_the_SKU_is_Not_DETA_eligible() throws Throwable {
		shippingPage.verifyNotDETAShipmode();

	}

	@Then("^I verify Apply button is not displayed$")
	public void i_verify_Apply_button_is_not_displayed() throws Throwable {
		shippingPage.verifyApplyBtnNotDisplayed();

	}

	@And("^I see the SKU's are same Ship type$")
	public void i_see_the_SKU_s_are_same_Ship_type() throws Throwable {
		shippingPage.verifySameShipType();

	}

	@And("^I see the SKU's are different Ship type$")
	public void i_see_the_SKU_s_are_different_Ship_type() throws Throwable {
		shippingPage.verifyDiffShipType();

	}

	@And("^I enter Shipping Details in an Overlay$")
	public void i_enter_shipping_details_in_an_overlay() throws Exception {
		shippingPage.enterZipcodeInOverlay();
	}
	
	

	// I verify HDDP plan in right rail
	@And("^I verify HDDP plan in right rail$")
	public void I_verify_HDDP_plan_in_right_rail() throws Exception {
		shippingPage.verifyHDPPrightrail();
	}

	@And("^I enter \"(.*?)\" in First name$")
	public void i_enter_arg1_in_First_name(String arg1) throws Throwable {
		shippingPage.enterValidSymbolsFirstName(arg1);
	}

	@And("^I place order from checkout page$")
	public void i_place_order_from_checkout_page() throws Throwable {
		paymentPage = shippingPage.clickContinueBtn();
		paymentPage.verifyPaymentPage();
		paymentPage.enterCardDetails();
		thankYouPage = paymentPage.submitOrder();
		thankYouPage.verifyThankYouPage();
	}

	@And("^I enter invalid symbols in First name$")
	public void i_enter_invalid_symbols_in_First_name() throws Throwable {
		shippingPage.enterInvalidSymbolsFirstName();
	}

	@And("^I verify all details in shipping page$")
	public void i_verify_all_details_in_shipping_page() throws Throwable {
		shippingPage.verifyShippingPage();
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();
		shippingPage.verifyAllFields();
		pickupPage.verifyContinueAndBackBtn();
		shippingPage.enterShippingDetails();
		shippingPage.clickContinueBtn();
		paymentPage.verifyPaymentPage();
	}

	@And("^I place order from checkout page with different cards$")
	public void i_place_order_from_checkout_page_with_different_cards() throws Throwable {
		paymentPage = shippingPage.clickContinueBtn();
		paymentPage.verifyPaymentPage();
		paymentPage.enterDiffCardDetails();
		thankYouPage = paymentPage.submitOrder();
		thankYouPage.verifyThankYouPage();
	}

	@And("^I enter \"(.*?)\" in Last name$")
	public void i_enter_arg1_in_Last_name(String arg1) throws Throwable {
		shippingPage.enterValidSymbolsLastName(arg1);
	}

	@And("^I enter invalid symbols in Last name$")
	public void i_enter_invalid_symbols_in_Last_name() throws Throwable {
		shippingPage.enterInvalidSymbolsLastName();
	}

	@And("^I enter \"(.*?)\" in Address$")
	public void i_enter_arg1_in_Address(String arg1) throws Throwable {
		shippingPage.enterValidSymbolsAddress(arg1);
	}

	@And("^I enter address starting invalid symbols$")
	public void i_enter_address_starting_invalid_symbols() throws Throwable {
		shippingPage.enterAddressStartingInvalidSymbols();
	}

	@And("^I enter invalid symbols in Address$")
	public void i_enter_invalid_symbols_in_Address() throws Throwable {
		shippingPage.enterInvalidSymbolsAddress();
	}

	@And("^I enter invalid PoBox in Address$")
	public void i_enter_invalid_PoBox_in_Address() throws Throwable {
		shippingPage.enterInvalidPoBoxAddress();
	}

	@And("^I enter invalid symbols in Zipcode$")
	public void i_enter_invalid_symbols_in_Zipcode() throws Throwable {
		shippingPage.enterInvalidSymbolsZipcd();
	}

	@And("^I enter invalid symbols in Phone number$")
	public void i_enter_invalid_symbols_in_Phone_number() throws Throwable {
		shippingPage.enterInvalidSymbolsPhoneNum();
	}

	@And("^I enter zeroes in Zipcode$")
	public void i_enter_zeroes_in_Zipcode() throws Throwable {
		shippingPage.enterZeroesInZipcd();
	}

	@And("^I enter numbers with symbols in Zipcode$")
	public void i_enter_numbers_with_symbols_in_Zipcode() throws Throwable {
		shippingPage.enterNumbersWithSymbolsZipcd();
	}

	@And("^I enter invalid symbols in middle of First name$")
	public void i_enter_invalid_symbols_in_middle_of_First_name() throws Throwable {
		shippingPage.enterInvalidSymbolsInMiddleFirstName();
	}

	@And("^I enter invalid symbols in middle of Last name$")
	public void i_enter_invalid_symbols_in_middle_of_Last_name() throws Throwable {
		shippingPage.enterInvalidSymbolsMiddleLastName();
	}

	@And("^I enter invalid symbols in middle of Address$")
	public void i_enter_invalid_symbols_in_middle_of_Address() throws Throwable {
		shippingPage.enterAddressInvalidSymbolsInMiddle();
	}

	@And("^I enter \"(.*?)\" in Address(\\d+)$")
	public void i_enter_arg1_in_Address2(String arg1) throws Throwable {
		shippingPage.enterValidSymbolsAddress2Fiels(arg1);
	}

	@And("^I enter address(\\d+) starting invalid symbols$")
	public void i_enter_address2_starting_invalid_symbols() throws Throwable {
		shippingPage.enterAddress2fieldStartingInvalidSymbols();
	}

	@And("^I enter invalid symbols in Address(\\d+)$")
	public void i_enter_invalid_symbols_in_Address2() throws Throwable {
		shippingPage.enterInvalidSymbolsAddress2Field();
	}

	@And("^I enter invalid symbols in middle of Address(\\d+)$")
	public void i_enter_invalid_symbols_in_middle_of_Address2() throws Throwable {
		shippingPage.enterAddress2FieldInvalidSymbolsInMiddle();
	}

	@And("^I enter symbols in Zipcode$")
	public void i_enter_symbols_in_Zipcode() throws Throwable {
		shippingPage.enterSymbolsZipcd();
	}

	@And("^I enter zeroes in Phone number$")
	public void i_enter_zeroes_in_Phone_number() throws Throwable {
		shippingPage.enterZeroesPhoneNo();
	}

	@And("^I clear first and last name and click continue$")
	public void i_clear_first_and_last_name_and_click_continue() throws Throwable {
		shippingPage.clearFirstLastNameClickContinue();
	}

	@And("^I clear address and click continue$")
	public void i_clear_address_and_click_continue() throws Throwable {
		shippingPage.clearAddressClickContinue();
	}

	@And("^I clear zipcode and phone no and click continue$")
	public void i_clear_zipcode_and_phone_no_and_click_continue() throws Throwable {
		shippingPage.clearZipcodeAndPhoneClickContinue();
	}

	@And("^I verify was price in checkout pages$")
	public void i_verify_was_price_in_checkout_pages() throws Throwable {
		shippingPage.verifyWasPriceInCheckoutPage();
	}

	@And("^I verify Phone no field is displayed below Last Name in shipping page$")
	public void i_verify_Phone_no_field_is_displayed_below_Last_Name_in_shipping_page() throws Throwable {
		shippingPage.verifyPhoneFieldMovedUp();
	}

	@And("^I verify Phone field is displayed below Last Name in edit addr overlay$")
	public void i_verify_Phone_field_is_displayed_below_Last_Name_in_edit_addr_overlay() throws Throwable {
		shippingPage.verifyPhoneFieldMovedUpEditOverlay();
	}

	@And("^I verify Phone field is displayed below Last Name in add addr overlay$")
	public void i_verify_Phone_field_is_displayed_below_Last_Name_in_add_addr_overlay() throws Throwable {
		shippingPage.verifyPhoneFieldMovedUpAddOverlay();
	}

	@When("^I click edit this address link in shipping page$")
	public void i_click_edit_this_address_link_in_shipping_page() throws Throwable {
		shippingPage.clickEditThisAddress();
		// shippingPage.verifyEditAddressOverlay();
	}

	@Then("^I see edit address overlay in shipping page$")
	public void i_see_edit_address_overlay_in_shipping_page() throws Throwable {
		shippingPage.verifyEditAddressOverlay();
	}

	@When("^I click add new address link in shipping page$")
	public void i_click_add_new_address_link_in_shipping_page() throws Throwable {
		shippingPage.clickAddNewAddress();
		// shippingPage.verifyAddAddressOverlay();
	}

	@Then("^I see add address overlay in shipping page$")
	public void i_see_add_address_overlay_in_shipping_page() throws Throwable {
		shippingPage.verifyAddAddressOverlay();
	}

	@And("^I click on ship to multiple address link$")
	public void i_click_on_ship_to_multiple_address_link() throws Throwable {
		shippingPage.clickShipToMultipleAddrInShipPg();
	}

	@And("^I verify multiple addresses in shipping page$")
	public void i_verify_multiple_addresses_in_shipping_page() throws Throwable {
		shippingPage.verifyMultiAddressInShippingPage();
	}

	@And("^I get Shipping charge$")
	public void i_get_Shipping_charge() throws Throwable {
		shippingPage.getShippingCharge();
	}

	@And("^I verify restricted state err msg for multiple skus$")
	public void i_verify_restricted_state_err_msg_for_multiple_skus() throws Throwable {
		shippingPage.verifyErrorMsgForRestrictedStateForMultipleSkus();
	}

	@When("^I click edit this address link for multiple skus$")
	public void i_click_edit_this_address_link_for_multiple_skus() throws Throwable {
		shippingPage.clickEditThisAddressForMultipleSkus();
	}

	@And("^I click remove link for restricted zip$")
	public void i_click_remove_link_for_restricted_zip() throws Throwable {
		shippingPage.clickRemoveLinkForRestrictedState();
	}

	@And("^I click remove link for restricted zip for multiple skus$")
	public void i_click_remove_link_for_restricted_zip_for_multiple_skus() throws Throwable {
		shippingPage.clickRemoveLinkForRestrictedStateMultipleSkus();
	}

	@When("^I enter phone no fast and delete fourth digit$")
	public void i_enter_phone_no_fast_and_delete_fourth_digit() throws Throwable {
		shippingPage.enterPhoneNoDeleteFourthDigit();
	}

	@Then("^I see cursor position is retained$")
	public void i_see_cursor_position_is_retained() throws Throwable {
		shippingPage.verifyCursorPosition();
	}

	@And("^I verify address form remain expanded$")
	public void i_verify_address_form_remain_expanded() throws Throwable {
		shippingPage.verifyAddressFormExpanded();
	}

	@And("^I verify address form collapsed$")
	public void i_verify_address_form_collapsed() throws Throwable {
		shippingPage.verifyAddressFormCollapsed();
	}

	@And("^I verify edit addr overlay for multiple cities$")
	public void i_verify_edit_addr_overlay_for_multiple_cities() throws Throwable {
		shippingPage.verifyEditAddrOverlayForMultipleCities();
	}

	@And("^I verify edit addr overlay for single city$")
	public void i_verify_edit_addr_overlay_for_single_city() throws Throwable {
		shippingPage.verifyEditAddrOverlayForSingleCity();
	}

	@And("^I enter invalid PoBox in AddressOne field$")
	public void i_enter_invalid_PoBox_in_AddressOne_field() throws Throwable {
		shippingPage.enterInvalidPoBoxAddress();
	}

	@And("^I enter invalid PoBox in Addresstwo field$")
	public void i_enter_invalid_PoBox_in_Addresstwo_field() throws Throwable {
		shippingPage.enterInvalidPoBoxAddress2();
	}

	@Then("^I see Should be able to see the custom blind item detail in the Ship To Home POD$")
	public void i_see_should_be_able_to_see_the_custom_blind_detail_in_the_ship_to_home_pod() throws Exception {
		shippingPage.verifySTHPODItemDetails();
	}

	@Then("^I see revised copy shipping msg displayed$")
	public void i_see_revised_copy_shipping_msg_displayed() throws Throwable {
		shippingPage.verifyRevisedShippingMsg();
	}

	@And("^I see revised copy shipping msg not displayed$")
	public void i_see_revised_copy_shipping_msg_not_displayed() throws Throwable {
		shippingPage.verifyRevisedShippingMsgNotDisplayed();
	}

	@When("^I click back button in the shipping page$")
	public void i_click_back_button() throws Throwable {
		shippingPage.clickBackButton();
	}

	@When("^I verify order level promo in all pages$")
	public void i_verify_order_level_promo_in_all_pages() throws Throwable {
		shippingPage.verifyOrderLevelPromo();
	}

	@When("^I verify promo discount in checkout pages$")
	public void i_verify_promo_discount_in_checkout_pages() throws Throwable {
		shippingPage.verifyPromotionDiscountForCheckoutPg();
		shippingPage.verifyDiscountAmt();
	}

	@Then("^I see the shipping page with Standard Shipping method should only be the option$")
	public void i_see_shipping_page_with_standard_shipping_method_should_only_be_the_option() throws Exception {
		shippingPage.verifyShippingPage();
		shippingPage.verifyShippingMethodDefaultOption();

	}

	@When("^I enter non-taxable zipcode$")
	public void i_enter_nontaxable_zipcode() throws Exception {
		shippingPage.enterNonTaxableZipcode();
	}

	@When("^I clear all input fields$")
	public void i_clear_all_input_fields() throws Exception {
		shippingPage.clearAllFields();
	}

	@When("^I verify \"(.*?)\" error in shipping page$")
	public void i_verify_arg1_error_in_shipping_page(String arg1) throws Throwable {
		String errortype = arg1;
		if (errortype.equalsIgnoreCase("firstname")) {
			shippingPage.verifyFNError();
		} else if (errortype.equalsIgnoreCase("lastname")) {
			Thread.sleep(1000);
			shippingPage.verifyLNError();
		} else if (errortype.equalsIgnoreCase("zipcode")) {
			shippingPage.verifyZipcodeErr();
		}
	}

	@And("^I enter invalid phone number and verify error$")
	public void i_enter_invalid_phone_number_and_verify_error() throws Throwable {
		shippingPage.enterInvalidPhNumbers();
	}
	
	@And("^I enter zip code for APO address$")
	public void i_enter_zipcode_for_APO_address() throws Exception
	{
		shippingPage.enterShippingDetailsWithAPOAddress();
	}
	
	@And("^I enter zip code for FPO address$")
	public void i_enter_zipcode_for_FPO_address() throws Exception
	{
		shippingPage.enterShippingDetailsWithFPOAddress();
	}

	@And("^I enter zip code for DPO address$")
	public void i_enter_zipcode_for_DPO_address() throws Exception
	{
		shippingPage.enterShippingDetailsWithDPOAddress();
	}
	
	@Then("^I see Locality error message in Shipping Page$")
	public void i_see_locality_error_message_in_shipping_page() throws Exception
	{
		shippingPage.verifyLocalityNotEligibleErrMsg();
	}

	@And("^I verify type ahead not displayed$")
	public void i_verify_type_ahead_not_displayed() throws Throwable {
		shippingPage.verifyTypeAheadsNotDisplayed();
	}

	@And("^I verify type ahead displayed$")
	public void i_verify_type_ahead_displayed() throws Throwable {
		shippingPage.verifyTypeAheadsDisplayed();
	}

	@And("^I verify I'll type it myself text$")
	public void i_verify_I_ll_type_it_myself_text() throws Throwable {
		shippingPage.verifyTypeMyselfText();
	}

	@And("^I click on I'll type it myself text$")
	public void i_click_on_I_ll_type_it_myself_text() throws Throwable {
		shippingPage.clickTypeMyselfText();
	}

	@And("^I verify address type ahead dismissed$")
	public void i_verify_address_type_ahead_dismissed() throws Throwable {
		shippingPage.verifyTypeAheadsDismissed();
	}
	@And("^I click anywhere outside$")
	public void i_click_anywhere_outside() throws Throwable { 
		shippingPage.clickOutside();	  
	}

	@When("^I enter address with type ahead$")
	public void i_enter_address_with_type_ahead() throws Throwable {
		shippingPage.enterTypeAheadAddress();
	}
	
	@And("^I click address from type ahead suggestion$")
	public void i_click_address_from_type_ahead_suggestion() throws Throwable {
		shippingPage.clickAddressTypeAhead();
	}

	@And("^I verify zipcd city state prepopulated$")
	public void i_verify_zipcd_city_state_prepopulated() throws Throwable {
		shippingPage.verifyZipcdCityStatePopulated();
	}

	@And("^I verify I'll type it myself text not displayed$")
	public void i_verify_I_ll_type_it_myself_text_not_displayed() throws Throwable {
		shippingPage.verifyTypeMyselfTextNotDisplayed();
	}

	@And("^I enter address with type ahead in add address overlay$")
	public void i_enter_address_with_type_ahead_in_add_address_overlay() throws Throwable {
		shippingPage.enterAddressInAddAdressOverlay();

	}

	@And("^I verify zipcd city state prepopulated in add address overlay$")
	public void i_verify_zipcd_city_state_prepopulated_in_add_address_overlay() throws Throwable {
		shippingPage.verifyZipcdCityStatePopulatedAddAddrOverlay();
	}

	@And("^I click save button in add address overlay$")
	public void i_click_save_button_in_add_address_overlay() throws Throwable {
		shippingPage.clickSaveBtnAddAddrOverlay();
	}

	@And("^I verify and click type ahead in add address overlay$")
	public void i_verify_and_click_type_ahead_in_add_address_overlay() throws Throwable {
		shippingPage.verifyAndClickTypeAheadsAddAddressOverlay();
	}

	@And("^I enter special char in address$")
	public void i_enter_special_char_in_address() throws Throwable {
		shippingPage.enterSpecialCharAddressField();
	}
	@And("^I enter and verify type ahead in edit address overlay$")
	public void i_enter_and_click_type_ahead_in_edit_address_overlay() throws Throwable { 
		shippingPage.enterAndVerifyTypeAheadEditAdressOverlay();	  
	}
	
	@Then("^I Verify Estimated Sales Tax on shipping Page$")
	public void i_verify_estimated_sales_tax_on_shipping_page() throws Exception
	{
		shippingPage.verifyEstimatedSalesTaxInShippingPage();
	}
	
	@And("^I select different shipping and Revert back$")
	public void i_select_different_shipping_and_revert_back() throws Throwable 
	{
		shippingPage.selectDiffShippingAndRevertBack();
	}
	
	@And("^I verify From value near Shipping method$")
	public void i_verify_From_value_near_shipping_method() throws InterruptedException
	{
		shippingPage.verifyFromValueNearStdShipping();
	}
	
	
	//***************************Instant Rebates**********************************************
	
		@And("^I check price and store promo in shipping page$")
		public void i_check_price_and_store_promo_in_shipping_page() throws Throwable { 
		
			
			shippingPage.getpricedetails(database);

		
		}
		
		@When("^I enter Shipping Address$")
		public void i_enter_Shipping_Address() throws Throwable { 
		
			shippingPage.enterShippingAddress();	
			
		}
		
		@Then("^I verify IR message in shipping page$")
		public void i_verify_IR_message_in_shipping_page() throws Throwable { 
			shippingPage.verifyIRmessage();
		}				
			
		
		@And("^I edit the ship address$")
		public void i_edit_the_ship_address() throws Throwable {
			
			commonData.Zipcode="";
			commonData.Zipcode=dataTable.getData(DataColumn.ChangeZipCode);
			shippingPage.editAddress();
		}
		
		
		@And("^I change the zip code and remove items from cart$")
		public void i_change_the_zip_code_and_remove_items_from_cart() throws Throwable {

			commonData.Zipcode="";
			
			commonData.Zipcode=dataTable.getData(DataColumn.PersistedZipCode);
			shippingPage.editAddress();
			shippingPage.clickBackButton();
			shoppingCartPage.removeallitems();
		}
		
		@And("^I select multiple address for each item$")
		public void I_select_multiple_address_for_each_item() throws Throwable {
			shippingPage.selshipaddrfrmdropdown();
		}

		
		
		@Then("^I verify pricing in RR in shipping page$")
		public void i_verify_pricing_in_RR_in_shipping_page() throws Throwable { 
		 shippingPage.verifyRRprice();
		}
		
		

		//***************************Instant Rebates**********************************************


		@Then("^I verify tax calculation$")
		public void i_verify_tax_calculation() throws Throwable { 
		 shippingPage.taxCalculation();
		}

	@And("^I enter address details in add address overlay$")
	public void i_enter_address_details_in_add_address_overlay() throws Throwable {
		shippingPage.enterAddressdetailsInAddAddressOverlay();
	}

	@When("^I click on Edit cart button in shipping page$")
	public void i_click_on_Edit_cart_button_in_shipping_page() throws Throwable {
		shippingPage.clickEditCart();
	}
	
	@And("^I select address from drop down$")
	public void i_select_address_from_drop_down() throws Throwable {
		shippingPage.selectMultipleaddress();
	}

	@Then("^I select standard shipping$")
	public void i_select_standard_shipping() throws Throwable {
		shippingPage.selectStandardshipping();
	}

	@Then("^I select priority ground shipping$")
	public void i_select_priority_ground_shipping() throws Throwable {
		shippingPage.selectPriorityGroundShipping();
	}
	
	@Then("^I select expedited shipping$")
	public void i_select_expedited_shipping() throws Throwable {
		shippingPage.selectExpeditedShipping();
	}

	@And("^I select Express Shipping$")
	public void i_select_Express_Shipping() throws Throwable {
		shippingPage.selectExpressShipping();
	}

	@And("^I verify Express Shipping Charge$")
	public void i_verify_Express_Shipping_Charge() throws Throwable {
		shippingPage.verifyExpressShippingCharge();
	}

	@And("^I select alternate address from UPS address overlay$")
	public void i_select_alternate_address_from_UPS_address_overlay() throws Throwable {
		shippingPage.selectAlternateAddressFromUPSOverlay();
		shippingPage.verifySelectedAddressInGrr();
	}
	
	@Then("^I verify shipping address is not prepopulated$")
	public void i_verify_Shipping_Address_Is_Not_prepopulated() throws Throwable {
		shippingPage.verifyShippingAddressNotPrepopulatedforGuest();
	}
	
	@Then("^I verify pricing in left pod of shipping page$")
	public void i_verify_pricing_in_left_pod_of_shipping_page() throws Throwable { 
	 shippingPage.verifyleftpodprice();  
	}
	
	@Then("^I verify pricing in RR in Pickup options page for mixed cart$")
	public void i_verify_pricing_in_RR_in_Pickup_options_page_for_mixed_cart() throws Throwable { 
	 shippingPage.verifyRRPriceMixed();  
	}

}
