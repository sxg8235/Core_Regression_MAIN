package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;

public class ApplianceDeliveryPageStepDefn extends BaseStepDefn {

	public ApplianceDeliveryPageStepDefn(DataClass data) {
		super(data);
	}

	@And("^I see the appliance delivery charge applied in right rail$")
	public void i_see_the_appliance_delivery_charge_applied_in_right_rail() throws Throwable {
		applianceDelivery.verifyDeliveryChargeInRightRail();
	}

	@Then("^I see the appliance deliver page$")
	public void i_see_the_appliance_deliver_page() throws Throwable {
		applianceDelivery.verifyApplianceDeliveryPage();
	}

	@When("^I enter delivery address and delivery date and click continue$")
	public void i_enter_delivery_address_and_delivery_date_and_click_continue() throws Throwable {
		applianceDelivery.verifyAllFieldsInAppDelvPage();
		applianceDelivery.enterDeliveryAddress();
		applianceDelivery.selectDeliveryDate();
		shippingPage.clickContinueBtn();
	}

	/*
	 * This step is for BODFS scenario 1 added by kxn8362
	 */
	@When("^I enter delivery information$")
	public void i_enter_delivery_information() throws Throwable {
		applianceDelivery.verifyAllFieldsInAppDelvPage();
		applianceDelivery.enterDeliveryAddress();
	}

	@And("^I see price details in appliance delivery page$")
	public void i_see_price_details_in_appliance_delivery_page() throws Throwable {
		paymentPage.verifyUnitPriceRightRail();
		paymentPage.verifysubTotalRightRail();

	}

	@And("^I verify HDDP plan in right rail in appliance delivery page$")
	public void i_verify_HDDP_plan_in_right_rail_in_appliance_delivery_page() throws Throwable {
		shippingPage.verifyHDPPrightrail();

	}

	@And("^I verify Current Month Year in Delivery page$")
	public void i_verify_Current_Month_Year_in_Delivery_page() throws Exception {
		applianceDelivery.verifyCurrentMonthYearInDelvryPage();
	}

	@And("^I verify Previous Month Year in Delivery page$")
	public void i_verify_Previous_Month_Year_in_Delivery_page() throws Exception {
		applianceDelivery.verifyPreviousMnthInDelvryPage();
	}

	@And("^I verify Next Month Year in Delivery page$")
	public void i_verify_Next_Month_Year_in_Delivery_page() throws Exception {
		applianceDelivery.verifyNxtMnthInDelvryPage();
	}

	@And("^I select Delivery date$")
	public void i_select_select_delivery_date() throws Exception {
		applianceDelivery.selectDeliveryDate();
	}

	@And("^I verify Order summary section in Appliance delivery page$")
	public void i_verify_Order_summary_section_in_Appliance_delivery_page() throws Exception {
		applianceDelivery.orderSummarySectionAppliance();
	}

	/*
	 * @When("^I checkout to appliance delivery page as guest$") public void
	 * i_checkout_to_appliance_delivery_page_as_guest() throws Throwable {
	 * checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
	 * checkoutSignInPage.verifySecurePage();
	 * checkoutSignInPage.guestSignInAndContinue();
	 * applianceDelivery.verifyApplianceDeliveryPage();
	 * applianceDelivery.enterDeliveryAddress();
	 * applianceDelivery.selectDeliveryDate(); }
	 */

	@And("^I see the static zipcode is displayed$")
	public void i_see_the_static_zipcode_is_displayed() throws Exception {
		applianceDelivery.verifyStaticZipInDeliveryPage();
	}

	@And("^I verify Add and edit Address Links in Delivery page$")
	public void i_verify_add_and_edit_address_link() throws Exception {
		applianceDelivery.verifyAddEditAddressLinks();
	}

	@And("^I click Edit Address Link in Delivery page$")
	public void i_click_edit_address_link_in_delivery_page() throws InterruptedException {
		applianceDelivery.clickEditAddrLinkInApp();
	}

	@And("^I enter delivery address in Edit Address Overlay$")
	public void i_enter_delivery_address_in_Edit_Address_Overlay() throws Exception {
		applianceDelivery.enterApplianceAddressInOverlay();
	}

	@And("^I click the Cancel Button in edit address Overlay$")
	public void i_click_the_cancel_button_in_edit_address_overlay() throws Exception {
		applianceDelivery.clickCancelButton();
	}

	@And("^I verify Static address in Delivery page$")
	public void i_verify_static_address_in_Delivery_page() throws Exception {
		applianceDelivery.verifyApplianceStaticAddress();
	}

	@And("I click Add new address Link in delivery page")
	public void i_click_address_new_link_in_delivery_page() throws Exception {
		applianceDelivery.clickAddNewAddrInAppliancePage();

	}

	@And("I add new address in Appliance delivery page")
	public void i_add_new_address_in_Appliance_delivery_page() throws Exception {
		applianceDelivery.addAddrForApplianceDelivery();
	}

	@And("^I click Save button in add new address overlay$")
	public void clickSaveButton() throws Exception, Exception {
		applianceDelivery.clickSaveButton();
	}

	@Then("^I see add address overlay in delivery page$")
	public void i_see_add_address_overlay_in_delivery_page() throws Throwable {
		applianceDelivery.verifyAddAddressOverlay();
	}

	@And("^I verify Phone field is displayed below Last Name in appliance delivery page$")
	public void i_verify_Phone_field_is_displayed_below_Last_Name_in_appliance_delivery_page() throws Throwable {
		applianceDelivery.verifyPhoneFieldMovedUp();
	}

	@Then("^I see Edit address overlay in delivery page$")
	public void i_see_Edit_address_overlay_in_delivery_page() throws Throwable {
		applianceDelivery.verifyEditAddressOverlay();
	}

	@And("^I enter invalid PoBox in AddressOne field App Del page$")
	public void i_enter_invalid_PoBox_in_AddressOne_field_App_Del_page() throws Throwable {
		applianceDelivery.enterInvalidPoBoxAddressApplDelPage();
	}

	@And("^I enter invalid PoBox in Addresstwo field App del page$")
	public void i_enter_invalid_PoBox_in_Addresstwo_field_App_del_page() throws Throwable {
		applianceDelivery.enterInvalidPoBoxAddress2ApplDelPage();
	}

	@And("^I clear all input fields in deliverypage$")
	public void i_clear_all_input_fields_in_deliverypage() throws Throwable {
		applianceDelivery.clearAllFields();
	}

	@When("^I verify \"(.*?)\" error in appliance delivery page$")
	public void i_verify_arg1_error_in_appliance_page(String arg1) throws Throwable {
		String errortype = arg1;
		if (errortype.equalsIgnoreCase("AllFields")) {
			applianceDelivery.verifyAllFieldsError();
		} 
	}

	@And("^I enter \"(.*?)\" in First name in appliance delivery page$")
	public void i_enter_arg1_in_First_name_in_appliance_delivery_page(String arg1) throws Throwable {
		applianceDelivery.enterValidSymbolsFirstName(arg1);
	}

	@And("^I enter \"(.*?)\" in Last name in appliance delivery page$")
	public void i_enter_arg1_in_Last_name_in_appliance_delivery_page(String arg1) throws Throwable {
		applianceDelivery.enterValidSymbolsLastName(arg1);
	}
	
	@And("^I enter invalid altphone number and verify error$")
	public void i_enter_invalid_altphone_number_and_verify_error() throws Throwable {
		applianceDelivery.enterInvalidALTPhNumbers();
	}

	@And("^I verify special instruction field$")
	public void i_verify_special_instruction_field() throws Throwable {
		applianceDelivery.verifySplInstructionField();
	}
	
	@When("^I click change zipcode link in appliance delivery page$")
	public void i_click_change_zipcode_link_in_appliance_delivery_page() throws Throwable { 
		applianceDelivery.clickChangeDeliveryZipCode();	  
	}
	
	@And("^I edit the address in edit address overlay$")
	public void i_edit_the_address_in_edit_address_overlay() throws Throwable { 
		applianceDelivery.editApplianceAddressInEditOverlay();
	  
	}

	@Then("^I verify edited address is reflected in delivery page$")
	public void i_verify_edited_address_is_reflected_in_delivery_page() throws Throwable { 
		applianceDelivery.verifyApplianceEditedAddress();	  
	}
	
	@And("^I edit the city in edit address overlay$")
	public void i_edit_the_city_in_edit_address_overlay() throws Throwable { 
		applianceDelivery.editApplianceCityInEditOverlay();	  
	}

	@Then("^I verify edited city is reflected in delivery page$")
	public void i_verify_edited_city_is_reflected_in_delivery_page() throws Throwable { 
		applianceDelivery.verifyApplianceEditedCity();	  
	}

	@And("^I Add and save new address in delivery page$")
	public void i_Add_and_save_new_address_in_delivery_page() throws Throwable {
		applianceDelivery.clickAddNewAddrInAppliancePage();
		applianceDelivery.addAddrForApplianceDelivery();
		applianceDelivery.clickSaveButton();
	}

	@And("^I verify no change zipcode link for multiple items$")
	public void i_verify_no_change_zipcode_link_for_multiple_items() throws Throwable {
		applianceDelivery.verifyNoChangeLinkMultipleItems();
	}

	@And("^I verify err msg styling for address in delivery page$")
	public void i_verify_err_msg_styling_for_address_in_delivery_page() throws Throwable {
		applianceDelivery.verifyErrMsgStylingAddress();
	}

	@And("^I verify err msg styling for invalid phone in delivery page$")
	public void i_verify_err_msg_styling_for_invalid_phone_in_delivery_page() throws Throwable {
		applianceDelivery.verifyErrMsgStylingInvalidPhone();
	}

	@And("^I verify err msg styling for first name in delivery page$")
	public void i_verify_err_msg_styling_for_first_name_in_delivery_page() throws Throwable {
		applianceDelivery.verifyErrMsgStylingFirstName();
	}

	@And("^I verify delivery date displayed in right rail$")
	public void i_verify_delivery_date_displayed_in_right_rail() throws Throwable {
		applianceDelivery.verifySelectedApplDeliveryDate();
	}

	@And("^I select delivery date radio and close the calendar$")
	public void i_select_delivery_date_radio_and_close_the_calendar() throws Throwable {
		applianceDelivery.selectDeliveryRadioAndClickClose();
	}

}
