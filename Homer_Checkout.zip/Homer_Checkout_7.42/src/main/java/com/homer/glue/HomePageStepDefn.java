package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Given;
import com.homer.dao.Then;
import com.homer.dao.When;

public class HomePageStepDefn extends BaseStepDefn {

	public HomePageStepDefn(DataClass ih) {
		super(ih);
	}

	@Given("^I am a customer on Home Depot$")
	public void i_am_a_customer_on_Home_Depot() throws Throwable {
		homePage.open();
	}

	@When("^I search for keyword$")
	public void i_search_for_keyword() throws Throwable {

		plpPage = homePage.searchKeyword(dataTable.getData(DataColumn.Keyword));
	}

	@When("^I type keyword \"(.*?)\"$")
	public void i_land_on_PLP_page(String arg1) throws Throwable {

		System.out.println(arg1);
		System.out.println(dataTable.getData(DataColumn.Keyword));

		homePage.searchKeyword(dataTable.getData(DataColumn.Keyword));

	}

	@When("^I search for sku$")
	public void i_search_for_sku() throws Throwable {

		pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
	}

	@And("^I added \"(.*?)\" item to cart$")
	public void i_added_arg1_item_to_cart(String arg1) throws Throwable {

		String skuType = arg1;
		if (skuType.equalsIgnoreCase("sth")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage.CapturePipPageInfo();
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
			
			
		} else if  (skuType.equalsIgnoreCase("genmerchsth")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			pipPage.CapturePipPageInfo();
			shoppingCartPage = pipPage.clickAddToCart();
			
		}else if (skuType.equalsIgnoreCase("boss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage = pipPage.clickShipToStoreRadio();
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();

		} else if (skuType.equalsIgnoreCase("genmerchboss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			pipPage = pipPage.clickShipToStoreRadio();
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();
		
		}	else if (skuType.equalsIgnoreCase("bopis")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage = pipPage.clickPickupInStoreRadio();
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();

		} 	else if (skuType.equalsIgnoreCase("genmerchbopis")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			pipPage = pipPage.clickPickupInStoreRadio();
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();
			
		} else if (skuType.equalsIgnoreCase("appliance")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			atcOverlay = pipPage.clickAddToCartButton();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			applianceOverlay.verifyQty();
			shoppingCartPage = applianceOverlay.selectPartsAndServices(true);
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
			shoppingCartPage.saveApplianceSubtotal();
			
		} else if (skuType.equalsIgnoreCase("genmerchsmallappliancebopis")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			pipPage = pipPage.clickPickupInStoreRadio();
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();
			
		} else if (skuType.equalsIgnoreCase("genmerchsmallapplianceboss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			pipPage = pipPage.clickShipToStoreRadio();
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();
			
		} else if  (skuType.equalsIgnoreCase("genmerchsmallappliancesth")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage.CapturePipPageInfo();
			shoppingCartPage = pipPage.clickAddToCart();
			
		} else if (skuType.equalsIgnoreCase("appliancenoinstall")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			atcOverlay = pipPage.clickAddToCartButton();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			applianceOverlay.verifyQty();
			shoppingCartPage = applianceOverlay.selectPartsAndServices(false);
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
			shoppingCartPage.saveApplianceSubtotal();
		}

		else if (skuType.equalsIgnoreCase("hdpp")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			// pipPage=pipPage.CapturePipPageInfo();
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}
		else if (skuType.equalsIgnoreCase("genmerchhdpp")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			// pipPage=pipPage.CapturePipPageInfo();
			shoppingCartPage = pipPage.clickAddToCart();
			
		}

		else if (skuType.equalsIgnoreCase("bopis_alternate_store")) {
			// homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage = pipPage.clickPickupInStoreRadio();
			shoppingCartPage = pipPage.changePicupStoreAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}

		else if (skuType.equalsIgnoreCase("boss_alternate_store")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage = pipPage.clickShipToStoreRadio();
			shoppingCartPage = pipPage.changePicupStoreAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}

		else if (skuType.equalsIgnoreCase("bodfs")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			pipPage.clickTabletScheduleDeliveryRadioButton();
			wh.waitForPageLoaded();
			pipPage.enterZipCodeTabletBODFSItem();
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
			shoppingCartPage.clickBODFSZipCodeArrow();
		}
		
		else if (skuType.equalsIgnoreCase("genmerchbodfs")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			pipPage.clickTabletScheduleDeliveryRadioButton();
			wh.waitForPageLoaded();
			pipPage.enterZipCodeTabletBODFSItem();
			shoppingCartPage = pipPage.clickAddToCart();
			
		}
		else if (skuType.equalsIgnoreCase("bopisOnly")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			shoppingCartPage = pipPage.clickAddToCart();
			//shoppingCartPage.verifyShoppingCartPage();
			//shoppingCartPage.verifyShoppingCartNotEmpty();

		} else if (skuType.equalsIgnoreCase("genmerchbopisOnly")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			wh.waitForPageLoaded();
			shoppingCartPage = pipPage.clickAddToCart();

		}

		else if (skuType.equalsIgnoreCase("giftcard")) {
			shoppingCartPage = homePage.addGiftCardToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}

		else if (skuType.equalsIgnoreCase("blinds") || skuType.equalsIgnoreCase("customblinds")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			shoppingCartPage = pipPage.addBlindsItemThroURL();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}
		else if (skuType.equalsIgnoreCase("genmerchblinds") || skuType.equalsIgnoreCase("customblinds")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			
			shoppingCartPage = pipPage.addBlindsItemThroURL();
					
		}

		else if (skuType.equalsIgnoreCase("bss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			// For status 100,200 and 300,400 with onhand>0 bopis FM
			if (pipPage.verifyExpectedFulfilment("bopis")) {
				pipPage = pipPage.clickPickupInStoreRadio();
				wh.waitForPageLoaded();
			}
			// For Status 300,400,500 with onhand =0 FM
			else if (pipPage.verifyExpectedFulfilment("boss")) {
				pipPage = pipPage.clickShipToStoreRadio();
				wh.waitForPageLoaded();
			}
			// For Status 500 with onhand >0 STH only so no fulfilment selection
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}
		
		else if (skuType.equalsIgnoreCase("genmerchbss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			// For status 100,200 and 300,400 with onhand>0 bopis FM
			if (pipPage.verifyExpectedFulfilment("bopis")) {
				pipPage = pipPage.clickPickupInStoreRadio();
				wh.waitForPageLoaded();
			}
			// For Status 300,400,500 with onhand =0 FM
			else if (pipPage.verifyExpectedFulfilment("boss")) {
				pipPage = pipPage.clickShipToStoreRadio();
				wh.waitForPageLoaded();
			}
			// For Status 500 with onhand >0 STH only so no fulfilment selection
			shoppingCartPage = pipPage.clickAddToCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}

	}

	@And("^I am a registered user$")
	public void i_am_a_registered_user() throws Throwable {
		myAccountPage.registerUser();
	}

	@When("^I signin from the page with valid credentials$")
	public void i_signin_from_the_page_with_valid_credentials() throws Throwable {
		homePage.signInUser(dataTable.getCommonData(CommonDataColumn.RegUserEmail),
				dataTable.getCommonData(CommonDataColumn.RegUserPwd));
	}
	
	@When("^I signin from the page with valid credentials for hdpp$")
	public void i_signin_from_the_page_with_valid_credentials_for_hdpp() throws Throwable {
		
		homePage.signInUser(commonData.strEmail,commonData.strPassword);
	}

	@Then("^I See used loggedin and name displayed on top right corner$")
	public void i_See_used_loggedin_and_name_displayed_on_top_right_corner() throws Throwable {
		homePage.verifySignInUser();
	}

	@And("^I Sign Out My account$")
	public void i_Sign_Out_My_account() throws Throwable {
		homePage.signOut();
	}

	@When("^I signin from the page with invalid credentials$")
	public void i_signin_from_the_page_with_invalid_credentials() throws Throwable {
		homePage.signInInvalidCredentials(dataTable.getCommonData(CommonDataColumn.GuestEmail),
				dataTable.getCommonData(CommonDataColumn.WrongPwd));
	}

	@Then("^I see signin error message in overlay$")
	public void i_see_signin_error_message_in_overlay() throws Throwable {
		homePage.signInErrMsg();
	}

	@And("^I added \"(.*?)\" item to view protection plan tab$")
	public void i_added_arg1_item_to_view_protection_plan_tab(String arg1) throws Throwable {
		String skuType = arg1;
		if (skuType.equalsIgnoreCase("appliance")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			atcOverlay = pipPage.clickAddToCartButton();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			shoppingCartPage = applianceOverlay.partsAndServicesProtectionPlan(true);
		}
	}

	@And("^I added \"(.*?)\" item and click edit cart button in overlay$")
	public void i_added_arg1_item_and_click_edit_cart_button_in_overlay(String arg1) throws Throwable {
		String skuType = arg1;
		if (skuType.equalsIgnoreCase("appliance")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			atcOverlay = pipPage.clickAddToCartButton();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			applianceOverlay.clickEditCart();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}

	}


	@When("^I search for \"(.*?)\" fulfillment item$")
	public void i_search_for_arg1_fulfillment_item(String arg1) throws Throwable {

		String skuType = arg1;
		if (skuType.equalsIgnoreCase("sth")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));

		} else if (skuType.equalsIgnoreCase("boss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));

		} else if (skuType.equalsIgnoreCase("bopis")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));

		} else if (skuType.equalsIgnoreCase("appliance")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			commonData.Zipcd = dataTable.getData("ZipCode");

		} else if (skuType.equalsIgnoreCase("genmerchsmallappliancesth")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			commonData.Zipcd = dataTable.getData("ZipCode");
			
		} else if (skuType.equalsIgnoreCase("appliancenoinstall")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));

		}

		else if (skuType.equalsIgnoreCase("bopis_alternate_store")) {
			// homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));

		}

		else if (skuType.equalsIgnoreCase("bodfs")) {
			wh.waitForPageLoaded();
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			commonData.Zipcd = dataTable.getData("ZipCode");

		}

		else if (skuType.equalsIgnoreCase("bodfs_shared")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));

		}

		else if (skuType.equalsIgnoreCase("bss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
		}
		else if (skuType.equalsIgnoreCase("blinds") || skuType.equalsIgnoreCase("customblinds")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
		}
		
		else if (skuType.equalsIgnoreCase("hdpp")) {
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			// pipPage=pipPage.CapturePipPageInfo();
			shoppingCartPage = pipPage.clickAddToCart();
		}
		pipPage.CapturePipPageInfo();

	}

	@And("^I click more information link$")
	public void i_click_more_information_link() throws Throwable {
		applianceOverlay = applianceOverlay.clickMoreInfoLink();
	}

	@And("^I click terms and conditions link$")
	public void i_click_terms_and_conditions_link() throws Throwable {
		applianceOverlay = applianceOverlay.clickTermsAndConditionLink();
	}

	@Then("^I verify terms and conditions in new tab$")
	public void i_verify_terms_and_conditions_in_new_tab() throws Throwable {
		applianceOverlay = applianceOverlay.verifyTermsAndCondInNewTab();
	}

	@Then("^I verify more information in new tab$")
	public void i_verify_more_information_in_new_tab() throws Throwable {
		applianceOverlay = applianceOverlay.verifyMoreInfoInNewTab();
	}

	@When("^I change the localized store in the header$")
	public void i_change_the_localized_store_in_the_header() throws Throwable {
		homePage.clickChangeLinkInheader();
	}

	@And("^I click your account in home page$")
	public void i_click_your_account_in_home_page() throws Throwable {
		homePage.clickYourAccountInHomePg();
	}

	@Then("^I click mini cart button in the header$")
	public void i_click_mini_cart_button_in_the_header() throws Throwable {
		shoppingCartPage = homePage.clickMiniCartBtn();
	}

	@When("^I localize to store$")
	public void i_localize_to_store() throws Throwable {
		homePage = homePage.localiseJumpUrl();
	}

	@Then("^I delete user session cookie$")
	public void i_delete_user_session_cookie() throws Throwable {
		homePage.deleteUserSessionCookie();
	}

	@And("^I sign in through header$")
	public void i_sign_in_through_header() throws Throwable {
		homePage.signInUser(commonData.strEmail, commonData.strPassword);
	}

	@When("^I search keyword for \"(.*?)\" fulfillment item$")
	public void i_search_keyword_for_arg1_fulfillment_item(String arg1) throws Throwable {

		String SKU = dataTable.getData(DataColumn.SKU);
		String model = plpPage.SearchKeywordBySKU(SKU);
		commonData.modelNo = model;
	}
	
	@When("^I search keyword for bodfs item$")
	public void I_search_keyword_for_bodfs_item() throws Throwable {
		homePage = homePage.localiseJumpUrl();
		String SKU = dataTable.getData(DataColumn.SKU);
		String model = plpPage.SearchKeywordBySKU(SKU);
		commonData.modelNo = model;
	}

	@And("^I refresh Home Page$")
	public void i_refresh_Home_Page() throws Throwable {
		homePage.refreshHome();

	}

	@And("^I click Continue shoppi$")
	public void i_click_Continue_shoppi() throws Throwable {

	}

	@And("^I am a existing user$")
	public void i_am_a_existing_user() throws Throwable {

		homePage.signInUser(dataTable.getCommonData(CommonDataColumn.RegUserEmail),
				dataTable.getCommonData(CommonDataColumn.RegUserPwd));
		homePage.navigateMCCCart();
		shoppingCartPage.removeItemsFromCart();
		// Thread.sleep(commonData.littleWait);
		homePage.signOut();
		// homePage.refreshHome();

	}
	
	@When("^I navigate to special buy of the day page$")
	public void i_navigate_to_special_buy_of_the_day_page() throws Throwable { 
		homePage.navigateToSbotd();	  
	}
	
	@When("^the HDPPFeatureSwitch is OFF$")
	public void the_HDPPFeatureSwitch_is_OFF() throws Throwable { 
		dbConnection.verifyHDPPFeatureSwitchOFFInDB();
	}
	
	@And("^I check for availability of BODFS item PIP$")
	public void i_check_for_availability_of_BODFS_item_PIP() throws Throwable {
		pipPage.clickTabletScheduleDeliveryRadioButton();
		wh.waitForPageLoaded();
		pipPage.enterZipCodeTabletBODFSItem();

	}

	@And("^I add samples from blinds$")
	public void i_ad_samples_from_blinds() throws Throwable {
		pipPage.addSampleFromBlinds();
		pipPage.clickContinueShoppingForSamples();
	}

	@And("^I get auto localized store$")
	public void i_get_auto_localized_store() throws Throwable {
		homePage.getAutoLocalizedStore();
		
	}
	
	@And("^I verify auto localized store in all pages$")
	public void i_verify_auto_localized_store_in_all_pages() throws Throwable {
		homePage.verifyAutoLocalizedStoreInAllPages();
		
	}
	
	@When("^I verify the MCCAtcModalCoNowFeatureSwitch is ON$")
	public void i_verify_the_MCCAtcModalCoNowFeatureSwitch_is_ON() throws Throwable { 
		dbConnection.verifyMCCAtcModalCoNowFeatureSwitchOnInDB();
	}
	
	
	@When("^I select Product From FlyOut$")
	public void i_vselect_Product_From_FlyOut() throws Throwable { 
		homePage.flyOutNav();
	}
	
	@When("^I verify the EnableStoreCreditSwitch is OFF$")
	public void i_verify_the_EnableStoreCreditSwitch_is_OFF() throws Throwable { 
	dbConnection.verifyEnableStoreCreditSwitchIsOffInDB();
	}
	
	@And("^I clear cookies$")
	public void i_clear_cookies() throws Throwable {
		homePage.clearCookies();
	}
	
	@Then("^I open foreseeUrl$")
	public void i_open_foreseeurl() throws Throwable {
		homePage.LaunchForeseeUrl();
		homePage.verifyForeseePage();
	}
	
	@When("^I enter browseqty in foreseepage$")
	public void i_enter_browseqty_in_foreseepage() throws Throwable {
		homePage.enterBrowseQtyInForeseePg();
	}
	
	@And("^I verify foresee popup$")
	public void i_verify_foresee_popup() throws Throwable {
		homePage.verifyForeseePopup();
	}
	
	@And("^I click no thanks in foresee popup$")
	public void i_click_no_thanks_in_foresee_popup() throws Throwable {
		homePage.clickNoThanksBtnInForeseePopup();
	}
	
	@And("^I click yes button in foresee popup$")
	public void i_click_yes_button_in_foresee_popup() throws Throwable {
		homePage.clickYesBtnInForeseePopup();
	}
	
	
	@And("^I switch to foresee window$")
	public void i_switch_to_foresee_window() throws Throwable {
		homePage.switchWindow();
	}
	
	@And("^I verify custom survey page$")
	public void i_verify_custom_survey_page() throws Throwable {
		homePage.verifyCustSurveyPage();
	}
	
	
	@When("^I enter feedback comments in foresee survey page$")
	public void i_enter_feedback_comments_in_foresee_survey_page() throws Throwable {
		homePage.enterCommentsInCustSurveyPage();
	}

	@And("^I am an existing user with restricted zip as default address$")
	public void i_am_an_existing_user_with_restricted_zip_as_default_address() throws Throwable {

		homePage.signInUser(dataTable.getCommonData(CommonDataColumn.RegUserEmailRestrictedZip),
				dataTable.getCommonData(CommonDataColumn.RegUserPwdRestrictedZip));
		homePage.navigateMCCCart();
		shoppingCartPage.removeItemsFromCart();

	}
	
	@When("^I click on gift card link$")
	public void i_click_on_gift_card_link() throws Throwable {
		homePage.clickGiftCard();
	}

	@And("^I click edit cart button in appliance overlay$")
	public void i_click_edit_cart_button_in_appliance_overlay() throws Throwable {
		applianceOverlay.clickEditCart();
		shoppingCartPage.verifyShoppingCartPage();
		shoppingCartPage.verifyShoppingCartNotEmpty();
	}
	
	@When("^I navigate to PLP using FlyOut$")
	public void i_navigate_to_PLP_using_FlyOut() throws Throwable { 
		homePage.flyOutNavToPLP();
	}
	
	@When("^I signin with valid credentials for merge cart$")
	public void i_signin_with_valid_credentials_for_merge_cart() throws Throwable {
		homePage.signInUser(dataTable.getData(DataColumn.Regusername),
				dataTable.getData(DataColumn.Regpwd));
	}

	@And("^I navigate to home page$")
	public void i_navigate_to_home_page() throws Throwable {
		homePage.navigateToHomePage();
	}

}
