package com.homer.glue;

import com.homer.dao.DataClass;
import com.homer.dao.Given;
import com.homer.dao.Then;
import com.homer.dao.And;
import com.homer.dao.When;

public class EmailStepDefn extends BaseStepDefn {
	
	public EmailStepDefn(DataClass data) {
		super(data);
	}
	
	@Given("^I am a Home Depot mail user$")
	public void i_am_a_Home_Depot_mail_user() throws Throwable { 
		emailPage.loginThdEmail();	  
	}
		
	@And("^verify order confirmation mail received$")
	public void verify_order_confirmation_mail_received() throws Throwable { 
		emailPage.verifyOrderConfEmail();
	}
	
	@And("^UnitPrice displayed in e-mail pods is equivalent to the price in Cassandra DB$")
	public void unitPrice_displayed_in_e_mail_pods_is_equivalent_to_the_price_in_Cassandra_DB() throws Throwable { 
		emailPage.verifyUnitPriceEmailPods();
	}

	@And("^Subtotal displayed in email pods is as in thank you page$")
	public void subtotal_displayed_in_email_pods_is_as_in_thank_you_page() throws Throwable { 
		emailPage.verifySubtotalEmailPods();
	}
	@And("^I naviagate to order confirmation email page for \"(.*?)\" item$")
	public void i_naviagate_to_order_confirmation_email_page_for_arg1_item(String arg1) throws Throwable { 
		emailPage.navigateToOrderConfimationEmailPg(arg1);
	}
	
	@Then("^I see price details in email for \"(.*?)\" item$")
	public void i_see_price_details_in_email_for_arg1_item(String arg1) throws Throwable { 
			  
	  if (arg1.equalsIgnoreCase("sth") || arg1.equalsIgnoreCase("boss")){
		  emailPage.verifyUnitPriceEmailPods();
		  emailPage.verifySubtotalEmailPods();
	  }else if (arg1.equalsIgnoreCase("bopis")||arg1.equalsIgnoreCase("appliance")) {
		  emailPage.verifyUnitPriceBOPISEmailPods();
		  emailPage.verifySubtotalBOPISEmailPods();
	  }
	  
	}
	
	@When("^I search for \"(.*?)\" email for an order$")
	public void i_search_for_arg1_email_for_an_order(String arg1) throws Throwable { 
		emailPage.searchEmailForOrder(arg1);  
	}
	
	@Then("^I click and verify \"(.*?)\" email received$")
	public void i_click_and_verify_arg1_email_received(String arg1) throws Throwable { 
		emailPage.verifyEmailReceived(arg1);	  
	}


}
