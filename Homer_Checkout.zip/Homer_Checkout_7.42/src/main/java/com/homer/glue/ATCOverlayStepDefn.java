package com.homer.glue;

import java.util.Iterator;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.homer.dao.And;
import com.homer.dao.CommonData;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Given;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class ATCOverlayStepDefn extends BaseStepDefn {
	
	public ATCOverlayStepDefn(DataClass data) {
		super(data);
	}
	
	@Then("^I see ATC modal with Image & total & quantity added$")
	public void i_see_ATC_modal_with_Image__total__quantity_added() throws Throwable { 
		
		atcOverlay.verifyProductImageInATCOverlay();
		atcOverlay.verifyProductQtyInATCOverlay();
		atcOverlay.verifyTotalPriceInATCOverlay(); 
	  
	}
	
	@Then("^I see delivery charge message displayed in atc overlay$")
	public void i_see_delivery_charge_message_displayed_in_zip_overlay() throws Throwable { 
		atcOverlay.verifyADCMessageInATCOverlay();	  
	}
	
	@And("^I click Checkout Now in overlay$")
	public void i_click_Checkout_Now_in_overlay() throws Throwable { 
		atcOverlay.clickCheckoutNow();
	}
	
	@And("^I see 'Unit price' displayed in the ATC modal is equivalent to the price in Cassandra DB$")
	public void i_see_Unit_price_displayed_in_the_ATC_modal_is_equivalent_to_the_price_in_Cassandra_DB() throws Throwable {
		atcOverlay.verifyATCPriceWithDB();
	}
	
	@And("^TotalPrice displayed in the ATC modal is equivalent to the price in Cassandra DB$")
	public void totalPrice_displayed_in_the_ATC_modal_is_equivalent_to_the_price_in_Cassandra_DB()
			throws Throwable {
		if (!commonData.isAppliance){
			atcOverlay.verifyATCTotalPriceWithDB();
		}
		else{
			report.addReportStep("Verify Appliance total", "Appliance total is as expected", StepResult.PASS);
		}
	}

	@And("^Subtotal displayed in the ATC modal is equivalent to the sum of UnitPrice of all items in cart$")
	public void subtotal_displayed_in_the_ATC_modal_is_equivalent_to_the_sum_of_UnitPrice_of_all_items_in_cart()
			throws Throwable {
		if (!commonData.isAppliance){
			atcOverlay.verifyATCSubTotalPriceWithDB();
		}
		else{
			report.addReportStep("Verify Appliance sub total", "Appliance sub total is as expected", StepResult.PASS);
		}
	}

	
	@Then("^I see price details in Add to cart overlay$")
	public void i_see_price_details_in_Add_to_cart_overlay() throws Throwable { 
		atcOverlay.verifyATCPriceWithDB();
		atcOverlay.verifyATCTotalPriceWithDB();
		atcOverlay.verifyATCSubTotalPriceWithDB();
	}
	
	
	@And("^I select paypal from ATC$")
	public void i_select_paypal_from_ATC() throws Throwable { 
		atcOverlay.clickPayPal();
		
	}

	//***********The below  section is for HDPP*********************
	
			@Then("^I see ATC modal with HDPP$")
			public void i_see_ATC_modal_with_HDPP() throws Throwable { 
				
				atcOverlay.verifyHDPPInATCOverlay(); 
			  
			}
			
			@And("^I see ATC modal with Add Plan Option$")
			public void i_see_ATC_modal_with_Add_Plan_Option() throws Throwable { 			
				
				atcOverlay.verifyAddPlanInATCOverlay(); 
			  
			}
			
			@And("^I  do not see ATC modal with Add Plan Option$")
			public void i_do_not_see_ATC_modal_with_Add_Plan_Option() throws Throwable { 			
				
				atcOverlay = pipPage.clickAddToCartButton();
				applianceOverlay.enterZipcode();
				atcOverlay.verifyNoAddPlanInATCOverlay(); 
			  
			}
			
			@And("^I do not see Add Plan option in ATC overlay$")
			public void I_do_not_see_Add_Plan_option_in_ATC_overlay() throws Throwable { 			
				
				
				atcOverlay.verifyNoAddPlanInATCOverlay(); 
			  
			}
			
			
			

			@When("^I click Add Plan in overlay$")
			public void i_click_Add_Plan_in_overlay() throws Throwable { 
				atcOverlay.getSubTotal();
				atcOverlay.clickAddPlan();
			}	
			
			@When("^I click on View cart link$")
			public void I_click_on_View_cart_link() throws Throwable { 
				
				atcOverlay.clickViewCart();
			}	
			
			
			@Then("^I see ADDED TO CART message in overlay$")
			public void i_see_Added_to_cart_message_in_overlay() throws Throwable { 
				
				
				atcOverlay.verifyAddedToCartInATCOverlay(); 
			  
			}	
			
			@Then("^I close the overlay$")
			public void I_close_the_overlay() throws Throwable { 
				
				
				atcOverlay.closeOverlay(); 
			  
			}	
			
			//Then I see ATC modal with price & quantity added
			@Then("^I see ATC modal with price & quantity added$")
			public void i_see_ATC_modal_with_price_quantity_added() throws Throwable { 
				
				
				atcOverlay.verifyQtyfromPLPInATCOverlay(); 
				atcOverlay.verifyPricefromPLPInATCOverlay();
			  
			}	
			@And("^I see updated subtotal in ATC modal$")
		    public void i_see_updated_subtotal_in_ATC_modal() throws Throwable { 		
				
				atcOverlay.verifyUpdatedSubTotal(); 
			  
			}	
			
			@Then("^I see failure message in overlay$")
			public void i_see_failure_message_in_overlay() throws Throwable { 
				
				
				atcOverlay.verifyFailureMsgInATCOverlay(); 
			  
			}	
			
			@And("^I verify certona section in ATC Overlay$")
			public void i_verify_certona_section_in_ATC_Certona() throws Throwable { 
				atcOverlay.verifyCertonaSectionOverlay();	  
			}
			
			@When("^I click on AddToCart in ATC Certona$")
			public void i_click_on_AddToCart_in_ATC_Certona() throws Throwable { 
				atcOverlay.clickATCCertona();
				
			}	
			
			@And("^I do not see ATC modal with Add Plan Option for appliance$")
			public void i_do_not_see_ATC_modal_with_Add_Plan_Option_for_appliance() throws Throwable { 			
				atcOverlay = pipPage.clickAddToCartButton();
				applianceOverlay.enterZipcode();
				atcOverlay.verifyNoAddPlanInATCOverlay(); 
			  
			}
			
			//Then I see the tick mark 
			

			@And("^I see the tick mark$")
			public void I_see_the_tick_mark() throws Throwable { 			
				
				atcOverlay.verifyTickMark(); 
			  
			}
			
			@And("^I see ATC modal with product total & quantity added$")
			public void I_see_ATC_modal_with_product_total__quantity_added_from_PCP() throws Throwable { 
				atcOverlay.verifyQuantity();
				atcOverlay.verifyTotalPricefromPCPInATCOverlay();
				
			}
			
			@Then("^I see the updated quantity and price of the item$")
			public void I_see_the_updated_quantity_of_the_item() throws Throwable { 
				atcOverlay.verifyincreasedQuantity();
				atcOverlay.verifyTotalincraesedPriceInATCOverlay();
			  
			}
			@Then("^I see item level promotion applied in overlay$")
			public void I_see_item_level_promotion_applied_in_overlay() throws Throwable { 
				atcOverlay.verifypromo();
				
			  
			}
			
			@Then("^I do not see the remove link in ATC overlay$")
			public void I_do_not_see_the_remove_link_in_ATC_overlay() throws Throwable { 
				atcOverlay.verifyRemoveLink();

			}
			
			
	//********************The above section is for HDPP**************************************
	
	@And("^I click save chagnes button in P&S overlay$")
	public void i_click_save_chagnes_button_in_P_S_overlay() throws Throwable {
		applianceOverlay.clickSaveChangesBtn();
	}
	
	@Then("^I do not see the HDPP in ATC modal$")
	public void i_do_not_see_the_HDPP_in_ATC_modal() throws Throwable { 
		atcOverlay.verifyHDPPNotDisplayed();
	}
	
	@And("^I select protection plan in overlay$")
	public void i_select_protection_plan_in_overlay() throws Throwable { 
		applianceOverlay.selectProtectionPlan();	  
	}
	
	@And("^I click edit cart button in overlay$")
	public void i_click_edit_cart_button_in_overlay() throws Throwable { 
		applianceOverlay.clickEditCart();
	}
	
	@And("^I verify all details in ATC modal$")
	public void i_verify_all_details_in_ATC_modal() throws Throwable { 
		atcOverlay.verifyAddedToCartInATCOverlay(); 
		atcOverlay.verifyProductImageInATCOverlay();
		atcOverlay.verifyProductQtyInATCOverlay();
		atcOverlay.verifyTotalPriceInATCOverlay();
		atcOverlay.verifyATCPriceWithDB();
		atcOverlay.verifyATCTotalPriceWithDB();
		atcOverlay.verifyATCSubTotalPriceWithDB();
		atcOverlay.verifyCertonaSectionOverlay();
		
	  
	}
	
	@And("^I click select parts button in P&S overlay$")
	public void i_click_select_parts_button_in_P_S_overlay() throws Throwable {
		applianceOverlay.clickSelectPartsButton();
	}
	
	@And("^I verify two step instal msg in P&S overlay$")
	public void i_verify_two_step_instal_msg_in_P_S_overlay() throws Throwable { 
		applianceOverlay.verifyTwoStepInstalMsg();	  
	}

	@And("^I see Continue Shopping link$")
	public void i_see_Continue_Shopping_link() throws Throwable { 
		atcOverlay.verifyContinueShoppingLink();
	}

	@Then("^I click on Continue Shopping link in overlay$")
	public void i_click_on_Continue_Shopping_link_in_overlay() throws Throwable { 
		atcOverlay.clickContinueShoppingLink();	  
	}
	
	@And("^I do not see Continue Shopping link in appliance ATC overlay$")
	public void i_do_not_see_Continue_Shopping_link_in_appliance_ATC_overlay() throws Throwable { 
		atcOverlay.verifyContinueShoppingLinkNotPresent();	  
	}
	
	@And("^I do not see the Continue Shopping button in ATC overlay$")
	public void i_do_not_see_the_Continue_Shopping_button_in_ATC_overlay() throws Throwable { 
		atcOverlay.verifyContinueShoppingButtonNotPresent();
	}
	
	
	@And("^I do not see checkoutwithpaypal button in ATC overlay$")
	public void i_do_not_see_checkoutwithpaypal_button_in_ATC_overlay() throws Throwable { 
		atcOverlay.checkoutWithPaypalNotDisplayed();
	}

	@And("^I see Continue Shopping button in P&S overlay$")
	public void i_see_Continue_Shopping_button_in_P_S_overlay() throws Throwable {
		applianceOverlay.verifyContinueShoppingButton();
	}
	
	@Then("^I see ATC overlay closed$")
	public void i_see_ATC_overlay_closed() throws Throwable { 
		atcOverlay.verifyATCOverlayClosed();	  
	}

	//**********Instant Rebate**********************//
	
		@And("^I check price and store promotion in ATC$")
		public void i_check_price_and_store_promotion_in_ATC() throws Throwable { 
			
			{
			
				String sku = commonData.sku;
				String store = dataTable.getData(DataColumn.storeID);
				database.getUnitPriceFromPricingService(sku, store);	
				commonData.IRList.add(commonData.shortdesc);
				commonData.changedstoreprice = commonData.unitPriceDB;
				commonData.PriceList.add(commonData.unitPriceDB);
		
		}
		}
		
		@Then("^I Verify Instant Rebate Message in Add to cart overlay$")
		public void I_verify_Instant_Rebate_Message_in_Add_to_cart_overlay() throws Throwable { 
		
		atcOverlay.verifyInstantRebateMsgATC();
		
		}
		
		//**********End of Instant Rebate**********//
		
	@And("^I verify P&S overlay is displayed$")
	public void i_verify_P_S_overlay_is_displayed() throws Throwable {
		applianceOverlay.verifyPartsAndServicesOverlay();
	}

	
	@And("^I see close button in ATC overlay$")
	public void i_see_close_button_in_ATC_overlay() throws Throwable { 
		atcOverlay.verifyCloseButton();
	}
}
