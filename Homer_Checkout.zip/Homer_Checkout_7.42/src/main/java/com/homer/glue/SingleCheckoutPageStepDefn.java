package com.homer.glue;
import com.homer.dao.*;


public class SingleCheckoutPageStepDefn extends BaseStepDefn{

	public SingleCheckoutPageStepDefn(DataClass data) {
		super(data);
		
	}
	
	@Then("^I add OpenPageCheckout parameter in cart$")
	public void i_add_OpenPageCheckout_parameter_in_cart() throws Throwable
	{
		
		signInSection.addOPCParameter();
		
	}
	
	@And("^I see signin section$")
	public void i_see_signin_section() throws Throwable{
		
		signInSection.verifySigninSection();
	}

	
/***********************PICKUP OPTION SECTION STEP DEFINITIONS***************************/

	@Then("^I see pickup option section$")
	public void i_see_pickup_option_section() throws Throwable { 
		pickUpOptionSection.verifyPickupOptionSection();  
//		pickupPage.verifyAndCloseSaveTripOverlay();
	}
	
	@And("^I click on continue button in Pickup Option Section$")
	public void i_click_on_continue_button_in_pickup_option_section()throws Throwable
	{
		pickUpOptionSection.clickContinueButton();
		pickUpOptionSection.checkForErrorMessage();
	}
	
	@And("^I see Pickup Option Summary$")
	public void i_see_pickup_option_summary() throws Throwable
	{
		pickUpOptionSection.verifyPickupOptionSummary();
	}
	
	@And("^I choose another person for pickup$")
	public void i_choose_another_person_for_pickup()throws Throwable
	{
		pickupPage.enterChooseAnotherPersonDetails();
		pickupPage.clickSaveAnotherPersonDetails();
	}
	
	
	@And("^I select Pro desk in Instore Pickup Location$")
	public void i_select_pro_desk_in_pickup_locaton() throws Throwable
	{
		
		pickUpOptionSection.selectProDesk();
	}
	
	@And ("^I modify the First and Last name of pickup person$")
	public void i_modify_the_first_and_last_name_of_pickup_person () throws Throwable
	{
		pickUpOptionSection.verifyChooseAnotherPersonDetailsModified();
	}
	
	@When("^I click on Edit Link in Pickup Options Summary$")
	public void i_click_on_edit_link_in_Pickup_Options_Summary() throws Throwable 
	{
		pickUpOptionSection.clickEditLink();
		
	}
	
	
	
	@When("^I click on Edit cart button in right rail$")
	public void i_click_on_edit_cart_button_in_right_rail() throws Throwable
	{
		pickUpOptionSection.editCart();
	}

	@When("^I click on Modify link in Right rail$")
	public void i_click_on_modify_link_in_right_rail() throws Throwable
	{
		pickUpOptionSection.clickModifyLinkInRightRail();
	}
	
	
	@And("^I modify the Pickup Date and time$")
	public void i_modify_the_pickup_date_and_time()throws Throwable
	{
		pickUpOptionSection.verifyChooseTimeandDateModified();
	}
	/*******************PAYMENT SECTION****************************/
	

	@Then("^I see payment section$")
	public void i_see_payment_section() throws Throwable { 
		
		paymentSection.verifyPaymentSection();	  
	}
	
	@When("^I fill creditcard details in Payment section$")
	public void i_fill_creditcard_details_in_payment_section() throws Throwable{
		
		paymentSection.fillCreditCardDetails();	
	}
	
	@And("^I click on continue button in Payment section$")
	public void i_click_on_continue_button_in_payment_section()throws Throwable
	{
		paymentSection.clickContinue();
	}
			
	@And("^I see payment summary$")
	public void i_see_payment_summary()throws Throwable{
		
		paymentSection.verifyPaymentSummary();
		
	}
	@Then("^I see Billing section$")
	public void i_see_billing_section() throws Throwable { 
		
		paymentSection.verifyBillingSection();	  
	}
	
	@When("^I fill the billing information$")
	public void i_fill_the_billing_information() throws Throwable{
		
		paymentSection.fillBillingInfo();	
	}
	
	@And("^I click on continue button in Billing section$")
	public void i_click_on_continue_button_in_billing_section()throws Throwable
	{
		paymentSection.clickBillingContinue();
	}
	
	@And ("^I see Billing Summary$")
	public void i_see_billing_summary()throws Throwable{
		paymentSection.verifyBillingSummary();
	}
	
	@And("^I click submitorder button$")
	public void i_click_submitorder_button() throws Throwable { 
		
		thankYouPage = paymentSection.submitOrder1();
	}
	
	@And("^I verify payment section gets hidden$")
	public void i_verify_payment_section_gets_hidden()throws Throwable
	{
		paymentSection.hidePaymentSection();
	}
	
	@When("^I click on Edit link in Payment Summary$")
	public void i_click_on_Edit_link_in_Payment_Summary() throws Throwable
	{
		paymentSection.clickEditLinkSummary();
	}
	
	@And("^I entered the modified payment details$")
	public void i_entered_the_modified_payment_details()throws Throwable
	{
		paymentSection.modifyPaymentDetails();
		
	}
	
	@And("^I see Billing section is hidden$")
	public void i_see_billing_section_is_hidden() throws Throwable
	{
		paymentSection.hideBillingSection();
	}

}
