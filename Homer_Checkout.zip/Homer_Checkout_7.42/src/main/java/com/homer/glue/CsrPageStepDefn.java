package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;
import com.homer.dao.When;

public class CsrPageStepDefn extends BaseStepDefn {

	public CsrPageStepDefn(DataClass data) {
		super(data);
		// TODO Auto-generated constructor stub
	}

	@When("^I Login in CSR$")
	public void i_login_in_csr() throws Exception
	{
		csrPage.csrBopisLogin();
	}
	
	@And("^I Check the Order in CSR$")
	public void i_check_the_Order_in_CSR()
	{
		csrPage.searchOrderDetailsInCSRPage();
	}
	
	@Then("^I see Order detail should be shown properly$")
	public void i_see_order_detail_should_be_shown_properly()
	{
		csrPage.orderStatusForBopisInCSRSearchPage();
	}
	
	
	
}
