package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.CommonData;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Given;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class PLPStepDefn extends BaseStepDefn {
	
	public PLPStepDefn(DataClass data) {
		super(data);
	}

	
	@Then("^I see the initial search PLP$")
	public void i_see_the_initial_search_PLP() throws Throwable { 
		
		plpPage.verifyPLPPage();
	}
	  
	@When("^I click first prod in Search PLP$")
	public void i_click_first_prod_in_Search_PLP() throws Throwable { 

		pipPage = plpPage.clickFirstPLPPOD();
		pipPage.addMCCparamter();
	}
	
	
	@And("^I sign in to site$")
	public void i_sign_in_to_site() throws Throwable { 
		
		plpPage.signInUser(dataTable.getCommonData(CommonDataColumn.RegUserEmail), dataTable.getCommonData(CommonDataColumn.RegUserPwd));
	  
	}
	
	@And("^I check appliance availability$")
	public void i_check_appliance_availability() throws Throwable { 
		applianceOverlay.enterZipCodeCheckAvailability();  
	}
	
	@Then("^I click Add to cart in PLP$")
	public void i_click_Add_to_cart_in_PLP() throws Throwable { 
		plpPage.clickAddToCartPLP();
	}
	
	@And("^I verify protection plan tab PLP$")
	public void i_verify_protection_plan_tab_PLP() throws Throwable { 
		shoppingCartPage = applianceOverlay.partsAndServicesProtectionPlan(true);	  
	}
	
	@And("^I click Continue shopping in overlay$")
	public void i_click_Continue_shopping_in_overlay() throws Throwable { 
		atcOverlay.clickContinueShopping();
	}

	@And("^I verify certona section in PLP$")
	public void i_verify_certona_section_in_PLP() throws Throwable {
		plpPage.verifyCertonaSectionPLP();
	}
	
	@And("^I click Add to cart from PLP certona$")
	public void i_click_Add_to_cart_from_PLP_certona() throws Throwable { 
		plpPage.clickAddtoCartCertonaPLP();	  
	}
	
	@And("^I check online price in Cassandra DB$")
	public void i_check_online_price_in_Cassandra_DB() throws Throwable {
		
		String sku = commonData.sku;
		String unitPrice1 = "";
		
		if(checkoutConfig.readPriceFromCassandra){	

			 unitPrice1 = database.getPriceFromCassandraRefAPP(sku,"");
			//String unitPrice1 = cassandraDB.getStorePriceCassandraDB(sku);
						
		}
		else{
			if(checkoutConfig.readFromPricingAPI){
				 unitPrice1 = database.getUnitPriceFromPricingService(sku,"");
			}
			report.addReportStep("Read From Cassndra", "Read From cassandra feature switch is off", StepResult.DONE);
		}
		
		if(!unitPrice1.equals("")){
			commonData.priceRead = true;
		}
	}
	
	@And("^I see the PLP price equivalent to the price in Cassandra DB$")
	public void i_see_the_PLP_price_equivalent_to_the_price_in_Cassandra_DB() throws Throwable { 
	  plpPage.verifyPriceDisplayed(commonData.sku);	  
	}
	
	@When("^I click Add to cart for selected product$")
	public void i_click_Add_to_cart_for_selected_product() throws Throwable { 
		atcOverlay = plpPage.clickAddToCartForSKU();	  
	}
	
	@And("^I get unit price from PLP certona$")
	public void i_get_unit_price_from_PLP_certona() throws Throwable {
		plpPage.getProdUnitPricePLPCertona();

	}
	
	@And("^I added blinds item to cart from PLP$")
	public void i_added_blinds_item_to_cart_from_PLP() throws Throwable { 
		
		homePage.SearchKeywordBySKU(dataTable.getData(DataColumn.SKU));
		plpPage.clickAddToCartForSKU();
		shoppingCartPage = pipPage.addBlindsItemThroURL();
		shoppingCartPage.verifyShoppingCartPage();
		shoppingCartPage.verifyShoppingCartNotEmpty(); 
	  
	}

	@And("^I verify pickup store not displayed in PLP$")
	public void i_verify_pickup_store_not_displayed_in_PLP() throws Throwable {
		plpPage.verifyPickUpStorePositionNotDisplayed();

	}
	
	@And("^I verify pickup store displayed in PLP$")
	public void i_verify_pickup_store_displayed_in_PLP() throws Throwable {
		plpPage.verifyPickUpStorePositionDisplayInPLPPg();

	}


}
