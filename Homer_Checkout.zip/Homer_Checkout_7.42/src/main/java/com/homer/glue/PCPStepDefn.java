package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Then;
import com.homer.dao.When;

public class PCPStepDefn extends BaseStepDefn {

	public PCPStepDefn(DataClass data) {
		super(data);
	}

	@When("^I select two items to compare$")
	public void i_select_two_items_to_compare() throws Throwable {
		plpPage.compareProducts();
	}

	@Then("^I see the initial PCP page$")
	public void i_see_the_initial_PCP_page() throws Throwable {
		pcppage.verifyPCPPage();
	}
	
	@And("^I see PCP price equivalent to the price in Cassandra DB\\.$")
	public void i_see_PCP_price_equivalent_to_the_price_in_Cassandra_DB() throws Throwable { 
		pcppage.verifyPriceDisplayed(commonData.sku);
	}

	@When("^I click on AddToCart in PCP page$")
	public void i_click_on_AddToCart_in_PCP_page() throws Throwable { 
		atcOverlay = pcppage.clickAddToCartButton();
	}
	
	//-------The below section is for hdpp------------------
		@And("^I verify certona section in PCP$")
		public void i_verify_certona_section_in_PCP() throws Throwable { 
			pcppage.verifyCertonaSectionPCP();	  
		}

		@And("^I click Add to cart from PCP certona$")
		public void i_click_Add_to_cart_from_PCP_certona() throws Throwable { 
			pcppage.clickAddtoCartCertonaPCP();	  	  
		}

		@And("^I click store inventory and enter quantity$")
		public void I_click_store_inventory_and_enter_quantity() throws Throwable { 
			pcppage.clickStoreInventory();
			pcppage.enterQuantity();
		}
		
		@When("^I click add to cart$")
		public void I_click_add_to_cart() throws Throwable { 
			pcppage.addcart();
		}
		
		@And("^I added blinds item to cart from PCP$")
		public void i_added_blinds_item_to_cart_from_PCP() throws Throwable { 
			homePage.SearchKeywordBySKU(dataTable.getData(DataColumn.SKU));
			plpPage.compareProducts();
			pcppage.clickBuildAndBuyButton();
			shoppingCartPage = pipPage.addBlindsItemThroURL();
			shoppingCartPage.verifyShoppingCartPage();
			shoppingCartPage.verifyShoppingCartNotEmpty();
		}
			
}
