package com.homer.glue;

import com.homer.dao.*;

public class Blinds_61889StepDefn extends BaseStepDefn {

	public Blinds_61889StepDefn(DataClass ic) {
		super(ic);
		// TODO Auto-generated constructor stub
	}


  @When("^I click on mini cart icon from cart page$")
  public void i_click_on_mini_cart_icon_from_cart_page() throws Exception{
	  blindsDefect.clickMiniCart();
  }
  
  @When("^I click on Products and Services menu bar$")
  public void i_click_on_p_and_s_menu_bar() throws Exception{
	  blindsDefect.clickPSonMenuBar();
  }
  
  @And("^I click on Blinds and Decor in flyout$")
  public void i_click_on_B_and_D() throws Exception{
	  blindsDefect.clickBandD();
  }
  
  @And("^i click on Blinds sub menu$")
  public void i_click_on_Blinds_sub_menu() throws Exception{
	  blindsDefect.clickBandSsubMenu();
  }
  
  @Then("^I see blinds PLP$")
  public void i_see_blinds_PLP() throws Exception{
	  blindsDefect.verfyBlindsPLP();
  }
  
  
  
  
  
  
  
  
  
  
}