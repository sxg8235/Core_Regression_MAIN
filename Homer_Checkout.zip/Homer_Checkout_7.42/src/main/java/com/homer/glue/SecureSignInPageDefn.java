package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Then;
import com.homer.dao.When;

public class SecureSignInPageDefn extends BaseStepDefn {
	
	public SecureSignInPageDefn(DataClass data) {
		super(data);
		
	}

	@Then("^I see secure checkout page$")
	public void i_see_secure_checkout_page() throws Throwable {
		
		checkoutSignInPage.verifySecurePage();		
	}

	@And("^I enter Guest email id and click continue$")
	public void i_enter_Guest_email_id_and_click_continue() throws Throwable { 
		
		shippingPage = checkoutSignInPage.guestSignInAndContinue();	  
	}
	
	/*
	 * Added by Kxn8362
	 */
	@When("^I checkout as registered user$")
	public void i_checkout_as_registered_user() throws Throwable { 
	checkoutSignInPage.registerUserSignIn();
	  
	}

	@And("^I handle cart merge overlay$")
	public void i_handle_card_merge_overlay() throws Throwable { 
	checkoutSignInPage.verifyCartMergeOverlay();
	}
	
	@And("^I login as registered user$")
	public void i_login_as_registered_user() throws Throwable { 
		checkoutSignInPage.registerUserSignIn();
	}
	
	@And("^I see cart merge overlay and click continue checkout$")
	public void i_see_cart_merge_overlay_and_click_continue_checkout() throws Throwable { 
		checkoutSignInPage.cartMergeOverlayCheckoutBtn();
	}
	
	@And("^I see cart merge overlay and click edit cart$")
	public void i_see_cart_merge_overlay_and_click_edit_cart() throws Throwable {
		checkoutSignInPage.cartMergeOverlayEditCartBtn();
	}
	
	@And("^I see session expired error msg in secure checkout page$")
	public void i_see_session_expired_error_msg_in_secure_checkout_page() throws Throwable { 
		checkoutSignInPage.verifySessionExpiredErrMsg();
	}

	@Then("^I enter password for persistent user$")
	public void i_enter_password_for_persistent_user() throws Throwable {
		checkoutSignInPage.enterPwdForPersistentUser();

	}
	@And("^I click back button in secure signin page$")
	public void i_click_back_button_in_secure_signin_page() throws Throwable { 
		checkoutSignInPage.clickBackButton();
	}
	
	@And("^I verify all details in secure checkout page$")
	public void i_verify_all_details_in_secure_checkout_page() throws Throwable { 
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.verifyGuestCheckoutSection();
		checkoutSignInPage.verifyRegCheckoutSection();
		checkoutSignInPage.guestSignInAndContinue();
	  
	}
	
	@And("^I verify View Cart link is present and click it$")
	public void i_verify_View_Cart_link_is_present_and_click_it() throws Throwable { 
		checkoutSignInPage.verifyViewCartLink();	  
	}
	
	@And("^I verify Back to Cart buttons are not available$")
	public void i_verify_Back_to_Cart_buttons_are_not_available() throws Throwable { 
		checkoutSignInPage.verifyBackButtonNotAvailable();		  
	}
	
	@Then("^I see persistent sign in page$")
	public void i_see_persistent_sign_in_page() throws Throwable { 
		checkoutSignInPage.verifyPersistentSignInPage();	  
	}
	@And("^I donot see session expired error msg in secure checkout page$")
	public void i_donot_see_session_expired_error_msg_in_secure_checkout_page() throws Throwable { 
		checkoutSignInPage.verifySessionExpiredErrMsgNotPresent();	  
	}
	
	@And("^I verify View Cart link with qty same as in cart$")
	public void i_verify_View_Cart_link_with_qty_same_as_in_cart() throws Throwable { 
		checkoutSignInPage.verifyViewCartLinkQty();
	}
	@And("^I sigin with empty password in checkout signin page$")
	public void i_sigin_with_empty_password_in_checkout_signin_page() throws Throwable { 
		checkoutSignInPage.enterEmptyPwdForRegUser();
	}
	@And("^I sigin with wrong password in checkout signin page$")
	public void i_sigin_with_wrong_password_in_checkout_signin_page() throws Throwable { 
		checkoutSignInPage.enterWrongPwdForRegUser();	  
	}

	@And("^I verify persistent guest section$")
	public void i_verify_persistent_guest_section() throws Throwable {
		checkoutSignInPage.verifyPersistentGuestSection();
	}

	@And("^I verify pesrsitent email prepopulated$")
	public void i_verify_pesrsitent_email_prepopulated() throws Throwable {
		checkoutSignInPage.verifyPersistentEmailPopulated();
	}

	@And("^I verify persistent guest overlay$")
	public void i_verify_persistent_guest_overlay() throws Throwable {
		checkoutSignInPage.verifyPersistentGuestOverLay();
	}

	@And("^I click proceed to checkout button in overlay$")
	public void i_click_proceed_to_checkout_button_in_overlay() throws Throwable {
		checkoutSignInPage.clickProceedCheckoutInOverlay();
	}
	
	/***MLTC-2718***/	
	@And("^I see the prompt for guest option and click Proceed Checkout$")
	public void i_see_the_prompt_for_guest_option_and_click_Proceed_checkout() throws Throwable {
		checkoutSignInPage.verifyProceedGuestCheckout();
	}

	@And("^I click continue button$")
	public void i_click_continue_button() throws Throwable {
		checkoutSignInPage.clickContinueButton();
	}
	
	@And("^I checkout as existing user$")
	public void i_checkout_as_existing_user() throws Throwable { 
		checkoutSignInPage.existingUserSignIn();
	}
	
	//***************** Instant Rebates************************///


	@When("^I checkout as reg user$")
	public void i_checkout_as_reg_user() throws Throwable {

		commonData.strEmail = "";
		commonData.strPassword = "";

		commonData.strEmail = dataTable.getCommonData(CommonDataColumn.RegUserEmail);
		System.out.println(commonData.strEmail);
		commonData.strPassword = dataTable.getCommonData(CommonDataColumn.RegUserPwd);
		System.out.println(commonData.strPassword);

		checkoutSignInPage.registerUserSignIn();

	}

	
	
}
