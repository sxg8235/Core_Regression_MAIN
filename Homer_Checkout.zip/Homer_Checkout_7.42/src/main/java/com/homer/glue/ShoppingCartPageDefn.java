package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class ShoppingCartPageDefn extends BaseStepDefn {

	public ShoppingCartPageDefn(DataClass data) {
		super(data);

	}

	@Then("^I see Shopping Cart page$")
	public void i_see_Shopping_Cart_page() throws Throwable {

		shoppingCartPage.verifyShoppingCartPage();

	}

	@Then("^I see Shopping cart page with the intended product displaying the qty$")
	public void i_see_Shopping_cart_page_with_the_intended_product_displaying_the_qty() throws Throwable {
		shoppingCartPage.verifyShoppingCartPage();
		shoppingCartPage.verifyShoppingCartNotEmpty();
		shoppingCartPage.verifyShoppingCartPageForIntendedProduct();
		shoppingCartPage.verifyCartPageForSelectedQTY();

	}

	@And("^I see paypal express button is not displayed$")
	public void i_see_paypal_express_button_is_not_displayed() throws Throwable {

		shoppingCartPage.verifyPayPalBtnNotPresentCartPage();
	}

	@And("^I click checkoutNow in ShoppingCart page$")
	public void i_click_AddToCart_in_ShoppingCart_page() throws Throwable {

		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
	}

	@When("^I checkout as guest user$")
	public void i_checkout_as_guest_user() throws Throwable {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.guestSignInAndContinue();
	}

	@And("I checkout as guest user with existing mail id")
	public void i_checkout_as_guest_user_with_existing_mail_id() throws Exception {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.guestSignInWithExistingMailIdAndContinue("smokereguser@hd.com");
	}

	@When("^I select paypal checkout$")
	public void i_select_paypal_checkout() throws Throwable {
		shoppingCartPage.verifyPayPalBtnCartPg();
		shoppingCartPage.clickPaypalbuttonInCartPage();
	}

	@Then("^I see appliance delivery charge changes in cart page$")
	public void i_see_appliance_delivery_charge_changes_in_cart_page() throws Throwable {
		shoppingCartPage.verifyADCChanges();
	}

	@And("^I apply promotion in cart$")
	public void i_apply_promotion_in_cart() throws Throwable {

		shoppingCartPage.applyPromotion();

	}

	@Then("^I see how to get it section with delivery charge message displayed in cart page$")
	public void i_see_how_to_get_it_section_with_delivery_charge_message_displayed_in_cart_page() throws Throwable {

		shoppingCartPage.verifyHowToGetItSectionFreeDelMsg();
	}

	@Then("^I select bopis assembly option in cart$")
	public void i_select_bopis_assembly_option_in_cart() throws Throwable {
		shoppingCartPage.selectAssemblyOption();
	}

	@And("^I click Add to list in cart$")
	public void i_click_Add_to_list_in_cart() throws Throwable {
		shoppingCartPage.clickAddToListCart();
	}

	@Then("^I Sign in as registered user add to list$")
	public void i_Sign_in_as_registered_user_add_to_list() throws Throwable {
		myListOverlay.regUserSignInAddToList();
	}

	@And("^I add item to list$")
	public void i_add_item_to_list() throws Throwable {
		myListOverlay.addProdToListCart();
	}

	@Then("^I verify signed in user retained$")
	public void i_verify_signed_in_user_retained() throws Throwable {
		shoppingCartPage.verifySigneduserRetainedCart();
	}

	@And("^I click on signin link in cart header$")
	public void i_click_on_signin_link_in_cart_header() throws Throwable {
		shoppingCartPage.signInCartHeader(commonData.strEmail, commonData.strPassword);
	}

	@And("^I click express checkout in ShoppingCart page$")
	public void i_click_express_checkout_in_ShoppingCart_page() throws Throwable {
		shoppingCartPage.clickExpressCheckoutCart();
	}

	@When("^I remove an item from cart$")
	public void i_remove_an_item_from_cart() throws Throwable {
		shoppingCartPage.removeItemFromCart();
	}

	@Then("^I see loading icon on delay$")
	public void i_see_loading_icon_on_delay() throws Throwable {
		shoppingCartPage.verifyLoadingIconCart();
	}

	@When("^I click edit parts and services in cart$")
	public void i_click_edit_parts_and_services_in_cart() throws Throwable {
		shoppingCartPage.clickEditPartAndServices();
	}

	@When("^I click change zipcode appliance in cart$")
	public void i_click_change_zipcode_appliance_in_cart() throws Throwable {
		shoppingCartPage.clickChangeZipCodeAppliance();
	}

	@Then("^I perform check availability in overlay$")
	public void i_perform_check_availability_in_overlay() throws Throwable {
		applianceOverlay.checkAvailabilityApplOverlay();
	}

	@And("^I remove promotion from cart$")
	public void i_remove_promotion_from_cart() throws Throwable {
		shoppingCartPage.removePromoCart();
	}

	@Then("^I check protection plan tab$")
	public void i_check_protection_plan_tab() throws Throwable {
		shoppingCartPage = applianceOverlay.partsAndServicesProtectionPlanCartPage();
	}

	@And("^I check for no radio button in cart page$")
	public void i_check_for_no_radio_button_in_cart_page() throws Throwable {
		shoppingCartPage.verifyNoRadioButton();
	}

	@And("^I verify subtotal text in all pages$")
	public void i_verify_subtotal_text_in_all_pages() throws Throwable {
		shoppingCartPage.verifySubtotalTxt();
	}

	@And("^I click \"(.*?)\" for assembly sku$")
	public void i_click_arg1_for_assembly_sku(String arg1) throws Throwable {
		shoppingCartPage.clickAssemblyRadioButton(arg1);
	}

	@When("^I click on zip code look up arrow beside the zip code entry field$")
	public void i_click_on_zip_code_look_up_arrow_beside_the_zip_code_entry_field() throws Throwable {
		shoppingCartPage.clickBODFSZipCodeArrow();
	}

	@Then("^I see page refreshes and display the zip code as a read only text$")
	public void i_see_page_refreshes_and_display_the_zip_code_as_a_read_only_text() throws Throwable {
		shoppingCartPage.verifyBodfsReadOnlyZipCode();
	}

	@Then("^I see the zip code is retained in the zip code entry field$")
	public void i_see_the_zip_code_is_retained_in_the_zip_code_entry_field() throws Throwable {
		// shoppingCartPage.verifyReadOnlyZipCodeRetained();
		shoppingCartPage.verifyBodfsReadOnlyZipCode();

	}

	@When("^I click your account in cart$")
	public void i_click_your_account_in_cart() throws Throwable {
		shoppingCartPage.clickYourAccountInCart();
	}

	@And("^I change the fulfillment type from STH to BODFS$")
	public void i_change_the_fulfillment_type_from_STH_to_BODFS() throws Throwable {
		shoppingCartPage.verifyCartpageforBODFS_STHItem();
		shoppingCartPage.clickExpressDeliverRadiobutton();

	}

	// I change the fulfilment from bodfs to sth

	@When("^I enter invalid zipcode and click on zipcode lookup arrow$")
	public void i_enter_invalid_zipcode_and_click_on_zipcode_lookup_arrow() throws Throwable {
		shoppingCartPage.enterInvalidZipcodeBODFSCartpage();
		shoppingCartPage.clickBODFSZipCodeArrow();

	}

	@When("^I enter valid zipcode and click on zipcode lookup arrow$")
	public void i_enter_valid_zipcode_and_click_on_zipcode_lookup_arrow() throws Throwable {
		shoppingCartPage.entervalidZipcodeBODFSCartpage();
		shoppingCartPage.clickBODFSZipCodeArrow();

	}

	@Then("^I see page level error message for invalid zip code$")
	public void i_see_page_level_error_message_for_invalid_zip_code() throws Throwable {
		shoppingCartPage.verifyWrongZipocodeBODFSErrMsg();

	}

	@And("^I verify assembly yes message in cart$")
	public void i_verify_assembly_yes_message_in_cart() throws Throwable {
		shoppingCartPage.verifyAssemblyYesMessage();
	}

	@Then("^I clear the qty of an item in cart$")
	public void i_clear_the_qty_of_an_item_in_cart() throws Throwable {
		shoppingCartPage.clearQtyCartPg();
	}

	@And("^I verify qty error message displayed in cart$")
	public void i_verify_qty_error_message_displayed_in_cart() throws Throwable {
		shoppingCartPage.verifyQtyErrorMessage();
	}

	@When("^I Enter Zip code\\(no inv\\) and click checkout now button$")
	public void i_Enter_Zip_code_no_inv_and_click_checkout_now_button() throws Throwable {
		shoppingCartPage.changeZipcodeForBODFSItem();
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
	}

	@Then("^I see item not in stock for delivery error message$")
	public void i_see_item_not_in_stock_for_delivery_error_message() throws Throwable {
		shoppingCartPage.verifyItemNotInStockErrMsg();
	}


	@And("^I verify item level error message (\\d+) in stock for the selected ZIP code$")
	public void i_verify_item_level_error_message_0_in_stock_for_the_selected_ZIP_code() throws Throwable {
		shoppingCartPage.verifyZeroInvErrorMsg();
	}

	@And("^UnitPrice displayed in cart is equivalent to the price in Cassandra DB$")
	public void unitPrice_displayed_in_cart_is_equivalent_to_the_price_in_Cassandra_DB() throws Throwable {
		shoppingCartPage.verifyUnitPriceCart();
	}

	@And("^ItemTotal displayed in the Cart is equivalent to the price in Cassandra DB$")
	public void itemTotal_displayed_in_the_Cart_is_equivalent_to_the_price_in_Cassandra_DB() throws Throwable {
		shoppingCartPage.verifyTotalPriceCart();
	}

	@And("^Subtotal displayed is the sum of the Item total of all the items in cart$")
	public void subtotal_displayed_is_the_sum_of_the_Item_total_of_all_the_items_in_cart() throws Throwable {
		shoppingCartPage.verifySubTotalCart();
	}

	@When("^I Increase the qty$")
	public void i_Increase_the_qty() throws Throwable {
		shoppingCartPage.increaseItemQtyCartPage();
	}

	@Then("^I see Earliest delivery date should be displayed$")
	public void i_see_Earliest_delivery_date_should_be_displayed() throws Throwable {
		shoppingCartPage.verifyEarliestDeliveryEstimateDate();
	}

	@And("^I verify the IDM sur_charge is applicable or not$")
	public void i_verify_the_IDM_sur_charge_is_applicable_or_not() throws Throwable {

	}

	@And("^I verify the Calculated Shipping charges is less than or equal to defined LIM from DB$")
	public void i_verify_the_Calculated_Shipping_charges_is_less_than_or_equal_to_defined_LIM_from_DB()
			throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@And("^Estimated Subtotal is the sum of all the totals$")
	public void estimated_Subtotal_is_the_sum_of_all_the_totals() throws Throwable {
		shoppingCartPage.verifyEstimatedSubtotal();
	}

	@And("^I click sth radio button in cart$")
	public void i_click_sth_radio_button_in_cart() throws Throwable {
		shoppingCartPage.clickShipToHomeRadioButton();
	}

	@And("^I click change store and update cart$")
	public void i_click_change_store_and_update_cart() throws Throwable {
		shoppingCartPage.clickchangeStoreAndUpdateCart();

	}

	@When("^I change BODFS zipcode in cart page$")
	public void i_change_BODFS_zipcode_in_cart_page() throws Throwable {
		shoppingCartPage.clickChangeLinkBODFSItem();
		shoppingCartPage.changeZipcodeForBODFSItem();
		shoppingCartPage.clickBODFSZipCodeArrow();
		shoppingCartPage.getDeliveryPriceOfBODFSITem();
	}

	@And("^I verify Order summary section should be present on cart page$")
	public void i_verify_Order_summary_section_should_be_present_on_cart_page() throws Throwable {
		shoppingCartPage.verifyCartOrderSummarySection();
	}

	@And("^I verify Cart Subtotal is sum of all line items total$")
	public void i_verify_Cart_Subtotal_is_sum_of_all_line_items_total() throws Throwable {
		shoppingCartPage.compareLineItemTotalInCartWithSubTotal();
	}

	@And("^I check changed store price in Cassandra DB$")
	public void i_check_changed_store_price_in_Cassandra_DB() throws Throwable {

		String sku = dataTable.getData(DataColumn.SKU);
		String store = commonData.alternateStore;
		String unitPrice1 = "";

		if (checkoutConfig.readPriceFromCassandra) {

			unitPrice1 = database.getPriceFromCassandraRefAPP(sku, store);
			// String unitPrice1 =
			// cassandraDB.getAlternateStorePriceCassandraDB(sku, store);

		} else {

			if (checkoutConfig.readFromPricingAPI) {
				unitPrice1 = database.getUnitPriceFromPricingService(sku, store);
			}

			report.addReportStep("Read From Cassndra", "Read From cassandra feature switch is off", StepResult.DONE);
		}

		if (!unitPrice1.equals("")) {
			commonData.priceRead = true;
		}
	}

	@And("^UnitPrice displayed in cart is equivalent to the certona price$")
	public void unitPrice_displayed_in_cart_is_equivalent_to_the_certona_price() throws Throwable {
		shoppingCartPage.verifyUnitPriceCartWithCertona();
	}

	@And("^I see only schedule delivery fulfillment with no radio buttons in buy box$")
	public void i_see_only_schedule_delivery_fulfillment_with_no_radio_buttons_in_buy_box() throws Throwable {
		shoppingCartPage.VerifyBODFSOnlyfulfillmentInCart();
		shoppingCartPage.verifyNoRadioButton();
	}

	@Then("^I see the availblity with Zip code,cheapest cost and earliest delivery date$")
	public void i_see_the_availblity_with_Zip_code_cheapest_cost_and_earliest_delivery_date() throws Throwable {
		shoppingCartPage.verifyBodfsReadOnlyZipCode();
		shoppingCartPage.verifyEarliestDeliveryEstimateDate();
	}

	@And("^I see price deatails in Shopping Cart page$")
	public void i_see_price_deatails_in_Shopping_Cart_page() throws Throwable {
		wh.waitForPageLoaded();
		if (rc.isProdEnvironment()) {

			report.addReportStep("Verify Price details in Prod Env", "We do not validate Prod Price details with DB",
					StepResult.WARNING);

		} else {
			shoppingCartPage.verifyUnitPriceCart();
			shoppingCartPage.verifyTotalPriceCart();
			shoppingCartPage.verifySubTotalCart();
			shoppingCartPage.verifyEstimatedSubtotal();
		}
	}

	@And("^I verify delivery price in shopping cart page$")
	public void i_verify_delivery_price_in_shopping_cart_page() throws Throwable {
		shoppingCartPage.getDeliveryPriceOfBODFSITem();
	}

	@Then("^I see the same delivery price$")
	public void i_see_the_same_delivery_price() throws Throwable {
		shoppingCartPage.verifyDelvryPriceSameAsInShoppingCartPage();
	}

	@Then("^I see BODFS availability date is retained$")
	public void i_see_bodfs_availability_date_is_retained() throws Exception {
		shoppingCartPage.verifyEarliestdeliveryDateIsRetained();
	}

	@Then("^I see the multiple products added in cart$")
	public void i_see_multiple_productes_in_cart() {
		shoppingCartPage.verifyMultipleProductsIncart();
	}

	@When("^I Perform check availability for the BODFS item with the same zip code$")
	public void i_Perform_check_availability_for_the_BODFS_item_with_the_same_zip_code() throws Throwable {
		shoppingCartPage.getDeliveryPriceOfBODFSITem();
		shoppingCartPage.clickBODFSZipCodeArrow();
		shoppingCartPage.verifyBodfsReadOnlyZipCode();
	}

	@Then("^I update the qty of an item in cart$")
	public void i_update_the_qty_of_an_item_in_cart() throws Throwable {
		shoppingCartPage.updateQtyCartPg();
	}

	@When("^I Perform check availability for the BODFS item with the different zip code$")
	public void i_Perform_check_availability_for_the_BODFS_item_with_the_different_zip_code() throws Throwable {
		shoppingCartPage.getDeliveryPriceOfBODFSITem();
		shoppingCartPage.changeZipcodeForBODFSItem();
		shoppingCartPage.clickBODFSZipCodeArrow();
		shoppingCartPage.verifyBodfsReadOnlyZipCode();
	}

	@Then("^I see the different delivery price$")
	public void i_see_the_different_delivery_price() throws Throwable {
		shoppingCartPage.verifyDelvryPriceDifferentAsInShoppingCartPage();
	}

	@When("^I Enter Zip code \\(No contract\\) and click checkout now button$")
	public void i_Enter_Zip_code_No_contract_and_click_checkout_now_bu_74tton() throws Throwable {
		shoppingCartPage.changeZipcodeForBODFSItem();
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
	}

	@Then("^I see item not available for delivery error message \"(.*?)\"$")
	public void i_see_item_not_available_for_delivery_error_message_arg1(String arg1) throws Throwable {
		shoppingCartPage.VerifyItemNotAvailForDelvryinZipErrMsg();
	}

	@And("^I verify item level error message \\(Item not available for the selected ZIP code\\)$")
	public void i_verify_item_level_error_message_Item_not_available_for_the_selected_ZIP_code() throws Throwable {
		shoppingCartPage.verifyItemNotAvailForSelectZipErr();
	}

	@Then("^I verify item store changed in cart$")
	public void i_verify_item_store_changed_in_cart() throws Throwable {
		shoppingCartPage.verifyItemStoreChanged();
	}

	@Then("^I verify item store is not changed in cart$")
	public void i_verify_item_store_is_not_changed_in_cart() throws Throwable {
		shoppingCartPage.verifyItemStoreNotChanged();
	}

	@And("^I click product image to navigate to PIP$")
	public void i_click_product_image_to_navigate_to_PIP() throws Throwable {
		shoppingCartPage.clickProductImage();
	}

	@And("^I click pickup in store radio button in cart$")
	public void i_click_pickup_in_store_radio_button_in_cart() throws Throwable {
		shoppingCartPage.clickPickUpInStoreRadioButton();
	}

	@And("^I click BODFS radio button in cart$")
	public void i_click_BODFS_radio_button_in_cart() throws Throwable {
		shoppingCartPage.clickExpressDeliverRadiobutton();

	}

	@And("^I click ship to store radio button in cart$")
	public void i_click_ship_to_store_radio_button_in_cart() throws Throwable {
		shoppingCartPage.clickShipToStoreRadioButton();
	}

	@And("^I click copy link in cart for blinds$")
	public void i_click_copy_link_in_cart_for_blinds() throws Throwable {
		shoppingCartPage.clickCopyCustomDetailBlinds();
	}

	@And("^I click Add this to cart button for blinds$")
	public void i_click_Add_this_to_cart_button_for_blinds() throws Throwable {
		shoppingCartPage.clickAddThisToCartBlinds();
	}

	@Then("^I see Limited availabilty for delivery error message displayed at page level$")
	public void i_see_limited_availability_for_delivery_error_message_displayed_at_page_level() throws Exception {
		shoppingCartPage.verifyLimitedInStockErrMsg();
	}


	@And("^I see item level error message displayed for all items$")
	public void i_see_item_level_error_message_displayed_for_all_items() throws Exception {
		shoppingCartPage.verifyLimitedItemForSelectZipErr();
	}

	@And("^I verify promo section in cart for each item$")
	public void i_verify_promo_section_in_cart_for_each_item() throws Exception {
		shoppingCartPage.verifyPromoForEachItem();
	}

	@And("^I see click on see details link displayed against the promotion below each line item$")
	public void i_see_click_on_see_details_link_displayed_against_the_promotion_below_each_line_item()
			throws Exception {
		shoppingCartPage.verifySeeDetailsInPromoSection();
	}

	@And("^I see You saved Section$")
	public void i_see_you_saved_section() throws Exception {
		shoppingCartPage.verifyYouSavedSection();
	}

	@And("^I get order level promo value$")
	public void i_get_order_level_promo_value() throws Exception {
		shoppingCartPage.getOrderLevelPromo();
	}

	@And("^I verify promotion discount$")
	public void i_verify_promotion_discount() throws Exception {
		shoppingCartPage.verifyPromotionDiscountForCartPg();
	}
	
	@And("^I get total with promo$")
	public void i_get_total_with_promo() throws Exception
	{
		shoppingCartPage.getTotalWithPromo();
	}
	
	@And("^I get total without promo$")
	public void i_get_total_without_promo() throws Exception
	{
		shoppingCartPage.getTotalWithoutPromo();
	}
	
	@And("^I see You saved Section is not displayed$")
	public void i_see_you_saved_section_is_not_displayed() throws Exception
	{
		shoppingCartPage.verifyYouSavedNotDisplayed();
	}
	
	@And("^I verify order total is recalculated in cart page$")
	public void i_verify_order_total_is_recalculated_in_cart_page() throws Exception
	{
		shoppingCartPage.verifyTotalRecalculated();
	}
	
	@And("^I verify remove link is displayed in cart$")
	public void i_verify_remove_link_is_displayed_in_cart() throws Exception
	{
		shoppingCartPage.verifyRemoveLinks();
	}

	// ****************This section is for HDPP*******************************

	@And("^I see HDPP item in cart$")
	public void I_see_HDPP_item_in_cart() throws Throwable {
		shoppingCartPage.verifyHDPPItem();
	}

	@And("^I see Add Plan option in the cart$")
	public void I_see_Add_Plan_option_in_the_cart() throws Throwable {
		shoppingCartPage.verifyAddPlan();
	}

	// And I do not see HDPP item in cart

	@And("^I do not see Add Plan option in the cart$")
	public void I_do_not_see_Add_Plan_option_in_the_cart() throws Throwable {
		shoppingCartPage.verifyNoAddPlan();
	}

	// I verify mini cart quantity
	@And("^I verify mini cart quantity$")
	public void I_verify_mini_cart_quantity() throws Throwable {
		shoppingCartPage.calculateQtyAllItems();
		shoppingCartPage.verifyMiniCart();
	}

	@And("^I verify mini cart quantity for merged cart$")
	public void I_verify_mini_cart_quantity_for_merged_cart() throws Throwable {
		shoppingCartPage.verifyMiniCartMerged();
	}

	@When("^I click Add Plan in the cart$")
	public void I_click_Add_Plan_in_the_cart() throws Throwable {
		shoppingCartPage.clickAddPlan();
	}

	@Then("^I see plan added in the cart$")
	public void I_see_plan_added_in_the_cart() throws Throwable {
		shoppingCartPage.verifyPlanAdded();
	}

	@Then("^I see Add to List and Remove links for HDPP$")
	public void I_see_Add_to_List_and_Remove_links_for_HDPP() throws Throwable {
		shoppingCartPage.verifyAddtoList();
		shoppingCartPage.verifyRemoveLinks();

	}

	@And("^I verify Subtotal displayed is the sum of the Item total of all the items in cart for HDPP$")
	public void I_verify_Subtotal_displayed_is_the_sum_of_the_Item_total_of_all_the_items_in_cart_for_HDPP()
			throws Throwable {

		shoppingCartPage.compareLineItemTotalInCartWithSubTotal();

	}

	@And("^I verify Estimated Subtotal is the sum of all the totals$")
	public void I_verify_estimated_Subtotal_is_the_sum_of_all_the_totals() throws Throwable {
		shoppingCartPage.verifyEstimatedSubtotal();

	}

	@And("^Estimated Subtotal for bopis is the sum of all the totals$")
	public void Estimated_Subtotal_for_bopis_is_the_sum_of_all_the_totals() throws Throwable {
		shoppingCartPage.verifyEstimatedSubtotalbopis();

	}

	@Then("^I increase the quantity of the plan$")
	public void I_increase_the_quantity_of_the_plan_and_verify_updated_quantity_in_the_cart() throws Throwable {
		shoppingCartPage.increasePlanQuantity();

	}

	@Then("^I decrease the quantity of the plan$")
	public void I_decrease_the_quantity_of_the_plan_and_verify_updated_quantity_in_the_cart() throws Throwable {
		shoppingCartPage.decreasePlanQuantity();

	}

	@Then("^I see the plan quantity alone updated$")
	public void I_see_the_plan_quantity_alone_updated() throws Throwable {
		shoppingCartPage.verifyNoChangeInPlanQty();

	}

	@Then("^I see item and HDPP plan quantity getting updated$")
	public void I_see_item_and_HDPP_plan_quantity_getting_updated() throws Throwable {
		shoppingCartPage.verifyItemAndPlanqty();

	}

	@Then("^I see the HDPP plan getting increased$")
	public void I_see_the_HDPP_plan_getting_increased() throws Throwable {
		shoppingCartPage.verifyIncreasedPlanqty();

	}

	@Then("^I see the HDPP plan getting decreased$")
	public void I_see_the_HDPP_plan_getting_decreased() throws Throwable {
		shoppingCartPage.verifyDecreasedPlanqty();

	}

	@Then("^I see quantity with the HDPP plan updated$")
	public void I_see_quantity_with_the_HDPP_plan_updated() throws Throwable {
		shoppingCartPage.verifyPlanqtyBOPIS();

	}

	@And("^I apply order level promotion in cart$")
	public void I_apply_order_level_promotion_in_cart() throws Throwable {
		shoppingCartPage.applyPromotion();

	}

	@And("^I verify the promotion is not applied on HDPP$")
	public void I_verify_the_promotion_is_not_applied_on_HDPP() throws Throwable {
		shoppingCartPage.verifyPromoforHDPP();

	}

	@And("^I verify the promotion is  applied on HDPP$")
	public void I_verify_the_promotion_is__applied_on_HDPP() throws Throwable {
		shoppingCartPage.verifyPromoApplyHDPP();

	}

	@When("^I click on remove link of the plan$")
	public void I_click_on_remove_link_of_the_plan() throws Throwable {
		shoppingCartPage.clickRemovePlanLink();

	}

	@When("^I remove the plan for the \"(.*?)\" item$")
	public void i_remove_the_plan_for_the_arg1_item(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		shoppingCartPage.clickRemovePlanLinkMixedCart();
	}

	// I click on remove link of 'sth' item
	@When("^I click on remove link of \"(.*?)\" item$")
	public void i_click_on_remove_link_of_the_arg1_item(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		shoppingCartPage.clickRemovePlanLinkMixedCart();
	}

	@When("^I clear plan quantity$")
	public void I_clear_plan_quantity() throws Throwable {
		shoppingCartPage.clearPlanQuantity();

	}

	// I make plan quantity to zero
	@When("^I make plan quantity to zero$")
	public void I_make_plan_quantity_to_zero() throws Throwable {
		shoppingCartPage.zeroPlanQuantity();

	}

	@Then("^I see HDPP removed from cart$")
	public void I_see_HDPP_removed_from_cart() throws Throwable {
		shoppingCartPage.verifyRemovePlanLink();

	}

	@Then("^I see Item removed from cart$")
	public void I_see_Item_removed_from_cart() throws Throwable {
		shoppingCartPage.verifyRemoveItemLink();

	}

	@When("^I click Learn More link$")
	public void I_click_Learn_More_link() throws Throwable {
		shoppingCartPage.clickLearnMore();

	}

	@Then("^I see the tool tip$")
	public void I_see_the_tool_tip() throws Throwable {
		shoppingCartPage.verifyToolTip();

	}

	@When("^I Decrease the qty$")
	public void i_Decrease_the_qty() throws Throwable {
		shoppingCartPage.decreaseItemQtyCartPage();
	}

	@When("^I see previous quantity without any updation in the item and the plan$")
	public void I_see_previous_quantity_without_any_updation_in_the_item_and_the_plan() throws Throwable {
		shoppingCartPage.verifyItemAndPlanqty();
	}

	// I see item and HDPP plan quantity are updated to the same

	@When("^I see item and HDPP plan quantity are updated to the same$")
	public void I_see_item_and_HDPP_plan_quantity_are_updated_to_the_same() throws Throwable {
		shoppingCartPage.verifyHDPPnItemQty();
	}

	@And("^I increase the quantity of item$")
	public void i_increase_the_quantity_of_item() throws Throwable {
		shoppingCartPage.increasefufilmentquantity();

	}

	@When("^I decrease the quantity of item$")
	public void i_decrease_the_quantity_of_item() throws Throwable {
		shoppingCartPage.decreasefufilmentquantity();
	}

	@When("^I make the quantity of the item to zero$")
	public void i_make_the_quantity_of_the_item_to_zero() throws Throwable {
		shoppingCartPage.clearfufilmentquantity();

	}

	@When("^I do not see the item and HDPP plan for the particular item$")
	public void i_do_not_see_the_item_and_HDPP_plan_for_the_particular_item() throws Throwable {
		shoppingCartPage.verifyNoItemPlan();

	}

	@When("^I make the quantity of the \"(.*?)\" plan item to zero$")
	public void i_make_arg1_plan_Quantity_to_zero(String arg1) throws Throwable {
		shoppingCartPage.clearPlanQuantity();

	}

	@Then("^I see HDPP plan getting decreased for the particular item$")
	public void I_see_HDPP_plan_getting_decreased_for_the_particular_item() throws Throwable {
		shoppingCartPage.verifyPlanqtyMixedCart();

	}

	@Then("^I see HDPP plan getting increased for the particular item$")
	public void I_see_HDPP_plan_getting_increased_for_the_particular_item() throws Throwable {
		shoppingCartPage.verifyPlanqtyMixedCart();

	}

	@And("^the \"(.*?)\" item should not be removed from the cart$")
	public void the_arg1_item_should_not_be_removed_from_the_cart(String arg1) throws Throwable {
		shoppingCartPage.verifyfulfilmentquantity();

	}

	@And("^I click boss radio button in cart$")
	public void i_click_boss_radio_button_in_cart() throws Throwable {
		shoppingCartPage.clickBOSSRadiobutton();
	}

	@When("^I click change pick up store in cart for bopis item and increase qty$")
	public void I_click_change_pick_up_store_in_cart_for_bopis_item() throws Throwable {
		shoppingCartPage.changePickupstoreNIncreaseQty();

	}

	@When("^I update the qty in overlay$")
	public void I_update_the_qty_in_overlay() throws Throwable {
		shoppingCartPage.IncreaseQtyOverlay();

	}

	@And("^the cart quantity is updated$")
	public void the_cart_quantity_is_updated() throws Throwable {
		shoppingCartPage.verifyMiniCartForHDPPSelectedQTY();

	}

	@And("^the cart quantity is updated after removing hdpp$")
	public void the_cart_quantity_is_updated_after_removing_hdpp() throws Throwable {
		shoppingCartPage.verifyMiniCartForHDPPRemovedQTY();

	}

	@And("^I see a proper guidance text before adding the HDPP$")
	public void I_see_a_proper_guidance_text_before_adding_the_HDPP() throws Throwable {
		shoppingCartPage.verifyGuidanceTextBefore();

	}

	@And("^I see a proper guidance text after adding the HDPP$")
	public void I_see_a_proper_guidance_text_after_adding_the_HDPP() throws Throwable {
		shoppingCartPage.verifyGuidanceTextAfter();

	}

	// I change the fulfilment from bodfs to sth
	@And("^I change the fulfilment from bodfs to sth$")
	public void I_change_the_fulfilment_from_bodfs_to_sth() throws Throwable {
		shoppingCartPage.bodfstoSth();

	}

	// And I click new list
	@And("^I click new list$")
	public void I_click_new_list() throws Throwable {
		shoppingCartPage.clickNewList();

	}

	@And("^the associated plan doesnt change$")
	public void the_associated_plan_doesnt_change() throws Throwable {
		shoppingCartPage.verifyHDPPItem();
	}

	@And("^I see the plan as a separate line item$")
	public void I_see_the_plan_as_a_separate_line_item() throws Throwable {
		shoppingCartPage.verifySeparatelineitem();

	}

	@Then("^I delete user session cookie in cart page$")
	public void I_delete_user_session_cookie_in_cart_page() throws Throwable {
		shoppingCartPage.deleteUserSession();

	}

	@And("^I click Add to list in cart for plan$")
	public void I_click_Add_to_list_in_cart_for_plan() throws Throwable {
		shoppingCartPage.clickAddToListCartforPlan();

	}

	@And("^I see Schedule Delivery label in Cart page$")
	public void i_see_Schedule_delivery_label_in_cart_Page() {
		shoppingCartPage.verifySceduleDeliveryLabel();
	}

	@And("^I verify Express Delivery from store label is displayed in the How to Get it section$")
	public void i_verify_if_the_Express_Delivery_from_Store_label_is_displayed_in_the_How_to_get_it_section()
			throws Exception {
		shoppingCartPage.verifyExpressDeliveryLabelInHowToGetSection();
	}

	@And("^I verify estimated express delivery label is displayed in Order total section$")
	public void i_verify_if_the_express_delivery_label_is_displayed_in_order_total_section() throws Exception {
		shoppingCartPage.verifyExpressDeliveryLabelInOrderTotalSection();
	}

	// *************The above sction is for HDPP*******************************

	@And("^I navigte to cart through jumpurl$")
	public void i_navigte_to_cart_through_jumpurl() throws Throwable {
		shoppingCartPage.navigateMCCCart();
	}

	@And("^I click edit link in cart for blinds$")
	public void i_click_edit_link_in_cart_for_blinds() throws Throwable {
		shoppingCartPage.clickEditCustomDetailBlinds();

	}

	@And("^I update room selector for blinds$")
	public void i_update_room_selector_for_blinds() throws Throwable {
		shoppingCartPage.updateRoomSelectorBlinds();
	}

	@And("^I click Update my cart button for blinds$")
	public void i_click_Update_my_cart_button_for_blinds() throws Throwable {
		shoppingCartPage.clickUpdateCartBlinds();
	}

	@And("^I click change zipcode link in cart page$")
	public void i_click_change_zipcode_link_in_cart_page() throws Throwable {
		shoppingCartPage.clickChangeLinkBODFSItem();
	}

	@And("^I verify all details in cart page$")
	public void i_verify_all_details_in_cart_page() throws Throwable {
		shoppingCartPage.verifyShoppingCartPage();
		shoppingCartPage.verifyUnitPriceCart();
		shoppingCartPage.verifyTotalPriceCart();
		shoppingCartPage.verifySubTotalCart();
		shoppingCartPage.verifyEstimatedSubtotal();
		shoppingCartPage.clearQtyCartPg();
		shoppingCartPage.clickCheckoutNow();
		shoppingCartPage.verifyQtyErrorMessage();
		shoppingCartPage.updateQtyCartPg();
		shoppingCartPage.clickCheckoutNow();
		shoppingCartPage.verifyQtyErrorMessage();
		shoppingCartPage.removeItemFromCart();
		shoppingCartPage.verifyLoadingIconCart();
	}

	@When("^I checkout to shipping page as guest$")
	public void i_checkout_to_shipping_page_as_guest() throws Throwable {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.guestSignInAndContinue();
		shippingPage.verifyShippingPage();
		shippingPage.verifyAllFields();
		shippingPage.enterShippingDetails();
	}

	@When("^I checkout to Pick up option page as guest$")
	public void i_checkout_to_Pick_up_option_page_as_guest() throws Throwable {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.guestSignInAndContinue();
		pickupPage.verifyPickupOptionPage();
		pickupPage.verifyAndCloseSaveTripOverlay();
	}

	@When("^I checkout to appliance delivery page as guest$")
	public void i_checkout_to_appliance_delivery_page_as_guest() throws Throwable {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.guestSignInAndContinue();
		applianceDelivery.verifyApplianceDeliveryPage();
		applianceDelivery.enterDeliveryAddress();
		applianceDelivery.selectDeliveryDate();
	}

	@When("^I checkout to express delivery page as guest$")
	public void i_checkout_to_express_delivery_page_as_guest() throws Throwable {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePage();
		checkoutSignInPage.guestSignInAndContinue();
		scheduleDeliveryPage.verifyScheduleDeliveryPage();
		scheduleDeliveryPage.enterScheduledDeliveryAddressMCC();
	}

	@And("^I see paypal express button is displayed$")
	public void i_see_paypal_express_button_is_displayed() throws Exception {
		shoppingCartPage.verifyPayPalBtnCartPg();
	}

	// To verify the required fulfillment sku is present in cart page
	@And("^I verify only \"(.*?)\" fulfillment in cart$")
	public void i_verify_the_fulfillment_in_cart_of_the_arg1_item(String arg1) throws Throwable {
		String skuType = arg1;
		if (skuType.equalsIgnoreCase("bopis")) {
			shoppingCartPage.verifyBOPIS();

		} else if (skuType.equalsIgnoreCase("sth")) {
			shoppingCartPage.verifyBOPIS();

		} else if (skuType.equalsIgnoreCase("boss")) {
			shoppingCartPage.verifyBOPIS();

		}

	}

	@Then("^I see Custom Blinds Item should be added to the cart page$")
	public void I_see_Custom_Blinds_Item_should_be_added_to_the_cart_page() throws Exception {
		shoppingCartPage.verifyCustomProdIncartPg();

	}

	@When("^I Click on the Copy Config link in the cart page$")
	public void i_click_on_the_copy_config_link_in_the_Cart_page() throws Exception {
		shoppingCartPage.CopyDesignLink();
	}

	@When("^I Do not update any configuration and Click Order My Blinds button$")
	public void i_do_not_update_any_configuration_and_click_order_my_blinds_button() throws Exception {
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@When("^I update any configuration and Click Order My Blinds button$")
	public void i_update_any_configuration_and_click_order_my_blinds_button() throws Exception {
		shoppingCartPage.updateColorInConfiguratorPage();
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@When("^I update width configuration and Click Order My Blinds button$")
	public void i_update_width_configuration_and_Click_Order_My_Blinds_button() throws Exception {
		shoppingCartPage.updateWidthInConfiguratorPage();
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@When("^I update height configuration and Click Order My Blinds button$")
	public void i_update_height_configuration_and_Click_Order_My_Blinds_button() throws Exception {
		shoppingCartPage.updateheightInConfiguratorPage();
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@When("^I update mount configuration and Click Order My Blinds button$")
	public void i_update_mount_configuration_and_Click_Order_My_Blinds_button() throws Exception {
		shoppingCartPage.updateMountInConfiguratorPage();
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@And("^I verify color updated for blinds item$")
	public void i_verify_color_updated_for_blinds_item() throws Throwable {
		shoppingCartPage.verifyColorUpdatedInCart();
	}

	@And("^I verify width updated for blinds item$")
	public void i_verify_width_updated_for_blinds_item() throws Throwable {
		shoppingCartPage.verifyWidthUpdatedInCart();
	}

	@And("^I verify height updated for blinds item$")
	public void i_verify_height_updated_for_blinds_item() throws Throwable {
		shoppingCartPage.verifyHeightUpdatedInCart();
	}

	@And("^I verify mount updated for blinds item$")
	public void i_verify_mount_updated_for_blinds_item() throws Throwable {
		shoppingCartPage.verifyMountUpdatedInCart();
	}

	@And("^I click custom details link for blinds item$")
	public void i_click_custom_details_link_for_blinds_item() throws Throwable {
		shoppingCartPage.clickCustomDetailsLink();
	}

	@And("^I verify custom attributes are displayed in the sequence")
	public void i_verify_custom_attributes_are_displayed_in_the_sequence() throws Exception {
		shoppingCartPage.verifyCustomAttrSequence();
	}

	@When("^I calculate total qty of all the items in cart$")
	public void i_calculate_total_qty_of_all_the_items_in_cart() throws Throwable {
		shoppingCartPage.calculateQtyAllItems();
	}

	@Then("^I close custom details overlay$")
	public void i_close_custom_details_overlay() throws Throwable {
		shoppingCartPage.closeCustomDetailsOverlay();
	}

	@And("^I verify cart is empty$")
	public void i_verify_cart_is_empty() throws Throwable {
		shoppingCartPage.verifyShoppingCartEmpty();
	}

	@And("^I verify invalid promo err msg in cart$")
	public void i_verify_invalid_promo_err_msg_in_cart() throws Throwable {
		shoppingCartPage.verifyInvalidPromoErrMsg();
	}

	@And("^I verify products in Cart$")
	public void i_verify_products_in_cart() throws Exception {
		shoppingCartPage.verifyProductsInCart();
	}

	@And("^I verify disclaimer message in cart page$")
	public void i_verify_disclaimer_message_in_cart_page() throws Throwable {
		shoppingCartPage.verifyDisclaimerMsgCart();
	}

	@And("^I verify express delivery radio is selected$")
	public void i_verify_express_delivery_radio_is_selected() throws Throwable {
		shoppingCartPage.verifyExpressDeliveryChecked();
	}

	@And("^I verify pickup in store radio is selected$")
	public void i_verify_pickup_in_store_radio_is_selected() throws Throwable {
		shoppingCartPage.verifyPickUpInstoreChecked();
	}

	@And("^I verify bulk pricing msg in cart$")
	public void i_verify_bulk_pricing_msg_in_cart() throws Throwable {
		shoppingCartPage.verifyBulkPricingMsgCart();
	}

	@And("^I see Bulk pricing message is being displayed and msg should remain static regardless of the qty ordered in cart$")
	public void i_see_bulkpricing_msg_is_being_displayed_and_msg_should_remain_static_regardless_of_the_qty_ordered_in_cart()
			throws Exception {
		shoppingCartPage.updateQtyCartPg();
		shoppingCartPage.verifyBulkPricingMsgCart();
	}

	@And("^I verify no assembly msg in cart$")
	public void i_verify_no_assembly_msg_in_cart() throws Throwable {
		shoppingCartPage.verifyAssemblyMsgNotDisplayed();
	}

	@And("^I verify assembly msg in cart for bopis item$")
	public void i_verify_assembly_msg_in_cart_for_bopis_item() throws Throwable {
		shoppingCartPage.verifyAssemblyMsg();
	}

	@Then("^I verify reduce qty error msg$")
	public void i_verify_reduce_qty_error_msg() throws Throwable {
		shoppingCartPage.verifyMoreQtyError();
	}

	@And("^I verify mini cart count with samples$")
	public void i_verify_mini_cart_count_with_samples() throws Throwable {
		shoppingCartPage.verifyMiniCartCountWithSamples();
	}

	@Then("^I see The STH default fullfillment options should be displayed in the cart page$")
	public void i_see_the_sth_default_fulfillment_options_should_be_displayed_in_the_cart_page() throws Exception {
		shoppingCartPage.verifyDefaultFullfillmentForSTHItems();
	}

	@Then("^I verify store updated in cart$")
	public void i_verify_store_updated_in_cart() throws Exception {
		shoppingCartPage.verifyStoreUpdatedInCart();
	}

	@When("^I click on view all custom details link$")
	public void i_click_on_view_all_custom_details_link() throws Exception {
		shoppingCartPage.clickViewAllCustomDetails();
	}

	@Then("^I see all the attributes of the blinds is displayed properly$")
	public void i_see_all_the_attributes_of_the_blinds_is_displayed_properly() throws Exception {
		shoppingCartPage.verifyCustomDetailOverlay();
		shoppingCartPage.closeCustomDetailsOverlay();
	}

	@And("^I leave the cart idle till session time out$")
	public void i_leave_the_cart_idle_till_session_time_out() {
		shoppingCartPage.simulateSessionExpiryCart();
	}

	@And("^I update the three attributes in configuration and Click Order My Blinds button$")
	public void i_update_the_three_attriibutes_in_configuration_and_click_order_my_blinds_button() throws Exception {
		shoppingCartPage.updateColorInConfiguratorPage();
		shoppingCartPage.updateheightInConfiguratorPage();
		shoppingCartPage.updateWidthInConfiguratorPage();
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@Then("^I see shopping Cart Page with the updated three attributes to the custom blind item$")
	public void i_see_shopping_cart_page_with_the_updated_three_attributes_to_the_custom_blind_item() throws Exception {
		shoppingCartPage.verifyColorUpdatedInCart();
		shoppingCartPage.verifyHeightUpdatedInCart();
		shoppingCartPage.verifyWidthUpdatedInCart();
	}

	@And("^I update all the attributes in configuration and Click Order My Blinds button$")
	public void i_update_all_the_attributes_in_configuration_and_click_Order_my_blinds_button() throws Exception {
		shoppingCartPage.updateColorInConfiguratorPage();
		shoppingCartPage.updateheightInConfiguratorPage();
		shoppingCartPage.updateWidthInConfiguratorPage();
		shoppingCartPage.updateRoomSelectorBlinds();
		shoppingCartPage.updateMountInConfiguratorPage();
		shoppingCartPage.clickOrderMyBlindsButton();
	}

	@Then("^I see shopping Cart Page with the updated all the attributes to the custom blind item$")
	public void i_see_shopping_cart_page_with_the_updated_all_the_attributes_to_the_custom_blind_item()
			throws Exception {
		shoppingCartPage.verifyColorUpdatedInCart();
		shoppingCartPage.verifyHeightUpdatedInCart();
		shoppingCartPage.verifyWidthUpdatedInCart();
		shoppingCartPage.verifyMountUpdatedInCart();
		shoppingCartPage.verifyRoomUpdatedInCart();
	}

	@And("^I Verify the total price before removing the Custom Blinds from cart$")
	public void i_verify_the_total_price_before_removing_the_custom_blinds_from_cart() throws Exception {
		shoppingCartPage.getCurrentOrderTotal();
	}

	@Then("^I see The total price should be updated accordingly after removinging the Custom Blinds from cart$")
	public void i_see_the_total_price_should_be_updated_accordingly_after_removinging_the_Custom_Blinds_from_cart()
			throws Exception {
		shoppingCartPage.verifyNewTotalNotSameAsPrev();
	}

	@When("^I Click the remove link for the custom blinds item in the cart$")
	public void i_click_the_remove_link_for_the_custom_blinds_item_in_the_cart() throws Exception {
		shoppingCartPage.removeItemFromCart();
	}

	@And("^I verify cart has no major appliance item in it$")
	public void i_verify_cart_has_no_major_appliance_item_in_it() throws Throwable {
		shoppingCartPage.clickMiniCartBtn();
		shoppingCartPage.verifyCartHasNoMajorApplianceInIt();
	}

	@And("^I verify cart has major appliance item in it$")
	public void i_verify_cart_has_major_appliance_item_in_it() throws Throwable {
		shoppingCartPage.clickMiniCartBtn();
		shoppingCartPage.verifyCartHasMajorApplianceInIt();
	}

	@And("^c")
	public void i_verify_cart_has_assembly_option_seleceted_or_not() throws Throwable {
		shoppingCartPage.clickMiniCartBtn();
		shoppingCartPage.verifyAssemblyOptionSelectedOrNot();
	}

	@And("^I verify cart has assembly item or not")
	public void i_verify_cart_has_assembly_item_or_not() throws Throwable {
		shoppingCartPage.clickMiniCartBtn();
		shoppingCartPage.verifyAssemblyOptionTextInCart();
	}

	@And("^I verify assembly error message in cart")
	public void i_verify_assembly_error_message_in_cart() throws Throwable {
		shoppingCartPage.verifyAssemblyErrorInCart();
	}

	@And("^I verify the discounted amount for Qualifying purchase$")
	public void i_verify_the_discounted_amount_for_qualifying_purchase() throws Exception {
		shoppingCartPage.verifyQualifierDiscountSection();
		shoppingCartPage.verifyQualifierDiscountTotal();
	}

	@And("I verify Boss Fullfillment in cart")
	public void i_verify_boss_fulfillment_in_cart() throws Exception {
		shoppingCartPage.verifyBOSS();
	}

	@And("I verify Bopis Fullfillment in cart")
	public void i_verify_bopis_fulfillment_in_cart() throws Exception {
		shoppingCartPage.verifyBOPIS();
	}

	@And("^I click change store in cart$")
	public void i_click_change_store_in_cart() throws Exception {
		shoppingCartPage.clickChangePickUpStoreLink();
	}

	@And("^I verify store present in cart$")
	public void i_verify_store_present_in_cart() throws Exception {
		shoppingCartPage.verifyStorePresentIncart();
	}

	@And("^I verify price present in cart$")
	public void i_verify_price_present_in_cart() throws Exception {
		shoppingCartPage.verifyPriceInCartPage();
	}

	@And("^I enter invalid promocode and verify promocode is invalid and case sensitive$")
	public void i_enter_invalid_promocode_and_verify_promocode_is_invalid_and_case_sensitive() throws Exception {
		shoppingCartPage.verifyPromocodeErrMsg();
	}

	@And("^I click on See Details Link$")
	public void i_click_on_see_details_link() throws Throwable {

		shoppingCartPage.clickSeeDetailsToolTip();
	}

	@And("^I verify Free haulaway is removed from Free Tool tip$")
	public void i_verify_free_haulaway_is_removed_from_Free_tool_tip() throws Throwable {
		shoppingCartPage.verifyFreeHaulAwayRemoved();
	}

	@And("^I verify \"(.*?)\" optional parts for appliance sku$")
	public void i_verify_arg1_optional_parts_for_appliance_sku(String arg1) throws Throwable {
		shoppingCartPage.verifyOptionlParts(arg1);
	}

	@And("^I verify cart is not empty$")
	public void i_verify_cart_is_not_empty() throws Throwable {
		shoppingCartPage.verifyShoppingCartNotEmpty();
	}

	@And("^I click mini cart button in header$")
	public void i_click_mini_cart_button_in_header() throws Throwable {
		shoppingCartPage.clickMiniCartBtn();
	}

	@And("^I get item count from cart$")
	public void i_get_item_count_from_cart() throws Throwable {
		shoppingCartPage.getItemCountCart();
	}

	@And("^I verify item count is same$")
	public void i_verify_item_count_is_same() throws Throwable {
		shoppingCartPage.compareItemTotalCart();
	}

	@Then("^I verify page level error in cart page$")
	public void i_verify_arg1_page_level_error_in_cart_page() throws Throwable {
		shoppingCartPage.verifyPageLevelError();
	}

	@Then("^I verify qty update is disabled for appliance$")
	public void i_verify_qty_update_is_disabled_for_appliance() throws Throwable {
		shoppingCartPage.verifyQtyBoxDisabled();
	}

	@When("^I click on remove for particular item$")
	public void i_click_on_remove_for_particular_item() throws Throwable {
		shoppingCartPage.clickRemoveLinkMixedCart();
	}

	@When("^I click on AddToCart in Cart Certona$")
	public void i_click_on_AddToCart_in_Cart_Certona() throws Throwable {
		shoppingCartPage.clickATCCertonaCart();
	}

	@And("^I click Add to list in cart for an item$")
	public void i_click_Add_to_list_in_cart_for_an_item() throws Throwable {
		shoppingCartPage.clickAddToListItemCart();
	}

	@And("^I see limited per order err msg$")
	public void i_see_limited_per_order_err_msg() throws Throwable {
		shoppingCartPage.verifyLimitPerOrderErrMsg();

	}

	@When("^I verify invalid or removed promo not displayed$")
	public void I_verify_invalid_or_removed_promo_not_displayed() throws Throwable {
		shoppingCartPage.verifyInvalidPromo();
	}

	@Then("^I select parts and services in overlay for new zip$")
	public void i_select_parts_and_services_in_overlay_for_new_zip() throws Throwable {
		shoppingCartPage = applianceOverlay.partsAndServicesProtectionPlanCartPage();
		applianceOverlay.selectProtectionPlan();
		applianceOverlay.clickSaveChangesBtn();
	}

	@And("^I verify parts and services overlay is displayed$")
	public void i_verify_parts_and_services_overlay_is_displayed() throws Throwable {
		shoppingCartPage.verifyPartAndServices();

	}

	@And("^I increase qty more than stock in overlay$")
	public void i_increase_qty_more_than_stock_in_overlay() throws Throwable {
		shoppingCartPage.increaseQtyMoreThanStockInOverlay();
	}

	@And("^I verify qty exceeds error msg in overlay$")
	public void i_verify_qty_exceeds_error_msg_in_overlay() throws Throwable {
		shoppingCartPage.verifyQtyExceedsErrorMsg();
	}

	@Then("^I increase qty more than limit per order in overlay$")
	public void i_increase_qty_more_than_limit_per_order_in_overlay() throws Throwable {
		shoppingCartPage.increaseQtyLimitPerOrder();
	}

	@And("^I verfiy warning msg on price update for BODFS$")
	public void i_verfiy_warning_msg_on_price_update_for_BODFS() throws Throwable {
		shoppingCartPage.verifyWarningMsgOnZipCdChangeBODFS();
	}
	
	@And("^I verify the count down timer displayed for parcel sth sku$")
	public void i_verify_the_count_down_timer_dispalyed_for_parcel_sth_sku() throws Exception
	{
		shoppingCartPage.verifyCountDownTimer();
	}
	
	@Then("I verify the Estimated arrival is displayed for parcel sth sku$")
	public void i_verify_the_Estimated_arrival_is_displayed_for_parcel_sth_sku() throws Exception
	{
		shoppingCartPage.verifyEstimatedArrival();
	}
	
	@And("^I verify From Value for STH in Cart$")
	public void i_verify_from_value_for_sth_in_cart() throws Exception
	{
		shoppingCartPage.verifyFromValueSTH();
	}
	
	@And("^I increase to the threshold qty and click update$")
	public void i_increase_to_the_threshold_qty_and_click_update() throws Exception
	{
		shoppingCartPage.updateQtyAbvThreshold();
	}
	
	@Then("^I increase to the threshold qty and verify discounted price$")
	public void i_increase_to_the_threshold_qty_and_verify_discounted_price() throws Exception
	{
		shoppingCartPage.quantUpdateEqualThresh();
	}
	
	@Then("^I see Summary Section for only Merchandise$")
	public void i_see_summary_section_for_only_Merchandise()
	{
		shoppingCartPage.verifySummarySecMerch();
	}
	
	@Then("I see Summary Section for both Merchandise")
	
	
	

	// **********Instant Rebate**********************//

	@And("^I check price and store promotion in cart$")
	public void i_check_price_and_store_promotion_in_cart() throws Throwable {

		shoppingCartPage.getpricedetails(database);
	}

	@And("^I check price and store promotion for merged cart$")
	public void i_check_price_and_store_promotion_for_merged_cart() throws Throwable {

		shoppingCartPage.getpricedetails(database);

	}

	@Then("^I verify IR message in cart$")
	public void i_verify_IR_message_in_cart() throws Throwable {

		shoppingCartPage.verifyIRmessageinCart();
	}

	@And("^I remove all items in cart$")
	public void i_remove_all_items_in_cart() throws Throwable {
		shoppingCartPage.removeallitems();
		commonData.skuList.clear();
	}

	@And("^I change store from cart header$")
	public void I_change_store_from_cart_header() throws Throwable {

		commonData.localizestore = dataTable.getData(DataColumn.storeID);
		shoppingCartPage.headerlocalization();
	}

	@When("^I click pickup in store radio button in cart(\\d+)$")
	public void i_click_pickup_in_store_radio_button_in_cart1() throws Throwable {

		shoppingCartPage.pickupStore();
	}

	@And("^I check price and store promotion for STH in cart$")
	public void i_check_price_and_store_promotion_for_STH_in_cart() throws Throwable {

		String sku = commonData.sku;
		String store = dataTable.getData(DataColumn.LocalizeStore);
		database.getUnitPriceFromPricingService(sku, store);
		commonData.IRList1.add(commonData.shortdesc);
		commonData.PriceList1.add(commonData.unitPriceDB);

	}

	@When("^I click sth radio button in cart(\\d+)$")
	public void i_click_sth_radio_button_in_cart1() throws Throwable {

		shoppingCartPage.sthradiobtn();
	}

	@And("^I signin as registered user$")
	public void i_signin_as_registered_user() throws Throwable {

		shoppingCartPage.signInreguser();
	}

	@And("^I validate the fulfilment selected in cart$")
	public void i_validate_the_fulfilments_selected_in_cart() throws Throwable {

		shoppingCartPage.Fulfilmenttype();
	}

	@And("^I click change store and select multiple pickup store$")
	public void i_click_change_store_and_select_multiple_pickup_store() throws Throwable {

		shoppingCartPage.MultiplePickupStore();
		commonData.skuList.add(commonData.sku);

	}

	@And("^I localize from cart header$")
	public void I_localize_from_cart_header() throws Throwable {

		commonData.localizestore = dataTable.getData(DataColumn.multistoreID);
		shoppingCartPage.headerlocalization();
	}

	@And("^I checkout to shipping page as Reg user$")
	public void i_checkout_to_shipping_page_as_Reg_user() throws Throwable {
		shoppingCartPage.clickCheckoutNowBtn();
		shippingPage.verifyShippingPage();
	}

	@And("^I Enter Zip code and click the arrow mark in cart$")
	public void i_Enter_Zip_code_and_click_the_arrow_mark_in_cart() throws Throwable {
		shoppingCartPage.changeZipcodeForBODFSItem();
		shoppingCartPage.clickBODFSZipCodeArrow();
	}

	@And("^I get Product description$")
	public void i_get_Product_description() throws Throwable {
		int noOfItems = commonData.skuList.size();
		for (int i = 0; i < noOfItems; i++) {
			String sku = commonData.skuList.get(i);
			shoppingCartPage.getProdDescription(sku);
			commonData.Proddesc.add(commonData.prodDescription);
		}

	}

	// **********End of Instant Rebate**********//
	
	@And("^I verify signin overlay and signin$")
	public void i_verify_signin_overlay_and_signin() throws Throwable {
		shoppingCartPage.signInAddToList(commonData.strEmail, commonData.strPassword);
	}
	
	@And("^I veify add to list popup in cart$")
	public void i_veify_add_to_list_popup_in_cart() throws Throwable {
		shoppingCartPage.verifyAddToListOverlay();
	}

	@And("^I verify invalid zipcode error in overlay$")
	public void i_verify_invalid_zipcode_error_in_overlay() throws Throwable {
		shoppingCartPage.verifyErrMsgInvalidZipAppliance();
	}
	
	@And("^I verify delivery unavailable error msg in overlay$")
	public void i_verify_delivery_unavailable_error_msg_in_overlay() throws Throwable {
		shoppingCartPage.verifyDeliveryUnavailAppliance();
	}
	
	@And("^I enter quantity greater than available quantity$")
    public void i_enter_quantity_greater_than_available_quantity() throws Throwable {
		shoppingCartPage.enterQtyMoreThanAvailable();
    }
	
	@And ("^I see page level Error message on overlay$")
	 public void i_see_Error_message_on_overlay() throws Exception {
	  shoppingCartPage.verifyQuantityExceedsErrMsgonOverlay();
	}

	@And("^I verify backorder error msg$")
	public void i_verify_backorder_error_msg() throws Throwable {
		shoppingCartPage.verifyBackorderMsg();
	}

	@And("^I increase the qty and verify limit per order err msg$")
	public void i_increase_the_qty_and_verify_limit_per_order_err_msg() throws Throwable {
		shoppingCartPage.verifyLimitperOrderMsg();
	}

	@Then("^I verify warning message for promo applied in cart$")
	public void i_verify_warning_message_for_promo_applied_in_cart() throws Throwable {
		shoppingCartPage.verifyWarningMsgPromo();
	}
	
	@Then("^I verify no error msg is displayed in cart$")
	public void i_verify_no_error_msg_is_displayed_in_cart() throws Throwable { 
		shoppingCartPage.verifyNoErrorCartPage();	  
	}

	@And("^I verify warning msg in overlay for BOSS$")
	public void i_verify_warning_msg_in_overlay_for_BOSS() throws Throwable {
		shoppingCartPage.verifyWarningBOSSInOverlay();
	}
	
	@When("^I checkout as guest user and verify guest user ID is not prepopulated$")
	public void i_checkout_as_guest_user_and_verify_guest_user_Id_is_not_prepopulated() throws Throwable {
		checkoutSignInPage = shoppingCartPage.clickCheckoutNow();
		checkoutSignInPage.verifySecurePageGuest();
	
	}

	@And("^I verify estimate subtotal varies after removing item$")
	public void i_verify_estimate_subtotal_varies_after_removing_item() throws Throwable {
		shoppingCartPage.checkEstimatedTotAftrRmvingItem();
	}
	
	@And("^I verify free shipping eligible message in cart page$")
	public void i_verify_free_shipping_eligible_message_in_cart_page() throws Throwable {
		shoppingCartPage.freeShippingEligibleMsg();
	}
	
	@And("^I verify free shipping message in cart page$")
	public void i_verify_free_shipping_message_in_cart_page() throws Throwable {
		shoppingCartPage.freeShippingMsg();
	}
	
	@And("^I verify promo section in cart page$")
	public void i_verify_promo_section_in_cart_page() throws Throwable {
		shoppingCartPage.verifyPromoSection();
	}
	
	@And("^I click on prod description in cart page$")
	public void i_click_on_prod_description_in_cart_page() throws Throwable {
		shoppingCartPage.shoppingCartItemDesc();
	}
	
	@And("^I remove second item in cart$")
	public void i_remove_second_item_in_cart() throws Throwable {
		shoppingCartPage.removeSecondItem();
		
	}
	
	@And("^I update the qty of multiple item in cart$")
	public void i_update_the_qty_of_multiple_item_in_cart() throws Throwable {

		shoppingCartPage.updatemulitemQtyCartPg();
	}
	
	@And("^I verify cart merge in cart page$")
	public void i_verify_cart_merge_in_cart_page() throws Throwable {
		shoppingCartPage.verifyCartMerge();
	}

}
