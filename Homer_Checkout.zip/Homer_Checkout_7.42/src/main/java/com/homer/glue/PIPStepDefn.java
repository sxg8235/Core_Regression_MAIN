package com.homer.glue;

import java.util.Iterator;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.homer.dao.And;
import com.homer.dao.CommonData;
import com.homer.dao.CommonDataColumn;
import com.homer.dao.DataClass;
import com.homer.dao.DataColumn;
import com.homer.dao.Given;
import com.homer.dao.Then;
import com.homer.dao.When;
import com.homer.enums.EnumClass.StepResult;

public class PIPStepDefn extends BaseStepDefn {

	public PIPStepDefn(DataClass data) {
		super(data);
	}

	@Then("^I see PIP page displayed$")
	public void i_see_PIP_page_displayed() throws Throwable {

		pipPage.verifyPIPPage();
	}

	@Then("^I see PIP page for SKU displayed$")
	public void i_see_PIP_page_for_SKU_displayed() throws Throwable {

		pipPage.verifyPIPForSKU();
	}

	@And("^I click checkout now$")
	public void i_click_checkout_now() throws Throwable {
		atcOverlay.clickCheckoutNow();
	}

	@When("^I click on AddToCart in PIP page$")
	public void i_click_on_AddToCart_in_PIP_page() throws Throwable {

		atcOverlay = pipPage.clickAddToCartButton();

	}

	@And("^I add item to cart$")
	public void i_add_item_to_cart() throws Throwable {
		shoppingCartPage = pipPage.clickAddToCart();
	}

	@When("^I add \"(.*?)\" item to cart$")
	public void i_add_arg1_item_to_cart(String arg1) throws Throwable {
		String skuType = arg1;
		if (skuType.equalsIgnoreCase("bodfs")) {
			pipPage.clickTabletScheduleDeliveryRadioButton();
			pipPage.enterZipCodeTabletBODFSItem();
			pipPage.getExpressDeliveryCharge();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("sth")) {
			pipPage.clickShipToHomeRadioButton();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("bodfs_only")) {
			pipPage.verifyPIPpageforBODFSOnlyItem();
			pipPage.enterZipCodeTabletBODFSItem();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("boss")) {
			pipPage.clickShipToStoreRadio();
			pipPage.CapturePipPageInfo();
			pipPage.CaptureStoreInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("bopis")) {
			pipPage.clickPickupInStoreRadio();
			pipPage.CapturePipPageInfo();
			pipPage.CaptureStoreInfo();
			atcOverlay = pipPage.clickAddToCartButton();
		} else if (skuType.equalsIgnoreCase("bss")) {
			homePage = homePage.localiseJumpUrl();
			pipPage = homePage.searchSkuNo(dataTable.getData(DataColumn.SKU));
			// For status 100,200 and 300,400 with onhand>0 bopis FM
			if (pipPage.verifyExpectedFulfilment("bopis")) {
				pipPage = pipPage.clickPickupInStoreRadio();
				wh.waitForPageLoaded();
			}
			// For Status 300,400,500 with onhand =0 FM
			else if (pipPage.verifyExpectedFulfilment("boss")) {
				pipPage = pipPage.clickShipToStoreRadio();
				wh.waitForPageLoaded();
			}
			// For Status 500 with onhand >0 STH only so no fulfilment selection
			atcOverlay = pipPage.clickAddToCartButton();

		}else if (skuType.equalsIgnoreCase("appliance")) {
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();
			atcOverlay.verifyProductImageInATCOverlay();
			atcOverlay.verifyTotalPriceInATCOverlay();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			// we get the qty from Parts and service overlay to validate the same in cart page.
			applianceOverlay.verifyQty();
			shoppingCartPage = applianceOverlay.selectPartsAndServices(true);
		}

		else if (skuType.equalsIgnoreCase("AppliancehookupNO")) {
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();
			atcOverlay.verifyProductImageInATCOverlay();
			atcOverlay.verifyTotalPriceInATCOverlay();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			// we get the qty from Parts and service overlay to validate the same in cart page.
			applianceOverlay.verifyQty();
			shoppingCartPage = applianceOverlay.selectPartsAndServices(false);
		}

	}

	@And("^I open a new tab in browser$")
	public void i_open_a_new_tab_in_browser() throws Throwable {
		pipPage.openNewTabAndLaunch();
	}

	@And("^I check for no radio button in PIP page for \"(.*?)\" item$")
	public void i_check_for_no_radio_button_in_PIP_page_for_arg1_item(String arg1) throws Throwable {
		String skuType = arg1;
		if (skuType.equalsIgnoreCase("sth")) {
			pipPage.verifyNoRadioButtonSTHPIP();
		} else if (skuType.equalsIgnoreCase("sth")) {
			pipPage.verifyNoRadioButtonBOPISPIP();
		}
	}

	@And("^I click Add to List from PIP$")
	public void i_click_Add_to_List_from_PIP() throws Throwable {
		myListOverlay = pipPage.clickAddToListButton();
	}

	@And("^I Add product to list$")
	public void i_Add_product_to_list() throws Throwable {
		myListOverlay.addProdToListPIP();
	}

	@Then("^I verify PIP page for BODFS and STH option$")
	public void i_verify_PIP_page_for_BODFS_and_STH_option() throws Throwable {
		pipPage.verifyPIPPage();
		pipPage.verifyPIPpageforBODFS_STHItem();
	}

	@And("^I select parts and services in overlay$")
	public void i_select_parts_and_services_in_overlay() throws Throwable {
		shoppingCartPage = applianceOverlay.selectPartsAndServices(true);
	}

	@And("^I click on ShipToStore radio button$")
	public void i_click_on_ShipToStore_radio_button() throws Throwable {
		pipPage.clickShipToStoreRadio();

	}

	@And("^I click on PickUpInStore radio button$")
	public void i_click_on_PickUpInStore_radio_button() throws Throwable {
		pipPage.clickPickupInStoreRadio();
	}

	@And("^I verify certona section in PIP$")
	public void i_verify_certona_section_in_PIP() throws Throwable {
		pipPage.verifyCertonaSectionPIP();
	}

	@And("^I click Add to cart from PIP certona$")
	public void i_click_Add_to_cart_from_PIP_certona() throws Throwable {
		pipPage.clickAddtoCartCertonaPIP();
	}

	@Then("^I see special buy of the day page$")
	public void i_see_special_buy_of_the_day_page() throws Throwable {
		pipPage.verifySbotdPage();
	}

	@And("^I click Add to cart from sbotd page$")
	public void i_click_Add_to_cart_from_sbotd_page() throws Throwable {
		pipPage.clickAddtoCartSBOTD();
	}

	@And("^I see the PIP price equivalent to the price in Cassandra DB$")
	public void i_see_the_PIP_price_equivalent_to_the_price_in_Cassandra_DB() throws Throwable {
		pipPage.verifyPriceDisplayed(commonData.sku);
	}

	@And("^I check store price in Cassandra DB$")
	public void i_check_store_price_in_Cassandra_DB() throws Throwable {

		String sku = commonData.sku;
		String unitPrice1 = "";

		if (checkoutConfig.readPriceFromCassandra) {

			unitPrice1 = database.getPriceFromCassandraRefAPP(sku, "");
			// String unitPrice1 = cassandraDB.getStorePriceCassandraDB(sku);

		} else {
			if (checkoutConfig.readFromPricingAPI) {
				unitPrice1 = database.getUnitPriceFromPricingService(sku, "");
			}
			report.addReportStep("Read From Cassndra", "Read From cassandra feature switch is off", StepResult.DONE);
		}

		if (!unitPrice1.equals("")) {
			commonData.priceRead = true;
		}
	}

	@And("^I select different store and add to cart$")
	public void i_select_different_store_and_add_to_cart() throws Throwable {
		pipPage.changeShipToStorePIP();
	}

	// *******************hddpp*********************************
	@When("^I add \"(.*?)\" item to mixed cart$")
	public void i_add_arg1_item_to_mixed_cart(String arg1) throws Throwable {
		String skuType = arg1;
		if (skuType.equalsIgnoreCase("bodfs")) {
			pipPage.clickTabletScheduleDeliveryRadioButton();
			pipPage.enterZipCodeTabletBODFSItem();
			pipPage.getExpressDeliveryCharge();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("sth")) {
			pipPage.clickShipToHomeRadioButton();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("bodfs_only")) {
			pipPage.verifyPIPpageforBODFSOnlyItem();
			pipPage.enterZipCodeTabletBODFSItem();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("boss")) {
			pipPage.clickShipToStoreRadio();
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();

		} else if (skuType.equalsIgnoreCase("appliance")) {
			pipPage.CapturePipPageInfo();
			atcOverlay = pipPage.clickAddToCartButton();
			// overlays.verifyProductImageInATCOverlay();
			// overlays.verifyTotalPriceInATCOverlay();
			applianceOverlay = applianceOverlay.enterZipCodeCheckAvailability();
			shoppingCartPage = applianceOverlay.selectPartsAndServices(true);
		}

	}

	@When("^I Increase the quantity$")
	public void i_Increase_the_qty() throws Throwable {
		pipPage.increaseItemQtypipPage();
	}

	// And I add the plan in PIP
	@When("^I add the plan in PIP$")
	public void i_add_the_plan_in_PIP() throws Throwable {
		pipPage.addPlanPIP();
	}

	@When("^I remove the plan in PIP after adding it$")
	public void I_remove_the_plan_in_PIP_after_adding_it() throws Throwable {
		pipPage.removePlanPIP();
	}

	@When("^I click AddToCart in PIP page$")
	public void i_click_AddToCart_in_PIP_page() throws Throwable {

		atcOverlay = pipPage.clickAddToCartbtn();
	}

	@And("^I enter quanity in PIP page$")
	public void i_enter_quanity_in_PIP_page() throws Throwable {
		pipPage.enterQuantityInPIP();
	}

	@And("^I click on PickUpInStore radio button for zero in stock item$")
	public void i_click_on_PickUpInStore_radio_button_for_zero_in_stock_item() throws Throwable {
		pipPage.clickPickupInStoreRadio_NoInvCheck();
	}
	
	@And("^I click on Change PickUp In Store Link$")
	public void i_click_on_change_pickup_in_store_link() throws Exception
	{
		pipPage.clickChangePickUpInStoreInPIP();
	}

	@When("^I select different pickup store and add to cart$")
	public void i_select_different_pickup_store_and_add_to_cart() throws Throwable {
		pipPage.changePickupStoreAddToCart();
		atcOverlay.clickCheckoutNow();
	}

	@And("^I verify restricted state msg in PIP$")
	public void I_verify_restricted_state_msg_in_PIP() throws Throwable {
		pipPage.verifyRestrictedStateMsgPIP();
	}

	@And("^I check for zero in stock BODFS error msg in PIP$")
	public void i_check_for_zero_in_stock_BODFS_error_msg_in_PIP() throws Throwable {
		pipPage.verifyZeroInStockBODFSPIP();
	}

	@When("^I add Blind item to cart using jumpurl$")
	public void i_add_item_to_cart_using_jumpurl() throws Exception {
		pipPage.addBlindsItemThroURL();
	}
	
	@And("^I verify Bopis Shared fullfillment in PIP Page$")
	public void i_verify_bopis_shared_fullfillment_in_pip_page() throws Exception {
		pipPage.verifyPIPpageforBOPIS_STHItem();
	}
	
	@And("^I verify Boss Shared fullfillment in PIP Page")
	public void i_verify_boss_shared_fullfillment_in_pip_page() throws Exception
	{
		pipPage.verifyPIPpageforBOSS_STHItem();
	}
	
	@And("^I click Ship to store link in PIP page$")
	public void i_click_ship_to_store_link_in_pip_page() throws Exception
	{
		pipPage.clickShipToAnotherStoreLink();
	}

	@And("^I verify Estimated Arrival for STH item in PIP")
	public void i_verify_estimated_arrival_for_sth_item_in_pip() throws Throwable {
		pipPage.verifyETAMsgForSTHInPIP();
	}

	@And("^I verify Free text message for Ship to home and pick up in store labels in PIP$")
	public void i_verify_Free_text_message_for_Ship_to_home_and_pick_up_in_store_labels_in_PIP() throws Exception {
		pipPage.verifyFreeTextMsgForSharedBOPIS();
	}
	
	@And("^I verify default STH Fullfillment$")
	public void i_verify_default_sth_fullfillment() throws Exception
	{
		pipPage.verifyDefaultSTHBtnSelected();
	}
	
	@And("^I change zipcode and verify error msg for appliance$")
	public void i_change_zipcode_and_verify_error_msg_for_appliance() throws Exception
	{
		pipPage.changeZipcodeAndVerifyErr();
	}
	
	@And("^I verify shipping Option link in PIP$")
	public void i_verify_shipping_Option_link_in_PIP() throws Exception
	{
		pipPage.verifyShippingOptLink();
	}
	
	@And("^I verify quantity field is present$")
	public void i_verify_quantity_field_is_present() throws Throwable
	{
		pipPage.verifyQtyboxFieldPresent();
	}
	
	@And("^I verify Add to My list is displayed$")
	public void i_verify_add_to_list_is_displayed() throws Exception
	{
		pipPage.verifyAddToMyList();
	}
	
	@Then("^I verify Out of stock online messge is displayed$")
	public void i_verify_out_of_stock_online_message_is_displayed() throws Exception
	{
		pipPage.verifyOutOfStock();
	}

	

	// **********Instant Rebate**********************//

	@When("^I change the pick up store and add to cart$")
	public void i_change_the_pickup_store_and_add_to_cart() throws Throwable {
		pipPage.changePickupStoreAddToCart();
	}

	@And("^I check price and store promotion in PIP$")
	public void i_check_price_and_store_promotion_in_PIP() throws Throwable {
		{

			String sku = commonData.sku;
			System.out.println(sku);
			String store = dataTable.getData("LocalizeStore");
			database.getUnitPriceFromPricingService(sku, store);
			commonData.IRList.add(commonData.shortdesc);
			commonData.PriceList.add(commonData.unitPriceDB);
			commonData.StoreList.add(store);
			
	
		}
	}

	@When("^I change the ship to store and add to cart$")
	public void i_change_the_ship_to_store_and_add_to_cart() throws Throwable {
		pipPage.changeShipToStoreAddToCart();

	}
	
	@Then("^I verify Error message if we add more than two LA")
	public void i_verify_error_message_if_we_add_more_than_two_LA() throws InterruptedException
	{
		pipPage.verifyErrorMoreTwoAppliance();
	}

	// **********End of Instant Rebate**********//

	@And("^I click paypal button in PIP$")
	public void i_click_paypal_button_in_PIP() throws Throwable {
		pipPage.clickPaypalButton();
	}
	
	@And("^I verify delivery unavailable msg for BODFS$")
	public void i_verify_delivery_unavailable_msg_for_BODFS() throws Throwable {
		pipPage.verifyDeliveryUnavailableForBODFS();
	}

	@And("^I verify recently viewed section$")
	public void i_verify_recently_viewed_section() throws Throwable {
		pipPage.verifyRVSection();
	}
	
	@And("^I click product decription of RV section item$")
	public void i_click_product_decription_of_RV_section_item() throws Throwable {
		pipPage.clickProdInRVSection();
	}

	@And("^I verify IRG section$")
	public void i_verify_IRG_section() throws Throwable {
		pipPage.verifyIRGSection();
	}
	
	@And("^I click checkout in IRG multi ATC overlay$")
	public void i_click_checkout_in_IRG_multi_ATC_overlay() throws Throwable {
		pipPage.clickCheckoutInMultiATC();
	}
	
	@And("^I verify delivery price retained$")
	public void i_verify_delivery_price_retained() throws Throwable {
		pipPage.clickTabletScheduleDeliveryRadioButton();
		pipPage.verifyPriceRetained();
	}
	
	@And("^I verify clarification msg in Change store overlay$")
	public void i_verify_clarification_msg_in_Change_store_overlay() throws Throwable {
		pipPage.verifyClarificationMsginBOPISoverlay();
	}
	
	@And("^I verify bopis overlay contents$")
	public void i_verify_bopis_overlay_contents() throws Exception
	{
		pipPage.verifyBopisOverlayContents();
	}
	
	@When("^I add Blind item to config page$")
    public void i_add_item_to_config_page() throws Exception {
           pipPage.addBlinds();
    }
}
