package com.homer.glue;

import com.homer.dao.And;
import com.homer.dao.DataClass;
import com.homer.dao.Then;

public class BSSOverlayStepDefn extends BaseStepDefn {

	public BSSOverlayStepDefn(DataClass data) {
		super(data);
		// TODO Auto-generated constructor stub
	}
	
	@And("^I verify BSS overlay for Boss$")
	public void i_verify_BSS_overlay_for_boss() throws Exception
	{
		bssOverlay.verifyBSSOverlayForBoss();
	}
	
	@And("^I verify BSS overlay for Bopis$")
	public void i_verify_BSS_overlay_for_bopis() throws Exception
	{
		bssOverlay.verifyBSSOverlayForBOPIS();
	}
	
	@Then("^I verify BSS overlay text message for Bopis click ADDCART$")
	public void i_verify_BSS_overlay_text_message_for_bopis_click_ADDCART() throws Exception
	{
		bssOverlay.verifyBopisSmartOverlay();
	}
	

}
